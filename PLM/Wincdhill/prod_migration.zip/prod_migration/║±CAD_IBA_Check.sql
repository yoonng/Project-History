
======= ��CAD�� IBA check

select * from epmdocumentmaster m, epmdocument d
where m.documentnumber like '07857%_B.CATDRAWING'
and d.ida3masterreference = m.ida2a2


select d.displayname, v.value 
from stringvalue v, stringdefinition d
where v.ida3a6 = d.ida2a2
and v.ida3a4 in ( 
    select d.ida2a2 
    from epmdocumentmaster m, epmdocument d
    --where m.documentnumber like '07857%_B.CATDRAWING'
    where m.documentnumber like '%_B.CATDRAWING'
    and d.ida3masterreference = m.ida2a2
)

------------
CAD ��-����
REF PART NO
OUT EO
------------
select distinct d.displayname
from stringvalue v, stringdefinition d
where v.ida3a6 = d.ida2a2
and v.ida3a4 in ( 
    select d.ida2a2 
    from epmdocumentmaster m, epmdocument d
    --where m.documentnumber like '07857%_B.CATDRAWING'
    where m.documentnumber like '%_B.CATDRAWING'
    and d.ida3masterreference = m.ida2a2
)

================================================
================================================


select * from epmbuildrule
where branchida3a5 in ( 
  select branchiditerationinfo from epmdocument d, epmdocumentmaster m
  where d.ida3masterreference = m.ida2a2
  and m.name = '3SUPGA00000E'
)


select m.name 
from epmdocumentmaster m 
where m.name like '__UPG%'


select t.upgs, count(*) from (
  select substr(m.name, 0, 5) upgs 
  from epmdocumentmaster m 
  where m.name like '__UPG%' 
) t
group by t.upgs


  select substr(m.name, 0, 5) upgs 
  from epmdocumentmaster m , epmdocument d, epmbuildrule r
  where m.name like '__UPG%' 
  and m.ida2a2 = d.ida3masterreference 
  and d.branchiditerationinfo = branchida3a5

select substr(t.upgs, 0, 5), count(*) from (
  select distinct m.name upgs 
  from epmdocumentmaster m , epmdocument d, epmbuildrule r
  where m.name like '__UPG%' 
  and m.ida2a2 = d.ida3masterreference 
  and d.branchiditerationinfo = branchida3a5
) t
group by substr(t.upgs, 0, 5)


