update hkmccadtitle set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select createdate, substr(createdate, 0, 4), substr(createdate, 6,2), substr( createdate, 9,2) from hkmccadtitle 

select * from hkmccadtitle 

select batch_id, migrated, count(*) from hkmccadtitle group by batch_id, migrated

--update hkmccadtitle set migrated = 0 where migrated = 1
=======

update hkmccadrevisionreason set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmccadrevisionreason where subrev like '%)%'

select batch_id, migrated, count(*) from hkmccadrevisionreason group by batch_id, migrated

======

update hkmccadsafetycls set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
updatedate = substr(updatedate, 0, 4) || substr(updatedate, 6,2) || substr( updatedate, 9,2)

select * from hkmccadsafetycls where subrev like '%)%'

select batch_id, migrated, count(*) from hkmccadsafetycls group by batch_id, migrated
======

update hkmccadnote set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
updatedate = substr(updatedate, 0, 4) || substr(updatedate, 6,2) || substr( updatedate, 9,2)

select * from hkmccadnote where subrev like '%)%'

update hkmccadnote set migrated = 0 where migrated = 2

select batch_id, migrated, count(*) from hkmccadnote group by batch_id, migrated

======

update hkmccadweld set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
updatedate = substr(updatedate, 0, 4) || substr(updatedate, 6,2) || substr( updatedate, 9,2)

select * from hkmccadweld where subrev like '%)%'

select batch_id, migrated, count(*) from hkmccadweld group by batch_id, migrated
======

update hkmccadesmsspec set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmccadesmsspec where subrev like '%)%'

select batch_id, migrated, count(*) from hkmccadesmsspec group by batch_id, migrated

======

update itemnolink set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from itemnolink where subrev like '%)%'


insert into itemnolink
select * from itemnolink_assy

select * from consentedpartlink

select batch_id, migrated, count(*) from itemnolink group by batch_id, migrated

======
update consentedpartlink set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from consentedpartlink

select batch_id, migrated, count(*) from consentedpartlink group by batch_id, migrated

======

update cadvendorpartlink set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from cadvendorpartlink where subrev like '%)%'

select batch_id, migrated, count(*) from cadvendorpartlink group by batch_id, migrated
======

update esmsvendorpartlink set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from cadvendorpartlink where subrev like '%)%'

select batch_id, migrated, count(*) from esmsspecvendorpart group by batch_id, migrated
======

update hkmccadecdfiles set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmccadecdfiles where subrev like '%)%'

select batch_id, migrated, count(*) from hkmccadecdfiles group by batch_id, migrated
======

hkmcstdnote

hkmcstdnotemaster

select batch_id, migrated, count(*) from hkmcstdnote group by batch_id, migrated
======


select batch_id, migrated, count(*) from hkmcassupplymanual group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcassupplymanual group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcnoncad group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcnoncadlend group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcstandardpartname group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcstandardword group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcstdpartnamereq group by batch_id, migrated
======

select batch_id, migrated, count(*) from hkmcstdpartnamereqdet group by batch_id, migrated
======

update hkmcaltsel set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmcaltsel where batch_id = 1

update hkmcaltsel set migrated = 0  where migrated = 2

select batch_id, migrated, count(*) from hkmcaltsel group by batch_id, migrated

======

update hkmckdpart set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmckdpart where batch_id = 1

update hkmckdpart set migrated = 0 

select batch_id, migrated, count(*) from hkmckdpart group by batch_id, migrated

======

update hkmcshownon set createdate = substr(createdate, 0, 4) || substr(createdate, 6,2) || substr( createdate, 9,2),
modifydate = substr(modifydate, 0, 4) || substr(modifydate, 6,2) || substr( modifydate, 9,2)

select * from hkmcshownon where batch_id = 1

update hkmcshownon set migrated = 0 

select batch_id, migrated, count(*) from hkmcshownon group by batch_id, migrated

======

delete hkmccdnote
select * from hkmccadnote where batch_id = '1'
select * from hkmccadnotewbmstatus
select migrated, count(*) from hkmccadnote group by migrated
select loadstatus, count(*) from hkmccadnotewbmstatus group by loadstatus

update hkmccadnote set migrated = 0 where migrated = 2
update hkmccadnotewbmstatus set loadstatus = '' where loadstatus is not null


select batch_id, migrated, count(*) from hkmcstandardpartname group by batch_id, migrated
select batch_id, migrated, count(*) from hkmcstandardword group by batch_id, migrated
select batch_id, migrated, count(*) from hkmcstdpartnamereq group by batch_id, migrated
select batch_id, migrated, count(*) from hkmcstdpartnamereqdet group by batch_id, migrated

select batch_id, migrated, count(*) from hkmccadnote group by batch_id, migrated

select loadstatus, count(*) from hkmcnoncadlendwbmstatus group by loadstatus

select objectnumber, sheet, revision, seq, count(*) from hkmcnoncadlend  group by objectnumber, sheet, revision, seq  having count(*) > 1
select batch_id, migrated, count(*) from hkmcnoncadlend group by batch_id, migrated

select migrated, count(*) from hkmcmicrofilm group by migrated
select migrated, count(*) from hkmcnoncad group by migrated

select migrated, count(*) from hkmcshownon group by migrated
select partnumber2, objectnumber, count(*) from hkmcshownon group by partnumber2, objectnumber having count(*) > 1
select * from hkmcshownon

select objectnumber from upgvc
minus
select wtpartnumber from wtpartmaster@plmprd.plmdbadmin


select migrated, count(*) from upg group by migrated
0	272319

1	272319    2011-0926

select migrated, count(*) from upgvc group by migrated
1	2428740
0	2985044
2	13857 

1	5414162    2011-0926
2	13479

select migrated, count(*) from hkmcpart group by migrated
1	2527958  9/14
0	13433721
2	163419

1	16124552    2011-0926
2	546


select migrated, count(*) from wtpartusagelink group by migrated
1	6501555    2011-0926 08:09
0	67898824
2	164726

select migrated, count(*) from wtdatedeffectivity group by migrated
1	249578    2011-0926 08:09
2	7946
0	21567534




select * from hkmcpart a, xxebom_odetxttb_bs@legacydb b
where a.objectnumber = b.od05_desc_c
and a.eono = b.od05_eono_c

select count(*) from hkmcaltsel

insert into rm3_partlatestversion
select m.wtpartnumber, max(v.versionida2versioninfo)
from wtpartmaster@plmprd.plmdbadmin m , wtpart@plmprd.plmdbadmin v
where v.ida3masterreference = m.ida2a2
group by m.wtpartnumber


===============

  insert into hkmcnoncadlend_ootb
  select * from hkmcnoncadlend@plmprd.plmdbadmin
  
  
  update hkmcshownon set migrated = 0 where migrated = 2
  
  select * from hmcccodetype where ida2a2 = 102313
  
================
check hkmcmicrofilm -- 631557

drawingsize is null -- 226819

projectcode is null -- 306912
��ü - projectcode null = --324645



==== db temp space check

select * from dba_data_files where tablespace_name = 'TEMP1'

select * from temp_data_files where tablespace_name = 'TEMP1'
