
select m.name, m.documentnumber, d.versionida2versioninfo, d.iterationida2iterationinfo, a.*
from holdertocontent h, applicationdata a, epmdocument d, epmdocumentmaster m
where h.ida3b5 = a.ida2a2
and h.ida3a5 = d.ida2a2
and d.ida3masterreference = m.ida2a2
;

select * from holdertocontent
;


select * from stampingdrawinglink
where branchida3b5 in (
325298978,
325306010,
325306072
)
;


select branchida3b5, count(*) from stampingdrawinglink 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
group by branchida3b5 having count(*) > 1
;


select * from stampingdrawinglink where branchida3b5 = 332612299
;

select * from HKMCCADRevisionReason
where ida2a2 in ( 
2098784220,
2227184221,
2227184223,
2227184225
)
;


select branchida3b5, count(*) from stampingdrawinglink 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
group by branchida3b5 having count(*) > 1
;

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// HKMCCADRevisionReason�� �ߺ��߻�
// OID�� ������ �ʿ���.

-- �����Ұ� 2442
select sum( count(*) )  -- 4362
from stampingdrawinglink l, HKMCCADRevisionReason r
where l.ida3a5 = r.ida2a2 --and l.branchida3b5 = d.branchiditerationinfo-- and d.ida3masterreference = m.ida2a2

having count(*) > 1
;

 delete hkmccadrevisionreason where ida2a2 = 2226580784; delete stampingdrawinglink where branchida3b5 = 1503520961 and ida3a5 = 2226580784 ; 

-- 1920 �ߺ�
select branchida3b5, r.isdetail, r.seq, r.subrev, max(r.ida2a2), count(*)
from stampingdrawinglink l, HKMCCADRevisionReason r
where l.ida3a5 = r.ida2a2 --and l.branchida3b5 = d.branchiditerationinfo-- and d.ida3masterreference = m.ida2a2
group by branchida3b5, r.isdetail, r.seq, r.subrev
having count(*) > 1
;

select m.documentnumber, m.name, d.versionida2versioninfo, d.iterationida2iterationinfo, dupr.*
from epmdocument d, epmdocumentmaster m, ( 
    select branchida3b5, r.isdetail, r.seq, r.subrev, count(*)
    from stampingdrawinglink l, HKMCCADRevisionReason r 
    where l.ida3a5 = r.ida2a2  --and l.branchida3b5 = d.branchiditerationinfo and d.ida3masterreference = m.ida2a2
    group by branchida3b5, r.isdetail, r.seq, r.subrev
    having count(*) > 1
) dupr
where  d.branchiditerationinfo = dupr.branchida3b5
and d.ida3masterreference = m.ida2a2
order by m.documentnumber, d.versionida2versioninfo, d.iterationida2iterationinfo
;

select * from stampingdrawinglink ll, HKMCCADRevisionReason rr, ( 
    select l.branchida3b5, r.isdetail, r.seq, r.subrev, count(*)
    from stampingdrawinglink l, HKMCCADRevisionReason r 
    where l.ida3a5 = r.ida2a2  --and l.branchida3b5 = d.branchiditerationinfo and d.ida3masterreference = m.ida2a2
    group by l.branchida3b5, r.isdetail, r.seq, r.subrev
    having count(*) > 1
) dupr
where ll.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
and ll.branchida3b5 = dupr.branchida3b5 and ll.ida3a5 = rr.ida2a2
and rr.isdetail = dupr.isdetail and rr.seq = dupr.seq and rr.subrev = dupr.subrev
order by ll.branchida3b5, rr.ida2a2
;


select *
from stampingdrawinglink l, HKMCCADRevisionReason r
where l.ida3a5 = r.ida2a2 
and branchida3b5 in (
1574340380,
1580319646,
1561582829,
2020391803
)
order by branchida3b5, ida3a5, r.isdetail, r.seq, r.subrev
;
