
select * from epmmemberlink
where ida3a5  in (
    select d.ida2a2   from epmdocumentmaster m, epmdocument d
    where m.name = '3SUPGAB671BE' and
    m.ida2a2 = d.ida3masterreference 
)
order by ida3a5, ida3b5
;

select ida3masterreference from epmdocument where branchiditerationinfo  = 2305768364;
--372007639

select * from epmdocumentmaster where ida2a2 in (
    select ida3masterreference  from epmdocument where ida2a2 = 2691226848
);

select * 
  from epmmemberlink
  where ida3a5  in ( 
      select d.ida2a2 from epmdocumentmaster m, epmdocument d
      where m.name = '3SUPGBA823AE' and
      m.ida2a2 = d.ida3masterreference 
  )
  order by ida3a5, ida3b5;

update epmmemberlink  set ida3a5 = ida3a5 - ida3a5 - ida3a5 , ida3b5 = ida3b5 - ida3b5 - ida3b5  
where ida2a2 in (
  select ida2a2 --, ida3a5,  ida3a5 - ida3a5 - ida3a5 , ida3b5, ida3b5 - ida3b5 - ida3b5
  from epmmemberlink
  where ida3a5  in ( 
      select d.ida2a2 from epmdocumentmaster m, epmdocument d
      where m.name = '3SUPGBA823AE' and
      m.ida2a2 = d.ida3masterreference 
  )
  and uniquendid like 'M%'
);

-- ���� 1������ ��ǰ ã��
select distinct m.wtpartnumber  from wtpartusagelink l, wtpartmaster m
where ida3a5 in ( 
    select p.ida2a2 from wtpartmaster m, wtpart p 
    where m.wtpartnumber = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
)
and l.ida3b5 = m.ida2a2
order by m.wtpartnumber
;


-- ���� 1������ ��ǰ ã��
select distinct m.documentnumber, m.name  from epmmemberlink l, epmdocumentmaster m
where ida3a5 in ( 
    select p.ida2a2 from epmdocumentmaster m, epmdocument p 
    where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
)
and l.ida3b5 = m.ida2a2
order by m.name
;

----------------------------------------------------
-- ���� Assy ������ �ߺ��� epm �ִ��� üũ

select ida3a5, ida3b5, count(*) from epmmemberlink ml
where ml.ida3a5 in (
    select max(ida2a2) ida2a2 from epmdocument dd
    where dd.ida3masterreference in (
        select m.ida2a2 from epmmemberlink l, epmdocumentmaster m
        where l.ida3a5 in (
            select max(p.ida2a2) from epmdocumentmaster m, epmdocument p 
            where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
        ) 
        and l.ida3b5 = m.ida2a2
    ) group by dd.ida3masterreference
) group by ida3a5, ida3b5
;

select * from epmmemberlink
where ida3a5 = 2691012645
and ida3b5 = 416206280
;

--------------------------------------------------------
-- epm�� ���� ������ AMrt�� �������� ��
select mm.name, ml.ida3a5,  count(*)
from epmmemberlink ml, epmdocumentmaster mm, epmdocument pp
where ml.ida3a5 in (
    select max(ida2a2) ida2a2 from epmdocument dd
    where dd.ida3masterreference in (
        select m.ida2a2 from epmmemberlink l, epmdocumentmaster m
        where l.ida3a5 in (
            select max(p.ida2a2) from epmdocumentmaster m, epmdocument p 
            where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
        ) 
        and l.ida3b5 = m.ida2a2
    ) group by dd.ida3masterreference
) 
and pp.ida3masterreference = mm.ida2a2 and pp.ida2a2 = ml.ida3a5
group by mm.name, ml.ida3a5
order by mm.name
;

--- CAD �۾��� CSV ����


select distinct mm.name, mm.name, ppm.name, ppm.name  -- , ppm.*
from epmmemberlink ml, epmdocumentmaster mm, epmdocument pp, wtpartmaster ppm
where ml.ida3a5 in (
    select max(ida2a2) ida2a2 from epmdocument dd
    where dd.ida3masterreference in (
        select m.ida2a2 from epmmemberlink l, epmdocumentmaster m
        where l.ida3a5 in (
            select max(p.ida2a2) from epmdocumentmaster m, epmdocument p 
            where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
        ) 
        and l.ida3b5 = m.ida2a2
    ) group by dd.ida3masterreference
) 
and pp.ida3masterreference = mm.ida2a2 and pp.ida2a2 = ml.ida3a5 and mm.name = ppm.wtpartnumber
order by mm.name
;

select ida3a5, ida3b5, count(*) from wtpartusagelink ml
where ml.ida3a5 in (
    select max(ida2a2) ida2a2 from wtpart dd
    where dd.ida3masterreference in (
        select m.ida2a2 from wtpartusagelink l, wtpartmaster m
        where l.ida3a5 in (
            select max(p.ida2a2) from wtpartmaster m, wtpart p 
            where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
        ) 
        and l.ida3b5 = m.ida2a2
    ) group by dd.ida3masterreference
) group by ida3a5, ida3b5
;

select distinct mm.wtpartnumber from wtpartmaster mm, wtpart pp
where pp.ida2a2 in (
    select ida3a5 from wtpartusagelink ml
    where ml.ida3a5 in (
        select max(ida2a2) ida2a2 from wtpart dd
        where dd.ida3masterreference in (
            select m.ida2a2 from wtpartusagelink l, wtpartmaster m
            where l.ida3a5 in (
                select max(p.ida2a2) from wtpartmaster m, wtpart p 
                where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
            ) 
            and l.ida3b5 = m.ida2a2
        ) group by dd.ida3masterreference
    ) group by ida3a5, ida3b5
    having count(*) > 1
)
and pp.ida3masterreference = mm.ida2a2
;

select * from wtpartusagelink 

            select m.* from wtpartmaster m, wtpart p 
            where p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1 
            and p.ida2a2 = 2235082482
            ;
-------------------------------------
-- last�� CadNameKo ����
update stringvalue set ida3a4 = ida3a4 - ida3a4 - ida3a4
where ida2a2 in (
      select distinct v.ida2a2
      from stringvalue v, stringdefinition d
      where ida3a4 in (
          select max(ida2a2) ida2a2 from epmdocument dd
          where dd.ida3masterreference in (
              select m.ida2a2 from epmmemberlink l, epmdocumentmaster m
              where l.ida3a5 in (
                  select max(p.ida2a2) from epmdocumentmaster m, epmdocument p 
                  where m.name = 'AM' and p.ida3masterreference = m.ida2a2 and p.latestiterationinfo = 1
              ) 
              and l.ida3b5 = m.ida2a2
          ) group by dd.ida3masterreference
      )
      and d.name = 'CadNameKo'
      and v.ida3a6 = d.ida2a2
);

