
== s,c �ΰ��̰�, null �ΰ��϶�, HKMCPART�� ���ؼ��� update

select ptc_str_29TYPEINFOWTPART, ptc_str_12TYPEINFOWTPART from wtpart
where ptc_str_29TYPEINFOWTPART in ( 'S', 'C' ) 
and ptc_str_12TYPEINFOWTPART is null


select ptc_str_29TYPEINFOWTPART, ptc_str_12TYPEINFOWTPART from wtpart
-- update wtpart set ptc_str_12TYPEINFOWTPART = ptc_str_29TYPEINFOWTPART , ptc_str_29TYPEINFOWTPART = ''
where ptc_str_29TYPEINFOWTPART in ( 'S', 'C' ) 
and ptc_str_12TYPEINFOWTPART is null;
commit;




select  ptc_str_29TYPEINFOWTPART , count(*) from wtpart group by ptc_str_29TYPEINFOWTPART

	21350282
V	98
'	6
1	3
*	48
R	288784
H	1
U	80
3	6
EA	42
P	4
6	6
EB	12
I	11
D	277
0	13
A	94373
C	346536
B	194
5	1
9	2
S	2088148
E	117002
`	3
2	2
--'=====================================

select ptc_str_12TYPEINFOWTPART , count(*) from wtpart 
group by ptc_str_12TYPEINFOWTPART
order by count(*) desc

	18063397
5	5737704
RB	79177
CC	75139
RC	26057
RA	13513
2	1437
CB	1127
 U 	 578

update wtpart set 


select ptc_str_12TYPEINFOWTPART , ptc_str_2TYPEINFOWTPART from wtpart 
where ptc_str_12TYPEINFOWTPART  = 'PLM01'