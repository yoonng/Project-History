
--==============================
--== Alt Sel role ����

1. �Data ��   table_name_1102�� ����

select ida3a5 roleA, ida3b5 roleB from configurabledescribelink
select d.logicalidentifier from wttypedefinition d where d.ida2a2 = l.ida2typedefinitionreference

select * from configurabledescribelink
--  select ida3a5 roleA, ida3b5 roleB, ida2typedefinitionreference, d.logicalidentifier  from configurabledescribelink l, wttypedefinition d
where ida2typedefinitionreference in ( '1864471328', '2167959614')  and d.ida2a2 = l.ida2typedefinitionreference
order by ida3a5, ida3b5, ida2typedefinitionreference;

select * from stringvalue
where ida3a4 in (  -- 61996
    select ida2a2 from configurabledescribelink
    --  select ida3a5 roleA, ida3b5 roleB, ida2typedefinitionreference  from configurabledescribelink
    where ida2typedefinitionreference in ( '1864471328', '2167959614') 
    --order by ida3a5, ida3b5, ida2typedefinitionreference
);


select a.ida3a5 roleA, a.ida3b5 roleB, a.ida2typedefinitionreference, a.ida2a2, b.value
from configurabledescribelink a, stringvalue b
where a.ida2typedefinitionreference in ( '1864471328', '2167959614') 
and b.ida3a4(+) = a.ida2a2
order by a.ida3a5, a.ida3b5, a.ida2typedefinitionreference

-- string value�� null �ΰ��� ���� -- �ߺ��Ǿ�����

--  delete configurabledescribelink  where ida2a2 in ( 
  select a.ida2a2  -- 
  a.ida3a5 roleA, a.ida3b5 roleB, a.ida2typedefinitionreference, a.ida2a2, b.value, a.*
  from configurabledescribelink a, stringvalue b
  where a.ida2typedefinitionreference in ( '1864471328', '2167959614', '2116099132') 
  and b.ida3a4(+) = a.ida2a2
  and b.ida2a2 is null 
)

-- update configurabledescribelink set ida3a5 = ida3b5 , ida3b5 = ida3a5
-- select * from configurabledescribelink
where ida2typedefinitionreference in ( '1864471328', '2167959614') 


select ida3a5, ida3b5, count(*)  from configurabledescribelink
where ida2typedefinitionreference in ( '1864471328', '2167959614') group by ida3a5, ida3b5 
having count(*) > 1


1864471324	1864471328	33197	kr.co.hkmc.AltSelLink
50589	2167959607	2518	kr.co.hkmc.ShownOnPartLink
50589	1864471305	3211409	kr.co.hkmc.ShownOnPartLink
1864471324	2167959614	28799	kr.co.hkmc.AltSelLink

===============================
-- ���� ��ũ�� �� ���� Ȯ��

select am.wtpartnumber, a.versionida2versioninfo , bm.wtpartnumber , b.versionida2versioninfo
from configurabledescribelink l, wtpart a, wtpartmaster am, wtpart b, wtpartmaster bm
where l.ida2typedefinitionreference in ( '1864471328', '2167959614') 
and l.ida3a5 = a.ida2a2
and a.ida3masterreference = am.ida2a2
and l.ida3b5 = b.ida2a2
and b.ida3masterreference = bm.ida2a2
order by am.wtpartnumber, bm.wtpartnumber 

select am.wtpartnumber, bm.wtpartnumber , count(*)
from configurabledescribelink l, wtpart a, wtpartmaster am, wtpart b, wtpartmaster bm
where l.ida2typedefinitionreference in ( '1864471328', '2167959614') 
and l.ida3a5 = a.ida2a2
and a.ida3masterreference = am.ida2a2
and l.ida3b5 = b.ida2a2
and b.ida3masterreference = bm.ida2a2 
group by am.wtpartnumber, bm.wtpartnumber
having count(*) > 1

select batch_id, migrated, count(*) from hkmcaltsel group by batch_id, migrated

select count(*) from stringvalue;

===============================

select batch_id, migrated, count(*) from hkmcaltsel group by batch_id, migrated 
1	1	1
3	2	371
5	1	30185

���� config altsel ��ũ�� 30177   ??????????? ���̴� ����???
8�� 
stringvalue �� 30186 <<== �̰����� Ȯ��.(�ߺ��Ȱ��� �߰��Ǿ���)

�ߺ��Ȱ� üũ
select partnumber2, objectnumber, count(*) from hkmcaltsel group by partnumber2, objectnumber





select * from hkmcaltsel

update hkmcaltsel set migrated = 0 where migrated = 2

update hkmcaltsel set migrated = 0 where migrated = 1 and batch_id = 3

update hkmcaltsel set batch_id = 5 where migrated = 1 and batch_id = 3

update hkmcaltsel set migrated = 0 where migrated = 2 and batch_id = 3

24412
 5776
= 30188

28���� �ߺ�
��ü 30557
-- ���������� 352
-- 30205
-- 5792
select * from hkmcaltsel a, wtpartmaster@plmprd.plmdbadmin b, wtpartmaster@plmprd.plmdbadmin c
where a.objectnumber = b.wtpartnumber
and a.partnumber2 = c.wtpartnumber




select * from cadneutral 

select batch_id, migrated, count(*) from cadneutral group by batch_id, migrated


================

�ߺ��Ȱ� üũ
select partnumber2, objectnumber, count(*) from hkmcaltsel group by partnumber2, objectnumber
having count(*) > 1

2231133010	2231133000	2
5351543008	5351543000	2
251002A010	251002A000	2
5351543003	5351543000	2
5351543004	5351543000	2
5351543006	5351543000	2
861112G740	861112G240	2
4517136190	4517136195	2
5210044510	5210044500	2
2341124120	2341124110	2
5270144510	5270144500	2
5270144520	5270144500	2
52910FD701	52910FD601	2
5311843010	5311843000	2
5351543009	5351543000	2
8868643200	8868643003	2
AAAAAAAAA	AAAAA	2
529002G910	529002G900	2
529314A850	529314A810	2
5351543007	5351543000	2
5351543010	5351543000	2
8868643102	8868643003	2
5351543005	5351543000	2
2845032210	2845032510	2
2361142110	2361142100	2
5351543001	5351543000	2
5351543002	5351543000	2
2341124100	2341124110	2




select batch_id, migrated, count(*) from CADVENDORPARTLINK group by batch_id, migrated


select batch_id, migrated, count(*) from ESMSSPECVENDORPART group by batch_id, migrated

select type, batch_id, migrated, count(*) from itemnolink group by type, batch_id, migrated



select count(*) from applicationdata
where category = 'ECD_MANUAL' 
and to_date(createstampa2, 'yy/MM/dd') = to_date('11/10/23', 'yy/MM/dd')
order by createstampa2 desc

select * from wtdocumentmaster
