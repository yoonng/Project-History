
select * from wtdocumentmaster m, wtdocument d
where d.ida3masterreference = m.ida2a2
and ida2typedefinitionreference = 46357;
-- 748

select m.wtdocumentnumber, d.iterationida2iterationinfo, h.* from wtdocumentmaster m, wtdocument d, holdertocontent h
where d.ida3masterreference = m.ida2a2
and d.ida2typedefinitionreference = 46357
and h.ida3a5 = d.ida2a2
order by  m.wtdocumentnumber, d.iterationida2iterationinfo
; -- 638


select m.wtdocumentnumber, d.iterationida2iterationinfo, h.*, a.*
from wtdocumentmaster m, wtdocument d, holdertocontent h, applicationdata a
where d.ida3masterreference = m.ida2a2
and d.ida2typedefinitionreference = 46357
and h.ida3a5 = d.ida2a2
and h.ida3b5 = a.ida2a2
order by  m.wtdocumentnumber, d.iterationida2iterationinfo
; -- 638


select * from holdertocontent