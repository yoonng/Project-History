
==== Drawing_note
-- version�� ��� 1�̹Ƿ� revision�� üũ�ϸ��.

insert into drawing_note_latest
select s_draw_no, s_sheet, nvl(s_revision, '--'), max(u_create)
from 
(
    select * from drawing_note_1003_bak
    union
    select * from drawing_note_1028
)
group by  s_draw_no, s_sheet, nvl(s_revision, '--');
commit;

==== drawrevi
-- check version
select s_draw_no, s_sheet, nvl(s_revision, '--') , min( s_version ) || '+++' || max( s_version ), count(s_version)
from 
(
  select distinct s_draw_no, s_sheet, s_revision, nvl(s_version, '--') s_version
  from (
    select * from drawrevi_1003_bak
    union
    select * from drawrevi_1028
  )
)
GROUP BY s_draw_no, s_sheet, nvl(s_revision, '--')
having count(*) > 1

insert GROUP BY s_draw_no, s_sheet, s_revision into drawing_note_latest
select s_draw_no, s_sheet, nvl(s_revision, '--'), max(u_create)
from 
(
    select * from drawrevi_1003_bak
    union
    select * from drawrevi_1028
)
group by  s_draw_no, s_sheet, nvl(s_revision, '--');
commit;


