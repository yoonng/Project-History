
---------
select batch_id, migrated, count(*) from hkmccadecdfiles group by batch_id, migrated
select migrated, count(*) from hkmccadecdfiles group by migrated
update consentedpartlink set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067

---------
select batch_id, migrated, count(*) from consentedpartlink group by batch_id, migrated
select migrated, count(*) from consentedpartlink group by migrated

update consentedpartlink set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067
select sequencenumber, count(*) from consentedpartlink group by sequencenumber having count(*) > 1
---------
select batch_id, migrated, count(*) from itemnolink group by batch_id, migrated
select migrated, count(*) from itemnolink group by migrated

update itemnolink set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067

delete itemnolink where batch_id = 3;
commit;

select * from itemnolink
select count(*) from itemnolink
select * from itemnolinkwbmstatus

delete itemnolinkwbmstatus where sequencenumber > 1889045 

select sequencenumber from itemnolink group by sequencenumber having count(*) > 1

update itemnolink set sequencenumber = rownum
update itemnolinkwbmstatus set sequencenumber = rownum, loadstatus = ''

select sequencenumber from itemnolink
where (objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--'), sequencenumber) in (
  select objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--'), max(sequencenumber)-- , count(*) 
  from itemnolink 
  group by objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--')
  having count(*) > 1
)
order by objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--')

delete tempseq

insert into tempseq
select sequencenumber from itemnolink
where (objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--'), sequencenumber) in (
  select objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--'), max(sequencenumber)-- , count(*) 
  from itemnolink 
  group by objectnumber, sheet, revision, parpartno, childpartno, nvl(prefix, '--')
  having count(*) > 1
)

delete itemnolink where sequencenumber in (
    select * from tempseq
)

---------

select batch_id, migrated, count(*) from cadneutral group by batch_id, migrated
select migrated, count(*) from cadneutral group by migrated

update cadneutral set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067

select * from cadneutral
---------
select batch_id, migrated, count(*) from hkmcvendmstr group by batch_id, migrated
select migrated, count(*) from hkmcvendmstr group by migrated

update hkmcvendmstr set sequencenumber = rownum

update hkmcvendmstrwbmstatus set sequencenumber = rownum

update hkmcvendmstr set filepath = '/ptcvault/ecd/vendmstr'

update hkmcvendmstr set projectcode = 'ETC' where projectcode = 'XX'
update hkmcvendmstr set migrated = 0 where migrated = 2  and batch_id = 3 -- 3067
update hkmcvendmstr set batch_id = 3 where batch_id <> 9 -- 3067
update hkmcvendmstr set migrated = 0 where  batch_id = 3 -- 3067

select * from hkmcvendmstr where createdate like '%/%'

---------
select batch_id, migrated, count(*) from hkmccadnote group by batch_id, migrated
select migrated, count(*) from hkmccadnote group by migrated

update hkmccadnote set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067
update hkmccadnote set batch_id = 3 where batch_id <> 9 -- 3067

select * from hkmccadnote where createdate like '%/%'

update hkmccadnote 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
modifydate = '20' || substr(modifydate, 0, 2) || substr(modifydate, 4,2) || substr( modifydate, 7,2)
where createdate like '%/%'

update hkmccadnote set batch_id = 9 where batch_id = '9-9'

select * from hkmccadnote a, (select drawno, sheet, seq, max(createdate), count(*)  from hkmccadnote group by  drawno, sheet, seq having count(*) > 1 ) b
where a.drawno = b.drawno 
and a.sheet = b.sheet
and a.seq = b.seq

update hkmccadnote set batch_id = batch_id || '-' 
where (drawno, sheet, seq) in (
    select drawno, sheet, seq from tempseq2 
) 

update hkmccadnote set batch_id = batch_id || '9' 
where (drawno, sheet, seq, createdate) in (
    select drawno, sheet, seq, createdate from tempseq2 
) 

insert into tempseq2
select drawno, sheet, seq, max(createdate) from hkmccadnote group by  drawno, sheet, seq having count(*) > 1

select * from hkmccadnote where drawno = '563001W100'

#################################################################
=============== RevisionReason

select batch_id, migrated, count(*)  from HKMCCADREVISIONREASON@PLMPRD.staging group by batch_id, migrated

select batch_id, migrated, count(*) from hkmccadrevisionreason group by batch_id, migrated
select migrated, count(*) from hkmccadrevisionreason group by migrated

update hkmccadrevisionreason set migrated = 0 where migrated in ( 1, 2 )  and batch_id = 9 -- 3067

select * from hkmccadrevisionreason  -- 287717
where batch_id = '1028'
where migrated = 0
where createdate like '%/%'

select max(sequencenumber) from hkmccadrevisionreason

select sequencenumber, count(*) from hkmccadrevisionreason group by sequencenumber having count(*) > 1

update hkmccadrevisionreason set subrev = ''  where subrev = ' '
---------
select batch_id, migrated, count(*) from hkmccadnotetable group by batch_id, migrated
select migrated, count(*) from hkmccadnotetable group by migrated

update hkmccadnotetable set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067

select * from hkmccadnotetable
---------
select batch_id, migrated, count(*) from hkmccadesmsspec group by batch_id, migrated
select migrated, count(*) from hkmccadesmsspec group by migrated

update hkmccadesmsspec set migrated = 0 where migrated = 2  and batch_id = 9 -- 3067

select * from hkmccadesmsspec where createdate like '%/%'

update hkmccadesmsspec 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
modifydate = '20' || substr(modifydate, 0, 2) || substr(modifydate, 4,2) || substr( modifydate, 7,2)
where createdate like '%/%'

select sequencenumber, count(*) from hkmccadesmsspec group by sequencenumber having count(*) > 1

---------
select batch_id, migrated, count(*) from HKMCCADSAFETYCLS group by batch_id, migrated
select migrated, count(*) from HKMCCADSAFETYCLS group by migrated

update HKMCCADSAFETYCLS set migrated = 0 where migrated = 2 and batch_id = '1028'  -- 3067

select * from HKMCCADSAFETYCLS where createdate like '%/%'

update HKMCCADSAFETYCLS 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate = '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
where createdate like '%/%'

select sequencenumber, count(*) from HKMCCADSAFETYCLS group by sequencenumber having count(*) > 1

---------
select batch_id, migrated, count(*) from hkmccadweld group by batch_id, migrated
select migrated, count(*) from hkmccadweld group by migrated

update hkmccadweld set migrated = 0 where migrated = 2  and batch_id = '1030' -- 3067

select * from hkmccadweld where createdate like '%/%'

update hkmccadweld 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate = '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
where createdate like '%/%'

select sequencenumber, count(*) from hkmccadweld group by sequencenumber having count(*) > 1

---------
select batch_id, migrated, count(*) from hkmccadtitle group by batch_id, migrated
select migrated, count(*) from hkmccadtitle group by migrated

update hkmccadtitle set migrated = 0 where migrated = 2  and batch_id = '1030'  -- 3067

select * from hkmccadtitle where createdate like '%/%'

update hkmccadtitle 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
modifydate = '20' || substr(modifydate, 0, 2) || substr(modifydate, 4,2) || substr( modifydate, 7,2)
where createdate like '%/%'

select sequencenumber, count(*) from hkmccadtitle group by sequencenumber having count(*) > 1

---------
select batch_id, migrated, count(*) from hkmcstdnote group by batch_id, migrated
select migrated, count(*) from hkmcstdnote group by migrated
select noteno, count(*) from hkmcstdnote group by noteno

select * from hkmcnotecontent
where classnamekeya3 = 'com.hkmc.cad.HKMCStdNote'

update hkmcstdnote set migrated = 0 where migrated = 2 and batch_id = '1028'  -- 3067
update hkmcstdnote set modifier = creater where modifier like '20%'
select * from hkmcstdnote
where batch_id = 9

update hkmcstdnote 
set  --createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
modifydate = '20' || substr(modifydate, 0, 2) || substr(modifydate, 4,2) || substr( modifydate, 7,2)
where modifydate like '%/%'

---------
select batch_id, migrated, count(*) from hkmcaltsel group by batch_id, migrated
select migrated, count(*) from hkmcaltsel group by migrated

update hkmcaltsel set migrated = 0 where migrated = 1  -- 3067

select * from hkmcaltsel
where batch_id = 9

---------
select batch_id, migrated, count(*) from hkmckdpart group by batch_id, migrated
select migrated, count(*) from hkmckdpart group by migrated

select * from hkmckdpart
where batch_id = 9
---------
select batch_id, migrated, count(*) from hkmcshownon group by batch_id, migrated
select migrated, count(*) from hkmcshownon group by migrated

select * from hkmcshownon
where batch_id = 9

---------
select batch_id, migrated, count(*) from hkmcassupplymanual group by batch_id, migrated
select migrated, count(*) from hkmcassupplymanual group by migrated

select * from hkmcassupplymanual
where batch_id = 9

---------
select batch_id, migrated, count(*) from HKMCMicroFilm group by batch_id, migrated
select migrated, count(*) from HKMCMicroFilm group by migrated

select * from HKMCMicroFilm
where batch_id = 9

---------
select batch_id, migrated, count(*) from HKMCNonCADLend group by batch_id, migrated
select migrated, count(*) from HKMCNonCADLend group by migrated

select * from HKMCNonCADLend
where batch_id = 9

update HKMCNonCADLend set migrated = 0  where migrated = 2 

---------  5017 
select batch_id, migrated, count(*) from HKMCNonCAD group by batch_id, migrated
select migrated, count(*) from HKMCNonCAD group by migrated
select migrated, count(*) from HKMCNonCAD group by migrated

select * from HKMCNonCAD where migrated = 2 where batch_id = 1028

select distinct revision from hkmcnoncad where migrated = 2

update hkmcnoncad set batch_id = batch_id || sheet where migrated = 2 


update HKMCNonCAD set migrated = 0  where migrated = 2 and projectcode = 'ETC'

update HKMCNonCAD set projectcode = 'ETC'  where migrated = 2 and projectcode in ( 'OLD', 'X1', 'PON', 'SIR' ) 

update hkmcnoncad set revorder 
---------
select batch_id, migrated, count(*) from hkmcstandardpartname group by batch_id, migrated
select migrated, count(*) from hkmcstandardpartname group by migrated

select * from hkmcstandardpartname
where createdate like '%/%'
where batch_id = 9

update hkmcstandardpartname set migrated = 0  where migrated = 2

update hkmcstandardpartname set sequencenumber = rownum

update hkmcstandardpartnamewbmstatus set sequencenumber = rownum, loadstatus = ''

update hkmcstandardpartname 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate = '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
where createdate like '%/%'

select basicno, seq, count(*) from hkmcstandardpartname group by basicno, seq having count(*) > 1
---------
select batch_id, migrated, count(*) from hkmcstdpartnamereq group by batch_id, migrated
select migrated, count(*) from hkmcstdpartnamereq group by migrated

select * from hkmcstdpartnamereq
where batch_id = 9

select requestno, count(*) from hkmcstdpartnamereq group by requestno having count(*) > 1

update hkmcstdpartnamereq set migrated = 0 where migrated = 2

update hkmcstdpartnamereq 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
u_conf_date = '20' || substr(u_conf_date, 0, 2) || substr(u_conf_date, 4,2) || substr( u_conf_date, 7,2),
u_rqst_date = '20' || substr(u_rqst_date, 0, 2) || substr(u_rqst_date, 4,2) || substr( u_rqst_date, 7,2),
u_appr_date = '20' || substr(u_appr_date, 0, 2) || substr(u_appr_date, 4,2) || substr( u_appr_date, 7,2)
where createdate like '%/%'

select createdate, '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate, '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
from hkmcstdpartnamereq
where createdate like '%/%'

---------
select batch_id, migrated, count(*) from hkmcstdpartnamereqdet group by batch_id, migrated
select migrated, count(*) from hkmcstdpartnamereqdet group by migrated

select * from hkmcstdpartnamereqdet
where 
batch_id = '1028'  and 
requestno in ( select requestno from hkmcstdpartnamereq )

update hkmcstdpartnamereqdet set batch_id = '9-' where batch_id = 9

update hkmcstdpartnamereqdet set batch_id = '9' where batch_id = '94'

update hkmcstdpartnamereqdet set batch_id = '94'
where 
batch_id = 9
and requestno in ( select requestno from hkmcstdpartnamereq )


select * from hkmcstdpartnamereqdet
where batch_id = 9

select * from hkmcstdpartnamereqdetwbmstatus
select requestno, seq, count(*) from hkmcstdpartnamereqdet group by requestno, seq having count(*) > 1

update hkmcstdpartnamereqdet set migrated = 0 where migrated = 2

delete hkmcstdpartnamereqdetwbmstatus where sequencenumber > 8300

update hkmcstdpartnamereqdetwbmstatus set sequencenumber = rownum, loadstatus = ''
update hkmcstdpartnamereqdet set sequencenumber = rownum

update hkmcstdpartnamereqdet 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate = '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
where createdate like '%/%'

select createdate, '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate, '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
from hkmcstandardword
where createdate like '%/%'
---------
select batch_id, migrated, count(*) from hkmcstandardword group by batch_id, migrated
select migrated, count(*) from hkmcstandardword group by migrated

select * from hkmcstandardword
where batch_id = 9

select englishword, count(*) from hkmcstandardword group by englishword having count(*) > 1

update hkmcstandardword set migrated = 0 where migrated = 2

update hkmcstandardword 
set createdate = '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate = '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
where createdate like '%/%'

select createdate, '20' || substr(createdate, 0, 2) || substr(createdate, 4,2) || substr( createdate, 7,2),
updatedate, '20' || substr(updatedate, 0, 2) || substr(updatedate, 4,2) || substr( updatedate, 7,2)
from hkmcstandardword
where createdate like '%/%'




=======================


 UPDATE APPLICATIONDATA SET FILENAME = 'FENDER_PNL_ǥ�ظ� ���̵�.ppt'  WHERE FILENAME = '035872B400.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66311_ǥ�ظ𵨰��̵�_R00(�̵���)_090116.ppt'  WHERE FILENAME = '66311ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66317_ǥ�ظ𵨰��̵�_R00_090106.ppt'  WHERE FILENAME = '66317ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66317_ǥ�ظ𵨰��̵�_R00(��ȫ��)_090428.ppt'  WHERE FILENAME = '66317ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'HOOD ǥ�ظ� ���̵�(080724).ppt'  WHERE FILENAME = '66411ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66421_ǥ�ظ𵨰��̵�_R00_081103.ppt'  WHERE FILENAME = '66421ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66425_ǥ�ظ𵨰��̵�_R00_0811219_��ȣ��.ppt'  WHERE FILENAME = '66425ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66425_ǥ�ظ𵨰��̵�_R00(�赵��)_090526.ppt'  WHERE FILENAME = '66426ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66445_ǥ�ظ𵨰��̵�_R00_090130_��ȣ��.ppt'  WHERE FILENAME = '66445ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66714_ǥ�ظ𵨰��̵�_R02_081105.ppt'  WHERE FILENAME = '66714GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66715_ǥ�ظ𵨰��̵�_R00_090218_����.ppt'  WHERE FILENAME = '66715ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66715_ǥ�ظ𵨰��̵�_R00_090528.ppt'  WHERE FILENAME = '66715ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66721_ǥ�ظ𵨰��̵�_R00_081112.ppt'  WHERE FILENAME = '66721ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66721_ǥ�ظ𵨰��̵�_R00_090528.ppt'  WHERE FILENAME = '66721ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66731_ǥ�ظ𵨰��̵�_R00_090108.ppt'  WHERE FILENAME = '66731ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66747_ǥ�ظ𵨰��̵�_090217_������.ppt'  WHERE FILENAME = '66747ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66752_ǥ�ظ𵨰��̵�_R00_090114_����.ppt'  WHERE FILENAME = '66752ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66755_ǥ�ظ𵨰��̵�_R00_090218_����.ppt'  WHERE FILENAME = '66755ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66755_ǥ�ظ𵨰��̵�_R00(��ȫ��)_090428.ppt'  WHERE FILENAME = '66755ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66764_ǥ�ظ𵨰��̵�_R00_081113_������.ppt'  WHERE FILENAME = '66764ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66773_ǥ�ظ𵨰��̵�_R00_081226.ppt'  WHERE FILENAME = '66773ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66773_ǥ�ظ𵨰��̵�_R00_090528.ppt'  WHERE FILENAME = '66773ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66775_ǥ�ظ𵨰��̵�_R00_081211.ppt'  WHERE FILENAME = '66775ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3��_66775_ǥ�ظ𵨰��̵�_R00_BRKT_WIPER_MTG_CTR_����ں���_090423.ppt'  WHERE FILENAME = '66775ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66778_ǥ�ظ𵨰��̵�_R00_081217_����ȯ.ppt'  WHERE FILENAME = '66778ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66781_ǥ�ظ𵨰��̵�_R00_081217_����ȯ.ppt'  WHERE FILENAME = '66781ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66791_ǥ�ظ𵨰��̵�_R01_090122.ppt'  WHERE FILENAME = '66791ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66791_ǥ�ظ𵨰��̵�_R00_090311.ppt'  WHERE FILENAME = '66791ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '66794_ǥ�ظ𵨰��̵�_R00_������_1119_����.ppt'  WHERE FILENAME = '66794ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '67123_ǥ�ظ𵨰��̵�_R01_081106.ppt'  WHERE FILENAME = '67123GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '67139_ǥ�ظ𵨰��̵�_R00_081119_��ȣö.ppt'  WHERE FILENAME = '67139ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '67154_ǥ�ظ𵨰��̵�_R00_090107_������.ppt'  WHERE FILENAME = '67154ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '67320_ǥ�ظ𵨰��̵�_R00_081119_��ȣö.ppt'  WHERE FILENAME = '67320ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_R00_081211(��â��_69117).ppt'  WHERE FILENAME = '69117ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69128_ǥ�ظ𵨰��̵�_R00_081125_������(����).ppt'  WHERE FILENAME = '69128ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69138_ǥ�ظ𵨰��̵�_R00_081119.ppt'  WHERE FILENAME = '69138ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_R00_081124(��â��_69152).ppt'  WHERE FILENAME = '69152ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69155_ǥ�ظ𵨰��̵�_R01_081203.ppt'  WHERE FILENAME = '69155ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'T_LID OTR ǥ�ظ� ���̵�(080723).ppt'  WHERE FILENAME = '69211ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69221_ǥ�ظ𵨰��̵�_R00_081106.ppt'  WHERE FILENAME = '69221GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'FRAME_RR_WDW_OPENING_OTR_ǥ�ظ� ���̵�(���׹�).ppt'  WHERE FILENAME = '69318ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69341_ǥ�ظ𵨰��̵�_R00_081210.ppt'  WHERE FILENAME = '69341ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69356_ǥ�ظ𵨰��̵�_R01_081114.ppt'  WHERE FILENAME = '69356ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'F_F_DR ǥ�ظ� ���̵�(080724).ppt'  WHERE FILENAME = '69510ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '69510_ǥ�ظ𵨰��̵�_R00(�赵��)_090526.ppt'  WHERE FILENAME = '69510ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Side OTR ǥ�ظ� ���̵�(080721).ppt'  WHERE FILENAME = '71112ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71132_ǥ�ظ𵨰��̵�_R02_081112.ppt'  WHERE FILENAME = '71132GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71132_ǥ�ظ𵨰��̵�_R01_090529(������).ppt'  WHERE FILENAME = '71132ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71153_ǥ�ظ� ���̵�_R01_20090225.ppt'  WHERE FILENAME = '71153ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71153_ǥ�ظ� ���̵�_R01_090529.ppt'  WHERE FILENAME = '71153ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71155_ǥ�ظ𵨰��̵�_R00(������)_090206.ppt'  WHERE FILENAME = '71155ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71157_ǥ�ظ𵨰��̵�_R00_090120.ppt'  WHERE FILENAME = '71157ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71157_ ǥ�ظ� ���̵�_R01(������).ppt'  WHERE FILENAME = '71157ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71173_ǥ�ظ𵨰��̵�_R00(������)_090206.ppt'  WHERE FILENAME = '71173ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71176_ǥ�ظ𵨰��̵�_R00_090112.ppt'  WHERE FILENAME = '71176ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71211_ǥ�ظ𵨰��̵�_R00_081119.ppt'  WHERE FILENAME = '71211ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_71433_�輮��(090528).ppt'  WHERE FILENAME = '71433ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71455_ǥ�ظ𵨰��̵�_R00_081229_����.ppt'  WHERE FILENAME = '71455ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71471_ǥ�ظ𵨰��̵�_R01_081112.ppt'  WHERE FILENAME = '71471ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71473_ǥ�ظ𵨰��̵�_R00_081219_����_����.ppt'  WHERE FILENAME = '71473ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'F_F HSG ǥ��ȭ�� ���̵�.ppt'  WHERE FILENAME = '71531ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71556_ǥ�ظ𵨰��̵�_R00_090227.ppt'  WHERE FILENAME = '71556ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71556_ǥ�ظ𵨰��̵�_R00(�輺��)_090427.ppt'  WHERE FILENAME = '71556ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71575_ǥ�ظ𵨰��̵�_R00_090220_�ǿ��� (NXPowerLite).ppt'  WHERE FILENAME = '71575ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71575_ǥ�ظ𵨰��̵�_R00_090428.ppt'  WHERE FILENAME = '71575ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71577_ǥ�ظ𵨰��̵�_R00_090107.ppt'  WHERE FILENAME = '71577ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71577_ǥ�ظ𵨰��̵�_R00(�輺��)_090427.ppt'  WHERE FILENAME = '71577ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71593_ǥ�ظ𵨰��̵�_R01_081103.ppt'  WHERE FILENAME = '71592GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71611_ǥ�ظ𵨰��̵�_R00_090402.ppt'  WHERE FILENAME = '71611GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71613_ǥ�ظ𵨰��̵�_R00_090220_���ȯ.ppt'  WHERE FILENAME = '71613ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3��_71613_ǥ�ظ𵨰��̵�_R000__QTR_INR_LWR_RR__��ȫ��__090429.ppt'  WHERE FILENAME = '71613ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71615_ǥ�ظ𵨰��̵�_R00_090121.ppt'  WHERE FILENAME = '71615ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71631_ǥ�ظ𵨰��̵�_R01_081112.ppt'  WHERE FILENAME = '71631ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '090218_71633_ǥ�ظ𵨰��̵�_R03_���Ǳ�..ppt'  WHERE FILENAME = '71633ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3��_71634_ǥ�ظ𵨰��̵�_R000__EXTN_W_HSE_INR_FR__��ȫ��__090429.ppt'  WHERE FILENAME = '71633ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71639_ǥ�ظ𵨰��̵�_R00_081111(�����)_�Ϸ�.ppt'  WHERE FILENAME = '71639ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71631_ǥ�ظ𵨰��̵�_R01_081112.ppt'  WHERE FILENAME = '71651ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71651_ǥ�ظ𵨰��̵�_R00(�輺��)_090119.ppt'  WHERE FILENAME = '71651ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '090218_71658_ǥ�ظ𵨰��̵�_R03_���Ǳ�..ppt'  WHERE FILENAME = '71658ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71658_ǥ�ظ𵨰��̵�_R00_090430������.ppt'  WHERE FILENAME = '71658ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71672_ǥ�ظ𵨰��̵�_R00_081119.ppt'  WHERE FILENAME = '71672ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71677_ǥ�ظ𵨰��̵�_R00_081224_�Ѽ���.ppt'  WHERE FILENAME = '71677ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71731_ǥ�ظ𵨰��̵�_R00_081224_�ǿ���.ppt'  WHERE FILENAME = '71731ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71733_ǥ�ظ𵨰��̵�_R00_������_1216.ppt'  WHERE FILENAME = '71733ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71733_ǥ�ظ𵨰��̵�_������_090427.ppt'  WHERE FILENAME = '71733ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '73730_ǥ�ظ𵨰��̵�_R00_081224_������.ppt'  WHERE FILENAME = '73730ST001.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '73750_REINF-T_GATE_G_LIFTER ǥ�ظ𵨰��̵�_09121.ppt'  WHERE FILENAME = '73750ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '73750_ǥ�ظ𵨰��̵�_R00(���濭)_090602.ppt'  WHERE FILENAME = '73750ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '73790_ǥ�ظ𵨰��̵�_R00_081224.ppt'  WHERE FILENAME = '73790ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'FR DR OTR PNL ǥ�ظ� ���̵�(080804).ppt'  WHERE FILENAME = '76111ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Door Checker ǥ�ظ� ���̵�(090225).ppt'  WHERE FILENAME = '79480ST01A---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Door Checker ǥ�ظ� ���̵�(090225).ppt'  WHERE FILENAME = '79480ST01B---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_TGATE_HINGE_ASSY_090525_�Ϸ�.ppt'  WHERE FILENAME = '797102E000ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_TGATE_HINGE_ASSY_090525_�Ϸ�.ppt'  WHERE FILENAME = '797104D000.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'T_LID LATCH REINF ǥ�ظ� ���̵�(080723).ppt'  WHERE FILENAME = '79710ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79730_ǥ�ظ𵨰��̵�_R00_090107.ppt'  WHERE FILENAME = '79730ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79730_T_GATE_HINGE_REINF_090525_�Ϸ�.ppt'  WHERE FILENAME = '79730ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_TGATE_HINGE_ASSY_090525_�Ϸ�.ppt'  WHERE FILENAME = '79770ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_ǥ�ظ𵨰��̵�_R00_081126_����ȯ.ppt'  WHERE FILENAME = '797701C000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_ǥ�ظ𵨰��̵�_R00_081126_����ȯ.ppt'  WHERE FILENAME = '797701H000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79770_ǥ�ظ𵨰��̵�_R00_081126_����ȯ.ppt'  WHERE FILENAME = '797702C001ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81110_ǥ�ظ𵨰��̵�_R00_081224_����ȣ_�Ϸ�.ppt'  WHERE FILENAME = '81110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81110_ǥ�ظ𵨰��̵�_R00(�赵��)_090526.ppt'  WHERE FILENAME = '81110ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81124_ǥ�ظ𵨰��̵�__20090304.ppt'  WHERE FILENAME = '81124ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81170_ROD ASSY_HOOD_ǥ�ظ𵨰��̵�_R00_090106.ppt'  WHERE FILENAME = '81170ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81170_ǥ�ظ𵨰��̵�_R00(�赵��)_090528.ppt'  WHERE FILENAME = '81170ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81174_ǥ�ظ𵨰��̵�_R00_090121.ppt'  WHERE FILENAME = '811741G000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81174_ǥ�ظ𵨰��̵�_R00_090121.ppt'  WHERE FILENAME = '8117421010SST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81174_ǥ�ظ𵨰��̵�_R00_090121.ppt'  WHERE FILENAME = '811742L000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81174_ǥ�ظ𵨰��̵�_R00_090121.ppt'  WHERE FILENAME = '811761C000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'HOOD_LATCH_REL_HDL_ǥ�ظ𵨰��̵�_R00_081103.ppt'  WHERE FILENAME = '81180ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'HOOD_LATCH_REL_HDL_ǥ�ظ𵨰��̵�_R00_081103.ppt'  WHERE FILENAME = '81180STO1A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81210_ǥ�ظ𵨰��̵�_R00_090213.ppt'  WHERE FILENAME = '81210ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'F_F_DR_HDL_ǥ�ظ𵨰��̵�_R02_090121.ppt'  WHERE FILENAME = '81570ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81590_ǥ�ظ𵨰��̵�_20090220.ppt'  WHERE FILENAME = '81590ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '86450_ǥ�ظ𵨰��̵�_R00_090218.ppt'  WHERE FILENAME = '8173824210ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '81750_ǥ�ظ𵨰��̵�_R00_081106.ppt'  WHERE FILENAME = '81750GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82110_ǥ�ظ𵨰��̵�_R00_081219_����ȯ.ppt'  WHERE FILENAME = '82110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82130_ǥ�ظ𵨰��̵�_R00_090206_�躴��.ppt'  WHERE FILENAME = '82130ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '86450_ǥ�ظ𵨰��̵�_R00_090218.ppt'  WHERE FILENAME = '8219128010ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_82210,W_STRIP-FR DR BELT O_S.ppt'  WHERE FILENAME = '82210ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82210_ǥ�ظ𵨰��̵�_R00_090522.ppt'  WHERE FILENAME = '82210ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_82231,W_STRIP-FR DR BELT I_S_���ѽ�(090113)_������.ppt'  WHERE FILENAME = '82231ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_82393,PAD-FR DR S_IMPACT_������.ppt'  WHERE FILENAME = '82393ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82350_ǥ�ظ𵨰��̵�_R00_090121(�ӳ���).ppt'  WHERE FILENAME = '82530ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82550_ǥ�ظ𵨰��̵�_R00_090212.ppt'  WHERE FILENAME = '82550ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '82110_ǥ�ظ𵨰��̵�_R00_081219_����ȯ.ppt'  WHERE FILENAME = '83110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83130_ǥ�ظ𵨰��̵�_R00_090206_���.ppt'  WHERE FILENAME = '83130ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_82210,W_STRIP-FR DR BELT O_S.ppt'  WHERE FILENAME = '83210ST01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83210_ǥ�ظ𵨰��̵�_R00_090522.ppt'  WHERE FILENAME = '83210ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76113_ǥ�ظ𵨰��̵�_R00_090211_�����.ppt'  WHERE FILENAME = '76113ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'FR_RR DR IMPACT BEAM.ppt'  WHERE FILENAME = '76150GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76156_ǥ�ظ𵨰��̵�_R00_081205.ppt'  WHERE FILENAME = '76156ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76156_ǥ�ظ𵨰��̵�_R00_081205.ppt'  WHERE FILENAME = '76156ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'FR DR INR PNL ǥ�ظ� ���̵�(080714).ppt'  WHERE FILENAME = '76211ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76231_ǥ�ظ𵨰��̵�_R00_081211_�ڿ���.ppt'  WHERE FILENAME = '76231ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76410_ǥ�ظ𵨰��̵�_R00(������)_090427.ppt'  WHERE FILENAME = '76410ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76410_ǥ�ظ𵨰��̵�_R00_090225(FR_DR_FRAME).ppt'  WHERE FILENAME = '76410STA01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76410_ǥ�ظ𵨰��̵�_R00_090225(FR_DR_FRAME).ppt'  WHERE FILENAME = '76410STA02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76410_ǥ�ظ𵨰��̵�_R00_090225(FR_DR_FRAME).ppt'  WHERE FILENAME = '76410STA03A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76410_ǥ�ظ𵨰��̵�_R00_090225(FR_DR_FRAME).ppt'  WHERE FILENAME = '76410STA04A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76415_ǥ�ظ𵨰��̵�_R00_081105.ppt'  WHERE FILENAME = '76415GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '76433_GUIDE_R00_090114.ppt'  WHERE FILENAME = '76433ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77111_ǥ�ظ𵨰��̵�_R00(������)_090427(SLID''G DR).ppt'  WHERE FILENAME = '77111ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77113_ǥ�ظ𵨰��̵�_R00_090211_�����.ppt'  WHERE FILENAME = '77113ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'FR_RR DR IMPACT BEAM.ppt'  WHERE FILENAME = '77150GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '11.ppt'  WHERE FILENAME = '77156ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '11.ppt'  WHERE FILENAME = '77156ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77211(SLIDG DR)_ǥ�ظ𵨰��̵�_R00_090427.ppt'  WHERE FILENAME = '77211STD31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77230_ǥ�ظ𵨰��̵�_R00(���ȣ)_090427.ppt'  WHERE FILENAME = '77230STD31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77231_ǥ�ظ𵨰��̵�_FINAL_090216.ppt'  WHERE FILENAME = '77231ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77250_ǥ�ظ𵨰��̵�_R00(���ȣ)_090427.ppt'  WHERE FILENAME = '77250STD31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77270_ǥ�ظ𵨰��̵�_R00(���ȣ)_090427.ppt'  WHERE FILENAME = '77270STD31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '77410_ǥ�ظ𵨰��̵�_R00_090225(RR_DR_FRAME).ppt'  WHERE FILENAME = '77410ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'HOOD_LATCH_REL_HDL_ǥ�ظ𵨰��̵�_R00_081103.ppt'  WHERE FILENAME = '79110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79130_ǥ�ظ𵨰��̵�_R00_090204_����ȯ.ppt'  WHERE FILENAME = '79130ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '79210_ǥ�ظ𵨰��̵�_R00_081106 .ppt'  WHERE FILENAME = '79210GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '�¢�79260-MD000_BRKT ASSY-T-LID LOCK MTG.ppt'  WHERE FILENAME = '79260GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Door Checker ǥ�ظ� ���̵�(090225).ppt'  WHERE FILENAME = '79380ST01A---.02.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71211_ǥ�ظ𵨰��̵�_R01(������)_090506.ppt'  WHERE FILENAME = '71211ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71213_ǥ�ظ𵨰��̵�_R00_081219_����_����.ppt'  WHERE FILENAME = '71213ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71218_ǥ�ظ𵨰��̵�.ppt'  WHERE FILENAME = '71218GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71231_ǥ�ظ𵨰��̵�_R00_090203(���).ppt'  WHERE FILENAME = '71231ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71232_ǥ�ظ𵨰��̵�_R01_090529_MHS3.ppt'  WHERE FILENAME = '71232ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71238_ǥ�ظ𵨰��̵�_R01_081114.ppt'  WHERE FILENAME = '71238ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71251_ǥ�ظ𵨰��̵�_R00_������_0218.ppt'  WHERE FILENAME = '71251ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71271_ǥ�ظ𵨰��̵�_R00_090220.ppt'  WHERE FILENAME = '71271ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71312_ǥ�ظ𵨰��̵�_R00_081231.ppt'  WHERE FILENAME = '71312ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71315_ǥ�ظ𵨰��̵�_R00_090106.ppt'  WHERE FILENAME = '71315ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71331_ǥ�ظ𵨰��̵�_R00_090122_��ö��.ppt'  WHERE FILENAME = '71331ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71333_ǥ�ظ𵨰��̵�_R00_090122_��ö��.ppt'  WHERE FILENAME = '71333ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71338_ǥ�ظ𵨰��̵�_R00_081112.ppt'  WHERE FILENAME = '71338GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71371_ǥ�ظ𵨰��̵�_R01_081112.ppt'  WHERE FILENAME = '71371ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'CTR PLR INR ǥ�ظ� ���̵�(080724).ppt'  WHERE FILENAME = '71411ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71413_ǥ�ظ𵨰��̵�_R00_090220_�����.ppt'  WHERE FILENAME = '71413ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71415_ǥ�ظ𵨰��̵�_R02_081210.ppt'  WHERE FILENAME = '71415ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '71433_ǥ�ظ𵨰��̵�_R00_090217_�ǿ���.ppt'  WHERE FILENAME = '71433ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'EB_ǥ��ȭ������_RB_C_BOX_����ȯ_080818.ppt'  WHERE FILENAME = '86530ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_STIFFENER.ppt'  WHERE FILENAME = '86571ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_STIFFENER.ppt'  WHERE FILENAME = '86571ST301A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_STIFFENER.ppt'  WHERE FILENAME = '86571ST302A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_STIFFENER.ppt'  WHERE FILENAME = '86571ST303A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '��3�� V5 ǥ�ظ� ���̵�_SD_BRKT.ppt'  WHERE FILENAME = '86611ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '��3�� V5 ǥ�ظ� ���̵�_SD_BRKT.ppt'  WHERE FILENAME = '86611ST301A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '��3�� V5 ǥ�ظ� ���̵�_SD_BRKT.ppt'  WHERE FILENAME = '86611ST302A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Roof MLDG ǥ�ظ� ���̵�_�ۼ���.ppt'  WHERE FILENAME = '87210ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'Roof MLDG ǥ�ظ� ���̵�_�ۼ���.ppt'  WHERE FILENAME = '87210ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� ���̵�_�ۼ���(SPOILER).ppt'  WHERE FILENAME = '87220ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� ���̵�_�ۼ���(SPOILER).ppt'  WHERE FILENAME = '87220ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(ROOF_RACK).ppt'  WHERE FILENAME = '87230ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(ROOF_RACK).ppt'  WHERE FILENAME = '87230ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '87321_WEATHER_STRIP_T_GATE_ǥ�ظ𵨰��̵�_081105.ppt'  WHERE FILENAME = '87321GUIDE1.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '87321_WEATHER_STRIP_T_GATE_ǥ�ظ𵨰��̵�_081105.ppt'  WHERE FILENAME = '87321ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(OS_MRR).ppt'  WHERE FILENAME = '87610ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(OS_MRR).ppt'  WHERE FILENAME = '87610ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '87650_ǥ�ظ𵨰��̵�_R00_081211_����ȣ.ppt'  WHERE FILENAME = '87650ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(QTR_FIXED).ppt'  WHERE FILENAME = '87810ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(HEAD).ppt'  WHERE FILENAME = '92101ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(CORNERING LAMP).ppt'  WHERE FILENAME = '92104ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(FR FOG).ppt'  WHERE FILENAME = '92201ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(SRPTR).ppt'  WHERE FILENAME = '92303ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(STD_SRPTR).ppt'  WHERE FILENAME = '92303ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(RCL).ppt'  WHERE FILENAME = '92401ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(RR FOG)_�̱���_090615.ppt'  WHERE FILENAME = '92403ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(RR).ppt'  WHERE FILENAME = '92405ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(STD_LPL_LOCATION).ppt'  WHERE FILENAME = '92501ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(STD_LUGGAGE_LOCATION).ppt'  WHERE FILENAME = '926013F000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(HMSL_4DR).ppt'  WHERE FILENAME = '92700ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(HMSL_5DR).ppt'  WHERE FILENAME = '92750ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_83231,W_STRIP-RR DR BELT I_S_���ѽ�(090113)_������.ppt'  WHERE FILENAME = '83231ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_83393,PAD-RR DR S_IMPACT_������.ppt'  WHERE FILENAME = '83393ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83510_ǥ�ظ𵨰��̵�_R00_081203.ppt'  WHERE FILENAME = '83511STA01A---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83510_ǥ�ظ𵨰��̵�_R00_081203.ppt'  WHERE FILENAME = '83512STA02A---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83510_ǥ�ظ𵨰��̵�_R00_081203.ppt'  WHERE FILENAME = '83513STA03A---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83510_ǥ�ظ𵨰��̵�_R00_081203.ppt'  WHERE FILENAME = '83515STA04A---.01.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83530_ǥ�ظ𵨰��̵�_R00_09122_������.ppt'  WHERE FILENAME = '83530ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '11.ppt'  WHERE FILENAME = '83535ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83830_ǥ�ظ𵨰��̵�_R00_081112.ppt'  WHERE FILENAME = '83830ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83910_ǥ�ظ𵨰��̵�_R00_081106.ppt'  WHERE FILENAME = '83910GUIDE.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '83910_ǥ�ظ𵨰��̵�_R00(������)_090427.ppt'  WHERE FILENAME = '83910ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_CAR MAT_���弳��3��.ppt'  WHERE FILENAME = '84301GUIDE3.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ𵨰��̵�_BOOTS_FRAME_���弳��3��.ppt'  WHERE FILENAME = '84640ST301A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '�Ϸ���Ʈ_ǥ�ظ�.ppt'  WHERE FILENAME = '84661ST301A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ ����_LUGG_BOARD___HONEYCOMB_TYPE.ppt'  WHERE FILENAME = '85721ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� ���̵�_�ۼ��� (WS_Glass).ppt'  WHERE FILENAME = '86110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� ���̵�_�ۼ���(Glass_MLDG).ppt'  WHERE FILENAME = '86130ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '86423_ǥ�ظ𵨰��̵�_R00_090213.ppt'  WHERE FILENAME = '86423ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '86455_ǥ�ظ𵨰��̵�_R00_081217.ppt'  WHERE FILENAME = '86455ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST13A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST14A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST15A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Def Duct)_VER1.ppt'  WHERE FILENAME = '97350ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Def Duct)_VER1.ppt'  WHERE FILENAME = '97350ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Def Duct)_VER1.ppt'  WHERE FILENAME = '97350ST03A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(RR DUCT)_VER1.ppt'  WHERE FILENAME = '97376ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(VENT DUCT)_VER1.ppt'  WHERE FILENAME = '97470ST10A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(VENT DUCT)_VER1.ppt'  WHERE FILENAME = '97470ST10B.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(VENT DUCT)_VER1.ppt'  WHERE FILENAME = '97470ST11A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(WIPER).ppt'  WHERE FILENAME = '98110ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(WIPER).ppt'  WHERE FILENAME = '98110ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(WASHER).ppt'  WHERE FILENAME = '98610ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(WASHER).ppt'  WHERE FILENAME = '98610ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(RR_WIPER).ppt'  WHERE FILENAME = '98710ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = '3�� V5 ǥ�ظ� ���̵�_98810_RR WIPER BLADE_090612.ppt'  WHERE FILENAME = '98810ST31A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(OHCL).ppt'  WHERE FILENAME = '928001M000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(OHCL).ppt'  WHERE FILENAME = '92800ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(ROOM).ppt'  WHERE FILENAME = '928501M000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(STD_INT_LAMP_LOCATION).ppt'  WHERE FILENAME = '928501P000ST.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(ROOM).ppt'  WHERE FILENAME = '92850ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST01A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST02A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST03A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST04A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST05A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST06A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST07A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST08A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST09A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST10A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST11A.CATPARTYNAMKUNG';
 UPDATE APPLICATIONDATA SET FILENAME = 'ǥ�ظ� �Ϸ��ǰ Ȱ�뼺���� �������(Heater_Control)_VER1.ppt'  WHERE FILENAME = '97250ST12A.CATPARTYNAMKUNG';

select *
from ITEMNOLINK
where migrated = 0 and sequencenumber > 0 and batch_id = 9

select * from itemnolink
where sequencenumber is null

