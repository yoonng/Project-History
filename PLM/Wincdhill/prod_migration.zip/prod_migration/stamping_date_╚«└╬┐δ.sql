
select batch_id, migrated, count(*)  from upgtopart group by batch_id, migrated


select classnamekeyroleaobjectref, count(*) from stampingdrawinglink group by classnamekeyroleaobjectref

select * from stampingdrawinglink
where classnamekeyroleaobjectref in (
'com.hkmc.cad.HKMCCADSafetyClassification',
'com.hkmc.cad.HKMCCADWeld'
)



select d.namecontainerinfo, c.* 
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c, PDMLinkProduct d
where a.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADESMSSpec'
and a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2
and c.ida3containerreference = d.ida2a2



SELECT * FROM EPMDOCUMENTMASTER a ,EPMDOCUMENT b,STAMPINGDRAWINGLINK c, HKMCCADSafetyClassification d--, SAFETYCLSCODELINK e, HKMCCODE f
WHERE a.NAME LIKE '311313T000%'
AND a.ida2a2 = b.IDA3MASTERREFERENCE
--AND b.LATESTITERATIONINFO = 1
AND b.BRANCHIDITERATIONINFO = c.BRANCHIDA3B5
AND c.IDA3A5 = d.IDA2A2
--AND d.IDA2A2 = e.IDA3A5
--AND e.IDA3B5 = f.IDA2A2


select a.classnamekeyroleaobjectref, d.namecontainerinfo, c.* , b.*, a.*
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c, PDMLinkProduct d
where a.classnamekeyroleaobjectref in (
'com.hkmc.cad.HKMCCADESMSSpec'
--,
--'com.hkmc.cad.HKMCCADWeld'
)
--and c.NAME LIKE '311293T000%'
AND b.LATESTITERATIONINFO = 1
and a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2
and c.ida3containerreference = d.ida2a2