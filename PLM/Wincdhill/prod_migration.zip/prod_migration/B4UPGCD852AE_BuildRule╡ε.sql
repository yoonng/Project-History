
select * from hkmccadnote

select batch_id, migrated, count(*) from hkmccadnote group by batch_id, migrated

1100L	1	19184
1100	1	2
1100L	2	5
1100	0	50958

select batch_id, migrated, count(*) from hkmccadnote_bak group by batch_id, migrated

select * from hkmccadnote_bak
where drawno = '962903M300'

select m.*, d.versionida2versioninfo,  d.iterationida2iterationinfo , d.*
from epmdocumentmaster m, epmdocument d
where m.cadname like '962903M300%'
and m.ida2a2 = d.ida3masterreference


select * from epmbuildrule
where branchida3b5 in ( 
    select distinct branchiditerationinfo from wtpart where ida3masterreference in (
        select ida2a2  from wtpartmaster where wtpartnumber = '371803S011'
        )
    )

select * from wtpartusagelink
where branchida3b5 in ( 
    select distinct branchiditerationinfo from wtpart where ida3masterreference in (
        select ida2a2  from wtpartmaster where wtpartnumber = '371803S011'
        )
    )


select * from epmmemberlink
where ida3b5 in (
    select ida3masterreference from epmdocument 
    where branchiditerationinfo in (
    '1974149929',
    '832919925',
    '1396293791',
    '1942553823'
    )
)


select * from epmdocumentmaster 
where ida2a2 = 832918596

select m.ida2a2, d.ida2a2, d.branchiditerationinfo 
from epmdocumentmaster m, epmdocument d
where m.name = 'B4UPGCD852AE' and
m.ida2a2 = d.ida3masterreference 
order by d.ida2a2

2221362178	2221362182	2221362181
2221362178	2233508895	2221362181
2221362178	2233623243	2221362181
2221362178	2595516989	2221362181
2221362178	2620310662	2221362181
2221362178	2621148405	2221362181

select *
from stringvalue v, stringdefinition d
where ida3a4 in (
    select d.ida2a2 from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
)
and v.ida3a6 = d.ida2a2

ida3a4 in (2235194975,2624357687)

select count(*) from stringvalue
where ida3a6 = 42467


wt.iba.definition.StringDefinition	66417	wt.epm.EPMDocument	2624357687
wt.iba.definition.StringDefinition	66417	wt.epm.EPMDocument	2235194975
wt.iba.value.StringValue	2624356501
wt.iba.value.StringValue	2235194986


-- update StringValue set ida3a4 = -2624357687 where ida2a2 = 2624356501
-- update StringValue set ida3a4 = -2235194975 where ida2a2 = 2235194986



    select d.* from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
    
    2624357687
2624405605
2235194975

select * from epmbuildrule
where branchida3a5  in (
    select d.branchiditerationinfo from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
)

6
2221362181	wt.epm.EPMDocument	1917918083	wt.part.WTPart
wt.epm.build.EPMBuildRule	2221362198

-- update EPMBuildRule set buildtype = 6 where ida2a2 = 2221362198
-- update EPMBuildRule set branchida3a5 = 2235194974,  branchida3b5 = 1917833096 where ida2a2 = 2235194993


select * from epmbuildhistory
where ida3a5  in (
    select d.ida2a2 from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
)

wt.epm.EPMDocument	2624405605	wt.part.WTPart	2624405646
wt.epm.build.EPMBuildHistory	2624405654

-- update EPMBuildHistory set ida3a5 = -2624405605,  ida3b5 = -2624405646 where ida2a2 = 2624405654

select * from epmmemberlink
where ida3a5  in (
    select d.ida2a2 from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
)

select * from epmdescribelink
where ida3b5  in (
    select d.ida2a2 from epmdocumentmaster m, epmdocument d
    where m.name = 'B4UPGCD852AE' and
    m.ida2a2 = d.ida3masterreference 
)

wt.part.WTPart	2624405646	wt.epm.EPMDocument	2624405605
wt.epm.structure.EPMDescribeLink	2624405648

-- update EPMDescribeLink set ida3a5 = -2624405646,  ida3b5 = -2624405605 where ida2a2 = 2624405648


