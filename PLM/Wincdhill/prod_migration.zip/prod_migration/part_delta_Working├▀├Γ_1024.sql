
select count(*) from part_working_list   --- 802513

delete part_working_list
where partno like '%*%'   

select * from delta2_part_working2
where objectnumber like '%%'

802547
161443

963990

select partNo from part_working_list
minus
select objectnumber partNo from delta2_part_working2
---- �ߺ� �ֽŰ����� update 


CRACPG100016SH
CRADRG100007SH
CS8CPK100544WK
IHCCPS300257HU
IHCCPS300395HU





select * from delta2_part_working2
--  delete delta2_part_working2
where objectnumber like '%*%'   

------- �ߺ� ����
delete delta2_part_working2
-- select * from delta2_part_working2
where (objectnumber, to_date( substr(created, 0, 19), 'yyyy-MM-dd HH24:MI:SS' ) )  in (
    select objectnumber , max( to_date( substr(created, 0, 19), 'yyyy-MM-dd HH24:MI:SS' ) ) 
    from delta2_part_working2 group by objectnumber having count(*) > 1
)

select * from (
    select objectnumber , min( to_timestamp( created, 'yyyy-MM-dd HH24:MI:SS.ff' ) ) mindate
    from delta2_part_working2 group by objectnumber having count(*) > 1
) 
where maxdate = mindate 

select * from delta2_part_working2
where (objectnumber, to_timestamp( created, 'yyyy-MM-dd HH24:MI:SS.ff' ) ) in ( 
    select objectnumber , min( to_timestamp( created, 'yyyy-MM-dd HH24:MI:SS.ff' ) ) mindate
    from delta2_part_working2 group by objectnumber having count(*) > 1
)

-- 802547
insert into part_working_list
select distinct upper(trim(s_part_no)) partNo from part_list_1003_bak -- s_part_no
      where to_date( substr(u_create, 0, 10), 'yyyy-MM-dd') < to_date( '2011-10-02', 'yyyy-MM-dd' )
union
select distinct upper(trim(s_part_no)) partNo from part_list_1024 -- s_part_no
minus
select distinct upper(trim(oc01_part_no)) partNo from xxebom_ocitemtb_pim_v  -- oc01_part_no
;


select *  from part_list_1003_bak -- s_part_no
      where to_date( substr(u_create, 0, 10), 'yyyy-MM-dd') > to_date( '2011-09-30', 'yyyy-MM-dd' )
      and to_date( substr(u_create, 0, 10), 'yyyy-MM-dd') < to_date( '2011-10-02', 'yyyy-MM-dd' )

select * from part_working_list
--where partno like '%*%' 
where partno like '%��%'

-- delete part_working_list
where partno like '%*%'     -- 34
------------ step 0-1
-- create table 

select * from DELTA2_PART_WORKING2


CREATE TABLE "LEGACYDB"."DELTA2_PART_WORKING2"
  (
    "OBJECTNUMBER" VARCHAR2(50 BYTE),
    "EONO"         VARCHAR2(30 BYTE),
    "EONO2"         VARCHAR2(30 BYTE),
    "EODATE" DATE,
    "PTC_HKMCKEY"    VARCHAR2(200 BYTE),
    "PTC_HKMCKEY2"    VARCHAR2(200 BYTE),
    "ISLOADED"       VARCHAR2(1 BYTE),
    "CONTAINER"      VARCHAR2(40 BYTE),
    "LIFECYCLE"      VARCHAR2(40 BYTE),
    "LIFECYCLESTATE" VARCHAR2(40 BYTE),
    "FOLDERPATH"     VARCHAR2(40 BYTE),
    "TYPE"           VARCHAR2(40 BYTE),
    "GENERICTYPE"    VARCHAR2(40 BYTE),
    "NAME"           VARCHAR2(240 BYTE),
    "UNITOFMEASURE"  VARCHAR2(3 BYTE),
    "CREATEDBY"      VARCHAR2(50 BYTE),
    "CREATED"        VARCHAR2(150 BYTE),
    "UPDATEDBY"      VARCHAR2(50 BYTE),
    "UPDATED"        VARCHAR2(150 BYTE),
    "REGULATION"     VARCHAR2(2 BYTE),
    "DRGID"          VARCHAR2(150 BYTE),
    "REVCD"          VARCHAR2(150 BYTE),
    "TESTREQ"        VARCHAR2(16 BYTE),
    "ITEMFLAG"       VARCHAR2(150 BYTE),
    "GROUP_T"        VARCHAR2(150 BYTE),
    "COLORID"        VARCHAR2(150 BYTE),
    "SOURCE_T"       VARCHAR2(150 BYTE),
    "VALIDATIONCD"   VARCHAR2(150 BYTE),
    "EMISSION"       VARCHAR2(150 BYTE),
    "ISALTSEL"       VARCHAR2(2 BYTE),
    "SIMULTANEOUS"   VARCHAR2(1 BYTE),
    "ALTRREASON"     VARCHAR2(2 BYTE),
    "MATERIAL"       VARCHAR2(100 BYTE),
    "DESIGNWEIGHT"   VARCHAR2(12 BYTE),
    "GOALWEIGHT"     VARCHAR2(12 BYTE),
    "DESIGNCOST"     VARCHAR2(12 BYTE),
    "VARIABLECOST"   VARCHAR2(12 BYTE),
    "REMARK"         VARCHAR2(60 BYTE),
    "PARTTYPE"       VARCHAR2(1 BYTE),
    "PREEONO"        VARCHAR2(20 BYTE),
    "APLVEHICLES"    VARCHAR2(200 BYTE),
    "CCN"            VARCHAR2(150 BYTE),
    "TRANSFER"       VARCHAR2(1 BYTE),
    "PNC"            VARCHAR2(150 BYTE),
    "VENDERDRAWING"  VARCHAR2(15 BYTE),
    "PARTDEPT"       VARCHAR2(10 BYTE),
    "ISINSTALL"      VARCHAR2(150 BYTE),
    "UNIT"           VARCHAR2(3 BYTE),
    "HKMCREVISION"   VARCHAR2(10 BYTE),
    "ADDIN"          VARCHAR2(1 BYTE),
    "ISNOTITEM"   VARCHAR2(10 BYTE)
  )
  SEGMENT CREATION IMMEDIATE PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
  
CREATE INDEX "LEGACYDB"."RPHW2$NOEONO" ON "LEGACYDB"."DELTA2_PART_WORKING2"
  (
    "OBJECTNUMBER",
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;
CREATE INDEX "LEGACYDB"."REWORKW2$EONO" ON "LEGACYDB"."DELTA2_PART_WORKING2"
  (
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."REWORKW2$PTCKEY" ON "LEGACYDB"."DELTA2_PART_WORKING2"
  (
    "PTC_HKMCKEY"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."RPHW2$PARTNUMBER" ON "LEGACYDB"."DELTA2_PART_WORKING2"
  (
    "OBJECTNUMBER"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;

------------------ step1
DELETE DELTA2_PART_WORKING2

insert into DELTA2_PART_WORKING2
select 
	C0.partNo 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  ec.u_eo_no       as EONO,
  ''       as EONO2,
	ec.u_eo_date  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  ''      as PTC_HKMCKEY,
  ''      as PTC_HKMCKEY2,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  decode( nvl(ec.u_item_upg, '') || nvl(ec.u_gubun, ''), '5U', 'UPG', '5V', 'VC', 'PART')    as "type",     --    5�̿��� ����   5,u upg,    5,v vc,, ������ part 2
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  --C0.name       as "name" ,
  ec.u_part_name       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  ec.u_unit    as unitofmeasure,
	ec.u_create_user  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	ec.u_create 			as created,   -------------------------------------------- ok
	ec.u_lastmod_user 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	ec.u_lastmod 		as "updated",  --------------------------------------------  ok
	ec.u_law_gubn 				as regulation, 
	ec.u_ti 				as drgID,
	'' 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	ec.u_test_request1 || ',' || ec.u_test_request2 || ',' || ec.u_test_request3 || ',' || ec.u_test_request4 || ',' || ec.u_test_request5 || ',' || ec.u_test_request6 as TestREQ,	
  --------------------------------------------ok
	ec.u_item_upg 			as itemFlag,--------------------------------------------ok   5�̿��� ����   5,u upg,    5,v vc,, ������ part 2
	ec.u_group 			as GROUP_T,--------------------------------------------ok
	ec.u_color_id 			as ColorID,--------------------------------------------ok
	ec.u_source 			as SOURCE_T,--------------------------------------------ok
	ec.u_validation 			as validationCD,--------------------------------------------ok
	ec.u_em_gubn 			as emission,--------------------------------------------ok
	decode(ec.u_part_idno,null,'N','Y') as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	ec.u_simu_simbol 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ec.u_cresn  			as altReason,-------------------------------------------- ok
	ec.u_material 				as material,
	ec.u_dsgn_dweig 			as designWeight, 
	ec.u_goal_dweig 			as goalWeight, 
	ec.u_dsgn_dcost 			as designCost,
	ec.u_goal_dcost 			as VariableCost, 
	ec.u_note 			as Remark,--------------------------------------------  ok
	ec.u_part_gubun 			as partType,
  ec.u_preeo_no as PREEONO,
	ec.u_project 				as APLVehicles, 
	ec.u_ccn 			as CCN,   --------------------------------------------  ok 
	ec.u_transfer 				as TRANSFER,
	ec.u_pnc0_no 			as pnc,--------------------------------------------ok
	ec.u_vendor_drawing 		as venderDrawing, 
	ec.u_dept_code 				as PartDept,
  ec.u_id    as isinstall,
  ec.u_unit    as unit,
  ''    as hkmcrevision,--------------------------------------------ok
  ''    as addin  ,
  ''    as ISNOTITEM
  --  select * 
from 
--( select * from 
part_list_1003_bak  
--        where to_date( substr(u_create, 0, 10), 'yyyy-MM-dd') < to_date( '2011-10-02', 'yyyy-MM-dd' )
--  union 
--  select * from part_list_1024  )  
ec, 
--xxebom_odeelatb_bs_staging3 ela, 
--xxebom_ocitemtb_pim_v_staging3  xx, 
part_working_list  C0
where 
C0.partNo in (
'CRACPG100016SH',
'CRADRG100007SH',
'CS8CPK100544WK',
'IHCCPS300257HU',
'IHCCPS300395HU'
)
and
C0.partNo = upper(trim(ec.s_part_no));

commit;  -- 35293

select * from part_list_1003_bak
where s_part_no in (
'CRACPG100016SH',
'CRADRG100007SH',
'CS8CPK100544WK',
'IHCCPS300257HU',
'IHCCPS300395HU'
)
select * from part_working_list
where partno in (
'CRACPG100016SH',
'CRADRG100007SH',
'CS8CPK100544WK',
'IHCCPS300257HU',
'IHCCPS300395HU'
)
------------------ step3

select objectnumber, count(*) from DELTA2_PART_WORKING2 group by objectnumber having count(*) > 1

select * from DELTA2_PART_WORKING2 where type <> 'PART'

insert into DELTA2_PART_WORKING2
select * from DELTA2_PART_WORKING2
where PTC_HKMCKEY in (
    select PTC_HKMCKEY from DELTA2_PART_WORKING2
    minus
    select PTC_HKMCKEY from DELTA2_PART_WORKING2
);

commit;

select a.rowid, a.* from DELTA2_PART_WORKING2  a
where ptc_hkmckey in (
    select ptc_hkmckey from DELTA2_PART_WORKING2 group by ptc_hkmckey having count(*) > 1
)
order by ptc_hkmckey

-- delete DELTA2_PART_WORKING2
where 

-- 71738
select count(*) from DELTA2_PART_WORKING2

update DELTA2_PART_WORKING2 
set createdby = decode( createdby, '-1', decode(updatedby, '-1', '', updatedby) , createdby), 
updatedby = decode(updatedby, '-1', '', updatedby),
testreq = replace(testreq, ' ', ''), 
created = replace(created, '/', ''), 
updated = replace(updated, '/', '');

commit;

select * from delta2_part_master
where ptc_hkmckey = '692003S010XP4KB0003'
692003S010XP4KB0003	692003S010X	P4KB0003
692003S010XP4KB0003
select * from 

in (
select ptc_hkmckey from delta2_part_master
minus
select ptc_hkmckey from DELTA2_PART_WORKING2
)

select * from xxebom_ocitemtb_pim_v
where oc01_part_no = '692003S010X'

select * from xxebom_odeelatb_bs
where (od03_rpno_c, eono) in ( ('692003S010X','P4KB0003') )

select * from DELTA2_PART_WORKING2
where objectnumber in (
'BC4AC01629',
'BC4AC01642'
)

select s_part_no, length(s_part_no), length(trim(s_part_no)) from part_list 
where s_part_no in (
'BC4AC01629',
'BC4AC01642'
)