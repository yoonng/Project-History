
select to_timestamp(createstampa2) from stampingdrawinglink  -- 2248396

select classnamekeyroleaobjectref, count(*) from stampingdrawinglink group by classnamekeyroleaobjectref  

select * from stampingdrawinglink

-- �ߺ� ������ ��ü ����.. 
select * from stampingdrawinglink
where 
select classnamekeyroleaobjectref, branchida3b5, count(*) from stampingdrawinglink 
--  select distinct classnamekeyroleaobjectref from stampingdrawinglink 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
group by classnamekeyroleaobjectref, branchida3b5 having count(*) > 1

--- �ߺ� üũ
select classnamekeyroleaobjectref, branchida3b5, count(*) from stampingdrawinglink 
--  select distinct classnamekeyroleaobjectref from stampingdrawinglink 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
group by classnamekeyroleaobjectref, branchida3b5 having count(*) > 1

select m.documentnumber, d.versionida2versioninfo, d.iterationida2iterationinfo, d.ida2a2 
from epmdocumentmaster m, epmdocument d
where d.ida3masterreference = m.ida2a2
order by m.ida2a2, d.ida2a2


-- stampingdrawinglink ���ְ�, stamping OBJ�� ���� ��ũ ����
select a.*, b.* from stampingdrawinglink a, HKMCCADWeld b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null 


com.hkmc.cad.HKMCCADSafetyClassification	4881   -- �ߺ�����
com.hkmc.cad.HKMCCADNote	153549    -- �Ұ�
com.hkmc.cad.HKMCCADTitle	229205                 -- �ߺ�����
---com.hkmc.cad.HKMCCADWeld	1869                   -- �ߺ�����
--com.hkmc.cad.HKMCCADNoteTable	12  -- �Ұ�
com.hkmc.cad.HKMCCADRevisionReason	1366474      -- �ߺ�����
com.hkmc.cad.HKMCCADESMSSpec	492406             -- �ߺ�����


select ida3a5, ida3b5, c.code, count(*) from HKMCCADSafetyClassification a, safetyclscodelink b, hkmccode c
where a.ida2a2 = b.ida3a5 
and b.ida3b5 = c.ida2a2 group by ida3a5, ida3b5, c.code having count(*) > 1

select ida3a5, ida3b5, count(*) from HKMCCADSafetyClassification a, safetyclscodelink b, hkmccode c
where a.ida2a2 = b.ida3a5 group by ida3a5, ida3b5 having count(*) > 1

select * from HKMCCADWeld a, weldcodelink b
where a.ida2a2 = b.ida3a5 group by ida3a5, ida3b5 having count(*) > 1

select c.* from stampingdrawinglink a, hkmccadnote b, hkmcnotecontent c
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and branchida3b5 = 2180424098
and b.ida2a2 = a.ida3a5
and b.ida2a2 = ida3a3
order by langtype, seq

select * from stampingdrawinglink
where updatestampa2 > '2011-10-30'

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
===== weld �ֽ� üũ

select * from stampingdrawinglink
--- update stampingdrawinglink set branchida3b5 =  ( 
                select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
                where d.ida3masterreference = m.ida2a2
                and m.ida2a2 = ida3masterreference 
    )
where ida2a2 in ( 
    select ida2a2 from 
    ( 
        select a.ida2a2, a.ida3a5, a.branchida3b5 ,(
                select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
                where d.ida3masterreference = m.ida2a2
                and m.ida2a2 = b.ida3masterreference 
            ) maxBranchID
        from stampingdrawinglink a, epmdocument b
        where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld'
        and a.branchida3b5 = b.branchiditerationinfo
        order by  maxbranchid, branchida3b5, ida3a5
    ) 
    where branchida3b5 <> maxbranchid
)

select * from 
( select a.ida2a2, a.ida3a5, a.branchida3b5 ,
(
    select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
    where d.ida3masterreference = m.ida2a2
    and m.ida2a2 = b.ida3masterreference 
) maxBranchID
from stampingdrawinglink a, epmdocument b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld'
and a.branchida3b5 = b.branchiditerationinfo
order by  maxbranchid, branchida3b5, ida3a5
) 
where branchida3b5 <> maxbranchid

==== weld �ߺ� ����

select * from weldcodelink

select *  from stampingdrawinglink l, HKMCCADWeld d , weldcodelink w,  hkmccode c 
where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld'
and l.ida3a5 = d.ida2a2
and w.ida3a5 = d.ida2a2
and w.ida3b5 = c.ida2a2


select ida3a5, branchida3b5, count(*)  from stampingdrawinglink l 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld' group by ida3a5, branchida3b5 having count(*) > 1 


select branchida3b5, c.code, count(*)  
from stampingdrawinglink l, HKMCCADWeld d , weldcodelink w,  hkmccode c 
where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADWeld' 
and l.ida3a5 = d.ida2a2
and w.ida3a5 = d.ida2a2
and w.ida3b5 = c.ida2a2
group by l.branchida3b5, c.code  
having count(*) > 1 



@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
===== HKMCCADNoteTable �ֽ� üũ

select * from 
( select a.ida2a2, a.ida3a5, a.branchida3b5 ,
(
    select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
    where d.ida3masterreference = m.ida2a2
    and m.ida2a2 = b.ida3masterreference 
) maxBranchID
from stampingdrawinglink a, epmdocument b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNoteTable'
and a.branchida3b5 = b.branchiditerationinfo
order by  maxbranchid, branchida3b5, ida3a5
) 
where branchida3b5 <> maxbranchid


@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
===== HKMCCADSafetyClassification �ֽ� üũ

select * from 
( select a.ida2a2, a.ida3a5, a.branchida3b5 ,
(
    select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
    where d.ida3masterreference = m.ida2a2
    and m.ida2a2 = b.ida3masterreference 
) maxBranchID
from stampingdrawinglink a, epmdocument b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification'
and a.branchida3b5 = b.branchiditerationinfo
order by  maxbranchid, branchida3b5, ida3a5
) 
where branchida3b5 <> maxbranchid


select * from stampingdrawinglink
--- update stampingdrawinglink set branchida3b5 =  ( select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d where d.ida3masterreference = m.ida2a2 and m.ida2a2 = ida3masterreference  )
where ida2a2 in ( 
    select ida2a2 from 
    ( 
        select a.ida2a2, a.ida3a5, a.branchida3b5 ,(
                select max(d.branchiditerationinfo ) maxBranchID from epmdocumentmaster m, epmdocument d
                where d.ida3masterreference = m.ida2a2
                and m.ida2a2 = b.ida3masterreference 
            ) maxBranchID
        from stampingdrawinglink a, epmdocument b
        where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification'
        and a.branchida3b5 = b.branchiditerationinfo
        order by  maxbranchid, branchida3b5, ida3a5
    ) 
    where branchida3b5 <> maxbranchid
)

==== HKMCCADSafetyClassification �ߺ� ����

select *  from stampingdrawinglink l 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification'
select ida3a5, branchida3b5, count(*)  from stampingdrawinglink l 
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification' group by ida3a5, branchida3b5 having count(*) > 1 

=========== esms �ߺ� Ȯ��

select * from hkmccadesmsspec

select branchida3b5, d.speccode, count(*) from stampingdrawinglink l, hkmccadesmsspec d
where l.ida3a5 = d.ida2a2
and classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADESMSSpec'
group by branchida3b5, d.speccode
having count(*) > 1 


delete stampingdrawinglink where ida2a2 in (
    select min(l.ida2a2) from stampingdrawinglink l, hkmccadesmsspec d
    where l.ida3a5 = d.ida2a2
    and classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADESMSSpec'
    group by branchida3b5, d.speccode
    having count(*) > 1 
)