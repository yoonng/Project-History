
--===== �ش� epm�� note content ���� Ȯ��
select c.documentnumber, b.versionida2versioninfo, b.iterationida2iterationinfo, n.* 
from epmdocument b, epmdocumentmaster c, stampingdrawinglink a, hkmcnotecontent n  
where c.documentnumber like '962903M300%'
and c.ida2a2 = b.ida3masterreference
and b.branchiditerationinfo = a.branchida3b5
and a.ida3a5 = n.ida2a2


select c.documentnumber, b.versionida2versioninfo, b.iterationida2iterationinfo , a.*
from epmdocument b, epmdocumentmaster c, stampingdrawinglink a
where c.documentnumber like '962903M300%'
and c.ida2a2 = b.ida3masterreference
and b.branchiditerationinfo = a.branchida3b5


-----------------------------------------------------

select c.documentnumber, b.versionida2versioninfo, b.iterationida2iterationinfo, a.* 
from epmdocument b, epmdocumentmaster c , stampingdrawinglink a 
where c.documentnumber like '962903M300%'
and c.ida2a2 = b.ida3masterreference
and b.branchiditerationinfo = a.branchida3b5


select * from stampingdrawinglink

select * from hkmccadnote

select count(*) from hkmccadnote
676820
1257443

select * from hkmcnotecontent
select count(*) from hkmcnotecontent
1091458
2004773

select distinct classnamekeya3 from hkmcnotecontent
com.hkmc.cad.HKMCCADNote

select c.documentnumber, b.versionida2versioninfo, a.* --, count(*) cnt 
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c
where a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2 -- group by c.documentnumber
order by c.documentnumber desc


select c.documentnumber, b.versionida2versioninfo, a.* --, count(*) cnt 
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c
where a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2 -- group by c.documentnumber
and a.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and c.documentnumber like '%.CATDRAWING'
order by c.documentnumber desc 
and c.documentnumber in (
'0786517400_01.MODEL',
'846200A000_01.MODEL',
'078470R000_03.MODEL'
)
order by cnt desc

select * from 


select * from hkmccadtitle
where ida2a2 = 8001867591736

========== delete cadnote  -- 676819

select * from hkmccadnote
where to_date(updatestampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

select * from stampingdrawinglink
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and to_date(createstampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

select * from hkmcnotecontent
where to_date(updatestampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

-- delete hkmccadnote
where to_date(updatestampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

-- delete stampingdrawinglink
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and to_date(createstampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

-- delete hkmcnotecontent
where to_date(updatestampa2, 'yyyy/MM/dd') = to_date('2011/10/03', 'yyyy/MM/dd')

=============

select distinct ida2typedefinitionreference from configurablemasterslink

select distinct branchida2typedefinitionrefe from configurabledescribelink
1864471324,
50589

select distinct ida2typedefinitionreference from configurabledescribelink
1864471328,
1864471305

select * from wttypedefinition
where ida2a2 in (
1878438775,  -- ConsentedPartLink
1864468290,  -- HKMCKDPartLink
1864471328,  -- AltSellink
1864471305   -- shownon
)

============================ �ߺ� üũ

select * from hkmccadtitle
where (drawno, sheet, revision) in (
    select drawno, sheet, revision  from hkmccadtitle group by drawno, sheet, revision having count(*) > 1
)
order by drawno, sheet, revision

delete hkmccadtitle where sequencenumber in (
176777,176780,176785,176786,176787,176790,176791
,176799,176815,177827,178718,178724,194854,198155,202252,205718,206570,206776,207799,208843
,211058,214339,215507,217130,217289,218969,221909,225646,175287,175291,175302,175314,175319
,175327,175336,175338,175342,175354,175358,175373,175374,175396,175419,175421
,175441,175442,175446,175447,175979,175983,175987,175992,176001,176002,176004
,176005,176009,176012,176019,176020,176033,176041,176042,176061,176074,176102
,176104,176110,176113,176118,176120,176123,176131,176132,176417,176419,176671,176681,176683,176685,176686,176688
,176693,176707,176733,176746,176751,176758,176768,176769,176770,176776)


delete hkmccadtitle where sequencenumber in ( select * from tempseq )
select sequencenumber from (  -- 50619
select 
DRAWNO,SHEET,REVISION,REFERENCE,GENERALDIM,MACHINEDIM,PRESSDIM,CASTINGDIM,ANGELDIM,SECTIONDIM,BLANKDIM,FINISH
,SCALE,CREATEDATE,CREATER,MODIFYDATE,MODIFIER,BLANKDIMNAME,MIGRATED,BATCH_ID, max(sequencenumber)  queue
from hkmccadtitle
group by DRAWNO,SHEET,REVISION,REFERENCE,GENERALDIM,MACHINEDIM,PRESSDIM,CASTINGDIM,ANGELDIM,SECTIONDIM,BLANKDIM,FINISH
,SCALE,CREATEDATE,CREATER,MODIFYDATE,MODIFIER,BLANKDIMNAME,MIGRATED,BATCH_ID
having count(*) > 1
)
)

insert into tempseq 
select queue from (  -- 50619
select 
DRAWNO,SHEET,REVISION,REFERENCE,GENERALDIM,MACHINEDIM,PRESSDIM,CASTINGDIM,ANGELDIM,SECTIONDIM,BLANKDIM,FINISH
,SCALE,CREATEDATE,CREATER,MODIFYDATE,MODIFIER,BLANKDIMNAME,MIGRATED,BATCH_ID, max(sequencenumber)  queue
from hkmccadtitle
group by DRAWNO,SHEET,REVISION,REFERENCE,GENERALDIM,MACHINEDIM,PRESSDIM,CASTINGDIM,ANGELDIM,SECTIONDIM,BLANKDIM,FINISH
,SCALE,CREATEDATE,CREATER,MODIFYDATE,MODIFIER,BLANKDIMNAME,MIGRATED,BATCH_ID
having count(*) > 1
); commit;




select 
PARTNO,SHEET,REVISION,SPOT,GMAW,SEAM,PLUG,LASER
,UPDATEUSER, max(sequencenumber) queue
from hkmccadweld
group by PARTNO, SHEET, REVISION, SPOT, GMAW, SEAM, PLUG, LASER, UPDATEUSER  
having count(*) > 1

delete tempseq

insert into tempseq
select equeu from (
select 
PARTNO,SHEET,REVISION,VERSION,ECC,ECE,ADR,FMVSS,CMVSS
,DOMESTIC,SRRV,CCC,CREATEUSER,UPDATER, max(sequencenumber) equeu
from hkmccadsafetycls group by PARTNO, SHEET, REVISION, VERSION, ECC, ECE, ADR, FMVSS, CMVSS, DOMESTIC, SRRV, CCC, CREATEUSER, UPDATER
having count(*) > 1
)

select * from tempseq
delete tempseq

insert into tempseq
select queue from (
select 
DRAWNO,SHEET,REVISION,SPECCODE,SPECTYPE,DRAWERID,DEPTCODE, max(sequencenumber) queue
from HKMCCADESMSSPEC group by DRAWNO, SHEET, REVISION, SPECCODE, SPECTYPE, DRAWERID, DEPTCODE
having count(*) > 1
)

update HKMCCADESMSSPEC set sequencenumber = rownum

delete HKMCCADESMSSPEC where sequencenumber in (
select * from tempseq)