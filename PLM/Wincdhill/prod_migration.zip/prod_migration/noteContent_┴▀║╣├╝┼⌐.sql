
-- ��ü �ߺ� üũ
select langtype, ida3a3, seq, count(*) 
from hkmcnotecontent
group by langtype, ida3a3, seq  
having count(*) > 1



select * from EpmDocumentMaster a, EpmDocument b, StampingDrawingLink c, HKMCCadNote d, HKMCNoteContent e
where a.name  '98980A6500'
and a.ida2a2 = b.ida3masterreference
and b.branchiditerationinfo = c.branchida3b5
and c.ida3a5 =  d.ida2a2
and d.ida2a2 = e.ida3a3

select * from epmdocumentmaster
where name like '%98980A6500%'

select * from epmdocument 
where ida3masterreference in (
811943800,
1283927267
)


select * from stampingdrawinglink
where branchida3b5 in (
811944454,
890658733,
890651416,
1285613796,
1285613399,
1283927277
)



select * from hkmccadnote
where drawno = '313603S000'

select * from epmdocumentmaster 
where documentnumber like '313723S000%'

select * from stampingdrawinglink l, epmdocument e, epmdocumentmaster m
where 
m.documentnumber  like '313723S000%' and 
--l.ida3a5 = s.ida2a2 and 
l.branchida3b5 = e.branchiditerationinfo
and e.ida3masterreference = m.ida2a2

select m.*, s.*, e.* from stampingdrawinglink l, epmdocument e, hkmccadesmsspec s, epmdocumentmaster m
where m.documentnumber  like '313603S000%'
and l.ida3a5 = s.ida2a2
and l.branchida3b5 = e.branchiditerationinfo
and e.ida3masterreference = m.ida2a2


select m.*, s.*, e.* from stampingdrawinglink l, epmdocument e, hkmccadtitle s, epmdocumentmaster m
where m.documentnumber  like '98980A6500%'
and l.ida3a5 = s.ida2a2
and l.branchida3b5 = e.branchiditerationinfo
and e.ida3masterreference = m.ida2a2

select m.*, s.*, e.* from stampingdrawinglink l, epmdocument e, hkmccadnote s, epmdocumentmaster m
where m.documentnumber  like '313603S000%'
and l.ida3a5 = s.ida2a2
and l.branchida3b5 = e.branchiditerationinfo
and e.ida3masterreference = m.ida2a2

select m.*, s.*, e.* from stampingdrawinglink l, epmdocument e, hkmccadesmsspec s, epmdocumentmaster m
where m.documentnumber  like '313723S000%'
and l.ida3a5 = s.ida2a2
and l.branchida3b5 = e.branchiditerationinfo
and e.ida3masterreference = m.ida2a2



select * from wttypedefinition
where ida2a2 = 1864488164


-- copy stampingdrawinglink
select distinct a.*
--,c.documentnumber, b.versionida2versioninfo, a.* --, count(*) cnt 
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c
where a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2 -- group by c.documentnumber
and a.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
--and c.documentnumber like '%.CATDRAWING'
and c.documentnumber in(
'98980A6500_01.CATDRAWING',
'989801W000_01.CATDRAWING',
'989801R000_01.CATDRAWING',
'989801P200_01.CATDRAWING',
'989801P100_01.CATDRAWING'
)


-- copy hkmccadnote

select distinct d.*
--,c.documentnumber, b.versionida2versioninfo, a.* --, count(*) cnt 
from stampingdrawinglink a, epmdocument b, epmdocumentmaster c, hkmccadnote d
where a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2 -- group by c.documentnumber
and a.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
--and c.documentnumber like '%.CATDRAWING'
and c.documentnumber in(
'98980A6500_01.CATDRAWING',
'989801W000_01.CATDRAWING',
'989801R000_01.CATDRAWING',
'989801P200_01.CATDRAWING',
'989801P100_01.CATDRAWING'
)
and a.ida3a5 = d.ida2a2

select * from epmdocumentmaster 
where documentnumber like '%.CATPART'


select * from epmdocumentmaster
where documentnumber like '%.CATDRAWING'

select * from epmdocumentmaster
where documentnumber = '0013643635_01.CATDRAWING'

select * from hkmccadnotewbmaudit

delete hkmccadnotewbmaudit

==============

select * from hkmccadnote
order by updatestampa2 desc 

select * from wtdocumentmaster
where ida2a2 = 1870203710
order by updatestampa2 desc 


select ida2a2 from wtdocument
order by ida2a2 desc 

select * from stringvalue
where ida3a4 = 1870203713


 UPDATE APPLICATIONDATA SET FILENAME = 'FENDER_PNL_ǥ�ظ� ���̵�.ppt'  WHERE FILENAME = '035872B400.CATPARTYNAMKUNG';
 

select * from epmdocumentmaster
where documentnumber like '%___.CATDRAWING'

CREATE TABLE "HKMCCADNOTETABLEWBMAUDIT"
  (
    "MIGRATIONSITE"   NUMBER,
    "PLMSILOOBJECTID" NUMBER,
    "TARGETOBJECTID"  NUMBER,
    "CLASS"           VARCHAR2(2000 BYTE)
  )
  SEGMENT CREATION IMMEDIATE PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
  
  
select * from stampingdrawinglink
where 


select * from hkmcnotecontent
order by langtype, seq, ida3a3

select * from hkmccadnote
select * from hkmccadnote

select c.*, a.* from hkmcnotecontent a, hkmccadnote b, stampingdrawinglink c
where a.ida3a3 = b.ida2a2
and b.ida2a2 = c.ida3a5
and a.langtype = 'ko'
order by c.branchida3b5, c.ida3a5, a.seq

order by a.langtype, a.seq, a.ida3a3


select documentnumber , d.* from epmdocumentmaster m, epmdocument d
where d.ida3masterreference = m.ida2a2
and m.documentnumber = '98980A6500_01.CATDRAWING'

1285613393
1285613393
1283927273

select * from stampingdrawinglink a
where a.branchida3b5 in (
1285613393,
1285613393,
1283927273
)

588708

select * from hkmccadnote 

select * from hkmcnotecontent
where classnamekeya3 = 'com.hkmc.cad.HKMCCADNote'
and notecontent is null
where ida3a3 = 1866882659
order by langtype, seq

-- 25725
select ida3a3, seq, count(*), max(ida2a2), min(ida2a2), max(createstampa2), min(createstampa2) from hkmcnotecontent 
--  select * from hkmcnotecontent 
where langtype = 'ko' 
and classnamekeya3 = 'com.hkmc.cad.HKMCCADNote'
group by ida3a3, seq having count(*) > 1
order by ida3a3, seq

-- 25725
delete hkmcnotecontent where ida2a2 in (
    select max(ida2a2) from hkmcnotecontent 
    --  select * from hkmcnotecontent 
    where langtype = 'ko' 
    and classnamekeya3 = 'com.hkmc.cad.HKMCCADNote'
    group by ida3a3, seq having count(*) > 1
    --order by ida3a3, seq
)

