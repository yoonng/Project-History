
select count(*) 
from part_list_delta ec, 
xxebom_odeelatb_bs ela, 
xxebom_ocitemtb_pim_v xx, 
delta_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY (+)
and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no)) ;





select 
	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono       as EONO,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY      as PTC_HKMCKEY,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  C0.name       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	nvl(ela.creation_date, xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(ela.LAST_UPDATE_DATE, xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	ec.u_law_gubn 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	',' || ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	decode(ec.u_part_idno,null,'N','Y') as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	ec.u_simu_simbol 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	ec.u_material 				as material,
	ec.u_dsgn_dweig 			as designWeight, 
	ec.u_goal_dweig 			as goalWeight, 
	ec.u_dsgn_dcost 			as designCost,
	ec.u_goal_dcost 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	ec.u_part_gubun 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	ec.u_project 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	ec.u_transfer 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	ec.u_vendor_drawing 		as venderDrawing, 
	ec.u_dept_code 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  
from part_list_delta ec, 
xxebom_odeelatb_bs ela, 
xxebom_ocitemtb_pim_v xx, 
delta_part_master  C0
where 
C0.objectnumber = xx.oc01_part_no
and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY (+)
and C0.objectnumber = ec.s_part_no;




select u_create_user from part_list_delta 
where 
--u_create_user = '*******'  -- 187000
--and 
u_create_user = 'SYSTEM'  -- 4340000


	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono       as EONO,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY      as PTC_HKMCKEY,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  C0.name       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- ok
	nvl(ela.creation_date, xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(ela.LAST_UPDATE_DATE, xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	ec.u_law_gubn 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	',' || ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	decode(ec.u_part_idno,null,'N','Y') as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	ec.u_simu_simbol 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	ec.u_material 				as material,
	ec.u_dsgn_dweig 			as designWeight, 
	ec.u_goal_dweig 			as goalWeight, 
	ec.u_dsgn_dcost 			as designCost,
	ec.u_goal_dcost 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	ec.u_part_gubun 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	ec.u_project 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	ec.u_transfer 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	ec.u_vendor_drawing 		as venderDrawing, 
	ec.u_dept_code 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  
  
  
select u_vendor_drawing from part_list_delta where u_vendor_drawing is not null


select u_vendor_drawing from part_list  where u_vendor_drawing is not null

select u_spec_con_part from drawsch2