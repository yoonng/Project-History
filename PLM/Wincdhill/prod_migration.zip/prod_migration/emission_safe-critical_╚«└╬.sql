
select oc01_emis_id, count(*) from xxebom_ocitemtb_pim_v group by oc01_emis_id

V	26
1	16
'	4
*	6
R	208805
U	8
3	4
6	12
P	1
I	2
D	65
0	9
A	84868
B	187
C	134049
9	1
 	8500653
E	31723
S	794257
`	1
2	1
--====================='

select od03_ride_c, count(*) from xxebom_odeelatb_bs group by od03_ride_c

P	3
I	11
D	278
C	318505
B	11
5	1
S	1814033
2	2
`	1
V	87
3	6
6	4
9	1
1	2
*	48
'	6
U	78
A	8799
 	13530052
E	112455
R	100662
H	1
0	13

--============='

select U_LAW_GUBN, count(*) from part_list group by U_LAW_GUBN

	8038654
 U	295
RA	2522
CC	41757
RB	9871
RC	4107
CB	241

==========

select U_EM_GUBN, count(*) from part_list group by U_EM_GUBN

	8097238
EA	127
EB	82




