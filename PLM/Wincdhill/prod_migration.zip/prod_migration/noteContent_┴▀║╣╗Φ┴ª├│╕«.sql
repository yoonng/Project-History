
-------- �������� legacydb�� ����

select langtype, ida3a3, seq, min(ida2a2) from hkmcnotecontent 
--where classnamekeya3 = 'com.hkmc.cad.HKMCStdNote'
group by langtype, ida3a3, seq having count(*) > 1

insert into HKMCNOTECONTENT_DELLIST1028
select * from hkmcnotecontent@plmdbadmin
where ida2a2 in (
  select min(ida2a2) from hkmcnotecontent@plmdbadmin 
  --where classnamekeya3 = 'com.hkmc.cad.HKMCStdNote'
  group by langtype, ida3a3, seq having count(*) > 1
)

-------- ����

delete hkmcnotecontent 
where ida2a2 in ( 
  select min(ida2a2) from hkmcnotecontent 
  --where classnamekeya3 = 'com.hkmc.cad.HKMCStdNote'
  group by langtype, ida3a3, seq having count(*) > 1
)

select * from wtpartmaster
where wtpartnumber = '219503S000'

select * from pdmlinkproduct
where ida2a2 = 139234


==== note ��ü ����

select * from stampingdrawinglink
-- delete stampingdrawinglink
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
; commit;


select * from hkmccadnote
-- delete hkmccadnote
; commit;

select * from hkmcnotecontent
-- delete hkmcnotecontent
where classnamekeya3 = 'com.hkmc.cad.HKMCCADNote'
; commit;



select m.documentnumber from stampingdrawinglink l, epmdocument d, epmdocumentmaster m
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and l.branchida3b5 = d.branchiditerationinfo
and d.ida3masterreference = m.ida2a2



==== weld ��ü ����

select l.ida2a2 from stampingdrawinglink l, HKMCCADRevisionReason a
-- delete stampingdrawinglink where ida2a2 in (
      select l.ida2a2 from stampingdrawinglink l, HKMCCADRevisionReason a
      where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
      and l.ida3a5 = a.ida2a2(+)
      and a.ida2a2 is null 
)


select * from stampingdrawinglink
-- delete stampingdrawinglink
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
; commit;


select * from HKMCCADNote 
-- delete HKMCCADNote  
; commit;


select * from HKMCNoteContent 
-- delete HKMCNoteContent  
; commit;


select * from safetyclscodelink
-- delete safetyclscodelink
; commit;


select count(d.ida2a2) from epmdocumentmaster m, epmdocument d
where m.documentnumber like '%_B.CATDRAWING'
and d.ida3masterreference = m.ida2a2

select * from hkmcnoncad


========= hkmccadnote �ߺ� ó��

1341326
select * from stampingdrawinglink@PLMPRD.PLMDBADMINLINK l
where  l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'

select l.brnchida3b5, max(l.ida3a5) 
from stampingdrawinglink l, hkmccadnote n, hkmcnotecontent c
where l.ida3a5 = n.ida2a2
and c.ida3a3 = n.ida2a2
and l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and l.branchida3b5 = 1514612459
group by l.brnchida3b5 

select * from cadnote_key
branch, maxida2a2
-- epm���� max hkmccadnote ida2a2 ����
insert into cadnote_key
select l.branchida3b5, max(l.ida3a5) noteMaxIda2a2
from stampingdrawinglink@PLMPRD.PLMDBADMINLINK l
where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
group by l.branchida3b5 
having count(*) > 1

select * from cadnote_key3
BRANCH, MAXIDA2A2, IDA2A2
-- 1287439
INSERT INTO CADNOTE_KEY3
SELECT L.branchida3b5, A.MAXIDA2A2, L.IDA3A5
from stampingdrawinglink@PLMPRD.PLMDBADMINLINK l, CADNOTE_KEY A
where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
AND L.branchida3b5 = A.branch


INSERT INTO CADNOTE_KEY3
SELECT L.branchida3b5, L.IDA3A5, L.IDA3A5
from stampingdrawinglink@PLMPRD.PLMDBADMINLINK l, CADNOTE_KEY A
where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
AND L.branchida3b5 = A.branch(+)
and a.branch is null

update hkmcnotecontent@PLMPRD.PLMDBADMINLINK set ida3a3 = 
( 
  SELECT T.MAXIDA2A2 FROM CADNOTE_KEY3 T WHERE T.IDA2A2 = IDA3A3
) ; COMMIT; 
where ida3a3 = 2221810882

SELECT * FROM hkmcnotecontent@PLMPRD.PLMDBADMINLINK  L, CADNOTE_KEY3 K
WHERE L.IDA3A3 = K.IDA2A2

select * from hkmcnotecontent@PLMPRD.PLMDBADMINLINK  
where ida2a2 = 2221810887
where ida3a3 = 2221810882
2221812084
com.hkmc.cad.HKMCNoteContent	2221810887


where IDA3A3 NOT IN (
  select branch from cadnote_key
)

      select l.branchida3b5, max(l.ida3a5) noteMaxIda2a2
      from stampingdrawinglink l
      where l.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
      AND branchida3b5 = (select distinct branchida3b5 from stampingdrawinglink where l.ida3a5 = 2221810882 )
      group by l.branchida3b5 
      having count(*) > 1
      
select * from 
