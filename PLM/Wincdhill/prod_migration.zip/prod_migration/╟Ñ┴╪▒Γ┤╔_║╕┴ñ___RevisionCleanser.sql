
--=============== revision cleanser

select classnamekeyb5, ida3b5 -- , ida3c5
from controlbranch
where classnamekeyb5 = 'wt.epm.EPMDocumentMaster'  and ida3b5 = '1470975984' 
group by classnamekeyb5, ida3b5
having count( distinct (ida3c5) ) > 1
;

411524745	823011W320.CATPART
1470975984	823011W320_01.CATDRAWING

select * from controlbranch
where ida3b5 = 1470975984

select d.ida3masterreference, d.versionida2versioninfo, d.ida2a2, b.* , s.*
from controlbranch b, epmdocument d , seriessortvalue s
where b.ida3b5 = 1470975984
and b.ida3c5 = d.ida2a2
and d.versionida2versioninfo = s.value

select d.ida2a2, d.versionida2versioninfo, d.iterationida2iterationinfo   , s.*, d.*
from epmdocument d, seriessortvalue s
where d.ida3masterreference = 1470975984
and d.latestiterationinfo = 1
and d.versionida2versioninfo = s.value
and iterationida2iterationinfo = 1



411524774	--
913421469	XA
939657392	XB
972975846	XC
1946114210	XD
1990594239	00
2233015669	XE

	0		0	--		wt.epm.EPMDocumentMaster	1470975984		0			0	0	11/09/21	0	11/09/21	wt.vc.ControlBranch	1470977019	2	11/09/21			0	c/i
	0	wt.epm.EPMDocument	1470977044	XA		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	1470977019	0	11/09/21	0	11/09/21	wt.vc.ControlBranch	1500195666	1	11/09/21			0	c/i
	0	wt.epm.EPMDocument	1500200157	XB		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	1500195666	0	11/09/22	0	11/09/22	wt.vc.ControlBranch	1548258297	1	11/09/22			0	c/i
	0	wt.epm.EPMDocument	1548263582	XC		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	1548258297	0	11/09/22	0	11/09/22	wt.vc.ControlBranch	1568906948	1	11/09/22			0	c/i
	0	wt.epm.EPMDocument	1568906861	XD		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	1568906948	0	11/10/19	0	11/10/19	wt.vc.ControlBranch	1989167377	1	11/10/19			0	c/i
	0	wt.epm.EPMDocument	1989167398	00		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	1989167377	0	11/10/20	0	11/10/20	wt.vc.ControlBranch	2020848390	1	11/10/20			0	c/i
	0	wt.epm.EPMDocument	2020848409	XE		wt.epm.EPMDocumentMaster	1470975984		0		wt.vc.ControlBranch	2020848390	0	11/11/05	0	11/11/05	wt.vc.ControlBranch	2233022690	1	11/11/05			0	c/i

select * from epmdocument d
where d.versionida2versioninfo = '00';

select mm.* from epmdocumentmaster mm, epmdocument dd
where mm.ida2a2 in (
    select distinct ida3masterreference from epmdocument 
    where ida3masterreference in (
        select d.ida3masterreference from epmdocument d   where d.versionida2versioninfo = '00' and d.latestiterationinfo = 1
        union        
        select d.ida3masterreference from epmdocument d   where d.versionida2versioninfo like 'X_' and d.latestiterationinfo = 1
    )
    group by ida3masterreference 
)
and mm.cadname like '%CATPart'
and dd.ida3masterreference = mm.ida2a2
and dd.versionida2versioninfo = '00';

--======= shownon  �̳���

select * from wtpartmaster m, wtpart p
where wtpartnumber in ( '933003S240', '933003S250' )
and m.ida2a2 = p.ida3masterreference 

select * from configurabledescribelink
where ida3a5 = 855036391 or ida3b5 = 855036391

select * from wttypedefinition
where ida2a2 = 1864471305

--====================
-- ǥ�ر�� table�� '�� #���� �ε��Ǿ���. �����ʿ�

select * from hkmccode;
select * from hkmccodetype;
select * from hkmccodename;

select distinct n.* from hkmccodename n, hkmccodetype t
where n.ida3a4 = t.ida2a2
and t.codetype = 'STDFUN'
;
select distinct n.* from hkmccodename n, hkmccodetype t
where n.ida3a4 = t.ida2a2
and t.codetype = 'STDFUN'
and n.name like '%#%'
;

select * from hkmccodename 
where name like '%#%'
and id
;

select * 
from hkmccode c, hkmccodetype t, hkmccodename n
where c.ida3a4 = t.ida2a2
and n.ida3a4 = c.ida2a2
and t.codetype = 'STDFUN'
and n.name like '%#%'
;

select c.code, n.name 
from hkmccode c, hkmccodetype t, hkmccodename n
where c.ida3a4 = t.ida2a2
and n.ida3a4 = c.ida2a2
and t.codetype = 'STDFUN'
and n.name like '%#%'
;

select * from wtpartmaster
where name like '%#%'

select * from wtpartmaster
where wtpartnumber like 'EQ00%' AND name like '%#%'
;

select * from wtpartmaster m, (
    select c.code, n.name 
    from hkmccode c, hkmccodetype t, hkmccodename n
    where c.ida3a4 = t.ida2a2
    and n.ida3a4 = c.ida2a2
    and t.codetype = 'STDFUN'
    and n.name like '%#%'
) ss
where m.wtpartnumber like '%' || ss.code || '%'
and m.name = ss.name
;
