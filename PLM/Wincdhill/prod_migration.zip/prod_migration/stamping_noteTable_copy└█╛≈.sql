
select * from hkmccadnotetable@plmprd.plmdbadminlink



insert into stampingdrawinglink@plmprd.plmdbadminlink
select * from stampingdrawinglink@plmdbadmin
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNoteTable'

insert into hkmccadnotetable@plmprd.plmdbadminlink
select * from hkmccadnotetable@plmdbadmin

insert into hkmccadnotetablecontent@plmprd.plmdbadminlink
select * from hkmccadnotetablecontent@plmdbadmin


select d.namecontainerinfo, c.* 
from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b, epmdocumentmaster@plmdbadmin c, PDMLinkProduct@plmdbadmin d
where a.classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNoteTable'
and a.branchida3b5 = b.branchiditerationinfo
and b.ida3masterreference = c.ida2a2
and c.ida3containerreference = d.ida2a2





SELECT * FROM EPMDOCUMENTMASTER a ,EPMDOCUMENT b,STAMPINGDRAWINGLINK c, hkmccadsafetyclassification d, SAFETYCLSCODELINK e, HKMCCODE f
WHERE a.NAME LIKE '311293T000%'
AND a.ida2a2 = b.IDA3MASTERREFERENCE
AND b.LATESTITERATIONINFO = 1
AND b.BRANCHIDITERATIONINFO = c.BRANCHIDA3B5
AND c.IDA3A5 = d.IDA2A2
AND d.IDA2A2 = e.IDA3A5
AND e.IDA3B5 = f.IDA2A2