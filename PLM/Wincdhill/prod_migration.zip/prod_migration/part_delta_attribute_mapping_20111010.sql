
select * from xxebom_odeelatb_bs

update xxebom_odeelatb_bs set PTC_HKMCKEY = trim(od03_rpno_c) || trim(eono);

--delete DELTA_PART_MASTER_STAGING

insert into DELTA_PART_MASTER_STAGING
select 
	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono       as EONO,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY      as PTC_HKMCKEY,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  C0.name       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(to_char(trim(ela.created_by)), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	nvl(to_char(ela.creation_date), xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(to_char(ela.LAST_UPDATE_DATE), xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	ec.u_law_gubn 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	',' || ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	decode(ec.u_part_idno,null,'N','Y') as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	ec.u_simu_simbol 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	ec.u_material 				as material,
	ec.u_dsgn_dweig 			as designWeight, 
	ec.u_goal_dweig 			as goalWeight, 
	ec.u_dsgn_dcost 			as designCost,
	ec.u_goal_dcost 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	ec.u_part_gubun 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	ec.u_project 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	ec.u_transfer 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	ec.u_vendor_drawing 		as venderDrawing, 
	ec.u_dept_code 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  
from 
part_list_delta_staging ec, 
xxebom_odeelatb_bs_staging ela, 
xxebom_ocitemtb_pim_v_staging  xx, 
delta_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY (+)
and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no));

commit;

1472521 --

==========================

insert into DELTA_PART_MASTER_STAGING2
select 
	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono       as EONO,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY      as PTC_HKMCKEY,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  C0.name       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(to_char(trim(ela.created_by)), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	nvl(to_char(ela.creation_date), xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(to_char(ela.LAST_UPDATE_DATE), xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	'' 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	',' || ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	'' as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	'' 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	'' 				as material,
	'' 			as designWeight, 
	'' 			as goalWeight, 
	'' 			as designCost,
	'' 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	'' 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	'' 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	'' 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	'' 		as venderDrawing, 
	'' 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  
from 
--part_list_delta_staging ec, 
xxebom_odeelatb_bs_staging ela, 
xxebom_ocitemtb_pim_v_staging  xx, 
delta_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY (+);
--and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no));

commit;

1700761
1472521
228240

insert into delta_part_master_staging
select * from delta_part_master_staging2
where PTC_HKMCKEY in (
    select PTC_HKMCKEY from delta_part_master_staging2
    minus
    select PTC_HKMCKEY from delta_part_master_staging
);

commit;


select count(*) from delta_part_master_staging  -- 1700751

select * from delta_part_master_staging
where ptc_hkmckey in (
'495AECM002H0XB0164',
'495AECM002H0XB0180',
'541005k000PLM01',
'254201e300PLM01',
'671 z06X24BJ226',
'8659028000K4XB0248',
'8659028000K4XB0254',
'628336b000F6B20009',
'8448043011LfPLM01',
'915105k020F5K20011',
'853014A000ciPLM01',
'393003C300C2BBE348'
)

select ptc_hkmckey from delta_part_master_staging group by ptc_hkmckey having count(*) > 1
======================

INSERT INTO part_list_delta_STAGING  -- 1130145
select * from part_list_delta  where upper(trim(s_part_no)) in (
   select upper(trim(objectnumber)) from delta_part_master )


INSERT INTO xxebom_odeelatb_bs_STAGING   -- 1949551
select * from xxebom_odeelatb_bs where PTC_HKMCKEY in (
   select PTC_HKMCKEY from delta_part_master ) 


INSERT INTO xxebom_ocitemtb_pim_v_STAGING   -- 1222031
select * from xxebom_ocitemtb_pim_v where upper(trim(oc01_part_no)) in (
   select upper(trim(objectnumber)) from delta_part_master )

update delta_part_master_staging 
set objectnumber = upper(trim(objectnumber)),
PTC_HKMCKEY = upper(trim(PTC_HKMCKEY))

select objectnumber, count(*) from delta_part_master_staging group by objectnumber having count(*) > 1


update delta_part_master_staging 
set createdby = decode( createdby, '-1', decode(updatedby, '-1', '', updatedby) , createdby), 
updatedby = decode(updatedby, '-1', '', updatedby),
testreq = replace(testreq, ' ', ''), 
created = replace(created, '/', ''), 
updated = replace(updated, '/', '')


select ptc_hkmckey, decode( createdby, '-1', updatedby, createdby), decode(updatedby, '-1', '', updatedby)
from delta_part_master_staging

select ptc_hkmckey, decode( createdby, '-1', updatedby, createdby), decode(updatedby, '-1', '', updatedby),
replace(testreq, ' ', ''), replace(created, '/', ''), replace(updated, '/', '')
from delta_part_master_staging

select count(*) from delta_part_master_staging  -- 1700751



====
select *
from 
( select * from part_list_delta  where upper(trim(s_part_no)) in (
   select upper(trim(objectnumber)) from delta_part_master ) ) ec, 
( select * from xxebom_odeelatb_bs where PTC_HKMCKEY in (
   select PTC_HKMCKEY from delta_part_master ) ) ela, 
( select * from xxebom_ocitemtb_pim_v where upper(trim(oc01_part_no)) in (
   select upper(trim(objectnumber)) from delta_part_master ) )  xx, 
delta_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY (+)
and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no));

select distinct upper(trim(C0.objectnumber)) from delta_part_master

=============
=============


select * 
from part_list_delta ec, 
( select z.* , trim(z.od03_rpno_c) || trim(z.eono) PTC_HKMCKEY from xxebom_odeelatb_bs z ) ela, 
xxebom_ocitemtb_pim_v xx, 
delta_part_master  C0
where 
C0.objectnumber = xx.oc01_part_no
and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY = ela.PTC_HKMCKEY(+)
and C0.objectnumber = ec.s_part_no

update xxebom_odeelatb_bs set PTC_HKMCKEY = trim(od03_rpno_c) || trim(eono);

======== counting
select count(*) from part_list_delta                   --8653955
select count(distinct trim(s_part_no)) from part_list_delta  --8653949

select * from part_list_delta 
where s_part_no in (
'0745639258',
'665343B000',
'665333B000',
'665343B900',
'0745639255',
'665323B000'
)
--select s_part_no from part_list_delta group by s_part_no having count(*) > 1

select count(*) from DELTA_PART_MASTER  -- 2,197,116

select * from xxebom_odeelatb_bs     where u_eo_no is not null  -- 2454
==========

select * from DELTA_PART_MASTER a, part_list_delta b  -- 1,552,767
where trim(a.objectnumber) = trim(b.s_part_no)
--where a.objectnumber = b.s_part_no

select count(*) from DELTA_PART_MASTER a, (select distinct s_part_no from part_list_delta ) b 
where a.objectnumber = b.s_part_no(+)
=====

select count(*) from DELTA_PART_MASTER a, xxebom_odeelatb_bs b  -- 1,949,548
where trim(a.objectnumber) = trim(b.od03_rpno_c) -- no �� �񱳽� 5674432
and  trim(a.eono) = trim(b.eono) 

select count(*) from DELTA_PART_MASTER a, (select distinct od03_rpno_c from xxebom_odeelatb_bs ) b 
where a.objectnumber = b.od03_rpno_c(+)
=========

select count(*) from DELTA_PART_MASTER a, xxebom_ocitemtb_pim_v b  -- 976,456
where trim(a.objectnumber) = trim(b.oc01_part_no) -- no �� �񱳽� 1700717
and trim(a.eono) = trim(b.oc01_last_eono)

select count(*) from DELTA_PART_MASTER a, (select distinct oc01_part_no from xxebom_ocitemtb_pim_v ) b 
where a.objectnumber = b.oc01_part_no(+)
========

select count(distinct a.objectnumber)  from DELTA_PART_MASTER a   -- 1612199

select count(distinct a.eono)  from DELTA_PART_MASTER a   -- 103977

select distinct a.eono  from DELTA_PART_MASTER a   -- 310
where eono like 'PLM%'
-- 22193==> PLM%

select a.ptc_hkmckey, b.od03_rpno_c || b.eono, c.oc01_part_no || c.oc01_last_eono, d.s_part_no
from DELTA_PART_MASTER a, xxebom_odeelatb_bs b, xxebom_ocitemtb_pim_v c, part_list_delta d
where a.ptc_hkmckey = b.od03_rpno_c || b.eono (+)
and  a.ptc_hkmckey = c.oc01_part_no
and a.objectnumber = d.s_part_no 


========= create table 

CREATE TABLE "LEGACYDB"."DELTA_PART_MASTER_STAGING"
  (
    "OBJECTNUMBER" VARCHAR2(50 BYTE),
    "EONO"         VARCHAR2(30 BYTE),
    "EODATE" DATE,
    "PTC_HKMCKEY"    VARCHAR2(200 BYTE),
    "ISLOADED"       VARCHAR2(1 BYTE),
    "CONTAINER"      VARCHAR2(40 BYTE),
    "LIFECYCLE"      VARCHAR2(40 BYTE),
    "LIFECYCLESTATE" VARCHAR2(40 BYTE),
    "FOLDERPATH"     VARCHAR2(40 BYTE),
    "TYPE"           VARCHAR2(40 BYTE),
    "GENERICTYPE"    VARCHAR2(40 BYTE),
    "NAME"           VARCHAR2(240 BYTE),
    "UNITOFMEASURE"  VARCHAR2(3 BYTE),
    "CREATEDBY"      VARCHAR2(50 BYTE),
    "CREATED"        VARCHAR2(150 BYTE),
    "UPDATEDBY"      VARCHAR2(50 BYTE),
    "UPDATED"        VARCHAR2(150 BYTE),
    "REGULATION"     VARCHAR2(2 BYTE),
    "DRGID"          VARCHAR2(150 BYTE),
    "REVCD"          VARCHAR2(150 BYTE),
    "TESTREQ"        VARCHAR2(16 BYTE),
    "ITEMFLAG"       VARCHAR2(150 BYTE),
    "GROUP_T"        VARCHAR2(150 BYTE),
    "COLORID"        VARCHAR2(150 BYTE),
    "SOURCE_T"       VARCHAR2(150 BYTE),
    "VALIDATIONCD"   VARCHAR2(150 BYTE),
    "EMISSION"       VARCHAR2(150 BYTE),
    "ISALTSEL"       VARCHAR2(2 BYTE),
    "SIMULTANEOUS"   VARCHAR2(1 BYTE),
    "ALTRREASON"     VARCHAR2(2 BYTE),
    "MATERIAL"       VARCHAR2(100 BYTE),
    "DESIGNWEIGHT"   VARCHAR2(12 BYTE),
    "GOALWEIGHT"     VARCHAR2(12 BYTE),
    "DESIGNCOST"     VARCHAR2(12 BYTE),
    "VARIABLECOST"   VARCHAR2(12 BYTE),
    "REMARK"         VARCHAR2(60 BYTE),
    "PARTTYPE"       VARCHAR2(1 BYTE),
    "PREEONO"        VARCHAR2(20 BYTE),
    "APLVEHICLES"    VARCHAR2(200 BYTE),
    "CCN"            VARCHAR2(150 BYTE),
    "TRANSFER"       VARCHAR2(1 BYTE),
    "PNC"            VARCHAR2(150 BYTE),
    "VENDERDRAWING"  VARCHAR2(15 BYTE),
    "PARTDEPT"       VARCHAR2(10 BYTE),
    "ISINSTALL"      VARCHAR2(150 BYTE),
    "UNIT"           VARCHAR2(3 BYTE),
    "HKMCREVISION"   VARCHAR2(10 BYTE),
    "ADDIN"          VARCHAR2(1 BYTE)
  )
  SEGMENT CREATION IMMEDIATE PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
  
CREATE INDEX "LEGACYDB"."RPH22$NOEONO" ON "LEGACYDB"."DELTA_PART_MASTER_STAGING"
  (
    "OBJECTNUMBER",
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;
CREATE INDEX "LEGACYDB"."REWORK22$EONO" ON "LEGACYDB"."DELTA_PART_MASTER_STAGING"
  (
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."REWORK22$PTCKEY" ON "LEGACYDB"."DELTA_PART_MASTER_STAGING"
  (
    "PTC_HKMCKEY"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."RPH22$PARTNUMBER" ON "LEGACYDB"."DELTA_PART_MASTER_STAGING"
  (
    "OBJECTNUMBER"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;