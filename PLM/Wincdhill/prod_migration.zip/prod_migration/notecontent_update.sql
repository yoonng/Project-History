
update hkmcnotecontent@PLMPRD.PLMDBADMINLINK set ida3a3 = 
( 
  SELECT T.MAXIDA2A2 FROM CADNOTE_KEY3 T WHERE T.IDA2A2 = IDA3A3
) 
where ida3a3 in (
  SELECT T.IDA2A2 FROM CADNOTE_KEY3 T 
)
; COMMIT; 


select (SELECT T.MAXIDA2A2 FROM CADNOTE_KEY3 T WHERE T.IDA2A2 = IDA3A3) keys, a.* 
from  hkmcnotecontent@PLMPRD.PLMDBADMINLINK a
where ida3a3 in (
  SELECT T.IDA2A2 FROM CADNOTE_KEY3 T 
)


update cadnote_key3 set ID = rownum

select branch, maxida2a2, ida2a2 from cadnote_Key3 where ID < 300000


select branch, maxida2a2, ida2a2 from cadnote_Key3 where ID >= 300000 and ID < 600000

C:\table_export(cadnoteKey4).csv

select branch, maxida2a2, ida2a2 from cadnote_Key3 where ID >= 600000 and ID < 900000


select branch, maxida2a2, ida2a2 from cadnote_Key3 where ID >= 900000 