
select count(distinct s_draw_no) from drawsch2_delta  -- 534445
select count(distinct upper(trim(s_draw_no)) ) from drawsch2_delta  -- 534426
select count(distinct trim(s_draw_no) ) from drawsch2_delta  -- 534429
select count(*) from tempseq  -- 534429
select count(*) from tempseq2 -- 528708

insert into tempseq
select distinct trim(s_draw_no) from drawsch2_delta


insert into tempseq2 -- 528708
select distinct a.s_draw_no from drawsch2 a, tempseq b
where upper(trim(a.s_draw_no)) = upper(b.partno)

select count(*) from tempseq  -- 534429
select count(*) from tempseq2 -- 528708

select max( u_create )  from drawsch2_delta  -- 2011-10-08 11:40:30.663894
select max( u_create )  from catia_model_1003_bak  -- 2011-10-03 15:30:13.953709
select max( u_create )  from drawsch2_1003_bak  -- 2011-10-03 15:30:13.79657
select max( u_create )  from part_list_1003_bak  -- 2011-10-04 22:04:44.093256

select count(*) from catia_model_1003_bak  -- 1,163,083
select count(*)  from drawsch2_1003_bak    -- 1,470,047
select count(*)  from part_list_1003_bak   -- 8,639,400
select * from part_list_1003_bak

-------------------------
insert into part_list_1003_diff
select distinct upper(trim(s_part_no)) -- , nvl(upper(trim(u_revision)), '--') 
from part_list_1003_bak;

commit;

delete part_list_1003_diff;
-------------------------
insert into catia_model_1003_diff
select distinct upper(trim(s_draw_no)), nvl(upper(trim(s_revision)), '--'), upper(trim(s_sheet)) 
from catia_model_1003_bak;

commit;
-------------------------
insert into drawsch2_1003_diff
select distinct upper(trim(s_draw_no)), nvl(upper(trim(s_revision)), '--'), upper(trim(s_sheet)) 
from drawsch2_1003_bak;

commit;
-------------------------
select * from 
--part_list_1003_diff
catia_model_1003_diff
drawsch2_1003_diff

update catia_model_1003_diff set keys = partno || revision || sheet; commit;
update drawsch2_1003_diff set keys = partno || revision || sheet; commit;

select keys, count(*) from catia_model_1003_diff group by keys having count(*) > 1
select keys, count(*) from drawsch2_1003_diff group by keys having count(*) > 1

select count(*) from ecims_master_no_diff  
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 1
-- 3�� ����
--1142322
insert into ecims_master_no_diff
select distinct a.partno, b.revision, b.sheet, 'Y', 'Y', 'Y' from 
part_list_1003_diff a,
drawsch2_1003_diff b,
catia_model_1003_diff c
where a.partno = b.partno 
and b.keys = c.keys ;
-- and b.partno = c.partno  and b.revision  = c.revision  and b.sheet  = c.sheet;

commit;

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2
-- partlist, drawsch2 ����
-- 306934

insert into ecims_master_no_diff
select distinct a.partno, b.revision, b.sheet, 'Y', 'Y', 'N' from 
part_list_1003_diff a,
drawsch2_1003_diff b,
catia_model_1003_diff c
where a.partno = b.partno
and b.keys = c.keys(+) 
and c.keys is null;
-- and b.partno = c.partno  and b.revision  = c.revision  and b.sheet  = c.sheet;

commit;

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3
-- catia_model�� ����
-- 6

insert into ecims_master_no_diff
select distinct c.partno, c.revision, c.sheet, 'N', 'N', 'Y' 
from part_list_1003_diff a, ( 
    select cc.partno, cc.revision, cc.sheet
    from drawsch2_1003_diff bb, catia_model_1003_diff cc
    where cc.keys = bb.keys(+) and bb.keys is null
) c
where c.partno = a.partno(+) and a.partno is null;

commit;

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 4
-- drawsch2�� catia_model�� ����

insert into ecims_master_no_diff
select distinct c.partno, c.revision, c.sheet , 'N', 'Y', 'Y' 
from part_list_1003_diff a, ( 
    select cc.partno, cc.revision, cc.sheet
    from drawsch2_1003_diff bb, catia_model_1003_diff cc
    where cc.keys = bb.keys
) c
where c.partno = a.partno(+) and a.partno is null;

commit;

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 5
-- partlist�� catia_model�� ����
-- 52 
insert into ecims_master_no_diff
select distinct c.partno, c.revision, c.sheet , 'N', 'Y', 'Y' 
from part_list_1003_diff a, ( 
    select cc.partno, cc.revision, cc.sheet
    from drawsch2_1003_diff bb, catia_model_1003_diff cc
    where cc.keys = bb.keys(+) and bb.partno is null
) c
where c.partno = a.partno;

commit;

