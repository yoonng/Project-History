SGARC340-BH 60/60(MS191-07), 0.7T
SPRC340(MS121-65)1.0T

(MS�� �����ڷ� 
�տ���   : Material :  ptc_str_35TYPEINFOWTPART
Ms �ڵ�  : PartMSNO :   ptc_str_33TYPEINFOWTPART 
�� �β�  : MaterialThickness :  ptc_dbl_6TYPEINFOWTPART, ptc_lng_11TYPEINFOWTPART 
�� Comment : MComment : ptc_str_3TYPEINFOWTPART


select * from xxebom_ocitemtb_pim_v

select * from xxebom_odeelatb_bs

select s_part_no, u_material from part_list
where u_material is not null
and trim(u_material) <> 'SEE DETAILS'
and trim(u_material) <> 'SEE DRG'
and trim(u_material) <> 'SEE DRW'
and trim(u_material) <> 'SEE DR`G'
and trim(u_material) <> 'SEE DETAIL'
and trim(u_material) <> 'SEE NOTES'
and trim(u_material) <> 'SEE NOTE'
and u_material like '%(MS%'


select count( u_material ) from part_list
where u_material is not null
and trim(u_material) <> 'SEE DETAILS'
and trim(u_material) <> 'SEE DRG'
and trim(u_material) <> 'SEE DETAIL'

'PU SLAB FOAM SPEC NO MS257-06 UF-4857133S300'

select s_part_no, u_material from part_list
where u_material like '%(ES%'
