
======================================== alt üũ
-- 2202
select * from xxebom_odetxttb_bs a, xxebom_odetxttb_bs b
where a.od05_gbcd_c = 'AT' and b.od05_gbcd_c = 'AT'
and a.od05_ptno_c = b.od05_desc_c
and b.od05_ptno_c = a.od05_desc_c

-- 82
select * from xxebom_odetxttb_bs a
where a.od05_gbcd_c = 'AT' 
and a.od05_ptno_c = a.od05_desc_c

======================================== sel üũ
-- 363
select * from xxebom_odetxttb_bs a, xxebom_odetxttb_bs b
where a.od05_gbcd_c = 'SP' and b.od05_gbcd_c = 'SP'
and a.od05_ptno_c = b.od05_desc_c
and b.od05_ptno_c = a.od05_desc_c

-- 19
select * from xxebom_odetxttb_bs a
where a.od05_gbcd_c = 'SP' 
and a.od05_ptno_c = a.od05_desc_c


======================================== KD üũ
-- 6342
select * from xxebom_odetxttb_bs a, xxebom_odetxttb_bs b
where a.od05_gbcd_c = 'KD' and b.od05_gbcd_c = 'KD'
and a.od05_ptno_c = b.od05_desc_c
and b.od05_ptno_c = a.od05_desc_c

-- 6292
select * from xxebom_odetxttb_bs a
where a.od05_gbcd_c = 'KD' 
and a.od05_ptno_c = a.od05_desc_c


======================================== SHOWNON üũ
-- 36447
select * from xxebom_odetxttb_bs a, xxebom_odetxttb_bs b
where a.od05_gbcd_c = 'SH' and b.od05_gbcd_c = 'SH'
and a.od05_ptno_c = b.od05_desc_c
and b.od05_ptno_c = a.od05_desc_c

-- 10165
select * from xxebom_odetxttb_bs a
where a.od05_gbcd_c = 'SH' 
and a.od05_ptno_c = a.od05_desc_c



@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@

select * from exthmc3
where s_type = 'SPECON' 


select * from exthmc3
where s_type = 'SPECON' 
and s_drawing_no in (
'073113E220',
'073114D010',
'073114D010',
'073114D020'
)

and s_sheet <> '1.0'


-- insert into CONSENTEDPARTLINK@PLMPRD.staging
select s_drawing_no, s_child_new, SUBSTR(u_seq_c, 0, LENGTH(u_seq_c) -2 ) itemno, s_level, u_qty_new, 
SUBSTR(s_sheet, 0, LENGTH(s_sheet) -2 ) sheet, '0', '3', rownum
from exthmc3 
where s_type = 'SPECON' 
and to_date(SUBSTR(u_create, 0, 10 ), 'yyyy-MM-dd')  < to_date('2011-04-01', 'yyyy-MM-dd') 
and s_child_new is not null and s_next_assy is null 
and trim(s_child_new) in (select partnumber from rm3_partmaster) -- part Ȯ��
and (s_drawing_no, s_sheet, s_revision) in ( select epmnumber, sheet, revision from rm3_epmlastversion )  -- CAD �ֽŹ��� Ȯ��



select * from part_list
select distinct u_cuse_c from part_list