
select * from cadneutral@plmdb.staging

select * from hkmccadecdfiles@plmdb.staging

select * from epmdocumentmaster@plmdbadmin 

select * from neutral_epm_attached a
where a.user_guide is not null

select * from neutral_epm_attached a, epmdocumentmaster@plmdbadmin b
where a.user_guide is not null
and a.documentnumber = b.documentnumber

-- 261
select * from neutral_epm_attached a, epmdocumentmaster@plmdbadmin b
where a.user_guide is not null
and a.documentnumber || '.CATPART' = b.documentnumber


select * from neutral_epm_attached a, epmdocumentmaster@plmdbadmin b
where a.user_guide is not null
and a.documentnumber || '.MODEL' = b.documentnumber


insert into cadneutral@plmdb.staging
select upper(cad_filename), '', '', '/ptcvault/ecd/neutral',  user_guide, rownum, 0, 3
from neutral_epm_attached 
where user_guide is not null



===============


CREATE TABLE "PLMDBADMIN"."CADNEUTRALWBMAUDIT"
  (
    "MIGRATIONSITE"   NUMBER,
    "PLMSILOOBJECTID" NUMBER,
    "TARGETOBJECTID"  NUMBER,
    "CLASS"           VARCHAR2(2000 BYTE)
  )
  SEGMENT CREATION IMMEDIATE PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;