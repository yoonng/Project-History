

@@ stampingdrawinglink

select * from stampingdrawinglink@plmprd.plmdbadminlink
select classnamekeyroleaobjectref, count(*) from stampingdrawinglink@plmprd.plmdbadminlink group by classnamekeyroleaobjectref

com.hkmc.cad.HKMCCADSafetyClassification	1
com.hkmc.cad.HKMCCADNote	676820
com.hkmc.cad.HKMCCADTitle	1
com.hkmc.cad.HKMCCADWeld	1
com.hkmc.cad.HKMCCADRevisionReason	2

select * from stampingdrawinglink@plmdbadmin -- oid�� ����
select classnamekeyroleaobjectref, count(*) from stampingdrawinglink@plmdbadmin group by classnamekeyroleaobjectref

com.hkmc.cad.HKMCCADSafetyClassification	577  
select count(*) from HKMCCADSafetyClassification@plmdbadmin
com.hkmc.cad.HKMCCADNote	1257443
select count(*) from HKMCCADNote@plmdbadmin
com.hkmc.cad.HKMCCADTitle	173465
select count(*) from HKMCCADTitle@plmdbadmin
com.hkmc.cad.HKMCCADRevisionReason	196540
select count(*) from HKMCCADRevisionReason@plmdbadmin
com.hkmc.cad.HKMCCADESMSSpec	439699
select count(*) from HKMCCADESMSSpec@plmdbadmin

select * from stampingdrawinglink@plmprd.plmdbadminlink
intersect
select * from stampingdrawinglink@plmdbadmin b


insert into stampingdrawinglink@plmprd.plmdbadminlink
select 
CLASSNAMEKEYROLEAOBJECTREF,IDA3A5 + 8000000000000,BRANCHIDA3B5,CLASSNAMEKEYROLEBOBJECTREF,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2
from stampingdrawinglink@plmdbadmin
where CLASSNAMEKEYROLEAOBJECTREF <> 'com.hkmc.cad.HKMCCADNote'



@@@@@@@@@@@@@@@@@@@@@@@@@@= ok
stampingdrawinglink, HKMCCADSafetyClassification, SafetyClsCodeLink 

--- data ����  HKMCCADSafetyClassification
select a.*  from stampingdrawinglink@plmdbadmin a, HKMCCADSafetyClassification@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null

select a.*  from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADSafetyClassification'
and a.branchida3b5 = b.branchiditerationinfo(+)
and b.ida2a2 is null

insert into HKMCCADSafetyClassification@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR, IDA3CREATOR,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,CREATESTAMPA2,MARKFORDELETEA2,MODIFYSTAMPA2,
CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADSafetyClassification@plmdbadmin

insert into SafetyClsCodeLink@plmprd.plmdbadminlink
select CLASSNAMEKEYROLEAOBJECTREF,IDA3A5 + 8000000000000,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2
from SafetyClsCodeLink@plmdbadmin

@@@@@@@@@@@@@@@@@@@@@@@@@@= ok -- ���� ����-- �Ϻ� ����.
stampingdrawinglink, HKMCCADNote, HKMCNOTECONTENT

select count(*) from HKMCCADNote@plmprd.plmdbadminlink
select count(*) from HKMCCADNote@plmdbadmin
--- data ����  HKMCCADNote
select a.*  from stampingdrawinglink@plmdbadmin a, HKMCCADNote@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null

select a.*  from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADNote'
and a.branchida3b5 = b.branchiditerationinfo(+)
and b.ida2a2 is null

@@@@@@@@@@@@@@@@@@@@@@@@@@= ok
stampingdrawinglink, HKMCCADTitle

select count(*) from HKMCCADTitle@plmdbadmin
--- data ����  HKMCCADTitle
select a.*  from stampingdrawinglink@plmdbadmin a, HKMCCADTitle@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADTitle'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null

select a.*  from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADTitle'
and a.branchida3b5 = b.branchiditerationinfo(+)
and b.ida2a2 is null

insert into HKMCCADTitle@plmprd.plmdbadminlink
select ANGLEDIM,BLANKDIM,BLANKDIMNAME,CASTINGDIM,CLASSNAMEKEYCREATOR,IDA3CREATOR,FINISH,GENERALDIM,MACHINEDIM,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,PRESSDIM
,REFERENCE,SCALE,SECTIONDIM,CREATESTAMPA2,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,
UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADTitle@plmdbadmin

@@@@@@@@@@@@@@@@@@@@@@@@@@= ok
select count(*) from HKMCCADRevisionReason@plmdbadmin
--- data ����  HKMCCADRevisionReason
select a.*  from stampingdrawinglink@plmdbadmin a, HKMCCADRevisionReason@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null

select a.*  from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADRevisionReason'
and a.branchida3b5 = b.branchiditerationinfo(+)
and b.ida2a2 is null

insert into HKMCCADRevisionReason@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR,IDA3CREATOR,ISDETAIL,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,REASON,SEQ,SUBREV,CREATESTAMPA2,MARKFORDELETEA2
,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADRevisionReason@plmdbadmin


@@@@@@@@@@@@@@@@@@@@@@@@@@= ok
select * from HKMCCADESMSSpec@plmdbadmin
--- data ����  HKMCCADESMSSpec
select a.*  from stampingdrawinglink@plmdbadmin a, HKMCCADESMSSpec@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADESMSSpec'
and a.ida3a5 = b.ida2a2(+)
and b.ida2a2 is null

select a.*  from stampingdrawinglink@plmdbadmin a, epmdocument@plmdbadmin b
where classnamekeyroleaobjectref = 'com.hkmc.cad.HKMCCADESMSSpec'
and a.branchida3b5 = b.branchiditerationinfo(+)
and b.ida2a2 is null

insert into HKMCCADESMSSpec@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR,IDA3CREATOR,CLASSNAMEKEYA5,IDA3A5,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,SPECCODE,SPECTYPE,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADESMSSpec@plmdbadmin

@@@@@@@@@@@@@@@@@@@@@@@@@@=

insert into stampingdrawinglink@plmprd.plmdbadminlink
select * from stampingdrawinglink@plmdbadmin

select * from epmdocument@plmdbadmin 

@@ hkmccadesmsspec

select * from hkmccadesmsspec@plmprd.plmdbadminlink

select * from hkmccadesmsspec@plmdbadmin -- oid�� ����

insert into hkmccadesmsspec@plmprd.plmdbadminlink
select * from hkmccadesmsspec@plmdbadmin

@@ hkmccadnote


@@ hkmccadrevisionreason


@@ hkmccadsafetycls


@@ hkmccadtitle


@@ hkmcstdnote


@@


=================================================
=================================================

insert into stampingdrawinglink@plmprd.plmdbadminlink
select 
CLASSNAMEKEYROLEAOBJECTREF,IDA3A5 + 8000000000000,BRANCHIDA3B5,CLASSNAMEKEYROLEBOBJECTREF,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2
from stampingdrawinglink@plmdbadmin
where CLASSNAMEKEYROLEAOBJECTREF <> 'com.hkmc.cad.HKMCCADNote';
commit;


insert into HKMCCADSafetyClassification@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR, IDA3CREATOR,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,CREATESTAMPA2,MARKFORDELETEA2,MODIFYSTAMPA2,
CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADSafetyClassification@plmdbadmin;
commit;

insert into SafetyClsCodeLink@plmprd.plmdbadminlink
select CLASSNAMEKEYROLEAOBJECTREF,IDA3A5 + 8000000000000,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2,MARKFORDELETEA2,
MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2
from SafetyClsCodeLink@plmdbadmin;
commit;

insert into HKMCCADTitle@plmprd.plmdbadminlink
select ANGLEDIM,BLANKDIM,BLANKDIMNAME,CASTINGDIM,CLASSNAMEKEYCREATOR,IDA3CREATOR,FINISH,GENERALDIM,MACHINEDIM,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,PRESSDIM
,REFERENCE,SCALE,SECTIONDIM,CREATESTAMPA2,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,
UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADTitle@plmdbadmin;
commit;

insert into HKMCCADRevisionReason@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR,IDA3CREATOR,ISDETAIL,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,REASON,SEQ,SUBREV,CREATESTAMPA2,MARKFORDELETEA2
,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADRevisionReason@plmdbadmin;
commit;

insert into HKMCCADESMSSpec@plmprd.plmdbadminlink
select CLASSNAMEKEYCREATOR,IDA3CREATOR,CLASSNAMEKEYA5,IDA3A5,CLASSNAMEKEYMODIFIER,IDA3MODIFIER,SPECCODE,SPECTYPE,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2 + 8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
from HKMCCADESMSSpec@plmdbadmin;
commit;
