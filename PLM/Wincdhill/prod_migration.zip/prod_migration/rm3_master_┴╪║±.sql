
select a.documentnumber, b.namecontainerinfo 
from epmdocumentmaster@plmdbadmin a, pdmlinkproduct@plmdbadmin b
where a.ida3containerreference = b.ida2a2



select * from hkmcpart@PLMDB.STAGING

select namecontainerinfo from pdmlinkproduct@plmdbadmin 

select a.wtpartnumber, b.namecontainerinfo 
from wtpartmaster@plmdbadmin a, pdmlinkproduct@plmdbadmin b
where a.ida3containerreference = b.ida2a2

=========== real query 

insert into rm3_partmaster_1020
select a.wtpartnumber, b.namecontainerinfo 
from wtpartmaster@plmdbadmin a, pdmlinkproduct@plmdbadmin b
where a.ida3containerreference = b.ida2a2;

commit;


insert into rm3_epmmaster_1020
select a.documentnumber, b.namecontainerinfo 
from epmdocumentmaster@plmdbadmin a, pdmlinkproduct@plmdbadmin b
where a.ida3containerreference = b.ida2a2;

commit;


