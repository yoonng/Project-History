select * from 

select * from HKMCASSupplyManual --308
select * from HKMCSTDNOTE 
select * from HKMCVENDMSTR(VendUser)
select * from HKMCStandardPartName
select * from HKMCStdPartNameReq
select * from HKMCStdPartNameReqDet
select * from HKMCStandardWord
select * from Vendesms
select * from VendList
