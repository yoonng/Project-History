
============ shownon ��ũ�� ������ �ش� Role A�� drgid�� S�� set

select * from configurabledescribelink
where ida2typedefinitionreference in (
'2167959607',
'1864471305'
)

A  wt.part.WTPart	1100818761	
B  wt.part.WTPart	1100533995
wt.configurablelink.ConfigurableDescribeLink	1869175328

select * from wtpart
where ida2a2 = 1100818761

select ptc_str_13TYPEINFOWTPART from wtpart
where ida2a2 in (
    select ida3a5 from configurabledescribelink
    where ida2typedefinitionreference in (
    '2167959607',
    '1864471305'
    )
)

update wtpart  set ptc_str_13TYPEINFOWTPART = 'S'
where ida2a2 in (
    select ida3a5 from configurabledescribelink
    where ida2typedefinitionreference in (
    '2167959607',
    '1864471305'
    )
);
commit;

