 
original data count : 71718

update xxebom_odeelatb_bs set ptc_hkmckey = upper(trim(od03_rpno_c)) || upper(trim(eono));
commit;

select upper(trim(od03_rpno_c)) || upper(trim(eono)) from xxebom_odeelatb_bs



-------------- ready  17560
select ptc_hkmckey, substr(ptc_hkmckey, 0, length(ptc_hkmckey)-2), eono, substr(eono, 0, length(eono)-2)
from delta2_part_master
where ptc_hkmckey like '%-1'
and eono like '%-1'

update delta2_part_master 
set ptc_hkmckey = substr(ptc_hkmckey, 0, length(ptc_hkmckey)-2), 
eono = substr(eono, 0, length(eono)-2)



select *  from delta2_part_master
select count(*) from delta2_part_master  -- 23912

22070
 1848
------------ step 0
part_list_delta ec, 
xxebom_odeelatb_bs ela, 
xxebom_ocitemtb_pim_v  xx, 

DELETE part_list_delta_staging3

-- 33538
insert into part_list_delta_staging3 
select * from part_list_delta 
where upper(trim(s_part_no)) in (
    select distinct objectnumber from delta2_part_master
);
commit;



DELETE xxebom_odeelatb_bs_staging3

-- 132772
insert into xxebom_odeelatb_bs_staging3
select * from xxebom_odeelatb_bs 
where upper(trim(od03_rpno_c)) in (
    select distinct objectnumber from delta2_part_master
);
commit;


DELETE xxebom_ocitemtb_pim_v_staging3

-- 70731
insert into xxebom_ocitemtb_pim_v_staging3
select * from xxebom_ocitemtb_pim_v 
where upper(trim(oc01_part_no)) in (
    select distinct objectnumber from delta2_part_master
);
commit;


------------ step 0-1
-- create table 

CREATE TABLE "LEGACYDB"."DELTA2_PART_MASTER_STAGING2"
  (
    "OBJECTNUMBER" VARCHAR2(50 BYTE),
    "EONO"         VARCHAR2(30 BYTE),
    "EONO2"         VARCHAR2(30 BYTE),
    "EODATE" DATE,
    "PTC_HKMCKEY"    VARCHAR2(200 BYTE),
    "PTC_HKMCKEY2"    VARCHAR2(200 BYTE),
    "ISLOADED"       VARCHAR2(1 BYTE),
    "CONTAINER"      VARCHAR2(40 BYTE),
    "LIFECYCLE"      VARCHAR2(40 BYTE),
    "LIFECYCLESTATE" VARCHAR2(40 BYTE),
    "FOLDERPATH"     VARCHAR2(40 BYTE),
    "TYPE"           VARCHAR2(40 BYTE),
    "GENERICTYPE"    VARCHAR2(40 BYTE),
    "NAME"           VARCHAR2(240 BYTE),
    "UNITOFMEASURE"  VARCHAR2(3 BYTE),
    "CREATEDBY"      VARCHAR2(50 BYTE),
    "CREATED"        VARCHAR2(150 BYTE),
    "UPDATEDBY"      VARCHAR2(50 BYTE),
    "UPDATED"        VARCHAR2(150 BYTE),
    "REGULATION"     VARCHAR2(2 BYTE),
    "DRGID"          VARCHAR2(150 BYTE),
    "REVCD"          VARCHAR2(150 BYTE),
    "TESTREQ"        VARCHAR2(16 BYTE),
    "ITEMFLAG"       VARCHAR2(150 BYTE),
    "GROUP_T"        VARCHAR2(150 BYTE),
    "COLORID"        VARCHAR2(150 BYTE),
    "SOURCE_T"       VARCHAR2(150 BYTE),
    "VALIDATIONCD"   VARCHAR2(150 BYTE),
    "EMISSION"       VARCHAR2(150 BYTE),
    "ISALTSEL"       VARCHAR2(2 BYTE),
    "SIMULTANEOUS"   VARCHAR2(1 BYTE),
    "ALTRREASON"     VARCHAR2(2 BYTE),
    "MATERIAL"       VARCHAR2(100 BYTE),
    "DESIGNWEIGHT"   VARCHAR2(12 BYTE),
    "GOALWEIGHT"     VARCHAR2(12 BYTE),
    "DESIGNCOST"     VARCHAR2(12 BYTE),
    "VARIABLECOST"   VARCHAR2(12 BYTE),
    "REMARK"         VARCHAR2(60 BYTE),
    "PARTTYPE"       VARCHAR2(1 BYTE),
    "PREEONO"        VARCHAR2(20 BYTE),
    "APLVEHICLES"    VARCHAR2(200 BYTE),
    "CCN"            VARCHAR2(150 BYTE),
    "TRANSFER"       VARCHAR2(1 BYTE),
    "PNC"            VARCHAR2(150 BYTE),
    "VENDERDRAWING"  VARCHAR2(15 BYTE),
    "PARTDEPT"       VARCHAR2(10 BYTE),
    "ISINSTALL"      VARCHAR2(150 BYTE),
    "UNIT"           VARCHAR2(3 BYTE),
    "HKMCREVISION"   VARCHAR2(10 BYTE),
    "ADDIN"          VARCHAR2(1 BYTE),
    "ISNOTITEM"   VARCHAR2(10 BYTE)
  )
  SEGMENT CREATION IMMEDIATE PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
  
CREATE INDEX "LEGACYDB"."RPH22122$NOEONO" ON "LEGACYDB"."DELTA2_PART_MASTER_STAGING2"
  (
    "OBJECTNUMBER",
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;
CREATE INDEX "LEGACYDB"."REWORK22122$EONO" ON "LEGACYDB"."DELTA2_PART_MASTER_STAGING2"
  (
    "EONO"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."REWORK22122$PTCKEY" ON "LEGACYDB"."DELTA2_PART_MASTER_STAGING2"
  (
    "PTC_HKMCKEY"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "USERS" ;
CREATE INDEX "LEGACYDB"."RPH22122$PARTNUMBER" ON "LEGACYDB"."DELTA2_PART_MASTER_STAGING2"
  (
    "OBJECTNUMBER"
  )
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS STORAGE
  (
    INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT
  )
  TABLESPACE "INDX" ;

------------------ step1
DELETE DELTA2_PART_MASTER_STAGING2

insert into DELTA2_PART_MASTER_STAGING
select 
	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono2       as EONO,
  C0.eono2       as EONO2,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY2      as PTC_HKMCKEY,
  C0.PTC_HKMCKEY2      as PTC_HKMCKEY2,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  --C0.name       as "name" ,
  ''       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(to_char(trim(ela.created_by)), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	nvl(to_char(ela.creation_date), xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(to_char(ela.LAST_UPDATE_DATE), xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	ec.u_law_gubn 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	decode(ec.u_part_idno,null,'N','Y') as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	ec.u_simu_simbol 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	ec.u_material 				as material,
	ec.u_dsgn_dweig 			as designWeight, 
	ec.u_goal_dweig 			as goalWeight, 
	ec.u_dsgn_dcost 			as designCost,
	ec.u_goal_dcost 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	ec.u_part_gubun 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	ec.u_project 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	ec.u_transfer 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	ec.u_vendor_drawing 		as venderDrawing, 
	ec.u_dept_code 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  ,
  ''    as ISNOTITEM
  --  select * 
from 
part_list_delta_staging3 ec, 
xxebom_odeelatb_bs_staging3 ela, 
xxebom_ocitemtb_pim_v_staging3  xx, 
delta2_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY2 = ela.PTC_HKMCKEY (+)
and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no));

commit;  -- 35293

------------------ step2

insert into DELTA2_PART_MASTER_STAGING2
select 
	C0.objectnumber 			as objectnumber, 
	--ela.eono 				    as EONO, -------------------------------------------- ok
  C0.eono       as EONO,
  C0.eono2       as EONO2,
	C0.EODATE  as EODATE,
	--xx.oc01_part_no|| ela.eono  as PTC_HKMCKEY,  -------------------------------------------- ok
  C0.PTC_HKMCKEY      as PTC_HKMCKEY,
  C0.PTC_HKMCKEY2      as PTC_HKMCKEY2,
--  C0.isloaded   as isloaded,
  ''    as isloaded, 
  ''    as "container",
  ''    as lifecycle,
  ''    as lifecyclestate,
  ''    as folderpath,
  ''    as "type",
  ''    as generictype,
	--ela.OD03_RPNM_C			as "name",  -------------------------------------------- ok
  --C0.name       as "name" ,
  ''       as "name" ,
--  C0.eono 				    as EONO1, 
	--ela.OD03_RUNT_C 			as unitofmeasure, -------------------------------------------- ok
  xx.oc01_unit_c    as unitofmeasure,
	nvl(to_char(trim(ela.created_by)), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- ok
	--nvl(ela.created_by, ec.u_create_user)  			as createdby,   -------------------------------------------- err
	--nvl(trim(ela.created_by), xx.oc01_repl_man)  			as createdby,   -------------------------------------------- err
	--ela.created_by  			as createdby,   -------------------------------------------- err
	nvl(to_char(ela.creation_date), xx.OC01_LAST_DATE) 			as created,   -------------------------------------------- ok
	xx.oc01_repl_man 			as updatedby, 			--�� A���� �����ڰ� ��� NULL
	nvl(to_char(ela.LAST_UPDATE_DATE), xx.OC01_LAST_DATE ) 		as "updated",  --------------------------------------------  ok
	'' 				as regulation, 
	xx.oc01_type_c 				as drgID,
	ela.od03_rrec_c 			as REVCD,    -------------------------------------------- ???  ok
  -------------------------------------------- ok
	ela.OD03_RTRN_C || ',' || ela.OD03_RTRD_C || ',' || ela.OD03_RTRL_C || ',' || ela.OD03_RTRF_C || ',' || ela.OD03_RTRE_C || ',' || ela.OD03_RTRR_C as TestREQ,	
  --------------------------------------------ok
	nvl(ela.OD03_RGUB_C, xx.oc01_gubn_c) 			as itemFlag,--------------------------------------------ok
	nvl(ela.OD03_RGRP_C, xx.oc01_grup_c) 			as GROUP_T,--------------------------------------------ok
	nvl(ela.OD03_RCID_C, xx.oc01_colr_id) 			as ColorID,--------------------------------------------ok
	nvl(ela.OD03_RSRE_C, xx.oc01_sour_main) 			as SOURCE_T,--------------------------------------------ok
	nvl(ela.od03_rval_c, xx.oc01_val0_c) 			as validationCD,--------------------------------------------ok
	nvl(ela.OD03_RIDE_C, xx.oc01_emis_id) 			as emission,--------------------------------------------ok
	'' as ISALTSEL,	--boolean true/false  altselpno �� null �� �ƴϸ� true �� ����
	'' 			as SIMULTANEOUS, 
--	ec.u_part_idno 				as ALT_SELPNO,
	ela.OD03_WHY0_C  			as altReason,-------------------------------------------- ok
	'' 				as material,
	'' 			as designWeight, 
	'' 			as goalWeight, 
	'' 			as designCost,
	'' 			as VariableCost, 
	ela.OD03_RRMK_C 			as Remark,--------------------------------------------  ok
	'' 			as partType,
  ( select t405_eono_cpre from preeogab where t405_eono_c = c0.eono ) as PREEONO,
	'' 				as APLVehicles, 
	nvl(ela.OD03_RCCN_C, xx.oc01_ccn0_no) 			as CCN,   --------------------------------------------  ok 
	'' 				as TRANSFER,
	nvl(ela.OD03_PNC0_NO, xx.oc01_pnc0_no) 			as pnc,--------------------------------------------ok
	'' 		as venderDrawing, 
	'' 				as PartDept,
  xx.oc01_didi_c    as isinstall,
  xx.oc01_unit_c    as unit,
  ela.od03_rrec_c    as hkmcrevision,--------------------------------------------ok
  ''    as addin  ,
  --C0.isnotitem    as ISNOTITEM
  ''    as ISNOTITEM
  --  select * 
from 
--part_list_delta_staging3 ec, 
xxebom_odeelatb_bs_staging3 ela, 
xxebom_ocitemtb_pim_v_staging3  xx, 
delta2_part_master  C0
where 
upper(trim(C0.objectnumber)) = upper(trim(xx.oc01_part_no))
--and  C0.eono =  xx.oc01_last_eono
--and C0.objectnumber = ela.od03_rpno_c
--and  C0.eono =  ela.eono
and C0.PTC_HKMCKEY2 = ela.PTC_HKMCKEY (+);
--and upper(trim(C0.objectnumber)) = upper(trim(ec.s_part_no));

commit;  -- 17560

------------------ step3


insert into DELTA2_PART_MASTER_STAGING
select * from DELTA2_PART_MASTER_STAGING2
where PTC_HKMCKEY in (
    select PTC_HKMCKEY from DELTA2_PART_MASTER_STAGING2
    minus
    select PTC_HKMCKEY from DELTA2_PART_MASTER_STAGING
);

commit;

select a.rowid, a.* from DELTA2_PART_MASTER_STAGING  a
where ptc_hkmckey in (
    select ptc_hkmckey from DELTA2_PART_MASTER_STAGING group by ptc_hkmckey having count(*) > 1
)
order by ptc_hkmckey

-- delete DELTA2_PART_MASTER_STAGING
where 

-- 71738
select count(*) from delta2_part_master_staging

update DELTA2_PART_MASTER_STAGING 
set createdby = decode( createdby, '-1', decode(updatedby, '-1', '', updatedby) , createdby), 
updatedby = decode(updatedby, '-1', '', updatedby),
testreq = replace(testreq, ' ', ''), 
created = replace(created, '/', ''), 
updated = replace(updated, '/', '');

commit;

select * from delta2_part_master
where ptc_hkmckey = '692003S010XP4KB0003'
692003S010XP4KB0003	692003S010X	P4KB0003
692003S010XP4KB0003
select * from 

in (
select ptc_hkmckey from delta2_part_master
minus
select ptc_hkmckey from delta2_part_master_staging
)

select * from xxebom_ocitemtb_pim_v
where oc01_part_no = '692003S010X'

select * from xxebom_odeelatb_bs
where (od03_rpno_c, eono) in ( ('692003S010X','P4KB0003') )

select * from delta2_part_master_staging2
where objectnumber = '692003S010X'
