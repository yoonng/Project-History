
select * from code_table_1003_bak
where to_date(codcrd, 'yyyy-MM-dd') > to_date('2011-03-31', 'yyyy-MM-dd')

select cod001, cod002, cod003, cod004, codcrd, codupd, codusr, cod005, cod006
from code_table_1003_bak  where cod001 <> 'DEPT'
minus
select cod001, cod002, cod003, cod004, codcrd, codupd, codusr, cod005, cod006
from code_table where cod001 <> 'DEPT'

delete assy_part_1020;
delete catia_model_1020;
delete catia_work_model_1020;
delete code_table_1020;
delete doclist_1020;
delete drawing_note_1020;
delete drawrevi_1020;
delete drawsch2_1020;
delete drawtag_1020;
delete drawweld_1020;
delete exthmc3_1020;
delete lawemtb_1020;
delete lpbhist_1020;
delete lpbpart_1020;
delete mstrtbm_1020;
delete mstrtbs_1020;
delete ncadlend_1020;
delete ncadmflm_1020;
delete part_esms_1020;
delete part_list_1020;
delete skinmstr_1020;
delete stndnote_1020;
delete stndrqst_1020;
delete stndword_1020;
delete vault_1020;
delete vendesms_1020;
delete vendlist_1020;


delete ncaddraw_1020;
delete stnddetl_1020;
delete vendmstr_1020;

commit;




select count(*) from  assy_part_1020;
select count(*) from  catia_model_1020;
select count(*) from  catia_work_model_1020;
select count(*) from  code_table_1020;
select count(*) from  doclist_1020;
select count(*) from  drawing_note_1020;
select count(*) from  drawrevi_1020;
select count(*) from  drawsch2_1020;
select count(*) from  drawtag_1020;
select count(*) from  drawweld_1020;
select count(*) from  exthmc3_1020;
select count(*) from  lawemtb_1020;
select count(*) from  lpbhist_1020;
select count(*) from  lpbpart_1020;
select count(*) from  mstrtbm_1020;
select count(*) from  mstrtbs_1020;
select count(*) from  ncadlend_1020;
select count(*) from  ncadmflm_1020;
select count(*) from  part_esms_1020;
select count(*) from  part_list_1020;
select count(*) from  skinmstr_1020;
select count(*) from  stndnote_1020;
select count(*) from  stndrqst_1020;
select count(*) from  stndword_1020;
select count(*) from  vault_1020;
select count(*) from  vendesms_1020;
select count(*) from  vendlist_1020;


select count(*) from  ncaddraw_1020;
select count(*) from  stnddetl_1020;
select count(*) from  vendmstr_1020;


