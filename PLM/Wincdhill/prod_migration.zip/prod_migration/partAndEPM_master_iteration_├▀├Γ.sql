
=========== part

select * from production_extraction

select distinct type from production_extraction

7748944 rows deleted

insert into rm3_partmaster
select distinct objectnumber, container from hkmcpart@staging 

select * from hkmcpart@staging
where objectnumber in (
select objectnumber from hkmcpart@staging
group by objectnumber, container having count(*) > 1
)

select * from hkmcpart@staging
where objectnumber in (
    select aa.objectnumber from (
        select distinct objectnumber, container from hkmcpart@staging
    ) aa
    group by aa.objectnumber, aa.container having count(*) > 1
)

insert into rm3_partmaster
select distinct objectnumber,  from hkmcpart@STAGING

delete rm3_partmaster


insert into rm3_partlastversion 
select oc01_part_no, nvl(trim(oc01_last_rev), '--'),  nvl(trim(oc01_last_eono), '--'), nvl(trim(oc01_unit_c), '--')
from xxebom_ocitemtb_pim_v
where org_id = 84
and oc01_part_no in ( 
    select partnumber from rm3_partmaster
)

insert into rm3_partlastversion 

select * 
from xxebom_ocitemtb_pim_v


select * from hkmcpart@staging
where objectnumber in (
'8582334101D',
'8582334101DAQ',
'0K24T1828Y',
'0K24T20380A',
'0K24T25700',
'0K24T3201074',
'0K24T3201077',
'0K24T32980AB',
'0K24T3298075',
'0K24T3298096',
'0K24T42131'
)

select * from hkmcpart@staging   -- 15865
where objectnumber  in (
select partnumber from rm3_partmaster
group by partnumber having count(*) > 1
)
order by objectnumber, container 

select * from rm3_partmaster   -- 15865
where partnumber  in (
select partnumber from rm3_partmaster
group by partnumber having count(*) > 1
)
order by partnumber, container 

=========== epm

8659124010_01.CATDrawing  container�� �� ����.


select * from production_extraction
where doc_number = '8659124010_01.CATDrawing'

327373 rows inserted

insert into rm3_epmmaster
select distinct doc_number, container from production_extraction

select * from rm3_epmmaster
where docnumber like '%Drawing'

delete rm3_epmmaster

insert into rm3_epmlastversion  (epmnumber, sheet, revision, eono)
select distinct trim(a.s_draw_no), a.s_sheet, nvl(trim(a.s_revision), '--'), a.u_eono_c from drawsch2 a, (
  select s_draw_no, s_sheet, max(u_create) createdate from drawsch2 group by s_draw_no, s_sheet
) b
where a.s_draw_no = b.s_draw_no
and a.s_sheet = b.s_sheet
and a.u_create = b.createdate


select * from rm3_epmmaster
where docnumber in (
select docnumber from rm3_epmmaster
group by docnumber having count(*) > 1
)
and docnumber like '%Drawing'
order by docnumber, container

select * from 