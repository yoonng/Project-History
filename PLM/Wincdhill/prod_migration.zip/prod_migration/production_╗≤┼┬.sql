
  select * from hkmccodetype where ida2a2 = 102286
  
  select * from hkmccode where ida3a4 = 102286
  select * from hkmccode where code like '%_CHECK'
  
  select * from hkmccodetype where codetype like '%SAFE%'
  

select  count(*) from hkmcmicrofilm 
======
select * from epmdocumentmaster

select  count(m.ida2a2) from epmdocumentmaster m
where documentnumber like '%_B.CATDRAWING' 
--436751

--477790
select  count(d.ida2a2) from epmdocumentmaster m, epmdocument d
where documentnumber like '%_B.CATDRAWING' 
and d.ida3masterreference = m.ida2a2
======

select * from wttypedefinition where ida2a2 = 1864468284

select * from wttypedefinitionmaster where ida2a2 = 1864488164

delete configurablemasterslink

==========
��ĳ�� ������ ���� üũ

select m.documentnumber, d. from epmdocumentmaster m, epmdocument d
where  m.ida2a2 in ( 
    select distinct mm.ida2a2 from epmdocumentmaster mm, epmdocument dd
    where m.documentnumber like '%_B.CATDRAWING'
    and dd.versionida2versioninfo = '--'
)
and d.ida3masterreference = m.ida2a2

update hkmccadrevisionreason set subrev = subrev2222

d.versionida2versioninfo

select * from epmdocument


select * from itemnolink