
==================
select * from hkmccadesmsspec 
select * from stampingdrawinglink ;

select * from hkmccadesmsspec where ida2a2 in ( 2998002296
);

-- delete hkmccadesmsspec where ida2a2 in ( 2998002296
);

select * from stampingdrawinglink where ida3a5 in (2998002296
);


SELECT A0.*
  FROM HKMCCADESMSSpec A0,StampingDrawingLink A1
  WHERE (A1.branchIdA3B5 = 445358899) AND (A0.specCode = 'MS201-02') AND (A0.specType = 'M')
;

select * from stampingdrawinglink where branchida3b5 in ( 445358899,
    445206073,
    445358899
    )
;
--  delete stampingdrawinglink where ida3a5 in (2998002296
);

select * from epmdocument;
select * from epmdocumentmaster m where ida2a2 in (
    select ida3masterreference from epmdocument where branchiditerationinfo in ( 445358899,
    445206073,
    445358899
    )
);

====================

select * from hkmcnotecontent where ida3a3 in ( 2219927303, 2996726867 )
order by ida3a3, seq, ida2a2;

select * from hkmccadnote where ida2a2 =2219927303 ;

delete hkmcnotecontent where ida2a2 in ( 2996782604,
2996782605);

select * from hkmcnotecontent where ida2a2 > 2996827063

  SELECT A0.*
  FROM HKMCNoteContent A0
  WHERE (A0.idA2A2 = 2219927303) AND (A0.seq = 1)

------ model�� catdrawing�� ���ÿ� �����ϴ°� search




-- 5999 �ߺ� �̰͵��� ��� ��ε� ==> stamping ����
select name, count(*) from (
  select substr(documentnumber, 0, length(documentnumber) -6) name from epmdocumentmaster where documentnumber like '%.MODEL'   -- 180243
  union all
  select substr(documentnumber, 0, length(documentnumber) -11) name from epmdocumentmaster 
  where documentnumber not like '%_B.CATDRAWING' and documentnumber like '%.CATDRAWING'   -- 89024
) nums 
group by name
having count(*) > 1
;

==== note �������� ���� �ߺ����� �������ΰ͵� ����
;

select *   -- 2830
from dup_epmlist_cat_model dl, hkmccadnote@PLMPRD.staging sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;
---
update hkmccadnote set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadnote set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

update hkmccadnote_bak set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadnote_bak set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

---
select * 
from dup_epmlist_cat_model dl, hkmccadnote_bak@PLMPRD.staging sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;

insert into hkmccadnote
select * from hkmccadnote_bak2 where batch_id like '%DUP12'
;

select * from hkmccadnote
order by drawno, sheet, revision, seq;


select drawno, sheet, revision, seq, max(sequencenumber), count(*) 
from hkmccadnote 
group by drawno, sheet, revision, seq
having count(*) > 1
;

select * from hkmccadnote aa, (
select drawno, sheet, revision, seq, max(sequencenumber), count(*) 
from hkmccadnote  where batch_id like '%DUP12'
group by drawno, sheet, revision, seq
having count(*) > 1
) bb
where aa.drawno = bb.drawno and aa.sheet = bb.sheet
and aa.revision = bb.revision and aa.seq = bb.seq
order by aa.drawno, aa.sheet, aa.revision, aa.seq
;


update hkmccadnote set batch_id = 'NOLOADING'
where sequencenumber in ( 
    select distinct bb.maxsequencenumber from hkmccadnote aa, (
        select drawno, sheet, revision, seq, max(sequencenumber) maxsequencenumber, count(*) 
        from hkmccadnote   where batch_id like '%DUP12'
        group by drawno, sheet, revision, seq
        having count(*) > 1
    ) bb
    where aa.drawno = bb.drawno and aa.sheet = bb.sheet
    and aa.revision = bb.revision and aa.seq = bb.seq
--    order by aa.drawno, aa.sheet, aa.revision, aa.seq
)
;

87049
1012
28

select * from hkmccadnote@PLMPRD.staging where batch_id <> 'NOLOADING' and createdate not like '%/%' ;

@@@@@@@@@@@@@@@@@@@@@@
==== hkmccadesmsspec �������� ���� �ߺ����� �������ΰ͵� ����
;

select *   -- 2830
from dup_epmlist_cat_model dl, hkmccadesmsspec sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;
---
update hkmccadesmsspec set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadesmsspec set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

update hkmccadesmsspec set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadesmsspec set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

---
select * 
from dup_epmlist_cat_model dl, hkmccadnote_bak@PLMPRD.staging sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;

insert into hkmccadnote
select * from hkmccadnote_bak2 where batch_id like '%DUP12'
;

select * from hkmccadesmsspec
order by drawno, sheet, revision, seq;


select drawno, sheet, revision, speccode, max(sequencenumber), count(*) 
from hkmccadesmsspec 
group by drawno, sheet, revision, speccode
having count(*) > 1
;

select * from hkmccadesmsspec aa, (
select drawno, sheet, revision, speccode, max(sequencenumber), count(*) 
from hkmccadesmsspec  where batch_id like '%DUP12'
group by drawno, sheet, revision, speccode
having count(*) > 1
) bb
where aa.drawno = bb.drawno and aa.sheet = bb.sheet
and aa.revision = bb.revision and aa.speccode = bb.speccode
order by aa.drawno, aa.sheet, aa.revision, aa.speccode
;


update hkmccadnote set batch_id = 'NOLOADING'
where sequencenumber in ( 
    select distinct bb.maxsequencenumber from hkmccadnote aa, (
        select drawno, sheet, revision, seq, max(sequencenumber) maxsequencenumber, count(*) 
        from hkmccadnote   where batch_id like '%DUP12'
        group by drawno, sheet, revision, seq
        having count(*) > 1
    ) bb
    where aa.drawno = bb.drawno and aa.sheet = bb.sheet
    and aa.revision = bb.revision and aa.seq = bb.seq
--    order by aa.drawno, aa.sheet, aa.revision, aa.seq
)
;

87049
1012
28


@@@@@@@@@@@@@@@@@@@@@@
==== hkmccadrevisionreason �������� ���� �ߺ����� �������ΰ͵� ����
;

select *   -- 61084
from dup_epmlist_cat_model dl, hkmccadrevisionreason sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;
--- 4 
update hkmccadrevisionreason set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadrevisionreason set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

update hkmccadrevisionreason set batch_id = batch_id || 'REASONNULL'
-- select * from hkmccadrevisionreason
where batch_id like '%DUP12' and reason is null;



@@@@@@@@@@@@@@@@@@@@@@
==== hkmccadweld �������� ���� �ߺ����� �������ΰ͵� ����
;

select *   -- 61084
from dup_epmlist_cat_model dl, hkmccadweld sd
where ( dl.docnumber  = sd.drawno || '_' || sd.sheet ) or
( dl.docnumber  = sd.drawno || '_0' || sd.sheet )
;
--- 4 
update hkmccadweld set batch_id = batch_id || 'DUP12'
where  drawno || '_' || sheet in ( select docnumber from dup_epmlist_cat_model ) ;

update hkmccadrevisionreason set batch_id = batch_id || 'DUP12'
where ( drawno || '_0' || sheet in ( select docnumber from dup_epmlist_cat_model ) );

update hkmccadrevisionreason set batch_id = batch_id || 'REASONNULL'
-- select * from hkmccadrevisionreason
where batch_id like '%DUP12' and reason is null;



@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
==================================

select * 
from epmdocumentmaster where documentnumber like '%.MODEL'
and length(documentnumber) < 20 ;
-- 180243



STRINGVALUE_1208_ESMSNO

===========;
select * from stringdefinition where name in ('ES_NO', 'MS_NO')

select * from stringvalue
where ida3a6 in ( 42422, 42429)



select ida3a4, value, count(*) from stringvalue
where ida3a6 in ( 42422, 42429) group by ida3a4, value
having count(*) > 1


-- delete stringvalue where ida2a2 in (
    select max(ida2a2) from stringvalue
    where ida3a6 in ( 42422, 42429) group by ida3a4, value
    having count(*) > 1
)

insert into STRINGVALUE_1208_ESMSNO 
select * from stringvalue
where ida2a2 in (
    select max(ida2a2) from stringvalue
    where ida3a6 in ( 42422, 42429) group by ida3a4, value
    having count(*) > 1
)

delete hkmccadnotewbmaudit