
select d.logicalidentifier, b.wtpartnumber, c.wtpartnumber 
from configurablemasterslink a, wtpartmaster b, wtpartmaster c, wttypedefinition d


select branchida2typedefinitionrefe, l.ida2typedefinitionreference, count(*) , 
    (select d.logicalidentifier from wttypedefinition d where d.ida2a2 = l.ida2typedefinitionreference ) typename
from configurabledescribelink l
group by branchida2typedefinitionrefe, l.ida2typedefinitionreference

1864471324	1864471328	33197	kr.co.hkmc.AltSelLink
50589	2167959607	74	kr.co.hkmc.ShownOnPartLink
50589	1864471305	3211409	kr.co.hkmc.ShownOnPartLink
1864471324	2167959614	28782	kr.co.hkmc.AltSelLink



======== plmmig
50589	2116099126	757   -- ShownOnPartLink
1864471324	1864471328	33197
1864471324	2116099132	27
50589	1864471305	3192182   -- ShownOnPartLink
=====

select branchida2typedefinitionrefe, ida2typedefinitionreference, count(*)  , 
    (select d.logicalidentifier from wttypedefinition d where d.ida2a2 = l.ida2typedefinitionreference ) typename
from configurablemasterslink l
group by branchida2typedefinitionrefe, ida2typedefinitionreference

1878438775	15234 -- ConsentedPartLink
1878438750	381   -- HKMCKDPartLink
1864468290	43030 -- HKMCKDPartLink
1878438771	1878438775	15234
51367	1864468290	43030
51367	1878438750	381

1878438771	2167950732	6	kr.co.hkmc.ConsentedPartLink
1878438771	1878438775	15674	kr.co.hkmc.ConsentedPartLink
51367	2167950725	2	kr.co.hkmc.HKMCKDPartLink
51367	1864468290	43030	kr.co.hkmc.HKMCKDPartLink
51367	1878438750	381	kr.co.hkmc.HKMCKDPartLink

select * from wttypedefinition
where ida2a2 in (
2116099126,1864471328,2116099132,1864471305
)
    1864468290 , 1878438750, 1878438775, 1864471328,  1864471305 
)

1864468290	kr.co.hkmc.HKMCKDPartLink
1878438750	kr.co.hkmc.HKMCKDPartLink
1864471305	kr.co.hkmc.ShownOnPartLink
1864471328	kr.co.hkmc.AltSelLink
1878438775	kr.co.hkmc.ConsentedPartLink



==============


select branchida2typedefinitionrefe, ida2typedefinitionreference, count(*) from configurabledescribelink group by branchida2typedefinitionrefe ,ida2typedefinitionreference

1864471328	33197  -- AltSelLink
1864471305	3190092  -- ShownOnPartLink
1864471324	1864471328	33197
50589	1864471305	3190092

1870057358	11  -- ShownOnPartLink
1864488171	7  -- ShownOnPartLink
1870057351	255    -- ShownOnPartLink
1864488164	430    -- ShownOnPartLink
50589	1870057351	502
1864474611	1864488171	7
1864474611	1870057358	11
50589	1864488164	523


select branchida2typedefinitionrefe, ida2typedefinitionreference, count(*) from configurablemasterslink group by branchida2typedefinitionrefe, ida2typedefinitionreference

1878438775	15234 -- ConsentedPartLink
1878438750	381   -- HKMCKDPartLink
1864468290	43030 -- HKMCKDPartLink
1878438771	1878438775	15234
51367	1864468290	43030
51367	1878438750	381

1870057005	2 -- HKMCKDPartLink
1865108337	1 -- HKMCKDPartLink
1870053398	12 -- ConsentedPartLink
1865108330	10 -- ConsentedPartLink
51367	1870057005	2
1864473951	1865108330	10
1864473951	1870053398	12
51367	1865108337	1
1878438771	1878438775	15234
51367	1864468290	43030
51367	1878438750	381


select * from wttypedefinition
where ida2a2 in (
    1870057358,1870057351,1864488171,1864488164, 1870057005,1870053398,1865108337,1865108330
)

1864468290	kr.co.hkmc.HKMCKDPartLink
1878438750	kr.co.hkmc.HKMCKDPartLink
1864471305	kr.co.hkmc.ShownOnPartLink
1864471328	kr.co.hkmc.AltSelLink
1878438775	kr.co.hkmc.ConsentedPartLink


1864488164	kr.co.hkmc.ShownOnPartLink
1870057351	kr.co.hkmc.ShownOnPartLink
1865108330	kr.co.hkmc.ConsentedPartLink
1870053398	kr.co.hkmc.ConsentedPartLink
1865108337	kr.co.hkmc.HKMCKDPartLink
1870057005	kr.co.hkmc.HKMCKDPartLink
1864488171	kr.co.hkmc.AltSelLink
1870057358	kr.co.hkmc.AltSelLink



================config ��ũ mig���� ����� ����

select 
CLASSNAMEKEYDOMAINREF,IDA3DOMAINREF,INHERITEDDOMAIN,CLASSNAMEKEYROLEAOBJECTREF,IDA3A5,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
,PTC_LNG_1TYPEINFOCONFIGURABL,PTC_LNG_2TYPEINFOCONFIGURABL,PTC_LNG_3TYPEINFOCONFIGURABL,PTC_LNG_4TYPEINFOCONFIGURABL
,PTC_STR_1TYPEINFOCONFIGURABL,PTC_STR_2TYPEINFOCONFIGURABL,PTC_STR_3TYPEINFOCONFIGURABL,PTC_STR_4TYPEINFOCONFIGURABL
from configurablemasterslink@plmdbadmin


select 
CLASSNAMEKEYDOMAINREF,IDA3DOMAINREF,INHERITEDDOMAIN,CLASSNAMEKEYROLEAOBJECTREF,IDA3A5,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
,PTC_LNG_1TYPEINFOCONFIGURABL,PTC_LNG_2TYPEINFOCONFIGURABL,PTC_LNG_3TYPEINFOCONFIGURABL,PTC_LNG_4TYPEINFOCONFIGURABL
,PTC_STR_1TYPEINFOCONFIGURABL,PTC_STR_2TYPEINFOCONFIGURABL,PTC_STR_3TYPEINFOCONFIGURABL,PTC_STR_4TYPEINFOCONFIGURABL
-- select * 
from configurablemasterslink@plmprd.plmdbadminlink

insert into configurablemasterslink@plmprd.plmdbadminlink
( CLASSNAMEKEYDOMAINREF,IDA3DOMAINREF,INHERITEDDOMAIN,CLASSNAMEKEYROLEAOBJECTREF,IDA3A5,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
,PTC_LNG_1TYPEINFOCONFIGURABL,PTC_LNG_2TYPEINFOCONFIGURABL,PTC_LNG_3TYPEINFOCONFIGURABL,PTC_LNG_4TYPEINFOCONFIGURABL
,PTC_STR_1TYPEINFOCONFIGURABL,PTC_STR_2TYPEINFOCONFIGURABL,PTC_STR_3TYPEINFOCONFIGURABL,PTC_STR_4TYPEINFOCONFIGURABL
)
select 
CLASSNAMEKEYDOMAINREF,IDA3DOMAINREF,INHERITEDDOMAIN,CLASSNAMEKEYROLEAOBJECTREF,IDA3A5,CLASSNAMEKEYROLEBOBJECTREF,IDA3B5,CREATESTAMPA2
,MARKFORDELETEA2,MODIFYSTAMPA2,CLASSNAMEA2A2,IDA2A2+8000000000000,UPDATECOUNTA2,UPDATESTAMPA2,BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE
,PTC_LNG_1TYPEINFOCONFIGURABL,PTC_LNG_2TYPEINFOCONFIGURABL,PTC_LNG_3TYPEINFOCONFIGURABL,PTC_LNG_4TYPEINFOCONFIGURABL
,PTC_STR_1TYPEINFOCONFIGURABL,PTC_STR_2TYPEINFOCONFIGURABL,PTC_STR_3TYPEINFOCONFIGURABL,PTC_STR_4TYPEINFOCONFIGURABL
from configurablemasterslink@plmdbadmin


update configurablemasterslink@plmprd.plmdbadminlink
set branchida2typedefinitionrefe = 1864473951, ida2typedefinitionreference = 1870053398
where ida2typedefinitionreference = 1878438775

update configurablemasterslink@plmprd.plmdbadminlink
set branchida2typedefinitionrefe = 51367, ida2typedefinitionreference = 1870057005
where ida2typedefinitionreference in ( 1864468290 , 1878438750 )

--
1878438775	15234 -- ConsentedPartLink
1878438750	381   -- HKMCKDPartLink
1864468290	43030 -- HKMCKDPartLink
1878438771	1878438775	15234
51367	1864468290	43030
51367	1878438750	381
---
1870057005	2 -- HKMCKDPartLink 
1865108337	1 -- HKMCKDPartLink
1870053398	12 -- ConsentedPartLink-------
1865108330	10 -- ConsentedPartLink
51367	1870057005	2 ======
1864473951	1865108330	10
1864473951	1870053398	12-----------
51367	1865108337	1
1878438771	1878438775	15234-------------
51367	1864468290	43030 =========
51367	1878438750	381===========


============ ����� ��� Ȯ��

select d.logicalidentifier, b.wtpartnumber, c.wtpartnumber 
from configurablemasterslink a, wtpartmaster b, wtpartmaster c, wttypedefinition d
where a.ida3a5 = b.ida2a2
and a.ida3b5 = c.ida2a2
and a.ida2typedefinitionreference = d.ida2a2
--and a.ida2typedefinitionreference = 1870053398


select d.logicalidentifier, bb.wtpartnumber, cc.wtpartnumber 
from configurabledescribelink a, wtpart b, wtpartmaster bb, wtpart c, wtpartmaster cc, wttypedefinition d
where a.ida3a5 = b.ida2a2
and a.ida3b5 = c.ida2a2
and a.ida2typedefinitionreference = d.ida2a2
and b.ida3masterreference = bb.ida2a2
and c.ida3masterreference = cc.ida2a2


select * from configurabledescribelink 

select * from configurablemasterslink 

===============================

select distinct itemnotype from itemnolink
where itemnotype = 'CSEW'


select a.wtpartnumber, b.wtpartnumber, l.* 
from itemnolink l, configurablemasterslink m, wtpartmaster a, wtpartmaster b
where l.ida3a5 = m.ida2a2
and m.ida3a5 = a.ida2a2
and m.ida3b5 = b.ida2a2




select a.wtpartnumber, b.wtpartnumber, m.ida2a2 
from itemnolink l, configurablemasterslink m, wtpartmaster a, wtpartmaster b
where l.ida3a5 = m.ida2a2
and m.ida3a5 = a.ida2a2
and m.ida3b5 = b.ida2a2

update configurablemasterslink set ida3a5 = ida3b5, ida3b5 = ida3a5
where ida2a2 in (
select distinct m.ida2a2 
from itemnolink l, configurablemasterslink m, wtpartmaster a, wtpartmaster b
where l.ida3a5 = m.ida2a2
and m.ida3a5 = a.ida2a2
and m.ida3b5 = b.ida2a2
)

