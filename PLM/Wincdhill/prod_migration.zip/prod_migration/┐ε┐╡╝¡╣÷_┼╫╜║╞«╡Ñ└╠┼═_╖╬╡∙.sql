
select * from hkmckdpart

select 