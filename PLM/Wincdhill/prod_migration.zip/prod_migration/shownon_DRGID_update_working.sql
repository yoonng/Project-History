
select ida2a2, ptc_str_13TYPEINFOWTPART from wtpart
where statestate <> 'RELEASED'
and ptc_str_13TYPEINFOWTPART is not null


-- working��
select ptc_str_13TYPEINFOWTPART , count(*) from wtpart
where statestate <> 'RELEASED'
and ptc_str_13TYPEINFOWTPART is not null 
group by ptc_str_13TYPEINFOWTPART

--- ��ü
select ptc_str_13TYPEINFOWTPART , count(*) from wtpart
where statestate = 'RELEASED'
and ptc_str_13TYPEINFOWTPART is not null 
group by ptc_str_13TYPEINFOWTPART



3209461 rows updated
commited

3402853

select statestate, ptc_str_13TYPEINFOWTPART, count(*) from wtpart
--where ptc_str_13TYPEINFOWTPART = 'S'
group by statestate, ptc_str_13TYPEINFOWTPART


update wtpart set ptc_str_13TYPEINFOWTPART = ''
where statestate = 'INWORK'
and ptc_str_13TYPEINFOWTPART = 'S'
; commit;




