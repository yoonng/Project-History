
select s_part_no, u_em_gubn  from part_list
where u_em_gubn is not null;


==== Level Mapping
L1, L2, L3, L4, LT  

W??
C?? 
U?? 

BSCD
SRC
PRD

===================
wt.iba.definition.AttributeOrganizer	42438	Level	�ϼ���	wt.admin.AdministrativeDomain	106
select * from AttributeOrganizer
where ida2a2 = 42438
select * from AdministrativeDomain
where ida2a2 = 106

select * from pdmlinkproduct 

select * from epmdocumentmaster 

@@@@@@@@@@@@@@@@@@@@@@@@
-- �Ʒ��� ida2a2���� B4�� L1���� ����
select distinct m.documentnumber  
--  insert into gate_baseline_b4l1
select m.documentnumber, max( d.ida2a2 )
--  select p.namecontainerinfo, m.documentnumber, d.description, d.ida2a2 , d.versionida2versioninfo, d.iterationida2iterationinfo, d.latestiterationinfo, m.*
from epmdocumentmaster@plmdbadmin m, epmdocument@plmdbadmin d, pdmlinkproduct@plmdbadmin p
where d.description is not null
and d.description like 'CWM%'
and d.ida3masterreference = m.ida2a2
and m.ida3containerreference = p.ida2a2
and p.namecontainerinfo = 'B4'
and substr( d.description, instr(d.description, '_', 1, 3) + 1, 1) = '1' 
GROUP BY m.documentnumber

===========
select description, instr(description, '_', 1, 3), instr(description, '_', 1, 4), 
substr( description, instr(description, '_', 1, 3) + 1, 1) from epmdocument 
where description like 'CWM%'


==========

select * from stringvalue
where classnamekeya4 = 'wt.vc.baseline.ManagedBaseline'

select * from timestampvalue 
where classnamekeya4 = 'wt.vc.baseline.ManagedBaseline'

