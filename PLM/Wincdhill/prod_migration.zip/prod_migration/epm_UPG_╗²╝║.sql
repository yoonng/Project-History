
-- 8323
select * from epmdocumentmaster m, epmdocument d
where m.ida2a2 = d.ida3masterreference 
and m.name like '__UPG%' 

-- 20992
select * from epmdocumentmaster m, epmdocument d, epmmemberlink l
where m.ida2a2 = d.ida3masterreference 
and m.name like '__UPG%' 
and l.ida3a5 = d.ida2a2

-- 290
select m.* from epmdocumentmaster m, epmdocument d, epmmemberlink l, derivedimage i
where m.ida2a2 = d.ida3masterreference 
and m.name like 'B4UPG%' 
and l.ida3a5 = d.ida2a2
and i.ida3a6 = d.ida2a2

=== memberlink ���� ����Ʈ
select m.documentnumber, m.name, d.versionida2versioninfo, d.iterationida2iterationinfo , l.ida2a2 
from epmdocumentmaster m, epmdocument d, epmmemberlink l
where m.ida2a2 = d.ida3masterreference 
and m.name like 'B4UPG%' 
and d.latestiterationinfo = 1
and d.ida2a2 = l.ida3a5(+)
and l.ida2a2 is null


select * from holdertocontent
where classnamekeyroleaobjectref <> 'wt.epm.EPMDocument'

select * from epmmemberlink

select * from DerivedImage

select buildtype, count(*) from epmbuildrule group by buildtype
7	229173
6	5101
2	887279

====== epm�� �� UPG���� Usagelink ���� memberlink ���� ���Ѵ�.
select * from wtpartusagelink
select * from epmmemberlink
select * from epmbuildrule 
;

select m.documentnumber, m.name, d.versionida2versioninfo, d.iterationida2iterationinfo ,
    (select count(*) from epmmemberlink ml where ml.ida3a5 = d.ida2a2) epmcounts, d.ida2a2,
    (select count(*) from wtpartusagelink ul where ul.ida3a5 = pd.ida2a2) wtcounts, pd.ida2a2,
    (
        select count(*) 
        from wtpartusagelink l, wtpartmaster cpm, wtpart cpd, epmbuildrule br 
        where l.ida3a5 = pd.ida2a2
        and l.ida3b5 = cpm.ida2a2
        and cpm.ida2a2 = cpd.ida3masterreference 
        and cpd.latestiterationinfo = 1 
        and br.branchida3b5 = cpd.branchiditerationinfo
        and br.buildtype = 7
    ) compEPMcounts 
from epmdocumentmaster m, epmdocument d, wtpartmaster pm, wtpart pd 
where m.ida2a2 = d.ida3masterreference 
and m.name like '3SUPG%' 
and d.latestiterationinfo = 1 
and m.name = pm.wtpartnumber
and pm.ida2a2 = pd.ida3masterreference
and pd.latestiterationinfo =  1 
order by name ;


2233624524

select * 
from wtpartusagelink l, wtpartmaster cpm, wtpart cpd, epmbuildrule br 
where 
l.ida3a5 = 2234045320
and l.ida3b5 = cpm.ida2a2
and cpm.ida2a2 = cpd.ida3masterreference 
and cpd.latestiterationinfo = 1 
and br.branchida3b5 = cpd.branchiditerationinfo
and br.buildtype = 7

============== upg ī��Ʈ Ȯ��

select t.upgs, count(*) from (
  select substr(m.name, 0, 5) upgs 
  from epmdocumentmaster m 
  where m.name like '__UPG%' 
) t
group by t.upgs


select substr(m.name, 0, 5) upgs 
  from epmdocumentmaster m , epmdocument d, epmbuildrule r
  where m.name like '__UPG%' 
  and m.ida2a2 = d.ida3masterreference 
  and d.branchiditerationinfo = branchida3a5


select substr(t.upgs, 0, 5), count(*) from (
  select distinct m.name upgs 
  from epmdocumentmaster m , epmdocument d, epmbuildrule r
  where m.name like '__UPG%' 
  and m.ida2a2 = d.ida3masterreference 
  and d.branchiditerationinfo = branchida3a5
) t
group by substr(t.upgs, 0, 5)


=================== epmmemberlink �ߺ� ����

select * from epmmemberlink
where ida3a5 in ( 
    select d.ida2a2 from epmdocumentmaster m, epmdocument d
    where m.ida2a2 = d.ida3masterreference
    and m.name like 'B4UPG%'
)
order by ida3a5, ida3b5

select * from epmmemberlink
where (ida3a5, ida3b5) in ( ( 1878560775,	1812711531 ) )

select ida3a5, ida3b5, count(*) from epmmemberlink
group by ida3a5, ida3b5
having count(*) > 1



    select m.*, d.ida2a2 
    from epmdocumentmaster m, epmdocument d
    where m.ida2a2 = d.ida3masterreference
    and m.name like '3SUPG%'