exec WTPK.dropTable('AFormBForm')
