exec WTPK.dropTable('ECRequest')
set echo on
REM Creating table ECRequest for ext.psk.ecm.ecr.ECRequest
set echo off
CREATE TABLE ECRequest (
   blob$entrySetadHocAcl   BLOB,
   businessDecisionSummary   VARCHAR2(600),
   classnamekeycontainerReferen   VARCHAR2(600),
   idA3containerReference   NUMBER,
   classnamekeyB7   VARCHAR2(600),
   idA3B7   NUMBER,
   cycleTime   DATE,
   description   VARCHAR2(4000),
   classnamekeydomainRef   VARCHAR2(600),
   idA3domainRef   NUMBER,
   entrySetadHocAcl   VARCHAR2(4000),
   eventSet   VARCHAR2(4000),
   classnamekeyA2folderingInfo   VARCHAR2(600),
   idA3A2folderingInfo   NUMBER,
   classnamekeyB2folderingInfo   VARCHAR2(600),
   idA3B2folderingInfo   NUMBER,
   nameB2folderingInfo   VARCHAR2(600),
   indexersindexerSet   VARCHAR2(4000),
   inheritedDomain   NUMBER(1),
   branchIditerationInfo   NUMBER,
   classnamekeyD2iterationInfo   VARCHAR2(600),
   idA3D2iterationInfo   NUMBER,
   iterationIdA2iterationInfo   VARCHAR2(180),
   latestiterationInfo   NUMBER(1),
   classnamekeyB2iterationInfo   VARCHAR2(600),
   idA3B2iterationInfo   NUMBER,
   noteiterationInfo   VARCHAR2(4000),
   classnamekeyC2iterationInfo   VARCHAR2(600),
   idA3C2iterationInfo   NUMBER,
   stateiterationInfo   VARCHAR2(90) NOT NULL,
   latest   NUMBER(1),
   classnamekeymasterReference   VARCHAR2(600),
   idA3masterReference   NUMBER,
   needDate   DATE,
   nonRecurringCostEst   VARCHAR2(600),
   oneOffVersionIdA2oneOffVersi   VARCHAR2(180),
   classnamekeyA2ownership   VARCHAR2(600),
   idA3A2ownership   NUMBER,
   recurringCostEst   VARCHAR2(600),
   resolutionDate   DATE,
   securityLabels   VARCHAR2(4000),
   atGatestate   NUMBER(1),
   classnamekeyA2state   VARCHAR2(600),
   idA3A2state   NUMBER,
   statestate   VARCHAR2(600) NOT NULL,
   teamIdIsNull   NUMBER(1),
   classnamekeyteamId   VARCHAR2(600),
   idA3teamId   NUMBER,
   teamTemplateIdIsNull   NUMBER(1),
   classnamekeyteamTemplateId   VARCHAR2(600),
   idA3teamTemplateId   NUMBER,
   theBusinessDecisionAuditIsNu   NUMBER(1),
   changeDateB9   DATE,
   newValueB9   VARCHAR2(600),
   oldValueB9   VARCHAR2(600),
   userIsNullB9   NUMBER(1),
   classnamekeyuserB9   VARCHAR2(600),
   idA3userB9   NUMBER,
   theBusinessDecisionCategory   VARCHAR2(600),
   theCategory   VARCHAR2(600),
   theComplexity   VARCHAR2(600),
   createStampA2   DATE,
   markForDeleteA2   NUMBER NOT NULL,
   modifyStampA2   DATE,
   classnameA2A2   VARCHAR2(600),
   idA2A2   NUMBER NOT NULL,
   updateCountA2   NUMBER,
   updateStampA2   DATE,
   theRequestPriority   VARCHAR2(600),
   branchIdA2typeDefinitionRefe   NUMBER,
   idA2typeDefinitionReference   NUMBER,
   versionIdA2versionInfo   VARCHAR2(180),
   versionLevelA2versionInfo   NUMBER,
   versionSortIdA2versionInfo   VARCHAR2(600),
 CONSTRAINT PK_ECRequest PRIMARY KEY (idA2A2))
 STORAGE ( INITIAL 20k NEXT 20k PCTINCREASE 0 )
LOB ( blob$entrySetadHocAcl ) STORE AS 
 (TABLESPACE BLOBS
    STORAGE ( INITIAL 50k NEXT 50k PCTINCREASE 1 )
             CHUNK 32k)
ENABLE PRIMARY KEY USING INDEX
 TABLESPACE INDX
 STORAGE ( INITIAL 20k NEXT 20k PCTINCREASE 0 )
/
COMMENT ON TABLE ECRequest IS 'Table ECRequest created for ext.psk.ecm.ecr.ECRequest'
/
REM @//ext/psk/ecm/ecr/ECRequest_UserAdditions
