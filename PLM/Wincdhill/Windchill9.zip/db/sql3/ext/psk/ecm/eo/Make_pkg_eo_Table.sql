@ext/psk/ecm/eo/create_EOBetaAForm_Table.sql
@ext/psk/ecm/eo/create_EOAlphaForm_Table.sql
@ext/psk/ecm/eo/create_EOBetaBForm_Table.sql
@ext/psk/ecm/eo/create_AFormBForm_Table.sql
@ext/psk/ecm/eo/create_EOBetaLink_Table.sql
