exec WTPK.dropIndex('AFormBForm$COMPOSITE')
exec WTPK.dropIndex('AFormBForm$COMPOSITE1')
