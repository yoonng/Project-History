exec WTPK.dropIndex('EOBetaLink$COMPOSITE')
exec WTPK.dropIndex('EOBetaLink$COMPOSITE1')
