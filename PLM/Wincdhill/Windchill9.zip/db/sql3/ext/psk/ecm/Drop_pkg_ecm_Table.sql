@ext/psk/ecm/eo/Drop_pkg_eo_Table.sql
@ext/psk/ecm/ecr/Drop_pkg_ecr_Table.sql
