exec WTPK.dropTable('ECRequest')
