exec WTPK.dropTable('EOBetaAForm')
