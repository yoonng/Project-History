@ext/psk/ecm/eo/create_EOBetaAForm_Index.sql
@ext/psk/ecm/eo/create_EOAlphaForm_Index.sql
@ext/psk/ecm/eo/create_EOBetaBForm_Index.sql
@ext/psk/ecm/eo/create_AFormBForm_Index.sql
@ext/psk/ecm/eo/create_EOBetaLink_Index.sql
