exec WTPK.dropTable('EOBetaLink')
