@ext/psk/ecm/eo/drop_EOBetaAForm_Index.sql
@ext/psk/ecm/eo/drop_EOAlphaForm_Index.sql
@ext/psk/ecm/eo/drop_EOBetaBForm_Index.sql
@ext/psk/ecm/eo/drop_AFormBForm_Index.sql
@ext/psk/ecm/eo/drop_EOBetaLink_Index.sql
