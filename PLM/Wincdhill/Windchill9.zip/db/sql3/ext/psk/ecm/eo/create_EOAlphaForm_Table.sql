exec WTPK.dropTable('EOAlphaForm')
set echo on
REM Creating table EOAlphaForm for ext.psk.ecm.eo.EOAlphaForm
set echo off
CREATE TABLE EOAlphaForm (
   applyDate   DATE,
   blob$entrySetadHocAcl   BLOB,
   changeReasonA   VARCHAR2(600),
   changeReasonB   VARCHAR2(600),
   classnamekeycontainerReferen   VARCHAR2(600),
   idA3containerReference   NUMBER,
   classnamekeyB7   VARCHAR2(600),
   idA3B7   NUMBER,
   cycleTime   DATE,
   department   VARCHAR2(600),
   description   VARCHAR2(4000),
   classnamekeydomainRef   VARCHAR2(600),
   idA3domainRef   NUMBER,
   entrySetadHocAcl   VARCHAR2(4000),
   eoContent   VARCHAR2(4000),
   eoType   VARCHAR2(600),
   eventSet   VARCHAR2(4000),
   evrTestList   VARCHAR2(600),
   evrTitle   VARCHAR2(600),
   classnamekeyA10   VARCHAR2(600),
   idA3A10   NUMBER,
   classnamekeyA2folderingInfo   VARCHAR2(600),
   idA3A2folderingInfo   NUMBER,
   classnamekeyB2folderingInfo   VARCHAR2(600),
   idA3B2folderingInfo   NUMBER,
   nameB2folderingInfo   VARCHAR2(600),
   indexersindexerSet   VARCHAR2(4000),
   inheritedDomain   NUMBER(1),
   branchIditerationInfo   NUMBER,
   classnamekeyD2iterationInfo   VARCHAR2(600),
   idA3D2iterationInfo   NUMBER,
   iterationIdA2iterationInfo   VARCHAR2(180),
   latestiterationInfo   NUMBER(1),
   classnamekeyB2iterationInfo   VARCHAR2(600),
   idA3B2iterationInfo   NUMBER,
   noteiterationInfo   VARCHAR2(4000),
   classnamekeyC2iterationInfo   VARCHAR2(600),
   idA3C2iterationInfo   NUMBER,
   stateiterationInfo   VARCHAR2(90) NOT NULL,
   latest   NUMBER(1),
   classnamekeymasterReference   VARCHAR2(600),
   idA3masterReference   NUMBER,
   needDate   DATE,
   needEVR   VARCHAR2(600),
   oneOffVersionIdA2oneOffVersi   VARCHAR2(180),
   classnamekeyorganizationRefe   VARCHAR2(600),
   idA3organizationReference   NUMBER,
   classnamekeyA2ownership   VARCHAR2(600),
   idA3A2ownership   NUMBER,
   resolutionDate   DATE,
   securityLabels   VARCHAR2(4000),
   atGatestate   NUMBER(1),
   classnamekeyA2state   VARCHAR2(600),
   idA3A2state   NUMBER,
   statestate   VARCHAR2(600) NOT NULL,
   stockMgt   VARCHAR2(600),
   teamIdIsNull   NUMBER(1),
   classnamekeyteamId   VARCHAR2(600),
   idA3teamId   NUMBER,
   teamTemplateIdIsNull   NUMBER(1),
   classnamekeyteamTemplateId   VARCHAR2(600),
   idA3teamTemplateId   NUMBER,
   theChangeNoticeComplexity   VARCHAR2(600) NOT NULL,
   createStampA2   DATE,
   markForDeleteA2   NUMBER NOT NULL,
   modifyStampA2   DATE,
   classnameA2A2   VARCHAR2(600),
   idA2A2   NUMBER NOT NULL,
   updateCountA2   NUMBER,
   updateStampA2   DATE,
   branchIdA2typeDefinitionRefe   NUMBER,
   idA2typeDefinitionReference   NUMBER,
   versionIdA2versionInfo   VARCHAR2(180),
   versionLevelA2versionInfo   NUMBER,
   versionSortIdA2versionInfo   VARCHAR2(600),
 CONSTRAINT PK_EOAlphaForm PRIMARY KEY (idA2A2))
 STORAGE ( INITIAL 20k NEXT 20k PCTINCREASE 0 )
LOB ( blob$entrySetadHocAcl ) STORE AS 
 (TABLESPACE BLOBS
    STORAGE ( INITIAL 50k NEXT 50k PCTINCREASE 1 )
             CHUNK 32k)
ENABLE PRIMARY KEY USING INDEX
 TABLESPACE INDX
 STORAGE ( INITIAL 20k NEXT 20k PCTINCREASE 0 )
/
COMMENT ON TABLE EOAlphaForm IS 'Table EOAlphaForm created for ext.psk.ecm.eo.EOAlphaForm'
/
REM @//ext/psk/ecm/eo/EOAlphaForm_UserAdditions
