@ext/psk/ecm/eo/drop_EOBetaAForm_Table.sql
@ext/psk/ecm/eo/drop_EOAlphaForm_Table.sql
@ext/psk/ecm/eo/drop_EOBetaBForm_Table.sql
@ext/psk/ecm/eo/drop_AFormBForm_Table.sql
@ext/psk/ecm/eo/drop_EOBetaLink_Table.sql
