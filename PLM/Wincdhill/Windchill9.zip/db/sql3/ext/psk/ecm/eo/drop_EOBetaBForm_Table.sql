exec WTPK.dropTable('EOBetaBForm')
