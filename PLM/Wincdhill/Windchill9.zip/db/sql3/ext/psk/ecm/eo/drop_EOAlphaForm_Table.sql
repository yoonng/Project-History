exec WTPK.dropTable('EOAlphaForm')
