
	/*
	 * by Use : onKeyUp( formName, maxLengthValue, 
	 */
	function onkeylengthMax(formobj,maxlength, objname){
		var li_byte     = 0;
		var li_len      = 0;
		
		for(var i=0; i< formobj.value.length; i++){
			if (escape(formobj.value.charAt(i)).length > 4){
		 		li_byte += 2;
			} else {
				li_byte++;
			}
			
			if(li_byte <= maxlength){
		 		li_len = i + 1;
			}
		}
		
		if(li_byte > maxlength){
			alert('글자수를 제한 합니다');
			formobj.value = formobj.value.substr(0, li_len);
		}
		formobj.focus();
	}

	/*
	 * text length check and validation check 
	 * @param formobj
	 * @param maxlength
	 * @param objname
	 * @return
	 */
	function onkeylengthMax_Copy(formobj,maxlength, objname){
		var li_byte     = 0;
		var li_len      = 0;
		
		for(var i=0; i< formobj.value.length; i++){
			if (escape(formobj.value.charAt(i)).length > 4){
		 		li_byte += 2;
			} else {
				li_byte++;
			}
			
			if(li_byte <= maxlength){
		 		li_len = i + 1;
			}
		}
		
		if(li_byte > maxlength){
			alert('글자수를 제한 합니다');
			formobj.value = formobj.value.substr(0, li_len);
		}
		formobj.focus();
	}

	//All view form open start
  	//EO view화면 호출
  	function openViewEO(oid)
	{
		var wSize = 519;
  		var hSize = 630;
  		var popName = "preEOViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/eo/passPage.jsp";
		url += "?cmd=viewEO";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
  	
  	//ECR view화면 호출
  	function openViewECR(oid)
	{
		var wSize = 570;
  		var hSize = 650;
  		var popName = "ecrViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/ecr/passPage.jsp";
		url += "?cmd=viewECR";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}

  	//EVN view화면 호출
  	function openViewEVN(oid)
	{
		var wSize = 519;
  		var hSize = 630;
  		var popName = "EVNViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/ev/passPage.jsp";
		url += "?cmd=viewEVN";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}

  	//EVR view화면 호출
  	function openViewEVR(oid)
	{
		var wSize = 519;
  		var hSize = 630;
  		var popName = "EVRViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/ev/passPage.jsp";
		url += "?cmd=viewEVR";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
  	

  	//PSCR view화면 호출
  	function openViewPSCR(oid)
	{
		var wSize = 600;
  		var hSize = 462;
  		var popName = "PSCRViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/psc/passPage.jsp";
		url += "?cmd=viewPSCR";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
  	

  	//PSCN view화면 호출
  	function openViewPSCN(oid)
	{
		var wSize = 600;
  		var hSize = 425;
  		var popName = "PSCNViewPopup";
  		var form = document.forms[0];
		
		url = "/Windchill/extcore/psk/jsp/ecm/psc/passPage.jsp";
		url += "?cmd=viewPSCN";
		url += "&oid=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
  	
  	//Nexus PSCN view화면 호출
  	function openViewNexusPSCN(oid)
	{	
		var wSize = 695;
  		var hSize = 300;
  		var popName = "PSCNViewPopup";
  		var form = document.forms[0];
		
		//url = "/Windchill/extcore/psk/jsp/ecm/psc/passPage.jsp";
		url  = "http://192.168.232.250:8080";
		url += "/newNexus/pscr.action";
		url += "?userId=s00001";
		url += "&record.pscnNo=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
  	
  	//Nexus PSCR view화면 호출
  	function openViewNexusPSCR(oid)
	{	
		var wSize = 695;
  		var hSize = 300;
  		var popName = "PSCNViewPopup";
  		var form = document.forms[0];
		
		//url = "/Windchill/extcore/psk/jsp/ecm/psc/passPage.jsp";
		url  = "http://192.168.232.250:8080";
		url += "/newNexus/pscr.action";
		url += "?userId=s00001";
		url += "&record.pscrNo=" + oid;
		
		pupUp(url, wSize, hSize, popName);
	}
	//All view form open end
	
	//attach File Start
  	function addFile() {
  		var tableObj = document.all.attchFiles;  //document.getElementsByName("attchFiles");
  		var trObj    = tableObj.insertRow();
  		var tdObj    = trObj.insertCell();

  		tdObj.innerHTML  = "&nbsp;";
  		tdObj.innerHTML += "&nbsp;<img src=\"/Windchill/extcore/psk/images/del2.png\" onClick=\"javascript:delFile(this);\" onMouseOver=\"this.style.cursor='pointer';\"/>";
  		tdObj.innerHTML += "&nbsp;<input type=\"file\" name=\"addFiles\" style=\"width:90%;\">";
  	}

  	function delFile(obj) {
  		obj.parentNode.removeNode(true);
  	}
	//attach File End
	
	//Approve History Call Start
    function approveHistory(oid) {
        if( oid == "OR:" ) {
            alert("OID가 없습니다");
            return;
        }

		var wSize = 1013;
  		var hSize = 500;
  		var popName = "approveHistory";
  		var form = document.forms[0];

		url = "/Windchill/extcore/psk/jsp/workflow/processHistory.jsp";
		url += "?oid=" + oid;

		//Windchill/netmarkets/jsp/workflow/processHistory.jsp?oid=OR %3A ext.psk.ecm.ecr.ECRequest %3A 37724
			
		pupUp(url, wSize, hSize, popName);
    }
	//Approve History Call End
    
  	//Creator Condition clear
  	function clearCreator() {
  	  	var form = document.forms[0];
  	  	form.shWtUserOid.value = "";
  	  	form.shIssueUserNm.value = "";
  	}

  	//Search Condition clear
  	function searchClear() {
  		var child = document.forms[0].elements;
  		
		for(var i=0; i < child.length; i++){
			if( child[i].name.length > 0 && child[i].name.substr(0,2) == "sh") {
				//alert("type = " + child[i].type + "  : name = " + child[i].name);
				switch(child[i].type) {
					case "select-one" :
						child[i].options[0].selected = true;
						//child[i].options.selectindex = 0;
						break;
					case "checkbox" :
						child[i].checked = false;
						break;
					default : 
						child[i].value = "";
						break;
				}
			}
		}	
  	}
	
	/*
	 * When popUpform, Position Center
	 */
	function pupUp(url, wSize, hSize, popupName) {
		var screenWidth = screen.width;
        var screenHeight = screen.height;
        var lPos = "";
        var tPos = "";

        lPos = ( screenWidth / 2 ) - ( wSize / 2 );
        tPos = ( screenHeight / 2 ) - ( hSize / 2 );

        //alert( screenWidth + "   " + screenHeight + "  " + lPos + "  " + tPos);

  		var stream = "toolbar=0,location=0,directory=0,status=1,menubar=0,scrollbars=1,resizable=0";
  		stream += ",width=" + wSize + ",height=" + hSize;
  		stream += ",left=" + lPos + ",top=" + tPos;
  		
	    open(url, popupName, stream);
	}
	
	// Calendar script Start 
	var calendarWindow = null;
	var calendarScreenX = 100; // either 'auto' or numeric
	var calendarScreenY = 100; // either 'auto' or numeric

	function getCalendar(in_dateField) 
	{
	    if (calendarWindow && !calendarWindow.closed) {
	        alert('Calendar window already open.  Attempting focus...');
	        try {
	            calendarWindow.focus();
	        }
	        catch(e) {}
	        
	        return false;
	    }
	    
	    var screenWidth = screen.width;
        var screenHeight = screen.height;
        var lPos = "";
        var tPos = "";
        
	    var wSize = 220;//415;
	    var hSize = 240;//310;
	    
	    lPos = ( screenWidth / 2 ) - ( wSize / 2 );
        tPos = ( screenHeight / 2 ) - ( hSize / 2 );
	    
	    var file = "/Windchill/extcore/psk/jsp/calendar/calendar.html";

	    // IE needs less space to make this thing
	    if ((document.all) && (navigator.userAgent.indexOf("Konqueror") == -1)) {
	    	wSize = 220; //410;
	    }
	    
	    var stream = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,dependent=no";
  		stream += ",width=" + wSize + ",height=" + hSize;
  		stream += ",left=" + lPos + ",top=" + tPos;

	    calendarTarget = in_dateField;
	    calendarWindow = window.open(file, 'dateSelectorPopup', stream );

	    return false;
	}

	function killCalendar() 
	{
	    if (calendarWindow && !calendarWindow.closed) {
	        calendarWindow.close();
	    }
	}
	// Calendar script End 
	
	//Start Drawing Call Back
	function pskDrawingCallback(objects, pickerID)
	{
		var form = document.forms[0];
		var obj = form.drawingDocument;
		var updateHiddenField = document.getElementById(pickerID);
		var updateDisplayField = document.getElementById(pickerID +"$label$");
		var myJSONObjects = objects.pickedObject;
		for(var i=0; i< myJSONObjects.length;i++) {
			var oid = myJSONObjects[i].oid;
			var displayAttr = eval("myJSONObjects[i].number");			
			
			updateHiddenField.value = oid;
			updateDisplayField.value = displayAttr;

			//var item = new Option( displayAttr, oid );
			//obj.options[obj.length] = item;
		}
	}

	function delDrawingPicker() {
		var form = document.forms[0];
		var obj = form.drawingDocument;
		
		if( obj.options.selectedIndex < 0 ) {
			alert("Choice DrawingDocument!!");
			return;
		}
		
		obj.options[obj.options.selectedIndex] = null;
	}
	//End Drawing Back
	
	//Start Document Call Back
	function pskDocumentCallback(objects, pickerID)
	{
		var form = document.forms[0];
		var obj = form.referenceDocument;
		var updateHiddenField = document.getElementById(pickerID);
		var updateDisplayField = document.getElementById(pickerID +"$label$");
		var myJSONObjects = objects.pickedObject;
		for(var i=0; i< myJSONObjects.length;i++) {
			var oid = myJSONObjects[i].oid;
			var displayAttr = eval("myJSONObjects[i].number");
			
			//updateHiddenField.value=oid;
			//updateDisplayField.value=displayAttr;
			
			var bFlag = true;
			for(var j = 0; j < obj.length; j++) {
				if( obj.options[j].value == oid ) {
					bFlag = false;
				}
			}
			
			if( bFlag ) {
				var item = new Option( displayAttr, oid );
				obj.options[obj.length] = item;
			}
		}
	}

	function delDocumentPicker() {
		var form = document.forms[0];
		var obj = form.referenceDocument;
		
		if( obj.options.selectedIndex < 0 ) {
			alert("Choice ReferenceDocument!!");
			return;
		}
		
		obj.options[obj.options.selectedIndex] = null;
	}
	//End Document Call Back
	
	//Start UPG ( psk Part )
	//delete, no use --> change code
	function pskPartCallback(objects, pickerID)
	{
		var form = document.forms[0];
		var updateHiddenField = document.getElementById(pickerID);
		var updateDisplayField = document.getElementById(pickerID +"$label$");		
		var myJSONObjects = objects.pickedObject;
		for(var i=0; i< myJSONObjects.length;i++) {
			var oid = myJSONObjects[i].oid;
			var displayAttr = eval("myJSONObjects[i].number");
			
			updateHiddenField.value = oid;
			updateDisplayField.value = displayAttr;
		}
	}
	//End UPG ( psk Part )
	
	//Document Viewer Open Start
  	function openViewRefDoc(oid)
	{	
		var wSize = 825;
  		var hSize = 650;
  		var popName = "refDocViewPopup";
  		var form = document.forms[0];

  		url = "/Windchill/extcore/psk/jsp/util/passPage.jsp";  		

  		if( oid.indexOf('OR:') >= 0 || oid.indexOf('VR:') >= 0 ) {
  			url += "?oid=" + oid;
  		} else if( oid.indexOf('EPMDocument') >= 0 ) {
  			url += "?oid=VR:" + oid;
  		} else {
  			url += "?oid=OR:" + oid;
  		}
  		
  		alert( url );
		
		pupUp(url, wSize, hSize, popName);
	}
	//Document Viewer Open End
	
	//Validation check Start	
	function esseCheck() {
		var flag = true;
		var strText = "";
  		var child = document.forms[0].elements;
  		
		for(var i=0; i < child.length; i++){
			var alertMsg = "는(은) 필수항목입니다.";
			
			//picker process : do not append esse attribute 
			//no used --> delete ok
			if( child[i].type == "text" && child[i].name == "part$part-regist$null$___pskPartPickerId$label$___textbox" && child[i].value.replace(/\s*$/,'') == "" ) {
				alertMsg += "\n 항목을 입력해 주세요";
				alert( "UPG" + alertMsg );
				
				//oid "" process
				document.forms[0].pskPartPickerId.value = "";
				child[i].focus();
				flag = false;
				break;
			}
			
			//picker process : do not append esse attribute
			if( child[i].type == "text" && child[i].name == "part$part-regist$null$___pskDrawingPickerId$label$___textbox" && child[i].value.replace(/\s*$/,'') == "" ) {
				var rFlag = false;
				var obj = document.getElementsByName("temporaryCad");
				var drawPicker = document.getElementsByName("part$part-regist$null$___pskDrawingPickerId$label$___textbox");
				
				for(var j = 0; j < obj.length; j++ ) {
					if( obj[j].value == "Use TempCAD" && obj[j].checked == true ) {
						rFlag = true;
						break;
					}
				}
				
				if( rFlag ) {
					alertMsg += "\n 항목을 입력해 주세요";
					alert( "Drawing Document" + alertMsg );
					
					//oid "" process
					document.forms[0].pskDrawingPickerId.value = "";
					child[i].focus();
					flag = false;
					break;
				}
			}
			
			if( child[i].esse == "true" && child[i].name.substr(0,2) != "sh"  ) {
				/*
				strText = "";
				strText += "type = " + child[i].type + "\n";
				strText += "name = " + child[i].name + "\n";
				strText += "value = " + child[i].value + "\n";
				strText += "multiple = " + child[i].multiple + "\n";
				strText += "esse = " + child[i].esse + "\n";
				strText += "esseLabel = " + child[i].esseLabel + "\n";
				strText += "length = " + child[i].length + "\n";
				//strText += "needEVR = " + document.forms[0].needEVR.checked + "\n";
				alert( strText );
				*/
				
				switch(child[i].type) {
					case "text": 
					case "hidden":
					case "textarea":
						alertMsg += "\n 항목을 입력해 주세요";
						break;
						
					case "select-multiple": 
						alertMsg += "\n 항목을 추가해 주세요";
						break;
						
					case "radio":
					case "checkbox":
					case "select-one":
						alertMsg += "\n 항목을 선택해 주세요";
						break;
				}
				
				if( child[i].type == "select-multiple" && child[i].multiple == true && child[i].length == 0 ) {
					flag = false;

				} else if( child[i].type == "select-one" && child[i].multiple == false && child[i].options.selectedIndex == 0 ) {
					flag = false;

				} else if( child[i].type == "checkbox" ) {
					flag = false;

				} else if( child[i].type == "radio" ) {
					var rFlag = false;
					var obj = document.getElementsByName(child[i].name);
					
					for(var j = 0; j < obj.length; j++ ) {
						if( obj[j].checked == true ) {
							rFlag = true;
						}
					}
					flag = rFlag;

				} else if(    child[i].type == "hidden" && child[i].value.replace(/\s*$/,'') == "" ){
					flag = false;
					
				} else if( child[i].type == "textarea" && child[i].value.replace(/\s*$/,'') == "" ) {
					flag = false;
					
				} else if( 	child[i].type == "text"  && child[i].value.replace(/\s*$/,'') == "" ) {

					if( (      child[i].name == "evrTitle" 
							|| child[i].name == "evrTestList"
							|| child[i].name == "evrCreatorNm"
						) && document.forms[0].needEVR.checked == true && child[i].value.replace(/\s*$/,'') == "" ) {
						flag = false;
						
					} else if( !(   child[i].name == "evrTitle" 
								  || child[i].name == "evrTestList"
								  || child[i].name == "evrCreatorNm"
								 ) && child[i].value.replace(/\s*$/,'') == "" ) {
						flag = false;
					}
					
				} 
				
				if( !flag ) {
					alert( child[i].esseLabel + alertMsg );
					child[i].focus();
					break;
				}
			}
		}
		
		return flag;
  	}
	//Validation check end