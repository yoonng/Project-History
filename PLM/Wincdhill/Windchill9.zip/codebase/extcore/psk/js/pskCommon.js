 /**
 * @(#)	file_name Created on 2007. 05. 28
 * @Copyright (c) e3ps. All rights reserverd
 * 
 * @author Kiseon Kim, kiskim@e3ps.com
 * @version 1.00
  */
  
  
function checkSize(cbox)
{
	if(cbox==null) 
		len=0;
	else
	{
		len=cbox.length
		if(''+len == 'undefined') len = 1;
	}
	return len;
}

function isNullData(str)
{
	if(str.length == 0)
		return true;
	for(var i=0;i<str.length;i++)
		if(str.charCodeAt(i) != 32)
			return false;
	return true;
}

function checkField(obj, fieldName)
{
	if(isNullData(obj.value))
	{
		alert( "Please insert \""+ fieldName + "\".");
//		alert( fieldName + unescape("%uC744%28%uB97C%29%20%uC785%uB825%uD558%uC138%uC694"));
		obj.focus();
		return true;
	}
	return false;
}

function disabledAllBtn()
{
	var f = document.forms[0];
    for(var i=0 ; i<f.length ; i++){
		if(f[i].type=="button")
			f[i].disabled = true;
	}
	f = document.getElementsByTagName('A');
	for(var i=0 ; i<f.length ; i++){
		f[i].disabled = true;
		f[i].href = '#';
	}
}

function selectAll(cboxAll, cbox) 
{	
	var len = checkSize(cbox);
	if(cbox != null)
	{
		if(len > 1){
			for(var i=0 ; i<len ; i++) 
			{
				if ( cboxAll.checked == true ) cbox[i].checked=true;
				else	cbox[i].checked=false;
			}
		}else{
			if ( cboxAll.checked == true ) cbox.checked=true;
			else cbox.checked=false;
		}
	}
} 

function selectAllUnChecked(cboxAll, cbox)
{
	if(cboxAll == null) return;
	var len = checkSize(cbox);
	if(cbox != null) {
		if (len > 1){
			if ( cboxAll.checked == true) cboxAll.checked = false;
		} else{
			if ( cboxAll.checked == true) cboxAll.checked = false;
			else cboxAll.checked = true;
		}

		for (var i=0 ; i<len ; i++ )
		{
			if(len>1) {
				if( cbox[i].checked != true) break;
				if ( (i+1) == len) cboxAll.checked = true;
			}
		}	
	}
}

function selectAllForEnable(cboxAll, cbox) 
{	
	var len = checkSize(cbox);
	if(cbox != null)
	{
		if(len > 1){
			for(var i=0 ; i<len ; i++) 
			{
				if (cbox[i].disabled == false) {
					if ( cboxAll.checked == true ) cbox[i].checked=true;
					else	cbox[i].checked=false;
				}
			}
		}else{
			if (cbox.disabled == false) {
				if ( cboxAll.checked == true ) cbox.checked=true;
				else cbox.checked=false;
			}
		}
	}
} 

function selectSingle(cbox, index)
{
	var len = checkSize(cbox);
	if(cbox != null) 
	{
		if(len>1) 
		{
			for (var i=0 ; i<len ; i++ )
			{
				if ( i != index) cbox[i].checked = false;
			}
		}
	}
}

function isChecked(cbox)
{
	var len = checkSize(cbox);
	if(cbox != null) {
		if(len > 1){
			for(var i=0 ; i<len ; i++) 
			{
				if( cbox[i].checked == true )
					return true;
			}
		}else{
			if ( cbox.checked == true )
					return true;
		}
	}
	
	alert(unescape('%uD558%uB098%20%uC774%uC0C1%20%uC120%uD0DD%uD558%uC138%uC694.'));
	return false;
}

function hasList(cbox)
{
	var len = checkSize(cbox);
	if(cbox!=null && len>0) return true;

	alert(unescape('%uD558%uB098%20%uC774%uC0C1%20%uCD94%uAC00%uD558%uC138%uC694.'));
	return false;
}

function getSelectedList(cbox)
{
	var selectedList = "";
	var len = checkSize(cbox);
	if(cbox != null) 
	{
		if(len > 1)
		{
			for(var i=0 ; i<len ; i++) 
			{			
				if (cbox[i].checked==true)
					selectedList += "param="+cbox[i].value+"&";
			}
		}else{
			if (cbox.checked==true) selectedList += "param="+cbox.value;
		}	
	}
	return selectedList;
}

function getList(cbox)
{
	var list = "";
	var len= checkSize(cbox);
	if(cbox!=null)
	{
		if(len>0)
		{
			for(var i=1;i<len;i++)
			{
				list+="param="+cbox[i].value+"&";
			}
		}
		else
		{
			list += "param="+cbox.value;
		}
		alert(list);
	}
	return list;
}

String.prototype.trim = function()
{
  return this.replace(/(^\s*)|(\s*$)/gi, "");
}

String.prototype.replaceAll = function(str1, str2)
{
  var temp_str = "";

  if (this.trim() != "" && str1 != str2)
  {
    temp_str = this.trim();

    while (temp_str.indexOf(str1) > -1)
    {
      temp_str = temp_str.replace(str1, str2);
    }
  }

  return temp_str;
}

function newXMLHTTP() {

	if(window.XMLHttpRequest) {
		try {
			xmlhttp = new XMLHttpRequest();
		} catch(e) {
			alert("XMLHTTP�� �ʱ�ȭ�� �� ��4ϴ�.");
			return false;
		}
	} else if(window.ActiveXObject) {

		try {
			xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch(e) {
			try {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} catch(e) {
				alert("XMLHTTP�� �ʱ�ȭ�� �� ��4ϴ�.");
				return false;
			}
		}
	} else {
		alert("XMLHTTP�� �ʱ�ȭ�� �� ��4ϴ�.");
		return false;
	}

	return xmlhttp;

} 

function postForm(obj) {

	var child = obj.elements;
	var data = new Array();

	for(var i = 0;i < child.length;i++) {

		//�� ��� ���� �ƴ� ��� ����
		if(child[i].tagName != "INPUT" && child[i].tagName != "TEXTAREA" && child[i].tagName != "SELECT") continue;

		//��ư ����
		if(child[i].type == "submit" || child[i].type == "button" || child[i].type == "reset") continue;

		//üũ�ڽ�, ���� ��ư ó��
		if((child[i].type == "radio" || child[i].type == "checkbox") && !child[i].checked) continue;

		//child[i].style.backgroundColor = "#FFF";

		//text,password Ÿ���� input�̳� select���� required="required"�� ��� value�� ��8�� ����
		if(child[i].getAttributeNode("required") && !child[i].value) {
			child[i].focus();
			alert("�ش� �׸��� ���� ��ų� �߸�Ǿ�4ϴ�.");
			return false;
		}
		var retstr = child[i].value;
		retstr = retstr.replace(/&/gi, "");
		retstr = retstr.replace(/=/gi, "");
		if (child[i].tagName == "SELECT" || child[i].tagName == "select") {
			if (child[i].multiple) {
				for (j=0; j<child[i].length; j++) {
					retstr = child[i].options[j].value;
					retstr = retstr.replace(/&/gi, "");
					retstr = retstr.replace(/=/gi, "");
					data.push(child[i].name+"="+retstr);
				}
			}
			else {
			   	data.push(child[i].name+"="+retstr);
			}
		}
		else {
		   	data.push(child[i].name+"="+retstr);
		}

	}

	var senddata = data.join("&");

	return senddata;

}

function changecursor(obj, cursorStyle) {

	obj.style.cursor = cursorStyle;
	
	var child = obj.elements;

	for(i = 0;i < child.length;i++) {
		child[i].style.cursor = cursorStyle;
	}

}

function selectedAll(){
	var form = document.forms[0];
	for(i=0;i<form.elements.length;i++) {
		if(form.elements[i].type == "select-multiple"){
			for(j=0; j<form.elements[i].options.length; j++){
				form.elements[i].options[j].selected = "true";
			}
		}
	}
}

function delCheck(delTarget)
{
	return confirm("Delete selected "+delTarget+"?");
}
