package ext.psk.wf.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
import ext.psk.util.PageControl;

import wt.doc.WTDocument;
import wt.fc.PagingQueryResult;
import wt.fc.WTObject;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import ext.psk.wf.*;
import ext.psk.ecm.ecr.ECRHelper;
import ext.psk.ecm.ecr.ECRequest;
import ext.psk.ecm.eo.*;

import ext.psk.common.*;
import ext.psk.ecm.eo.EOBetaAForm;
import ext.psk.ecm.ev.EVHelper;

public class WFRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getParameter("cmd");
		String returnURI = "";
		String strReturn = "";
		
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		
		System.out.println("Request Start ===== " + cmd);
		Iterator itor = (Iterator)req.getParameterNames();
		while( itor.hasNext() ) {
			String key = itor.next().toString();
			//String tempValue = CommonUtil.checkNull( req.getParameter(key) );
			
			String[] tempValues = req.getParameterValues(key);
			
			//reference 의 항목만 단건 또는 여러건으로 올 수 있으므로 따로 처리함
			if( key.equals("receiveTeam") || key.equals("reference") ) {
				String[] values = req.getParameterValues(key);
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("only key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			} else if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = req.getParameterValues(key);
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			
			if( cmd.equals("approvePreEO") || cmd.equals("approveECR") || cmd.equals("approveEVR") || cmd.equals("approveEVN") || cmd.equals("approveNexus") ) {
				
				WTObject obj = null;
				strReturn = WFHelper.service.requestApprove(obj, form);
				
				if( strReturn.startsWith("SUCCESS")) {
					if( cmd.equals("approveNexus") ) {
						//this.alertNsetValueNclose(res, strReturn, "apprSuccessEnd()");
						this.alertNsetValueNclose(res, strReturn);
					} else {
						this.alertNCallFuncNclose(res, strReturn, callMathod);
					}
				} else {
					if( cmd.equals("approveNexus") ) {
						//this.alertNsetValueNclose(res, strReturn, "apprFailEnd()");
						this.alertNsetValueNclose(res, strReturn);
					} else {
						this.alert(res, strReturn);
					}
				}
				
			} else if( cmd.equals("registCCB") ) {			//Common Regist
				WTObject obj = null;
				strReturn = WFHelper.service.saveCCBReview(obj, form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			
			} else if( cmd.equals("listPSCR") || cmd.equals("listPSCRCCB") ) {
				if( cmd.equals("listPSCR") ) {
					returnURI = "/extcore/psk/jsp/ecm/psc/pscr-list.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/workflow/CCB-list.jsp";
				}
				
				HashMap resultMap = WFHelper.service.queryPSCR(form);
				
				if( cmd.equals("listPSCRCCB") ) {
					QueryResult pagingResult = (QueryResult)resultMap.get("results");
					session.setAttribute("controlPSCR", pagingResult);
					
				} else {
					PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
					PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
					session.setAttribute("controlPSCR", control);
					
				}

				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("viewPSCR") ) {
				returnURI = "/extcore/psk/jsp/ecm/psc/pscr-view.jsp";
				
				HashMap resultMap = WFHelper.service.queryPSCR(form);
				WTDocument pscrForm = (WTDocument)resultMap.get("results");

				session.setAttribute("pscrForm", pscrForm);

				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("listPSCN") ) {
				returnURI = "/extcore/psk/jsp/ecm/psc/pscn-list.jsp";

				HashMap resultMap = WFHelper.service.queryPSCN(form);
				PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
				PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
				
				session.setAttribute("controlPSCN", control);

				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("viewPSCN") ) {
				returnURI = "/extcore/psk/jsp/ecm/psc/pscr-view.jsp";
				
				HashMap resultMap = WFHelper.service.queryPSCN(form);
				WTDocument pscnForm = (WTDocument)resultMap.get("results");

				session.setAttribute("pscnForm", pscnForm);

				this.gotoResult( req, res, returnURI);

			}
			
			System.out.println("Request End ===== " + cmd);
			
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}
