// Generated WFService%4C86F2AB0399: ? 09/08/10 15:22:12
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.wf;

import java.lang.String;
import java.util.HashMap;
import wt.fc.WTObject;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin WFService%4C86F2AB0399.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end WFService%4C86F2AB0399.doc

@RemoteInterface
public interface WFService {


   //##begin user.attributes preserve=yes
	
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin checkApproveStep%4C86F34D01C5.doc preserve=no
   /**
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end checkApproveStep%4C86F34D01C5.doc

   public String checkApproveStep( WTObject form, HashMap list )
            throws WTException;

   //##begin saveCCBReview%4C86F4AE01F4.doc preserve=no
   /**
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end saveCCBReview%4C86F4AE01F4.doc

   public String saveCCBReview( WTObject form, HashMap list )
            throws WTException;

   //##begin requestApprove%4C86F6460186.doc preserve=no
   /**
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end requestApprove%4C86F6460186.doc

   public String requestApprove( WTObject form, HashMap list )
            throws WTException;

   //##begin getApproveList%4C86F6F50399g.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end getApproveList%4C86F6F50399g.doc

   public HashMap getApproveList( WTObject form )
            throws WTException;

   //##begin complete%4C86F71B03A9.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end complete%4C86F71B03A9.doc

   public String complete( WTObject form )
            throws WTException;

   //##begin reject%4C86F74D01B5.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end reject%4C86F74D01B5.doc

   public String reject( WTObject form )
            throws WTException;

   //##begin release%4C86F774034B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end release%4C86F774034B.doc

   public String release( WTObject form )
            throws WTException;

   //##begin interfacePLM%4C86F7CF0000.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end interfacePLM%4C86F7CF0000.doc

   public HashMap interfacePLM( HashMap form )
            throws WTException;

   //##begin queryPSCR%4C86F8B802CE.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end queryPSCR%4C86F8B802CE.doc

   public HashMap queryPSCR( HashMap form )
            throws WTException;

   //##begin queryPSCN%4C86F8CB03D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end queryPSCN%4C86F8CB03D8.doc

   public HashMap queryPSCN( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
