// Generated StandardWFService%4C86F29801E4: ? 11/01/10 16:09:50
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.wf;


import ext.psk.common.CommonCode;
import ext.psk.common.util.InterfaceUtil;
import ext.psk.common.util.InterfaceUtilSendEO;
import ext.psk.ecm.ecr.ECRequest;
import ext.psk.ecm.eo.EOAlphaForm;
import ext.psk.ecm.ev.EOtoEVRLink;
import ext.psk.ecm.ev.EVNotice;
import ext.psk.ecm.ev.EVRequest;
import ext.psk.util.CommonUtil;
import ext.psk.util.LdapSearchUser;
import ext.psk.util.PSKCommonUtil;
import ext.psk.util.PageControl;
import ext.psk.wf.WFService;

import java.beans.PropertyVetoException;
import java.io.Serializable;
import java.lang.String;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Vector;

import wt.clients.folder.FolderTaskLogic;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.service.StandardIBADefinitionService;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.project.Role;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamTemplate;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
//##end user.imports

//##begin StandardWFService%4C86F29801E4.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardWFService</code> static factory method(s), not
 * the <code>StandardWFService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardWFService%4C86F29801E4.doc

public class StandardWFService extends StandardManager implements WFService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.wf.wfResource";
   private static final String CLASSNAME = StandardWFService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardWFService%newStandardWFServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardWFService
    * @exception wt.util.WTException
    **/
   //##end newStandardWFService%newStandardWFServicef.doc

   public static StandardWFService newStandardWFService()
            throws WTException {
      //##begin newStandardWFService%newStandardWFServicef.body preserve=no

      StandardWFService instance = new StandardWFService();
      instance.initialize();
      return instance;
      //##end newStandardWFService%newStandardWFServicef.body
   }

   //##begin checkApproveStep%4C86F34D01C5.doc preserve=no
   /**
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end checkApproveStep%4C86F34D01C5.doc

   public String checkApproveStep( WTObject form, HashMap list )
            throws WTException {
      //##begin checkApproveStep%4C86F34D01C5.body preserve=yes
		/**
		 * check Approve List existed Approver
		 */
		System.out.println("form=" + form);

		/**
		 * java.util.HashMap maps = new java.util.HashMap(); maps.put("key",
		 * "review1"); result =
		 * ext.psk.wf.WFHelper.service.checkApproveStep(primaryBusinessObject,
		 * maps); if(result.equals("OK") ) result="검토필요"; else result="검토없음";
		 **/

		String result = "NONE";
		ReferenceFactory rf = new ReferenceFactory();

		String keys = (String) list.get("key");
		WTPrincipalReference wpTemp[] = null;
		Enumeration userList = null;
		Team team = null;

		if (form instanceof EOAlphaForm) {
			EOAlphaForm forms = (EOAlphaForm) form;
			team = (Team) forms.getTeamId().getObject();
			
			if (keys.equals("review1")) {
				result = getRoleList(team, "REVIEWER_LEVEL_1");
			
			} else if (keys.equals("review2")) {
				result = getRoleList(team, "REVIEWER_LEVEL_2");

			} else if (keys.equals("decide")) {
				result = getRoleList(team, "DECIDER");

			} else if (keys.equals("approve")) {
				result = getRoleList(team, "APPROVER");

			} else if (keys.equals("reference")) {
				result = getRoleList(team, "REFERENCER");

			} else if (keys.equals("receiver")) {
				result = getRoleList(team, "RECEIVER");

			} else if (keys.equals("evrupdater")) {
				result = getRoleList(team, "EVRUPDATER");

			}
		} else if(form instanceof ECRequest) {
			ECRequest forms = (ECRequest) form;
			team = (Team) forms.getTeamId().getObject();

			if (keys.equals("review1")) {
				result = getRoleList(team, "REVIEWER_LEVEL_1");

			} else if (keys.equals("review2")) {
				result = getRoleList(team, "REVIEWER_LEVEL_2");

			} else if (keys.equals("decide")) {
				result = getRoleList(team, "DECIDER");

			} else if (keys.equals("approve")) {
				result = getRoleList(team, "APPROVER");

			} else if (keys.equals("reference")) {
				result = getRoleList(team, "REFERENCER");

			} else if (keys.equals("receiver")) {
				result = getRoleList(team, "RECEIVER");

			} else if (keys.equals("evrupdater")) {
				result = getRoleList(team, "EVRUPDATER");

			}
		} else if(form instanceof EVRequest) {
			EVRequest forms = (EVRequest) form;
			team = (Team) forms.getTeamId().getObject();

			if (keys.equals("review1")) {
				result = getRoleList(team, "REVIEWER_LEVEL_1");

			} else if (keys.equals("review2")) {
				result = getRoleList(team, "REVIEWER_LEVEL_2");

			} else if (keys.equals("decide")) {
				result = getRoleList(team, "DECIDER");

			} else if (keys.equals("approve")) {
				result = getRoleList(team, "APPROVER");

			} else if (keys.equals("reference")) {
				result = getRoleList(team, "REFERENCER");

			} else if (keys.equals("receiver")) {
				result = getRoleList(team, "RECEIVER");

			} else if (keys.equals("evrupdater")) {
				result = getRoleList(team, "EVRUPDATER");

			}
		} else if(form instanceof EVNotice) {
			EVNotice forms = (EVNotice) form;
			team = (Team) forms.getTeamId().getObject();

			if (keys.equals("review1")) {
				result = getRoleList(team, "REVIEWER_LEVEL_1");

			} else if (keys.equals("review2")) {
				result = getRoleList(team, "REVIEWER_LEVEL_2");

			} else if (keys.equals("decide")) {
				result = getRoleList(team, "DECIDER");

			} else if (keys.equals("approve")) {
				result = getRoleList(team, "APPROVER");

			} else if (keys.equals("reference")) {
				result = getRoleList(team, "REFERENCER");

			} else if (keys.equals("receiver")) {
				result = getRoleList(team, "RECEIVER");

			} else if (keys.equals("evrupdater")) {
				result = getRoleList(team, "EVRUPDATER");

			}
		} else if(form instanceof WTDocument) {
			WTDocument forms = (WTDocument) form;
			team = (Team) forms.getTeamId().getObject();

			if (keys.equals("review1")) {
				result = getRoleList(team, "REVIEWER_LEVEL_1");

			} else if (keys.equals("review2")) {
				result = getRoleList(team, "REVIEWER_LEVEL_2");

			} else if (keys.equals("decide")) {
				result = getRoleList(team, "DECIDER");

			} else if (keys.equals("approve")) {
				result = getRoleList(team, "APPROVER");

			} else if (keys.equals("reference")) {
				result = getRoleList(team, "REFERENCER");

			} else if (keys.equals("receiver")) {
				result = getRoleList(team, "RECEIVER");

			} else if (keys.equals("evrupdater")) {
				result = getRoleList(team, "EVRUPDATER");

			}
		}

		return result;
      //##end checkApproveStep%4C86F34D01C5.body
   }

   //##begin saveCCBReview%4C86F4AE01F4.doc preserve=no
   /**
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end saveCCBReview%4C86F4AE01F4.doc

   public String saveCCBReview( WTObject form, HashMap list )
            throws WTException {
      //##begin saveCCBReview%4C86F4AE01F4.body preserve=yes
		/**
		 * CCB Review Update CCB Review -->> Receive
		 * 
		 * 1. select Receive Team 2. input Review Description 3. set Receiver
		 */

		String resultMsg = CommonUtil.SUCC;
		Transaction trx = null;
		WTDocument wtReviewForm = null;
		ECRequest ecrReviewForm = null;
		
		try {
			trx = new Transaction();
			
			String result = (String) list.get("result");
			String[] receiveTeams = (String[]) list.get("receiveTeam");
			String receiveTeam = "";
			String description = (String) list.get("description");
			String dueDate = (String) list.get("dueDate");
	
			ReferenceFactory rf = new ReferenceFactory();		
	
			String formOid = (String) list.get("oid");
	
			if (formOid != null && !formOid.equals("")) {
				form = (WTObject) rf.getReference(formOid).getObject();
			} else {
				throw new WTException("requestApprove = formOid = " + formOid);
			}
	
			if (form instanceof ECRequest) {
				// ECR
				ecrReviewForm = (ECRequest) form;
				Team team = (Team) ecrReviewForm.getTeamId().getObject();
	
				ecrReviewForm.setCcbResult(result);

				if (receiveTeams != null) {
					for (int i = 0; i < receiveTeams.length; i++) {
						receiveTeam += receiveTeams[i] + "__/";
					}
				}
				ecrReviewForm.setCcbReceiveTeam(receiveTeam);
				ecrReviewForm.setCcbDescription(description);

				// reviewForm.setCcbDueDate(dueDate);

				ecrReviewForm.setCcbReviewDate(CommonUtil.getCurrentTimestamp());

				PersistenceServerHelper.manager.update(ecrReviewForm);

				if (result != null && !result.equals("")) {
					if (result.equals("Accept")) {
						LifeCycleHelper.service.setLifeCycleState(ecrReviewForm, State.toState("INRECEIVE"), true);
					} else {
						LifeCycleHelper.service.setLifeCycleState(ecrReviewForm, State.toState("REJECTED"), true);
					}
				} else {
					LifeCycleHelper.service.setLifeCycleState(ecrReviewForm, State.toState("REJECTED"), true);
				}
	
				// receiver팀의 User를 get해서
				// receiver Role에 추가
	
				if (result != null && result.equals("Accept") && receiveTeams != null) {
					WTGroup pskGroup = null;
					Enumeration childGroup = null;
	
					for (int i = 0; i < receiveTeams.length; i++) {
						pskGroup = (WTGroup) OrganizationServicesHelper.manager.getPrincipal(receiveTeams[i]);
	
						if (pskGroup != null) {
							childGroup = OrganizationServicesHelper.manager.members(pskGroup, false);
							WTPrincipal subs = null;
							System.out.println("@ pskGroup : " + pskGroup.getName());
	
							if (childGroup != null) {
	
								while (childGroup.hasMoreElements()) {
									subs = (WTPrincipal) childGroup.nextElement();
									// System.out.println("@ subs : " + subs);
	
									if (subs instanceof WTUser) {
										System.out.println("@ User : " + subs.getName());
	
										wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("RECEIVER"), subs, (wt.team.WTRoleHolder2) team);
										wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) ecrReviewForm);
	
									} else if (subs instanceof WTGroup) {
										System.out.println("@ Group : " + subs.getName());
									}
								}
							}
						} else {
							System.out.println("@ pskGroup is null");
						}
					}
				}
	
			} else if (form instanceof WTDocument) {
				// PSCR
				wtReviewForm = (WTDocument) form;
				Team team = (Team) wtReviewForm.getTeamId().getObject();
	
				//IBA 저장으로 변경
				Vector attName = new Vector();
				Vector attValue = new Vector();
	
				if (receiveTeams != null) {
					for (int i = 0; i < receiveTeams.length; i++) {
						receiveTeam += receiveTeams[i] + "__/";
					}
				}
	
				if (receiveTeam == null || receiveTeam.equals("")) receiveTeam = "N/A";
				if (receiveTeam != null && !receiveTeam.equals("")) {
					attName.add("CCBREVIEWTEAM");
					attValue.add(receiveTeam);
				}
	
				if (description == null || description.equals("")) description = "N/A";
				if (description != null && !description.equals("")) {
					attName.add("CCBCOMMENT");
					attValue.add(description);
				}
	
				if (dueDate == null || dueDate.equals("")) dueDate = "N/A";
				if (dueDate != null && !dueDate.equals("")) {
					attName.add("CCBDUEDATE");
					attValue.add(dueDate);
				}
	
				if (result != null && !result.equals("")) {
					attName.add("CCBRESULT");
					attValue.add(result);
				}

				attName.add("CCBREVIEWDATE");
				attValue.add(CommonUtil.getCurrentTime("yyyy-MM-dd HH:mm:ss"));
	
				// }
				if (attName != null) {
					trx.start();

					wt.vc.wip.Workable workable = (wt.vc.wip.Workable) wtReviewForm;
					wt.vc.wip.CheckoutLink checkOutLink = null;
					wt.vc.wip.Workable workingCopy = null;
					wt.vc.wip.Workable orgCopy = null;

					if (!wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
						if (!wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
							wt.folder.Folder folder = wt.vc.wip.WorkInProgressHelper.service.getCheckoutFolder();

							try {
								checkOutLink = (wt.vc.wip.CheckoutLink)wt.vc.wip.WorkInProgressHelper.service.checkout(workable, folder, "");
							} catch(wt.util.WTPropertyVetoException wtpve) {
								throw new WTException(wtpve);
							}
					      
							// get Original copy
							orgCopy = checkOutLink.getOriginalCopy();
							//System.out.println("orgCopy is " + orgCopy);

							// get working copy
							workingCopy = checkOutLink.getWorkingCopy();
							//System.out.println("workingCopy is " + workingCopy);

						} else if (wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
							// get Original copy
							orgCopy = wt.vc.wip.WorkInProgressHelper.service.originalCopyOf(workable);
							// get working copy
							workingCopy = wt.vc.wip.WorkInProgressHelper.service.workingCopyOf(workable);
							//System.out.println("workingCopy is " + workingCopy);
						}

					} else if (wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
						workingCopy = workable;
					}

					wtReviewForm = (WTDocument) workingCopy;

					wtReviewForm = (WTDocument) setIBADataNoCheckout((IBAHolder) wtReviewForm, attName, attValue);
					//System.out.println("wtReviewForm= + " + wtReviewForm);

					wtReviewForm = (WTDocument) PersistenceHelper.manager.save(wtReviewForm);

					// Start checkin ...
					//System.out.println("DB checkin start...");
					wtReviewForm = (WTDocument) wt.vc.wip.WorkInProgressHelper.service.checkin(wtReviewForm, "");
					//System.out.println("DB checkin end...");
					//System.out.println("DB refresh start...");
					wtReviewForm = (WTDocument) PersistenceHelper.manager.refresh(wtReviewForm, true, true);
					//System.out.println("DB refresh end...");
					// End checkin ...
					
					if (result != null && !result.equals("")) {
						if (result.equals("Accept")) {
							LifeCycleHelper.service.setLifeCycleState(wtReviewForm, State.toState("INRECEIVE"), true);
						} else {
							LifeCycleHelper.service.setLifeCycleState(wtReviewForm, State.toState("REJECTED"), true);
						}
					} else {
						LifeCycleHelper.service.setLifeCycleState(wtReviewForm, State.toState("REJECTED"), true);
					}

					trx.commit();
				}
	
				// receiver팀의 User를 get해서
				// receiver Role에 추가
				if (result != null && result.equals("Accept") && receiveTeams != null) {
					WTGroup pskGroup = null;
					Enumeration childGroup = null;
	
					for (int i = 0; i < receiveTeams.length; i++) {
						pskGroup = (WTGroup) OrganizationServicesHelper.manager.getPrincipal(receiveTeams[i]);
	
						if (pskGroup != null) {
							childGroup = OrganizationServicesHelper.manager.members(pskGroup, false);
							WTPrincipal subs = null;
							//System.out.println("@ pskGroup : " + pskGroup.getName());
	
							if (childGroup != null) {
	
								while (childGroup.hasMoreElements()) {
									subs = (WTPrincipal) childGroup.nextElement();
									// System.out.println("@ subs : " + subs);
	
									if (subs instanceof WTUser) {
										//System.out.println("@ User : " + subs.getName());
	
										wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("RECEIVER"), subs, (wt.team.WTRoleHolder2) team);
										wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) wtReviewForm);
	
									} else if (subs instanceof WTGroup) {
										System.out.println("@ Group : " + subs.getName());
									}
								}
							}
						} else {
							System.out.println("@ pskGroup is null");
						}
					}
				}
			}
		} catch (WTPropertyVetoException pve) {
			pve.printStackTrace();
			resultMsg = CommonUtil.FAIL + " : " + pve.getMessage();
			
		} catch (RemoteException re) {
			re.printStackTrace();
			resultMsg = CommonUtil.FAIL + " : " + re.getMessage();
			
		} catch (PropertyVetoException pve) {
			pve.printStackTrace();
			resultMsg = CommonUtil.FAIL + " : " + pve.getMessage();
			
		} catch (Exception e) {
			trx.rollback();

			System.out.println("Start UndoCheckout PSKPart Doc...");
			try {
				if (wt.vc.wip.WorkInProgressHelper.isCheckedOut((wt.vc.wip.Workable) wtReviewForm)) {
					wt.vc.wip.WorkInProgressHelper.service.undoCheckout(wtReviewForm);
				}
			} catch (Exception ee) {
				ee.printStackTrace();
			}
			System.out.println("End UndoCheckout PSKPart Doc...");

			e.printStackTrace();
			resultMsg = CommonUtil.FAIL + " : " + e.getMessage();
			
		} finally {
			trx = null;
		}

		return resultMsg;
		// ##end saveCCBReview%4C86F4AE01F4.body
	}

	// ##begin requestApprove%4C86F6460186.doc preserve=no
	/**
	 * @param form
	 * @param list
	 * @return String
	 * @exception wt.util.WTException
	 **/
	// ##end requestApprove%4C86F6460186.doc
	public String requestApprove(WTObject form, HashMap list) throws WTException {
		// ##begin requestApprove%4C86F6460186.body preserve=yes
		String result = CommonUtil.SUCC;
		ReferenceFactory rf = new ReferenceFactory();

		String sCmd = (String) list.get("cmd");
		try {
			if (sCmd != null && sCmd.equals("approveNexus")) {
				String sPscrNo = (String) list.get("pscrNo");
				String sPscrTitle = (String) list.get("pscrTitle");
				String sPscnNo = (String) list.get("pscnNo");
				String sPscnTitle = (String) list.get("pscnTitle");
				
				WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
				String sUserID = creator.getName(); //(String) list.get("userId");
	
				if (sPscrNo != null && !sPscrNo.equals("")) {
					if (sPscrTitle != null && !sPscrTitle.equals("")) {
						// pscr create
						WTDocument pscrDoc = this.createWTDocument(sUserID, "PSCR", sPscrNo, sPscrTitle);
						form = pscrDoc;
					}
				} else if (sPscnNo != null && !sPscnNo.equals("")) {
					if (sPscnTitle != null && !sPscnTitle.equals("")) {
						// pscn create
						WTDocument pscnDoc = this.createWTDocument(sUserID, "PSCN", sPscnNo, sPscnTitle);
						form = pscnDoc;
					}
				}
			}
	
			String formOid = (String) list.get("oid");
	
			if (formOid != null && !formOid.equals("")) {
				form = (WTObject) rf.getReference(formOid).getObject();
			} else {
				throw new WTException( "requestApprove = formOid = " + formOid );
			}
	
			LifeCycleManaged managedForm = null;
	
			if (form instanceof EOAlphaForm) {
				EOAlphaForm forms = (EOAlphaForm) form;
				managedForm = forms;
	
			} else if (form instanceof ECRequest) {
				ECRequest forms = (ECRequest) form;
				managedForm = forms;
	
			} else if (form instanceof EVRequest) {
				EVRequest forms = (EVRequest) form;
				managedForm = forms;
	
			} else if (form instanceof EVNotice) {
				EVNotice forms = (EVNotice) form;
				managedForm = forms;
				
			} else if (form instanceof WTDocument) {
				// PSCR, PSCN
				WTDocument forms = (WTDocument) form;
				managedForm = forms;
				
			}

	        WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
	        SessionHelper.manager.setAdministrator();
	
			if (managedForm != null) {
				Team team = (Team) managedForm.getTeamId().getObject();
	
				String szReview1 = (String) list.get("review1");
				String szReview2 = (String) list.get("review2");
				String szDecide = (String) list.get("decide");
				String szApprove = (String) list.get("approve");
				String[] szReference = (String[]) list.get("reference");
	
				WTUser getUser = null;
				WTPrincipal getPrincipal = null;
				Enumeration getEnum = null;
	
				if (szReview1 != null && !szReview1.equals("")) {
					getUser = (WTUser) rf.getReference(szReview1).getObject();
	
					getEnum = OrganizationServicesHelper.manager.getPrincipal(getUser.getName(), OrganizationServicesHelper.manager.getDirectoryServiceNames());
					if (getEnum.hasMoreElements()) {
						getPrincipal = (WTPrincipal) getEnum.nextElement();
						if (getPrincipal != null) {
							wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("REVIEWER_LEVEL_1"), getPrincipal, (wt.team.WTRoleHolder2) team);
							wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) managedForm);
						}
					}
				}
	
				if (szReview2 != null && !szReview2.equals("")) {
					getUser = (WTUser) rf.getReference(szReview2).getObject();
	
					getEnum = OrganizationServicesHelper.manager.getPrincipal(getUser.getName(), OrganizationServicesHelper.manager.getDirectoryServiceNames());
					if (getEnum.hasMoreElements()) {
						getPrincipal = (WTPrincipal) getEnum.nextElement();
						if (getPrincipal != null) {
							wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("REVIEWER_LEVEL_2"), getPrincipal, (wt.team.WTRoleHolder2) team);
							wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) managedForm);
						}
					}
				}
	
				if (szDecide != null && !szDecide.equals("")) {
					getUser = (WTUser) rf.getReference(szDecide).getObject();
	
					getEnum = OrganizationServicesHelper.manager.getPrincipal(getUser.getName(), OrganizationServicesHelper.manager.getDirectoryServiceNames());
					if (getEnum.hasMoreElements()) {
						getPrincipal = (WTPrincipal) getEnum.nextElement();
						if (getPrincipal != null) {
							wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("DECIDER"), getPrincipal, (wt.team.WTRoleHolder2) team);
							wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) managedForm);
						}
					}
				}
	
				if (szApprove != null && !szApprove.equals("")) {
					getUser = (WTUser) rf.getReference(szApprove).getObject();
	
					getEnum = OrganizationServicesHelper.manager.getPrincipal(getUser.getName(), OrganizationServicesHelper.manager.getDirectoryServiceNames());
					if (getEnum.hasMoreElements()) {
						getPrincipal = (WTPrincipal) getEnum.nextElement();
						if (getPrincipal != null) {
							wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("APPROVER"), getPrincipal, (wt.team.WTRoleHolder2) team);
							wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) managedForm);
						}
					}
				}
	
				if (szReference != null && (szReference.length > 0)) {
					for (int k = 0; k < szReference.length; k++) {
						getUser = (WTUser) rf.getReference(szReference[k]).getObject();
	
						getEnum = OrganizationServicesHelper.manager.getPrincipal(getUser.getName(), OrganizationServicesHelper.manager.getDirectoryServiceNames());
						while (getEnum.hasMoreElements()) {
							getPrincipal = (WTPrincipal) getEnum.nextElement();
							if (getPrincipal != null) {
								wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("REFERENCER"), getPrincipal, (wt.team.WTRoleHolder2) team);
								wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) managedForm);
							}
						}
					}
				}
			}
			
			LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) managedForm, State.toState("INAPPROVE"));
	        SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			
		} catch (WTException e) {
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//System.out.println("@@@ requestApprove error : " + e);
		}

		return result;
      //##end requestApprove%4C86F6460186.body
   }

   //##begin getApproveList%4C86F6F50399g.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end getApproveList%4C86F6F50399g.doc

   public HashMap getApproveList( WTObject form )
            throws WTException {
      //##begin getApproveList%4C86F6F50399g.body preserve=yes
	   /**
	    * Approve List And Approve History
	    */
	   
      return new HashMap();
      //##end getApproveList%4C86F6F50399g.body
   }

   //##begin complete%4C86F71B03A9.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end complete%4C86F71B03A9.doc

   public String complete( WTObject form )
            throws WTException {
      //##begin complete%4C86F71B03A9.body preserve=yes
	   /**
	    * Action after Completed
	    * 
	    * 1. Part : create cad, create link part to cad
	    * 2. pre-eo : create link and save quantity
	    * 
	    */
	   
	   String result = CommonUtil.SUCC;
	   
	   try {
		   
		   if( form instanceof EOAlphaForm) {
			   /**
			    *  eo 후처리 작업 진행
			    *	갑지 
			    *
			    *	을A
			    *		해당 Part를 Released 상태로 변경
			    **/

			   
			   EOAlphaForm alphaForm = (EOAlphaForm)form;
			   Team team = (Team) alphaForm.getTeamId().getObject();
			   //alphaForm.s
			   String needEVR = alphaForm.getNeedEVR();

			   /**
			    *  EO가 release되었을때  needEVR이 'off' 일때만  
			    * 을A지의 Part, CAD의 상태를 Released 로 상태 변경
			    * needEVR이 'on' 일때는 Skip한다.
			    * 
			    **/
			   String alphaFormState = alphaForm.getState().toString();
			   
//			   if( !alphaFormState.equals("PRERELEASED") ) {
				   if( needEVR != null && needEVR.equals("on") ) {
					   WTUser evrCreator = alphaForm.getEvrcreator();
					   
					   if( evrCreator != null ) {
						   wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("EVRUPDATER"), evrCreator, (wt.team.WTRoleHolder2) team);
						   wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) alphaForm);
					   }
					   
					   /**
					    *  EVR 생성
					    *  
					    *  1. EO에서 입력된 EVR Title, Test List, EVR Creator만을 설정한다.
					    *  2. EO와 EVR의 링크를 생성한다.
					    *  3. EVR Creator에서 Noti하여 EVR을 Update하도록 Task를 할당한다.
					    *  
					    */
					   
					   // evr 생성
					   this.createEVR(alphaForm, alphaForm.getEvrTitle(), alphaForm.getEvrTestList(), evrCreator.getName());
					   
//					   LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) alphaForm, State.toState("RELEASED"));
				   
				   } else {
					   /**
					    * evr이 없으므로 
					    * 바로 완료 처리를 실행
					    * 1. evr
					    */
					   WTUser evrCreator = alphaForm.getEvrcreator();
					   
					   if( evrCreator != null ) {
						   wt.team.TeamHelper.service.addRolePrincipalMap(Role.toRole("EVRUPDATER"), evrCreator, (wt.team.WTRoleHolder2) team);
						   wt.lifecycle.LifeCycleHelper.service.augmentRoles((wt.lifecycle.LifeCycleManaged) alphaForm);
					   }
					   
//					   LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) alphaForm, State.toState("RELEASED"));
				   }
//			   } else {
//				   // EVN 에 의해서 호출된 경우
//				   // EO의 state는 Pre released 인 경우
				   //
//				   // 위와 같이 하지말고 EVN에서 EO의 상태를 Released로 변경만 한다. 
//
//				   LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) alphaForm, State.toState("RELEASED"));
//			   }
			   
			   // 상태 변경은 WorkFlow에서 처리함.
			   
			   // release Date save
				Transaction trx = new Transaction();
				try {
					trx.start();
	
					alphaForm.setReleaseDate(CommonUtil.getCurrentTimestamp());
					alphaForm = (EOAlphaForm) PersistenceHelper.manager.save(alphaForm);
					
					/**
					 * @Todo
					 *  
					 * 을A지의 Part와 CAD를 쿼리하여 Released로 상태 변경
					 */
					
					trx.commit();
	
				} catch (Exception e) {
					trx.rollback();
					e.printStackTrace();
					throw new WTException(e);
	
				} finally {
					trx = null;
				}
			   
		   } else if (form instanceof ECRequest) {
				ECRequest forms = (ECRequest) form;
				Transaction trx = new Transaction();
				try {
					trx.start();
	
					forms.setReleaseDate(CommonUtil.getCurrentTimestamp());
					forms = (ECRequest) PersistenceHelper.manager.save(forms);
					
					trx.commit();
	
				} catch (Exception e) {
					trx.rollback();
					e.printStackTrace();
					throw new WTException(e);
	
				} finally {
					trx = null;
				}
	
			} else if (form instanceof EVRequest) {
				EVRequest forms = (EVRequest) form;
				Transaction trx = new Transaction();
				try {
					trx.start();
	
					forms.setReleaseDate(CommonUtil.getCurrentTimestamp());
					forms = (EVRequest) PersistenceHelper.manager.save(forms);
					
					trx.commit();
	
				} catch (Exception e) {
					trx.rollback();
					e.printStackTrace();
					throw new WTException(e);
	
				} finally {
					trx = null;
				}
	
			} else if (form instanceof EVNotice) {
				EVNotice forms = (EVNotice) form;
				Transaction trx = new Transaction();
				try {
					trx.start();
	
					forms.setReleaseDate(CommonUtil.getCurrentTimestamp());
					forms = (EVNotice) PersistenceHelper.manager.save(forms);
					
					/**
					 * @Todo
					 * 
					 * EVN --> EVR --> EO 를 찾아 
					 * EO를  nexus로 Interface 처리한다.
					 * 
					 * 찾은 EO가 needEVR이 체크 되어있을때만 실행
					 */
					
					
					trx.commit();
	
				} catch (Exception e) {
					trx.rollback();
					e.printStackTrace();
					throw new WTException(e);
	
				} finally {
					trx = null;
				}
				
			} else if (form instanceof WTDocument) {
				// PSCR, PSCN
				WTDocument forms = (WTDocument) form;
//				Transaction trx = new Transaction();
				try {
//					trx.start();
	
					/**
					 * IBA를 저장 하는것으로 처리
					 */
	//				forms.setReleaseDate(CommonUtil.getCurrentTimestamp());
	//				forms = (EOAlphaForm) PersistenceHelper.manager.save(forms);
					
//					trx.commit();
					
					

					/**
					 * state Interface to Nexus
					 */
					HashMap map = new HashMap();
					map.put("cmd", "SendPSCState");
					map.put("pscNumber", forms.getNumber());
					map.put("docState", forms.getState().toString());
					map.put("docOid", forms.toString());
					//map.put("interFormOid", "SendEO");
					
					this.interfacePLM(map);
	
				} catch (Exception e) {
//					trx.rollback();
					e.printStackTrace();
					throw new WTException(e);
	
				} finally {
//					trx = null;
				}
			}
		   
	   } catch(Exception ex) {
		   ex.printStackTrace();
		   result = CommonUtil.FAIL + " : " + ex.getMessage();
	   }

      return result;
      //##end complete%4C86F71B03A9.body
   }

   //##begin reject%4C86F74D01B5.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end reject%4C86F74D01B5.doc

   public String reject( WTObject form )
            throws WTException {
      //##begin reject%4C86F74D01B5.body preserve=yes

	   /**
	    *  EO가 reject되었을때
	    *  을A지의 Part, CAD의 상태를 In Work으로 상태 변경
	    **/

		String result = CommonUtil.SUCC;

		try {

			if (form instanceof EOAlphaForm) {
				EOAlphaForm alphaForm = (EOAlphaForm) form;
				
			} else if (form instanceof EVRequest) {
				EVRequest forms = (EVRequest) form;

			} else if (form instanceof EVNotice) {
				EVNotice forms = (EVNotice) form;

			} else if (form instanceof WTDocument) {
				// PSC state Interface
				WTDocument forms = (WTDocument) form;
				
				HashMap map = new HashMap();
				map.put("cmd", "SendPSCState");
				map.put("pscNumber", forms.getNumber());
				map.put("docState", forms.getState().toString());
				map.put("docOid", forms.toString());
				//map.put("interFormOid", "SendEO");
				
				this.interfacePLM(map);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			result = CommonUtil.FAIL + " : " + ex.getMessage();
		}

		return "";
      //##end reject%4C86F74D01B5.body
   }

   //##begin release%4C86F774034B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end release%4C86F774034B.doc

	public String release(WTObject form) throws WTException {
		// ##begin release%4C86F774034B.body preserve=yes

		/**
		 * This method is called Object's state is InApprove.
		 * 
		 * 결재가 시작될때 시작.
		 * 
		 * 
		 * EO가 결재 시작되었을때 을A지의 Part, CAD의 상태를 In Approve으로 상태 변경
		 */

		String result = CommonUtil.SUCC;

		try {

			if (form instanceof EOAlphaForm) {

				EOAlphaForm alphaForm = (EOAlphaForm) form;
				Team team = (Team) alphaForm.getTeamId().getObject();
				// alphaForm.s
				String needEVR = alphaForm.getNeedEVR();
				if (needEVR != null && needEVR.equals("on")) {

				}
				
				/**
				 * 을A지의 Part, CAD를 In Approve로 상태 변경한다.
				 */

			} else if (form instanceof EVRequest) {
				EVRequest forms = (EVRequest) form;

			} else if (form instanceof EVNotice) {
				EVNotice forms = (EVNotice) form;

			} else if (form instanceof WTDocument) {
				// PSC state Interface
				WTDocument forms = (WTDocument) form;
				
				HashMap map = new HashMap();
				map.put("cmd", "SendPSCState");
				map.put("pscNumber", forms.getNumber());
				map.put("docState", forms.getState().toString());
				map.put("docOid", forms.toString());
				//map.put("interFormOid", "SendEO");
				
				this.interfacePLM(map);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			result = CommonUtil.FAIL + " : " + ex.getMessage();
		}

		return "";
		// ##end release%4C86F774034B.body
	}

   //##begin interfacePLM%4C86F7CF0000.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end interfacePLM%4C86F7CF0000.doc

   public HashMap interfacePLM( HashMap form )
            throws WTException {
      //##begin interfacePLM%4C86F7CF0000.body preserve=yes
	   HashMap resultMap = new HashMap();
	   String sCmd = (String)form.get("cmd");
	   
	   try {
		   
		   if( sCmd == null || sCmd.equals("") ) {
			   
		   } else if( sCmd.equals("GetMasterData") ) {
			   // Create FSC, Module, UPG, UPGVC
			   InterfaceUtil util = new InterfaceUtil();
			   util.getMasterDataFromNexus();
			   
		   } else if( sCmd.equals("SendEO") ) {
			   // send EO Object to PLM
			   InterfaceUtilSendEO util = new InterfaceUtilSendEO();
	
			   String sEOOid = (String) form.get("eoOid");
			   String sInterFormOid = (String) form.get("interFormOid");
			   
			   if( sInterFormOid != null && !sInterFormOid.equals("") )
				   util.sendEO(sEOOid, sInterFormOid);
			   else 
				   util.sendEO(sEOOid);
			   
		   } else if( sCmd.equals("searchFSC")) {
			   // get GL(UPG VC List)
			   String sSegmentCode = (String) form.get("segmentCode");
			   QueryResult qr = this.queryFSC(sSegmentCode);
	
			   resultMap.put("result", qr);
			   
		   } else if( sCmd.equals("GetGLforFSC")) {
			   // get GL(UPG VC List)
			   InterfaceUtil util = new InterfaceUtil();
	
			   String sFscCode = (String) form.get("selectFSC");
			   String sSegmentCode = (String) form.get("segmentCode");
			   
			   Vector upgList = util.getGLforFSC(sFscCode);
			   resultMap.put("result", upgList);
			   
		   } else if( sCmd.equals("GetGLforMODULE")) {
			   // get GL(UPG VC List)
			   InterfaceUtil util = new InterfaceUtil();
			   
			   String sModuleCode = (String) form.get("moduleCode");
			   String sSegmentCode = (String) form.get("segmentCode");
			   
			   Vector upgList = util.getGLforModule(sModuleCode, sSegmentCode);
			   resultMap.put("result", upgList);
			   
		   } else if( sCmd.equals("SendPSCState")) {
			   // update PSCR/PSCN Status
			   InterfaceUtil util = new InterfaceUtil();
	
			   String sPscNumber = (String) form.get("pscNumber");
			   String sDocState = (String) form.get("docState");
			   String sDocOid = (String) form.get("docOid");
			   
			   String sInterFormOid = (String) form.get("interFormOid");
			   

			   if( sInterFormOid != null && !sInterFormOid.equals("") )
				   util.updatePSCState(sDocOid, sPscNumber, sDocState, sInterFormOid);
			   else 
				   util.updatePSCState(sDocOid, sPscNumber, sDocState);
			   
			   
		   } else if( sCmd.equals("saveDMUPart")) {
			   // update PSCR/PSCN Status
			   InterfaceUtil util = new InterfaceUtil();
	
			   String sDMUType = (String) form.get("dmuType");// FSC, Module
			   String sFscCode = (String) form.get("selectFSC");
			   String sModuleCode = CommonUtil.checkNull( (String) form.get("moduleCode") );
			   String sSegmentCode = (String) form.get("segmentCode");
	
			   InterfaceUtil iu = new InterfaceUtil();
			   String segmentCodeName = iu.getSegmentCode(sSegmentCode);
			   
			   String partNumber = "DMU";
			   try {
				   partNumber += CommonUtil.getSeqDMU("DMU_SEQ");
			   } catch(Exception ex){
				   ex.printStackTrace();
				   throw new WTException(ex.getMessage());
			   }
			   String partName = "";
			   
			   WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
			   String sUserID = creator.getName();
			   
			   Vector upgList = null;
			   if( sDMUType.equals("FSC") ) {
				   upgList = util.getGLforFSC(sFscCode);
				   partName = "FSC_DMU_FSCCode=" + sFscCode + "_" + sUserID;
				   //segmentCode = sFscCode.substring(2,3);
				   
			   } else if( sDMUType.equals("Module") ) {
				   upgList = util.getGLforModule(sModuleCode, sSegmentCode);
				   partName = "Module_DMU_ModuleCode=" + sModuleCode + "_SegmentCode=" + segmentCodeName + "_" + sUserID;
				   //segmentCode = sSegmentCode;
			   }
			   
			   WTPart dmuPart = null;
			   if( sSegmentCode != null && !sSegmentCode.equals("") ) {
				   dmuPart = util.makeDMUPart(segmentCodeName, partNumber, partName, upgList);
				   
				   resultMap.put("result", dmuPart);
			   } else {
				   throw new WTException("@ error segment code!");
			   }
		   }
	   } catch ( Exception ex) {
		   ex.printStackTrace();
	   }
	   
      return resultMap;
      //##end interfacePLM%4C86F7CF0000.body
   }

   //##begin queryPSCR%4C86F8B802CE.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end queryPSCR%4C86F8B802CE.doc

   public HashMap queryPSCR( HashMap form )
            throws WTException {
      //##begin queryPSCR%4C86F8B802CE.body preserve=yes
		PagingQueryResult pagingResults = null;
		HashMap results = new HashMap();
		WTDocument pscrForm = null;

		String sCmd = (String) form.get("cmd");
		String sPage = (String) form.get("page");
		String sTotalPage = (String) form.get("totalPage");
		String sSessionID = (String) form.get("sessionID");
		
		String sNumber    = (String) form.get("shNumber");  
		String sName      = (String) form.get("shTitle");
		
		String sState = (String) form.get("shApprovalStatus");		//state
		
		String sCreatorName = (String) form.get("shIssueUserNm");	
		String sCreator = "";
		if( sCreatorName != null && !sCreatorName.equals("") ) {
			LdapSearchUser searchUserId = new LdapSearchUser();

			sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
		}
		
		String sFromRegDate   = (String) form.get("shFromRegDate");
		String sToRegDate   = (String) form.get("shToRegDate");
		
		String sDepartment   = (String) form.get("shDepartment");
		String sOid			 = (String) form.get("oid");

		try {
			
			if( sCmd.startsWith("listPSCR") ) {
				QuerySpec query = new QuerySpec();
				query.setAdvancedQueryEnabled(true);
	
				if (query.getConditionCount() > 0) query.appendAnd();
	
				Class classType = WTDocument.class;
				int pskChangeIndex = query.appendClassList(classType, true);
	
				query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });
	
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, WTDocument.DOC_TYPE, SearchCondition.EQUAL,  "PSCR"), new int[] { pskChangeIndex });
				
				if (sNumber != null && !sNumber.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, WTDocument.NUMBER, SearchCondition.LIKE,  "%" + sNumber + "%"), new int[] { pskChangeIndex });
				}
	
				if (sName != null && !sName.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					
					query.appendWhere(new SearchCondition(classType, WTDocument.NAME, SearchCondition.LIKE, "%" + sName + "%"), new int[] { pskChangeIndex });
				}
				
				if (sState != null && !sState.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
				}
								
				if (sCreator != null && !sCreator.equals("")) {
					long lcreator = 0;
					WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
					if( creator != null ) { 
						lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
		
						if (query.getConditionCount() > 0) query.appendAnd();
						query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
					}
				}
				
				//RegistDate from to Start
				if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
				}
		          
				if ( sToRegDate != null && !sToRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
				}
				//RegistDate from to End
				
				if (sDepartment != null && !sDepartment.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "writeDept", SearchCondition.LIKE, "%" + sDepartment + "%"), new int[] { pskChangeIndex });
				}
				
				if( sCmd.equals("listPSCRCCB") ) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, "CCBREVIEW"), new int[] { pskChangeIndex });
				}
	
				//System.out.println("## REQUEST Query:" + query.toString());
	
				QueryResult queryResult = PersistenceHelper.manager.find(query);
				
				if( sCmd.equals("listPSCR") ) {
					if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
						pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
						
					} else if (sCmd != null && sCmd.equals("EXPORT")) {
						pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
						
					} else {
						int PAGE = Integer.parseInt(sPage);
						long pagingSessionID = Long.parseLong(sSessionID);
						pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
						
					}
				
					results.put("results", pagingResults);
				} else {
					results.put("results", queryResult);
				}
				
			} else if( sCmd.startsWith("viewPSCR") ) {
				ReferenceFactory rf = new ReferenceFactory();
				pscrForm = (WTDocument) rf.getReference(sOid).getObject();

				results.put("results", pscrForm);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return results;
      //##end queryPSCR%4C86F8B802CE.body
   }

   //##begin queryPSCN%4C86F8CB03D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end queryPSCN%4C86F8CB03D8.doc

   public HashMap queryPSCN( HashMap form )
            throws WTException {
      //##begin queryPSCN%4C86F8CB03D8.body preserve=yes
		PagingQueryResult pagingResults = null;
		HashMap results = new HashMap();
		WTDocument pscnForm = null;

		String sCmd = (String) form.get("cmd");
		String sPage = (String) form.get("page");
		String sTotalPage = (String) form.get("totalPage");
		String sSessionID = (String) form.get("sessionID");
		
		String sNumber    = (String) form.get("shNumber");  
		String sName      = (String) form.get("shTitle");
		
		String sState = (String) form.get("shApprovalStatus");		//state
		
		String sCreatorName = (String) form.get("shIssueUserNm");	
		String sCreator = "";
		if( sCreatorName != null && !sCreatorName.equals("") ) {
			LdapSearchUser searchUserId = new LdapSearchUser();

			sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
		}
		
		String sFromRegDate   = (String) form.get("shFromRegDate");
		String sToRegDate   = (String) form.get("shToRegDate");
		
		String sDepartment   = (String) form.get("shDepartment");
		String sOid			 = (String) form.get("oid");

		try {
			
			if( sCmd.startsWith("listPSCN") ) {
				QuerySpec query = new QuerySpec();
				query.setAdvancedQueryEnabled(true);
	
				if (query.getConditionCount() > 0) query.appendAnd();
	
				Class classType = WTDocument.class;
				int pskChangeIndex = query.appendClassList(classType, true);
	
				query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });
	
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, WTDocument.DOC_TYPE, SearchCondition.EQUAL,  "PSCN"), new int[] { pskChangeIndex });
				
				if (sNumber != null && !sNumber.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, WTDocument.NUMBER, SearchCondition.LIKE,  "%" + sNumber + "%"), new int[] { pskChangeIndex });
				}
	
				if (sName != null && !sName.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, WTDocument.NAME, SearchCondition.LIKE, "%" + sName + "%"), new int[] { pskChangeIndex });
				}
				
				if (sState != null && !sState.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
				}
				
				if (sCreator != null && !sCreator.equals("")) {
					long lcreator = 0;
					WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
					if( creator != null ) { 
						lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
		
						if (query.getConditionCount() > 0) query.appendAnd();
						query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
					}
				}
				
				//RegistDate from to Start
				if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
				}
		          
				if ( sToRegDate != null && !sToRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
				}
				//RegistDate from to End
				
				if (sDepartment != null && !sDepartment.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "writeDept", SearchCondition.LIKE, "%" + sDepartment + "%"), new int[] { pskChangeIndex });
				}
				
				//System.out.println("## REQUEST Query:" + query.toString());
	
				QueryResult queryResult = PersistenceHelper.manager.find(query);
				
				if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
					pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
					
				} else if (sCmd != null && sCmd.equals("EXPORT")) {
					pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
					
				} else {
					int PAGE = Integer.parseInt(sPage);
					long pagingSessionID = Long.parseLong(sSessionID);
					pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
					
				}

				results.put("results", pagingResults);
			} else if( sCmd.startsWith("viewPSCN") ) {
				ReferenceFactory rf = new ReferenceFactory();
				pscnForm = (WTDocument) rf.getReference(sOid).getObject();

				results.put("results", pscnForm);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return results;
      //##end queryPSCN%4C86F8CB03D8.body
   }

   //##begin user.operations preserve=yes
   public String getRoleList(Team team, String roleName) throws WTException {
	   String result = "OK";
		Enumeration userList = team.getPrincipalTarget(Role.toRole(roleName));

		if ((userList == null) || (userList.hasMoreElements() == false))
			result = "NONE";
		
		return result;
   }

	public WTDocument createWTDocument(String userid, String docType, String docNo, String docTitle) throws WTException {
		WTDocument docForm = WTDocument.newWTDocument();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			WTUser sCreator = (WTUser) OrganizationServicesHelper.manager.getUser(userid);

			// set Number
			docForm.setNumber(docNo);
			docForm.setName(docTitle);
			docForm.setTitle(docTitle);

			docForm.setDocType(DocumentType.toDocumentType(docType));
			// docForm.setOwnership(arg0)
			docForm.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(docType));

			// save content
			String liftCycle = "LC_PSK_ECM";

			WTLibrary product = PSKCommonUtil.getWTLibrary("Document");
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

			String yy = CommonUtil.getCurrentTime("yyyy");
			String mm = CommonUtil.getCurrentTime("MM");
			String sFolderPath = "/Default/" + docType + "/" + yy + "/" + mm;

			// Folder assign
			Folder folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
			FolderHelper.assignLocation((FolderEntry) docForm, folder);

			docForm.setContainer(product);
			LifeCycleHelper.setLifeCycle(docForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

			String teamName = "PSK_APPROVE_TEMPLATE";
			TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);

			try {
				docForm = (WTDocument) wt.team.TeamHelper.setTeamTemplate(docForm, mainTeam);

			} catch (WTPropertyVetoException pve) {
				pve.printStackTrace();
			}
	        
			docForm = (WTDocument) PersistenceHelper.manager.save(docForm);
			
			//result += " : " + docForm.getNumber();
			//System.out.println("@ created WTDocument(PSCR,PSCN) =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			throw new WTException(e);

		} finally {
			trx = null;
		}

		return docForm;
	}

   public EVRequest createEVR(EOAlphaForm eoForm, String title, String testList, String userid) throws WTException {
       EVRequest evrForm = EVRequest.newEVRequest();
       ReferenceFactory rf = new ReferenceFactory();

       String result = CommonUtil.SUCC;

       Transaction trx = new Transaction();
       try {
           trx.start();
           
           String sTitle = title;
           String sTestList = testList;
           String sUserid = userid;
           String sDepartment = CommonUtil.getGroupName(userid);
           
           WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
           
           /////////////////////////////////
           WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
           String curUserName = currentUser.getName();
           SessionHelper.manager.setPrincipal(sUserid);

           if (sTitle != null && !sTitle.equals("")) evrForm.setName(sTitle); // EO
           if (sTestList != null && !sTestList.equals("")) evrForm.setTestList(sTestList); //
           if (sDepartment != null && !sDepartment.equals("")) evrForm.setTeam(sDepartment); //
           
           // set Number
           String eoNumber = "EVR" + CommonUtil.getCurrentTime("yyMM") + CommonUtil.getSeq("EVR_SEQ");
           evrForm.setNumber(eoNumber);

           // save content
           String liftCycle = "LC_PSK_ECM";

           // Folder && LifeCycle Setting
           // WTContainer DefaultContainer = PSKCommonUtil.getDefaultFolder();
           Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
           FolderHelper.assignLocation((FolderEntry) evrForm, folder);
           PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
           WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);
           evrForm.setContainer(product);
           LifeCycleHelper.setLifeCycle(evrForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

           String teamName = "PSK_APPROVE_TEMPLATE";
           TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);
           
           evrForm = (EVRequest) wt.team.TeamHelper.setTeamTemplate(evrForm, mainTeam);
           evrForm = (EVRequest) PersistenceHelper.manager.save(evrForm);

			// ECR <-> Pre-EO AlphaForm Link
			if (eoForm != null) {
				EOtoEVRLink evrLink = EOtoEVRLink.newEOtoEVRLink(eoForm, evrForm);
				evrLink = (EOtoEVRLink) PersistenceHelper.manager.save(evrLink);
			}

           result += " : " + evrForm.getNumber();
           //System.out.println("@ created ECRequest =" + result);

           /////////////////////////////////
           SessionHelper.manager.setPrincipal(curUserName);
           
           trx.commit();

       } catch (Exception e) {
           trx.rollback();
           e.printStackTrace();
           result = CommonUtil.FAIL + " : " + e.getMessage();
           throw new WTException(e);

       } finally {
           trx = null;
       }
       
       return evrForm;
   }

	public IBAHolder setIBADataNoCheckout(IBAHolder target, Vector attName, Vector attValue) throws WTException, PropertyVetoException,
			RemoteException {

		try {
			target = IBAValueHelper.service.refreshAttributeContainer(target, null, null, null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) target.getAttributeContainer();
			
			StandardIBADefinitionService standardibadefinitionservice = new StandardIBADefinitionService();
			for (int i = 0; i < attName.size(); i++) {
				String attributeName = (String) attName.elementAt(i);
				String attributeValue = (String) attValue.elementAt(i);
				
				AttributeDefDefaultView attributedefdefaultview = standardibadefinitionservice.getAttributeDefDefaultViewByPath(attributeName);
				AbstractValueView aabstractvalueview[] = defaultattributecontainer.getAttributeValues(attributedefdefaultview);
	
				if (aabstractvalueview.length < 1) {
					StringValueDefaultView obj2 = new StringValueDefaultView((StringDefView) attributedefdefaultview, attributeValue);
					defaultattributecontainer.addAttributeValue(((AbstractValueView) (obj2)));
	
				} else {
					((StringValueDefaultView) aabstractvalueview[0]).setValue(attributeValue);
					defaultattributecontainer.updateAttributeValue(aabstractvalueview[0]);
	
				}
			}
			
			defaultattributecontainer.setConstraintParameter(defaultattributecontainer);
			target.setAttributeContainer(defaultattributecontainer);
		} catch(Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		return target;

	}

	public QueryResult queryFSC(String fscCode) throws WTException {

		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec();

			if (query.getConditionCount() > 0) query.appendAnd();

			Class classType = CommonCode.class;
			int pskIndex = query.appendClassList(classType, true);

			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE_TYPE, SearchCondition.EQUAL, "fsc"), new int[] { pskIndex });
			
			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE, SearchCondition.LIKE, "%" + fscCode + "%"), new int[] { pskIndex });

			queryResult = PersistenceHelper.manager.find(query);

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		return queryResult;
	}
	
	public WTPartMaster queryWTPartMaster(String number) throws WTException {

		WTPartMaster master = null;
		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec(WTPartMaster.class);

			if (query.getConditionCount() > 0) query.appendAnd();

			query.appendWhere(new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER, SearchCondition.EQUAL, number), new int[] { 0 });

			queryResult = PersistenceHelper.manager.find(query);

			 if (queryResult == null || (queryResult.size() < 0)) {
			 } else if (queryResult.size() > 0) {
				 master = (WTPartMaster)queryResult.nextElement();
				 System.out.println("@ master = " + master);
			 }

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		return master;
	}
   //##end user.operations
}
