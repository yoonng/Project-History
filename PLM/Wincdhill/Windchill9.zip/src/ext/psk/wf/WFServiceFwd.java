// Generated WFServiceFwd%4C86F2AB0399: ? 11/01/10 16:09:50
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.wf;

import ext.psk.wf.WFService;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import wt.fc.WTObject;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class WFServiceFwd implements RemoteAccess, WFService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = WFServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.psk.wf.WFService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.psk.wf.WFService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   public String checkApproveStep( WTObject form, HashMap list )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).checkApproveStep( form, list );
      else {
         try {
            Class[]	argTypes	= { WTObject.class, HashMap.class };
            Object[]	args		= { form, list };
            return (String)RemoteMethodServer.getDefault().invoke(
               "checkApproveStep", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "checkApproveStep" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "checkApproveStep" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   public String saveCCBReview( WTObject form, HashMap list )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).saveCCBReview( form, list );
      else {
         try {
            Class[]	argTypes	= { WTObject.class, HashMap.class };
            Object[]	args		= { form, list };
            return (String)RemoteMethodServer.getDefault().invoke(
               "saveCCBReview", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "saveCCBReview" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "saveCCBReview" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @param     list
    * @return    String
    * @exception wt.util.WTException
    **/
   public String requestApprove( WTObject form, HashMap list )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).requestApprove( form, list );
      else {
         try {
            Class[]	argTypes	= { WTObject.class, HashMap.class };
            Object[]	args		= { form, list };
            return (String)RemoteMethodServer.getDefault().invoke(
               "requestApprove", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "requestApprove" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "requestApprove" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap getApproveList( WTObject form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).getApproveList( form );
      else {
         try {
            Class[]	argTypes	= { WTObject.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "getApproveList", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "getApproveList" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "getApproveList" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String complete( WTObject form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).complete( form );
      else {
         try {
            Class[]	argTypes	= { WTObject.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "complete", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "complete" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "complete" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String reject( WTObject form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).reject( form );
      else {
         try {
            Class[]	argTypes	= { WTObject.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "reject", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "reject" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "reject" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String release( WTObject form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).release( form );
      else {
         try {
            Class[]	argTypes	= { WTObject.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "release", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "release" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "release" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap interfacePLM( HashMap form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).interfacePLM( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "interfacePLM", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "interfacePLM" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "interfacePLM" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap queryPSCR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).queryPSCR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "queryPSCR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "queryPSCR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "queryPSCR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap queryPSCN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((WFService)getManager()).queryPSCN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "queryPSCN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "queryPSCN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "queryPSCN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
