// Generated EVNotice%4C57858A038A: ? 10/18/10 10:45:32
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ev;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.doc.WTDocument;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EVNotice%4C57858A038A.doc preserve=no
/**
 * test
 * <p>
 * Use the <code>newEVNotice</code> static factory method(s), not the <code>EVNotice</code>
 * constructor, to construct instances of this class.  Instances must be
 * constructed using the static factory(s), in order to ensure proper initialization
 * of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end EVNotice%4C57858A038A.doc

public class EVNotice extends WTDocument implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.ev.evResource";
   private static final String CLASSNAME = EVNotice.class.getName();

   //##begin TEAM%TEAM.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEAM%TEAM.doc
   public static final String TEAM = "team";

   private static int TEAM_UPPER_LIMIT = -1;
   private String team;

   //##begin CUSTOMER_SITE%CUSTOMER_SITE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CUSTOMER_SITE%CUSTOMER_SITE.doc
   public static final String CUSTOMER_SITE = "customerSite";

   private static int CUSTOMER_SITE_UPPER_LIMIT = -1;
   private String customerSite;

   //##begin TEST_TERM_FROM%TEST_TERM_FROM.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEST_TERM_FROM%TEST_TERM_FROM.doc
   public static final String TEST_TERM_FROM = "testTermFrom";

   private Timestamp testTermFrom;

   //##begin TEST_TERM_TO%TEST_TERM_TO.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEST_TERM_TO%TEST_TERM_TO.doc
   public static final String TEST_TERM_TO = "testTermTo";

   private Timestamp testTermTo;

   //##begin RELEASE_DATE%RELEASE_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RELEASE_DATE%RELEASE_DATE.doc
   public static final String RELEASE_DATE = "releaseDate";

   private Timestamp releaseDate;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 6936387150629322812L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( customerSite );
      output.writeObject( releaseDate );
      output.writeObject( team );
      output.writeObject( testTermFrom );
      output.writeObject( testTermTo );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         customerSite = (String)input.readObject();
         releaseDate = (Timestamp)input.readObject();
         team = (String)input.readObject();
         testTermFrom = (Timestamp)input.readObject();
         testTermTo = (Timestamp)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "team", team );
      output.setString( "customerSite", customerSite );
      output.setTimestamp( "testTermFrom", testTermFrom );
      output.setTimestamp( "testTermTo", testTermTo );
      output.setTimestamp( "releaseDate", releaseDate );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      team = input.getString( "team" );
      customerSite = input.getString( "customerSite" );
      testTermFrom = input.getTimestamp( "testTermFrom" );
      testTermTo = input.getTimestamp( "testTermTo" );
      releaseDate = input.getTimestamp( "releaseDate" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getTeam%4CAADF51018Dg.doc preserve=no
   /**
    * Gets the value of the attribute: TEAM.
    *
    * @return    String
    **/
   //##end getTeam%4CAADF51018Dg.doc

   public String getTeam() {
      //##begin getTeam%4CAADF51018Dg.body preserve=no

      return team;
      //##end getTeam%4CAADF51018Dg.body
   }

   //##begin setTeam%4CAADF51018Ds.doc preserve=no
   /**
    * Sets the value of the attribute: TEAM.
    *
    * @param     a_Team
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTeam%4CAADF51018Ds.doc

   public void setTeam( String a_Team )
            throws WTPropertyVetoException {
      //##begin setTeam%4CAADF51018Ds.body preserve=no

      teamValidate( a_Team );   // throws exception if not valid
      team = a_Team;
      //##end setTeam%4CAADF51018Ds.body
   }

   //##begin teamValidate%4CAADF51018D.doc preserve=no
   /**
    * @param     a_Team
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end teamValidate%4CAADF51018D.doc

   private void teamValidate( String a_Team )
            throws WTPropertyVetoException {
      if ( TEAM_UPPER_LIMIT < 1 ) {
         try { TEAM_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "team" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TEAM_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Team != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Team, TEAM_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "team" ), String.valueOf( Math.min ( TEAM_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "team", team, a_Team ) );
      }
   }

   //##begin getCustomerSite%4CAADF6D03CEg.doc preserve=no
   /**
    * Gets the value of the attribute: CUSTOMER_SITE.
    *
    * @return    String
    **/
   //##end getCustomerSite%4CAADF6D03CEg.doc

   public String getCustomerSite() {
      //##begin getCustomerSite%4CAADF6D03CEg.body preserve=no

      return customerSite;
      //##end getCustomerSite%4CAADF6D03CEg.body
   }

   //##begin setCustomerSite%4CAADF6D03CEs.doc preserve=no
   /**
    * Sets the value of the attribute: CUSTOMER_SITE.
    *
    * @param     a_CustomerSite
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCustomerSite%4CAADF6D03CEs.doc

   public void setCustomerSite( String a_CustomerSite )
            throws WTPropertyVetoException {
      //##begin setCustomerSite%4CAADF6D03CEs.body preserve=no

      customerSiteValidate( a_CustomerSite );   // throws exception if not valid
      customerSite = a_CustomerSite;
      //##end setCustomerSite%4CAADF6D03CEs.body
   }

   //##begin customerSiteValidate%4CAADF6D03CE.doc preserve=no
   /**
    * @param     a_CustomerSite
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end customerSiteValidate%4CAADF6D03CE.doc

   private void customerSiteValidate( String a_CustomerSite )
            throws WTPropertyVetoException {
      if ( CUSTOMER_SITE_UPPER_LIMIT < 1 ) {
         try { CUSTOMER_SITE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "customerSite" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CUSTOMER_SITE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CustomerSite != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CustomerSite, CUSTOMER_SITE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "customerSite" ), String.valueOf( Math.min ( CUSTOMER_SITE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "customerSite", customerSite, a_CustomerSite ) );
      }
   }

   //##begin getTestTermFrom%4CAADFB1035Bg.doc preserve=no
   /**
    * Gets the value of the attribute: TEST_TERM_FROM.
    *
    * @return    Timestamp
    **/
   //##end getTestTermFrom%4CAADFB1035Bg.doc

   public Timestamp getTestTermFrom() {
      //##begin getTestTermFrom%4CAADFB1035Bg.body preserve=no

      return testTermFrom;
      //##end getTestTermFrom%4CAADFB1035Bg.body
   }

   //##begin setTestTermFrom%4CAADFB1035Bs.doc preserve=no
   /**
    * Sets the value of the attribute: TEST_TERM_FROM.
    *
    * @param     a_TestTermFrom
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTestTermFrom%4CAADFB1035Bs.doc

   public void setTestTermFrom( Timestamp a_TestTermFrom )
            throws WTPropertyVetoException {
      //##begin setTestTermFrom%4CAADFB1035Bs.body preserve=no

      testTermFrom = a_TestTermFrom;
      //##end setTestTermFrom%4CAADFB1035Bs.body
   }

   //##begin getTestTermTo%4CAADFC10396g.doc preserve=no
   /**
    * Gets the value of the attribute: TEST_TERM_TO.
    *
    * @return    Timestamp
    **/
   //##end getTestTermTo%4CAADFC10396g.doc

   public Timestamp getTestTermTo() {
      //##begin getTestTermTo%4CAADFC10396g.body preserve=no

      return testTermTo;
      //##end getTestTermTo%4CAADFC10396g.body
   }

   //##begin setTestTermTo%4CAADFC10396s.doc preserve=no
   /**
    * Sets the value of the attribute: TEST_TERM_TO.
    *
    * @param     a_TestTermTo
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTestTermTo%4CAADFC10396s.doc

   public void setTestTermTo( Timestamp a_TestTermTo )
            throws WTPropertyVetoException {
      //##begin setTestTermTo%4CAADFC10396s.body preserve=no

      testTermTo = a_TestTermTo;
      //##end setTestTermTo%4CAADFC10396s.body
   }

   //##begin getReleaseDate%4CBBA64801BEg.doc preserve=no
   /**
    * Gets the value of the attribute: RELEASE_DATE.
    *
    * @return    Timestamp
    **/
   //##end getReleaseDate%4CBBA64801BEg.doc

   public Timestamp getReleaseDate() {
      //##begin getReleaseDate%4CBBA64801BEg.body preserve=no

      return releaseDate;
      //##end getReleaseDate%4CBBA64801BEg.body
   }

   //##begin setReleaseDate%4CBBA64801BEs.doc preserve=no
   /**
    * Sets the value of the attribute: RELEASE_DATE.
    *
    * @param     a_ReleaseDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReleaseDate%4CBBA64801BEs.doc

   public void setReleaseDate( Timestamp a_ReleaseDate )
            throws WTPropertyVetoException {
      //##begin setReleaseDate%4CBBA64801BEs.body preserve=no

      releaseDate = a_ReleaseDate;
      //##end setReleaseDate%4CBBA64801BEs.body
   }

   //##begin newEVNotice%newEVNoticef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    EVNotice
    * @exception wt.util.WTException
    **/
   //##end newEVNotice%newEVNoticef.doc

   public static EVNotice newEVNotice()
            throws WTException {
      //##begin newEVNotice%newEVNoticef.body preserve=no

      EVNotice instance = new EVNotice();
      instance.initialize();
      return instance;
      //##end newEVNotice%newEVNoticef.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
