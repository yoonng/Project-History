// Generated EVServiceFwd%4CAAE4BF030A: ? 10/06/10 11:42:07
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ev;

import ext.psk.ecm.ev.EVService;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 * est
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class EVServiceFwd implements RemoteAccess, EVService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = EVServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.psk.ecm.ev.EVService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.psk.ecm.ev.EVService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createEVR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).createEVR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createEVR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createEVR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createEVR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateEVR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).updateEVR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateEVR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateEVR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateEVR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteEVR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).deleteEVR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteEVR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteEVR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteEVR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchEVR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).searchEVR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchEVR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchEVR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchEVR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewEVR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).viewEVR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewEVR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewEVR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewEVR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String creatorEVN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).creatorEVN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "creatorEVN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "creatorEVN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "creatorEVN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateEVN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).updateEVN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateEVN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateEVN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateEVN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteEVN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).deleteEVN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteEVN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteEVN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteEVN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchEVN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).searchEVN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchEVN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchEVN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchEVN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewEVN( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EVService)getManager()).viewEVN( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewEVN", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewEVN" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewEVN" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
