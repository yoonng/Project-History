package ext.psk.ecm.ev.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;
import ext.psk.util.upload.FileUploader;

import ext.psk.ecm.ev.*;

public class EVRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String contentType = req.getContentType();
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		FileUploader uploader = null;
		String cmd = "";
		String returnURI = "";
		String strReturn = "";
		boolean fileFlag = false;
		
		if ( contentType != null && contentType.indexOf("multipart/form-data") >= 0 ) {
			uploader = FileUploader.newFileUploader( null, req, res );
			//System.out.println("uploader = " + uploader);
			cmd = uploader.getFormParameter("cmd");
			System.out.println("addFiles : " +  uploader.getFiles() );
			form.put("addFiles", uploader.getFiles() == null ? new Vector() : uploader.getFiles() );
			
			fileFlag = true;
			
		} else {
			cmd = req.getParameter("cmd");
		}
		
		System.out.println("Request Start ===== " + cmd);

		Enumeration itor = null;
		if( fileFlag ) {
			itor = uploader.getFormParameter();
		} else {
			itor = req.getParameterNames();
		}
		
		while( itor.hasMoreElements() ) {
			String key = (String)itor.nextElement();
			String[] tempValues = null;
			if( fileFlag ) {
				tempValues = uploader.getFormValues(key);
			} else {
				tempValues = req.getParameterValues(key);
			}
			
			//when update, target put form
			if( key.equals("delFiles") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				
				Vector delFiles = new Vector();
				for(int i=0; i < values.length; i++ ) {
					HashMap hp = new HashMap();
					hp.put("fileId", values[i]);
					delFiles.addElement(hp);
				}
				form.put("fileId", delFiles);
				
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을 때 처리함 : 무조건 배열로 처리해야함
			} else if( key.equals("evrOid") || key.equals("eoOid") || key.equals("referenceDocument") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("only key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을때 처리함 : 무조건 문자열로 처리해야함
			} else if( key.equals("customerSite") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				String tempSite = "";
				
				for(int i = 0; i < values.length; i++) {
					tempSite += values[i] + "__/";
				}
				
				System.out.println("only key : " + key + " ____  value = " + tempSite );
				
				form.put(key, tempSite);
				
			} else if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}

		if( cmd.equals("registEVR") || cmd.equals("deleteEVR") || cmd.equals("updateEVR") ) {
			returnURI = "/Windchill/extcore/psk/jsp/ecm/ev/evr-list.jsp";
			
		} else if( cmd.equals("registEVN") || cmd.equals("deleteEVN") || cmd.equals("updateEVN") ) {
			returnURI = "/Windchill/extcore/psk/jsp/ecm/ev/evn-list.jsp";
			
		}

		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";

			if( cmd.equals("listEVR") || cmd.equals("listEVRPopup") ) {
				if( cmd.equals("listEVR") ) {
					returnURI = "/extcore/psk/jsp/ecm/ev/evr-list.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/ecm/ev/evr-Popup.jsp";
				}
				
				HashMap resultMap = EVHelper.service.searchEVR(form);
				PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
				PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
				
				session.setAttribute("control", control);
				req.setAttribute("return", strReturn);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("registEVR") ) {			//EVR Regist ( new, revise, suffix )
				strReturn = EVHelper.service.createEVR(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
			
			} else if( cmd.equals("registEVRForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/ecm/ev/evr-regist.jsp";
				
				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("updateEVRForm") || cmd.equals("viewEVR") ) {			//update Form Data Call
				if( cmd.equals("updateEVRForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/ev/evr-update.jsp";
				} else if( cmd.equals("viewEVR") ){
					returnURI = "/extcore/psk/jsp/ecm/ev/evr-view.jsp";
				}

				HashMap resultMap = EVHelper.service.viewEVR(form);
				EVRequest evrForm = (EVRequest)resultMap.get("evrForm");
				Vector eoList = (Vector)resultMap.get("eoList");
				Vector docList = (Vector)resultMap.get("docList");
				
				session.setAttribute("evrForm", evrForm);
				session.setAttribute("eoList", eoList);
				session.setAttribute("docList", docList);

				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("updateEVR") ) {
				strReturn = EVHelper.service.updateEVR(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("deleteEVR") ) {
				strReturn = EVHelper.service.deleteEVR(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
				
			} else if( cmd.equals("listEVN") ) {
				returnURI = "/extcore/psk/jsp/ecm/ev/evn-list.jsp";
		
				HashMap resultMap = EVHelper.service.searchEVN(form);
				PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
				PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
				
				session.setAttribute("control", control);
				req.setAttribute("return", strReturn);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("registEVN") ) {			//ECR Regist ( new, revise, suffix )
				strReturn = EVHelper.service.creatorEVN(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
			
			} else if( cmd.equals("registEVNForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/ecm/ev/evn-regist.jsp";
				
				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("updateEVNForm") || cmd.equals("viewEVN") ) {			//update Form Data Call
				if( cmd.equals("updateEVNForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/ev/evn-update.jsp";
				} else if( cmd.equals("viewEVN") ){
					returnURI = "/extcore/psk/jsp/ecm/ev/evn-view.jsp";
				}

				HashMap resultMap = EVHelper.service.viewEVN(form);
				EVNotice evnForm = (EVNotice)resultMap.get("evnForm");
				Vector docLinkList = (Vector)resultMap.get("docLinkList");
				
				session.setAttribute("evnForm", evnForm);
				session.setAttribute("docLinkList", docLinkList);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateEVN") ) {
				strReturn = EVHelper.service.updateEVN(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}

			} else if( cmd.equals("deleteEVN") ) {
				strReturn = EVHelper.service.deleteEVN(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			} 
			
			System.out.println("Request End ===== " + cmd);
			
		} catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}