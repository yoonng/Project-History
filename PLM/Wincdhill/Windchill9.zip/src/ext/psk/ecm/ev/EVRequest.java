// Generated EVRequest%4C5785810251: ? 10/18/10 10:45:32
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ev;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.doc.WTDocument;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EVRequest%4C5785810251.doc preserve=no
/**
 * Test
 * <p>
 * Use the <code>newEVRequest</code> static factory method(s), not the <code>EVRequest</code>
 * constructor, to construct instances of this class.  Instances must be
 * constructed using the static factory(s), in order to ensure proper initialization
 * of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end EVRequest%4C5785810251.doc

public class EVRequest extends WTDocument implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.ev.evResource";
   private static final String CLASSNAME = EVRequest.class.getName();

   //##begin SW_INFO%SW_INFO.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end SW_INFO%SW_INFO.doc
   public static final String SW_INFO = "swInfo";

   private static int SW_INFO_UPPER_LIMIT = -1;
   private String swInfo;

   //##begin TEST_LIST%TEST_LIST.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEST_LIST%TEST_LIST.doc
   public static final String TEST_LIST = "testList";

   private static int TEST_LIST_UPPER_LIMIT = -1;
   private String testList;

   //##begin TEAM%TEAM.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEAM%TEAM.doc
   public static final String TEAM = "team";

   private static int TEAM_UPPER_LIMIT = -1;
   private String team;

   //##begin RELEASE_DATE%RELEASE_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RELEASE_DATE%RELEASE_DATE.doc
   public static final String RELEASE_DATE = "releaseDate";

   private Timestamp releaseDate;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = -7744670163517288001L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( releaseDate );
      output.writeObject( swInfo );
      output.writeObject( team );
      output.writeObject( testList );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         releaseDate = (Timestamp)input.readObject();
         swInfo = (String)input.readObject();
         team = (String)input.readObject();
         testList = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "swInfo", swInfo );
      output.setString( "testList", testList );
      output.setString( "team", team );
      output.setTimestamp( "releaseDate", releaseDate );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      swInfo = input.getString( "swInfo" );
      testList = input.getString( "testList" );
      team = input.getString( "team" );
      releaseDate = input.getTimestamp( "releaseDate" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getSwInfo%4CAADD530277g.doc preserve=no
   /**
    * Gets the value of the attribute: SW_INFO.
    *
    * @return    String
    **/
   //##end getSwInfo%4CAADD530277g.doc

   public String getSwInfo() {
      //##begin getSwInfo%4CAADD530277g.body preserve=no

      return swInfo;
      //##end getSwInfo%4CAADD530277g.body
   }

   //##begin setSwInfo%4CAADD530277s.doc preserve=no
   /**
    * Sets the value of the attribute: SW_INFO.
    *
    * @param     a_SwInfo
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setSwInfo%4CAADD530277s.doc

   public void setSwInfo( String a_SwInfo )
            throws WTPropertyVetoException {
      //##begin setSwInfo%4CAADD530277s.body preserve=no

      swInfoValidate( a_SwInfo );   // throws exception if not valid
      swInfo = a_SwInfo;
      //##end setSwInfo%4CAADD530277s.body
   }

   //##begin swInfoValidate%4CAADD530277.doc preserve=no
   /**
    * @param     a_SwInfo
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end swInfoValidate%4CAADD530277.doc

   private void swInfoValidate( String a_SwInfo )
            throws WTPropertyVetoException {
      if ( SW_INFO_UPPER_LIMIT < 1 ) {
         try { SW_INFO_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "swInfo" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { SW_INFO_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_SwInfo != null && !wt.fc.PersistenceHelper.checkStoredLength( a_SwInfo, SW_INFO_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "swInfo" ), String.valueOf( Math.min ( SW_INFO_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "swInfo", swInfo, a_SwInfo ) );
      }
   }

   //##begin getTestList%4CAADD8B01B0g.doc preserve=no
   /**
    * Gets the value of the attribute: TEST_LIST.
    *
    * @return    String
    **/
   //##end getTestList%4CAADD8B01B0g.doc

   public String getTestList() {
      //##begin getTestList%4CAADD8B01B0g.body preserve=no

      return testList;
      //##end getTestList%4CAADD8B01B0g.body
   }

   //##begin setTestList%4CAADD8B01B0s.doc preserve=no
   /**
    * Sets the value of the attribute: TEST_LIST.
    *
    * @param     a_TestList
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTestList%4CAADD8B01B0s.doc

   public void setTestList( String a_TestList )
            throws WTPropertyVetoException {
      //##begin setTestList%4CAADD8B01B0s.body preserve=no

      testListValidate( a_TestList );   // throws exception if not valid
      testList = a_TestList;
      //##end setTestList%4CAADD8B01B0s.body
   }

   //##begin testListValidate%4CAADD8B01B0.doc preserve=no
   /**
    * @param     a_TestList
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end testListValidate%4CAADD8B01B0.doc

   private void testListValidate( String a_TestList )
            throws WTPropertyVetoException {
      if ( TEST_LIST_UPPER_LIMIT < 1 ) {
         try { TEST_LIST_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "testList" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TEST_LIST_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_TestList != null && !wt.fc.PersistenceHelper.checkStoredLength( a_TestList, TEST_LIST_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "testList" ), String.valueOf( Math.min ( TEST_LIST_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "testList", testList, a_TestList ) );
      }
   }

   //##begin getTeam%4CAADECD0079g.doc preserve=no
   /**
    * Gets the value of the attribute: TEAM.
    *
    * @return    String
    **/
   //##end getTeam%4CAADECD0079g.doc

   public String getTeam() {
      //##begin getTeam%4CAADECD0079g.body preserve=no

      return team;
      //##end getTeam%4CAADECD0079g.body
   }

   //##begin setTeam%4CAADECD0079s.doc preserve=no
   /**
    * Sets the value of the attribute: TEAM.
    *
    * @param     a_Team
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTeam%4CAADECD0079s.doc

   public void setTeam( String a_Team )
            throws WTPropertyVetoException {
      //##begin setTeam%4CAADECD0079s.body preserve=no

      teamValidate( a_Team );   // throws exception if not valid
      team = a_Team;
      //##end setTeam%4CAADECD0079s.body
   }

   //##begin teamValidate%4CAADECD0079.doc preserve=no
   /**
    * @param     a_Team
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end teamValidate%4CAADECD0079.doc

   private void teamValidate( String a_Team )
            throws WTPropertyVetoException {
      if ( TEAM_UPPER_LIMIT < 1 ) {
         try { TEAM_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "team" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TEAM_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Team != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Team, TEAM_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "team" ), String.valueOf( Math.min ( TEAM_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "team", team, a_Team ) );
      }
   }

   //##begin getReleaseDate%4CBBA63A0354g.doc preserve=no
   /**
    * Gets the value of the attribute: RELEASE_DATE.
    *
    * @return    Timestamp
    **/
   //##end getReleaseDate%4CBBA63A0354g.doc

   public Timestamp getReleaseDate() {
      //##begin getReleaseDate%4CBBA63A0354g.body preserve=no

      return releaseDate;
      //##end getReleaseDate%4CBBA63A0354g.body
   }

   //##begin setReleaseDate%4CBBA63A0354s.doc preserve=no
   /**
    * Sets the value of the attribute: RELEASE_DATE.
    *
    * @param     a_ReleaseDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReleaseDate%4CBBA63A0354s.doc

   public void setReleaseDate( Timestamp a_ReleaseDate )
            throws WTPropertyVetoException {
      //##begin setReleaseDate%4CBBA63A0354s.body preserve=no

      releaseDate = a_ReleaseDate;
      //##end setReleaseDate%4CBBA63A0354s.body
   }

   //##begin newEVRequest%newEVRequestf.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    EVRequest
    * @exception wt.util.WTException
    **/
   //##end newEVRequest%newEVRequestf.doc

   public static EVRequest newEVRequest()
            throws WTException {
      //##begin newEVRequest%newEVRequestf.body preserve=no

      EVRequest instance = new EVRequest();
      instance.initialize();
      return instance;
      //##end newEVRequest%newEVRequestf.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
