// Generated StandardEVService%4CAAE7340043: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ev;

import ext.psk.ecm.ev.EVService;
import java.io.Serializable;
import java.lang.String;
import java.util.HashMap;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import ext.psk.ecm.ecr.ECRequest;  // Preserved unmodeled dependency
import ext.psk.ecm.eo.EOAlphaForm;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency
import wt.lifecycle.LifeCycleHelper;  // Preserved unmodeled dependency
import wt.org.OrganizationServicesHelper;  // Preserved unmodeled dependency
import wt.org.WTPrincipalReference;  // Preserved unmodeled dependency
import wt.org.WTUser;  // Preserved unmodeled dependency
import wt.pdmlink.PDMLinkProduct;  // Preserved unmodeled dependency
import wt.pom.Transaction;  // Preserved unmodeled dependency
import wt.query.ClassAttribute;  // Preserved unmodeled dependency
import wt.query.OrderBy;  // Preserved unmodeled dependency
import wt.query.QuerySpec;  // Preserved unmodeled dependency
import wt.query.SearchCondition;  // Preserved unmodeled dependency
import wt.session.SessionHelper;  // Preserved unmodeled dependency
import wt.team.TeamTemplate;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
import wt.change2.ChangeNoticeComplexity;  // Preserved unmodeled dependency
import wt.change2.ChangeRecord2;  // Preserved unmodeled dependency
import wt.change2.RelevantRequestData2;  // Preserved unmodeled dependency
import wt.clients.folder.FolderTaskLogic;  // Preserved unmodeled dependency
import wt.doc.WTDocument;  // Preserved unmodeled dependency
import wt.doc.WTDocumentDependencyLink;  // Preserved unmodeled dependency
import wt.fc.PagingQueryResult;  // Preserved unmodeled dependency
import wt.fc.PagingSessionHelper;  // Preserved unmodeled dependency
import wt.fc.PersistenceHelper;  // Preserved unmodeled dependency
import wt.fc.PersistenceServerHelper;  // Preserved unmodeled dependency
import wt.fc.QueryResult;  // Preserved unmodeled dependency
import wt.fc.ReferenceFactory; // Preserved unmodeled dependency  // Preserved unmodeled dependency
import wt.folder.Folder;  // Preserved unmodeled dependency
import wt.folder.FolderEntry;  // Preserved unmodeled dependency
import wt.folder.FolderHelper;  // Preserved unmodeled dependency
import wt.inf.container.WTContainerRef;  // Preserved unmodeled dependency
import wt.inf.library.WTLibrary;
import ext.psk.ecm.ev.*;  // Preserved unmodeled dependency
import ext.psk.util.*;  // Preserved unmodeled dependency
import ext.psk.util.upload.PLMContentHelper;  // Preserved unmodeled dependency
//##end user.imports

//##begin StandardEVService%4CAAE7340043.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardEVService</code> static factory method(s), not
 * the <code>StandardEVService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardEVService%4CAAE7340043.doc

public class StandardEVService extends StandardManager implements EVService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.ev.evResource";
   private static final String CLASSNAME = StandardEVService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardEVService%newStandardEVServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardEVService
    * @exception wt.util.WTException
    **/
   //##end newStandardEVService%newStandardEVServicef.doc

   public static StandardEVService newStandardEVService()
            throws WTException {
      //##begin newStandardEVService%newStandardEVServicef.body preserve=no

      StandardEVService instance = new StandardEVService();
      instance.initialize();
      return instance;
      //##end newStandardEVService%newStandardEVServicef.body
   }

   //##begin createEVR%4CAAE50603AB.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEVR%4CAAE50603AB.doc

   public String createEVR( HashMap form )
            throws WTException {
      //##begin createEVR%4CAAE50603AB.body preserve=yes
       EVRequest evrForm = EVRequest.newEVRequest();
       ReferenceFactory rf = new ReferenceFactory();

       String result = CommonUtil.SUCC;

       Transaction trx = new Transaction();
       try {
           trx.start();
           
           String sTitle = (String) form.get("title");

           String sTestList = (String) form.get("testList");
           String sSwInfo = (String) form.get("swInfo");
           String sDepartment = (String) form.get("department");
           String sEvrRequestComment = (String) form.get("evrRequestComment");
           
           WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

           if (sTitle != null && !sTitle.equals("")) evrForm.setName(sTitle); // EO
           if (sTestList != null && !sTestList.equals("")) evrForm.setTestList(sTestList); //
           if (sSwInfo != null && !sSwInfo.equals("")) evrForm.setSwInfo(sSwInfo); //
           if (sDepartment != null && !sDepartment.equals("")) evrForm.setTeam(sDepartment); //
           if (sEvrRequestComment != null && !sEvrRequestComment.equals("")) evrForm.setDescription(sEvrRequestComment); // EO type
           
           // set Number
           String eoNumber = "VR" + CommonUtil.getCurrentTime("yyMM") + CommonUtil.getSeq("EVR_SEQ");
           evrForm.setNumber(eoNumber);
           
           // save content
           String liftCycle = "LC_PSK_ECM";

           WTLibrary product = PSKCommonUtil.getWTLibrary("Document");
           WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

           String yy = CommonUtil.getCurrentTime("yyyy");
           String mm = CommonUtil.getCurrentTime("MM");
           String sFolderPath = "/Default/EVR/" + yy + "/" + mm;

           // Folder assign
           Folder folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
           FolderHelper.assignLocation((FolderEntry) evrForm, folder);
           
           evrForm.setContainer(product);
           LifeCycleHelper.setLifeCycle(evrForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

           String teamName = "PSK_APPROVE_TEMPLATE";
           TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);

           try {
               evrForm = (EVRequest) wt.team.TeamHelper.setTeamTemplate(evrForm, mainTeam);
           } catch(WTPropertyVetoException pve) {
               pve.printStackTrace();
           }
           
           evrForm = (EVRequest) PersistenceHelper.manager.save(evrForm);
            
           //ECR <-> Pre-EO AlphaForm Link
           String[] eoOid = (String[]) form.get("eoOid");
           if( eoOid != null && (eoOid.length > 0) ) {
        	   for(int j=0; j < eoOid.length; j++) {
        		   EOAlphaForm eo = (EOAlphaForm) rf.getReference(eoOid[j]).getObject();
	               EOtoEVRLink evrLink = EOtoEVRLink.newEOtoEVRLink(eo, evrForm);
	               evrLink = (EOtoEVRLink) PersistenceHelper.manager.save(evrLink);
	           }
           }

           //EVR <-> Document
           String[] refDocOid = (String[]) form.get("referenceDocument");
           if( refDocOid != null && (refDocOid.length > 0) ) {
        	   for(int j=0; j < refDocOid.length; j++) {
        		   WTDocument doc = (WTDocument) rf.getReference(refDocOid[j]).getObject();
	               WTDocumentDependencyLink evrLink = WTDocumentDependencyLink.newWTDocumentDependencyLink((WTDocument)evrForm, (WTDocument)doc);
	               //WTDocumentDependencyLink evrLink = WTDocumentDependencyLink.newWTDocumentDependencyLink((WTDocument)doc, (WTDocument)evrForm);

	               evrLink = (WTDocumentDependencyLink) PersistenceHelper.manager.save(evrLink);
	           }
           }
           
	       Vector addFiles			 = (Vector) form.get("addFiles");
	       Vector delFiles			 = (Vector) form.get("fileId");
	       Vector fileDescVec 		 = new Vector();
		   for(int i=0;i<addFiles.size();i++){
			   fileDescVec.add("");
		   }
		   PLMContentHelper.service.updateContent(evrForm, addFiles, delFiles, fileDescVec, false);
           
           result += " : " + evrForm.getNumber();
           System.out.println("@ created ECRequest =" + result);

           trx.commit();

       } catch (Exception e) {
           trx.rollback();
           e.printStackTrace();
           result = CommonUtil.FAIL + " : " + e.getMessage();
           //throw new WTException(e);

       } finally {
           trx = null;
       }
       return result;
      //##end createEVR%4CAAE50603AB.body
   }

   //##begin updateEVR%4CAAE51003DD.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEVR%4CAAE51003DD.doc

   public String updateEVR( HashMap form )
            throws WTException {
      //##begin updateEVR%4CAAE51003DD.body preserve=yes
       ReferenceFactory rf = new ReferenceFactory();

       String result = CommonUtil.SUCC;
       EVRequest evrForm = null;

       Transaction trx = new Transaction();
       try {
          trx.start();
          
          String sOid = (String) form.get("oid");
          evrForm = (EVRequest) rf.getReference(sOid).getObject();
          
          //Start checkOut
          //System.out.println("EVRequest Document Check-out Started...");

          wt.vc.wip.Workable workable =(wt.vc.wip.Workable)evrForm;
          wt.vc.wip.CheckoutLink checkOutLink = null;
          wt.vc.wip.Workable workingCopy = null;
          wt.vc.wip.Workable orgCopy = null;
            
          if(!wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
              if(!wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
                  wt.folder.Folder folder = wt.vc.wip.WorkInProgressHelper.service.getCheckoutFolder();
                  //Folder folder = FolderHelper.service.getFolder("/Default");
                
                  //System.out.println("Folder is " + folder);
                  //System.out.println("checkOutLink Is: " + workable +" and Folder is : " + folder);
                
                  try {
                      checkOutLink = (wt.vc.wip.CheckoutLink)wt.vc.wip.WorkInProgressHelper.service.checkout(workable, folder, "");
                  } catch(wt.util.WTPropertyVetoException wtpve) {
                	  throw new WTException(wtpve);
                  }
                
                  // get Original copy
                  orgCopy = checkOutLink.getOriginalCopy();
                  //System.out.println("orgCopy is " + orgCopy);
                  
                  // get working copy
                  workingCopy = checkOutLink.getWorkingCopy();
                  //System.out.println("workingCopy is " + workingCopy);
                  
              } else if (wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
                  // get Original copy
                  orgCopy = wt.vc.wip.WorkInProgressHelper.service.originalCopyOf(workable);
                  // get working copy
                  workingCopy = wt.vc.wip.WorkInProgressHelper.service.workingCopyOf(workable);
                  //System.out.println("workingCopy is " + workingCopy);
              }
              
          } else if (wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
              workingCopy = workable;
          }

          evrForm = (EVRequest)workingCopy;
          //System.out.println("EVRequest Document Check-out Ended...");
          //End CheckOut

          String sTitle = (String) form.get("title");

          String sTestList = (String) form.get("testList");
          String sSwInfo = (String) form.get("swInfo");
          String sDepartment = (String) form.get("department");
          String sEvrRequestComment = (String) form.get("evrRequestComment");
          
          WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
          //WTUser evrUser = (WTUser) rf.getReference(sEvrWtUserOid).getObject();
          //evrForm.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);

          if (sTitle != null && !sTitle.equals("")) evrForm.setName(sTitle); // EO
          if (sTestList != null && !sTestList.equals("")) evrForm.setTestList(sTestList); //
          if (sSwInfo != null && !sSwInfo.equals("")) evrForm.setSwInfo(sSwInfo); //
          if (sDepartment != null && !sDepartment.equals("")) evrForm.setTeam(sDepartment); //
          if (sEvrRequestComment != null && !sEvrRequestComment.equals("")) evrForm.setDescription(sEvrRequestComment); // EO type
          
          //save content
          PersistenceServerHelper.manager.update(evrForm);
          //evrForm = (EVRequest) PersistenceHelper.manager.save(evrForm);

          //delete pre-EO link 
          deleteEotoEVRLink( evrForm.getPersistInfo().getObjectIdentifier().getId() );
          
          //EVR <-> Pre-EO AlphaForm Link
          String[] eoOid = (String[]) form.get("eoOid");
          if( eoOid != null && (eoOid.length > 0) ) {
       	   for(int j=0; j < eoOid.length; j++) {
       		   EOAlphaForm eo = (EOAlphaForm) rf.getReference(eoOid[j]).getObject();
	               EOtoEVRLink evrLink = EOtoEVRLink.newEOtoEVRLink(eo, evrForm);
	               evrLink = (EOtoEVRLink) PersistenceHelper.manager.save(evrLink);
	           }
          }
          
          //delete refrenceDocument link
          this.deleteWTDocumentDependencyLink( evrForm.getPersistInfo().getObjectIdentifier().getId(), "EVR" );
          
          //EVR <-> Document
          String[] refDocOid = (String[]) form.get("referenceDocument");
          if( refDocOid != null && (refDocOid.length > 0) ) {
       	   for(int j=0; j < refDocOid.length; j++) {
       		   WTDocument doc = (WTDocument) rf.getReference(refDocOid[j]).getObject();
	               WTDocumentDependencyLink evrLink = WTDocumentDependencyLink.newWTDocumentDependencyLink(evrForm, doc);

	               evrLink = (WTDocumentDependencyLink) PersistenceHelper.manager.save(evrLink);
	           }
          }
          
          Vector addFiles			 = (Vector) form.get("addFiles");
          Vector delFiles			 = (Vector) form.get("fileId");
          Vector fileDescVec 		 = new Vector();
          for(int i=0;i<addFiles.size();i++){
        	  fileDescVec.add("");
          }
          PLMContentHelper.service.updateContent(evrForm, addFiles, delFiles, fileDescVec, false);
		   
          //Start checkin ...
          //System.out.println("DB checkin start...");
          evrForm = (EVRequest)wt.vc.wip.WorkInProgressHelper.service.checkin(evrForm, "");
          //System.out.println("DB checkin end...");
          //System.out.println("DB refresh start...");
          evrForm = (EVRequest)PersistenceHelper.manager.refresh(evrForm, true, true);
          //System.out.println("DB refresh end...");
          //End checkin ...

          result += " : " + evrForm.getNumber();
          //System.out.println("@ created EVRequest =" + result);

          trx.commit();

       } catch (Exception e) {
          trx.rollback();
          
          System.out.println("Start UndoCheckout EVRequest Doc...");
          try {
              if (wt.vc.wip.WorkInProgressHelper.isCheckedOut((wt.vc.wip.Workable)evrForm)) {
                  wt.vc.wip.WorkInProgressHelper.service.undoCheckout(evrForm);
              }
          } catch(Exception ee) {
              ee.printStackTrace();
          }
          System.out.println("End UndoCheckout EVRequest Doc...");
          
          e.printStackTrace();
          result = CommonUtil.FAIL + " : " + e.getMessage();
          //throw new WTException(e);

       } finally {
          trx = null;
       }
       return result;
      //##end updateEVR%4CAAE51003DD.body
   }

   //##begin deleteEVR%4CAAE52E0334.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEVR%4CAAE52E0334.doc

   public String deleteEVR( HashMap form )
            throws WTException {
      //##begin deleteEVR%4CAAE52E0334.body preserve=yes

      return null;
      //##end deleteEVR%4CAAE52E0334.body
   }

   //##begin searchEVR%4CAAE53A01D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEVR%4CAAE53A01D8.doc

   public HashMap searchEVR( HashMap form )
            throws WTException {
      //##begin searchEVR%4CAAE53A01D8.body preserve=yes
       PagingQueryResult pagingResults = null;

       String sCmd = (String) form.get("cmd");
       String sPage = (String) form.get("page");
       String sTotalPage = (String) form.get("totalPage");
       String sSessionID = (String) form.get("sessionID");

       String sNumber = (String) form.get("shNumber");				//number
       String sTitle = (String) form.get("shTitle");				//title

       String sState = (String) form.get("shApprovalStatus");		//state

       String sCreatorName = (String) form.get("shIssueUserNm");	
       String sCreator = "";
       if( sCreatorName != null && !sCreatorName.equals("") ) {
           LdapSearchUser searchUserId = new LdapSearchUser();

           sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
       }

       String sSWInfo     = (String) form.get("shSWInfo");
       
       String sFromRegDate   = (String) form.get("shFromRegDate");
       String sToRegDate   = (String) form.get("shToRegDate");

       String sFromUpDate   = (String) form.get("shFromUpDate");
       String sToUpDate   = (String) form.get("shToUpDate");

       try {
           QuerySpec query = new QuerySpec();
           query.setAdvancedQueryEnabled(true);

           if (query.getConditionCount() > 0) query.appendAnd();

           Class classType = EVRequest.class;
           int pskChangeIndex = query.appendClassList(classType, true);

           query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });
           
           if (sNumber != null && !sNumber.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, EVRequest.NUMBER, SearchCondition.LIKE, "%" + sNumber + "%"), new int[] { pskChangeIndex });
           }
           
           if (sTitle != null && !sTitle.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "master>name", SearchCondition.LIKE, "%" + sTitle + "%"), new int[] { pskChangeIndex });
           }
           
           if (sState != null && !sState.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
           }
           
           if (sSWInfo != null && !sSWInfo.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               
               query.appendWhere(new SearchCondition(classType, EVRequest.SW_INFO, SearchCondition.LIKE, "%" + sSWInfo + "%"), new int[] { pskChangeIndex });
           }

           if (sCreator != null && !sCreator.equals("")) {
               long lcreator = 0;
               WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
               if( creator != null ) { 
                   lcreator = creator.getPersistInfo().getObjectIdentifier().getId();

                   if (query.getConditionCount() > 0) query.appendAnd();
                   query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
               }
           }
                       
           //RegistDate from to Start
           if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
           }
             
           if ( sToRegDate != null && !sToRegDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
           }
           //RegistDate from to End
           
           //UpdateDate from to Start
           if ( sFromUpDate != null && !sFromUpDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromUpDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
           }
             
           if ( sToUpDate != null && !sToUpDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToUpDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
           }
           //UpdateDate From To End
           
           ClassAttribute classattribute = new ClassAttribute();
           OrderBy orderby = null;
           classattribute = new ClassAttribute(classType, "thePersistInfo.createStamp");
           orderby = new OrderBy(classattribute, true);

           query.appendOrderBy(orderby, new int[] { 0 });

           //System.out.println("## REQUEST Query:" + query.toString());

           QueryResult queryResult = PersistenceHelper.manager.find(query);
           
           if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
               pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
               
           } else if (sCmd != null && sCmd.equals("EXPORT")) {
               pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
               
           } else {
               int PAGE = Integer.parseInt(sPage);
               long pagingSessionID = Long.parseLong(sSessionID);
               pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
               
           }
           
       } catch (Exception e) {
           e.printStackTrace();
       }

       HashMap results = new HashMap();
       results.put("results", pagingResults);

       return results;
      //##end searchEVR%4CAAE53A01D8.body
   }

   //##begin viewEVR%4CAAE5400129.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEVR%4CAAE5400129.doc

   public HashMap viewEVR( HashMap form )
            throws WTException {
      //##begin viewEVR%4CAAE5400129.body preserve=yes
       ReferenceFactory rf = new ReferenceFactory();
       String sOid = (String) form.get("oid");
       HashMap ecrMap = new HashMap();
       try {
	       EVRequest evrForm = (EVRequest) rf.getReference(sOid).getObject();
	       Vector eoList = this.getEotoEVRLink( evrForm.getPersistInfo().getObjectIdentifier().getId() );
	       Vector docList = this.getWTDocumentDependencyLink( evrForm.getPersistInfo().getObjectIdentifier().getId(), "EVR" );
	
	       ecrMap.put("evrForm", evrForm);
	       ecrMap.put("eoList", eoList);
	       ecrMap.put("docList", docList);

       } catch( Exception e) {
    	   e.printStackTrace();
    	   //throw new WTException(e);
       }

       return ecrMap;
      //##end viewEVR%4CAAE5400129.body
   }

   //##begin creatorEVN%4CABE02F02C3.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end creatorEVN%4CABE02F02C3.doc

   public String creatorEVN( HashMap form )
            throws WTException {
      //##begin creatorEVN%4CABE02F02C3.body preserve=yes
       EVNotice evnForm = EVNotice.newEVNotice();
       ReferenceFactory rf = new ReferenceFactory();

       String result = CommonUtil.SUCC;

       Transaction trx = new Transaction();
       try {
           trx.start();
           
           String sTitle = (String) form.get("title");
           
           String sDepartment = (String) form.get("department");
           String sCustomerSite = (String) form.get("customerSite");
           
           String sTestTermFrom = (String) form.get("testTermFrom");
           String sTestTermTo = (String) form.get("testTermTo");
           
           String sTestResult = (String) form.get("testResult");
           
           WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
           //WTUser evrUser = (WTUser) rf.getReference(sEvrWtUserOid).getObject();
           //evnForm.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);

           if (sTitle != null && !sTitle.equals("")) evnForm.setName(sTitle); // EO
           
           if (sDepartment != null && !sDepartment.equals("")) evnForm.setTeam(sDepartment); //
           if (sCustomerSite != null && !sCustomerSite.equals("")) evnForm.setCustomerSite(sCustomerSite); //
           
           if (sTestTermFrom != null && !sTestTermFrom.equals("")) evnForm.setTestTermFrom(CommonUtil.formatString2Timestamp( sTestTermFrom, "yyyy-MM-dd") ); //
           if (sTestTermTo != null && !sTestTermTo.equals("")) evnForm.setTestTermTo(CommonUtil.formatString2Timestamp( sTestTermTo, "yyyy-MM-dd") ); //
           
           if (sTestResult != null && !sTestResult.equals("")) evnForm.setDescription(sTestResult); // EO type
           
           // set Number
           String eoNumber = "VN" + CommonUtil.getCurrentTime("yyMM") + CommonUtil.getSeq("EVN_SEQ");
           evnForm.setNumber(eoNumber);
           
           // save content
           String liftCycle = "LC_PSK_ECM";

           WTLibrary product = PSKCommonUtil.getWTLibrary("Document");
           WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

           String yy = CommonUtil.getCurrentTime("yyyy");
           String mm = CommonUtil.getCurrentTime("MM");
           String sFolderPath = "/Default/EVN/" + yy + "/" + mm;

           // Folder assign
           Folder folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
           FolderHelper.assignLocation((FolderEntry) evnForm, folder);
           
           evnForm.setContainer(product);
           LifeCycleHelper.setLifeCycle(evnForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

           String teamName = "PSK_APPROVE_TEMPLATE";
           TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);

           try {
               evnForm = (EVNotice) wt.team.TeamHelper.setTeamTemplate(evnForm, mainTeam);
           } catch(WTPropertyVetoException pve) {
               pve.printStackTrace();
               throw new WTException(pve);
           }
           
           evnForm = (EVNotice) PersistenceHelper.manager.save(evnForm);

           //EVN <-> EVR
           String[] evrOid = (String[]) form.get("evrOid");
           if( evrOid != null && (evrOid.length > 0) ) {
        	   for(int j=0; j < evrOid.length; j++) {
        		   EVRequest evr = (EVRequest) rf.getReference(evrOid[j]).getObject();
	               WTDocumentDependencyLink evnLink = WTDocumentDependencyLink.newWTDocumentDependencyLink(evnForm, evr);
	
	               evnLink = (WTDocumentDependencyLink) PersistenceHelper.manager.save(evnLink);
	           }
           }
           
           //EVN <-> Document
           String[] refDocOid = (String[]) form.get("referenceDocument");
           if( refDocOid != null && (refDocOid.length > 0) ) {
        	   for(int j=0; j < refDocOid.length; j++) {
        		   WTDocument doc = (WTDocument) rf.getReference(refDocOid[j]).getObject();
	               WTDocumentDependencyLink evnLink = WTDocumentDependencyLink.newWTDocumentDependencyLink(evnForm, doc);

	               evnLink = (WTDocumentDependencyLink) PersistenceHelper.manager.save(evnLink);
	           }
           }
           
           Vector addFiles			 = (Vector) form.get("addFiles");
           Vector delFiles			 = (Vector) form.get("fileId");
           Vector fileDescVec 		 = new Vector();
           for(int i=0;i<addFiles.size();i++){
         	  fileDescVec.add("");
           }
           PLMContentHelper.service.updateContent(evnForm, addFiles, delFiles, fileDescVec, false);
           
           result += " : " + evnForm.getNumber();
           //System.out.println("@ created ECNotice =" + result);

           trx.commit();

       } catch (Exception e) {
           trx.rollback();
           e.printStackTrace();
           result = CommonUtil.FAIL + " : " + e.getMessage();
           //throw new WTException(e);

       } finally {
           trx = null;
       }
       return result;
      //##end creatorEVN%4CABE02F02C3.body
   }

   //##begin updateEVN%4CABE0360183.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEVN%4CABE0360183.doc

   public String updateEVN( HashMap form )
            throws WTException {
      //##begin updateEVN%4CABE0360183.body preserve=yes
       ReferenceFactory rf = new ReferenceFactory();

       String result = CommonUtil.SUCC;
       EVNotice evnForm = null;

       Transaction trx = new Transaction();
       try {
          trx.start();
          
          String sOid = (String) form.get("oid");
          evnForm = (EVNotice) rf.getReference(sOid).getObject();
          
          //Start checkOut
          //System.out.println("EVNotice Document Check-out Started...");

          wt.vc.wip.Workable workable =(wt.vc.wip.Workable)evnForm;
          wt.vc.wip.CheckoutLink checkOutLink = null;
          wt.vc.wip.Workable workingCopy = null;
          wt.vc.wip.Workable orgCopy = null;
            
          if(!wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
              if(!wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
                  wt.folder.Folder folder = wt.vc.wip.WorkInProgressHelper.service.getCheckoutFolder();
                  //Folder folder = FolderHelper.service.getFolder("/Default");
                
                  //System.out.println("Folder is " + folder);
                  //System.out.println("checkOutLink Is: " + workable +" and Folder is : " + folder);
                
                  try {
                      checkOutLink = (wt.vc.wip.CheckoutLink)wt.vc.wip.WorkInProgressHelper.service.checkout(workable, folder, "");
                  } catch(wt.util.WTPropertyVetoException wtpve) {
                	  throw new WTException(wtpve);
                  }
                
                  // get Original copy
                  orgCopy = checkOutLink.getOriginalCopy();
                  //System.out.println("orgCopy is " + orgCopy);
                  
                  // get working copy
                  workingCopy = checkOutLink.getWorkingCopy();
                  //System.out.println("workingCopy is " + workingCopy);
                  
              } else if (wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
                  // get Original copy
                  orgCopy = wt.vc.wip.WorkInProgressHelper.service.originalCopyOf(workable);
                  // get working copy
                  workingCopy = wt.vc.wip.WorkInProgressHelper.service.workingCopyOf(workable);
                  //System.out.println("workingCopy is " + workingCopy);
              }
              
          } else if (wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
              workingCopy = workable;
          }

          evnForm = (EVNotice)workingCopy;
          //System.out.println("EVNotice Document Check-out Ended...");
          //End CheckOut

          String sTitle = (String) form.get("title");
          
          String sDepartment = (String) form.get("department");
          String sCustomerSite = (String) form.get("customerSite");
          
          String sTestTermFrom = (String) form.get("testTermFrom");
          String sTestTermTo = (String) form.get("testTermTo");
          
          String sTestResult = (String) form.get("testResult");
          
          WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
          //WTUser evrUser = (WTUser) rf.getReference(sEvrWtUserOid).getObject();
          //evnForm.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);

          if (sTitle != null && !sTitle.equals("")) evnForm.setName(sTitle); // EO
          
          if (sDepartment != null && !sDepartment.equals("")) evnForm.setTeam(sDepartment); //
          if (sCustomerSite != null && !sCustomerSite.equals("")) evnForm.setCustomerSite(sCustomerSite); //
          
          if (sTestTermFrom != null && !sTestTermFrom.equals("")) evnForm.setTestTermFrom(CommonUtil.formatString2Timestamp( sTestTermFrom, "yyyy-MM-dd") ); //
          if (sTestTermTo != null && !sTestTermTo.equals("")) evnForm.setTestTermTo(CommonUtil.formatString2Timestamp( sTestTermTo, "yyyy-MM-dd") ); //
          
          if (sTestResult != null && !sTestResult.equals("")) evnForm.setDescription(sTestResult); // EO type
          
          //save content
          PersistenceServerHelper.manager.update(evnForm);
          //evrForm = (EVRequest) PersistenceHelper.manager.save(evrForm);
          
          //delete Document link 
          deleteWTDocumentDependencyLink( evnForm.getPersistInfo().getObjectIdentifier().getId(), "EVN" );
          
          //EVN <-> EVR Link
          String[] evrOid = (String[]) form.get("evrOid");
          if( evrOid != null && (evrOid.length > 0) ) {
        	  for(int j=0; j < evrOid.length; j++) {
        		  EVRequest evr = (EVRequest) rf.getReference(evrOid[j]).getObject();
        		  WTDocumentDependencyLink evnLink = WTDocumentDependencyLink.newWTDocumentDependencyLink(evnForm, evr);
	
        		  evnLink = (WTDocumentDependencyLink)PersistenceHelper.manager.save(evnLink);
        	  }
          }
          
          //EVN <-> Document
          String[] refDocOid = (String[]) form.get("referenceDocument");
          if( refDocOid != null && (refDocOid.length > 0) ) {
        	  for(int j=0; j < refDocOid.length; j++) {
        		  WTDocument doc = (WTDocument) rf.getReference(refDocOid[j]).getObject();
        		  WTDocumentDependencyLink evnLink = WTDocumentDependencyLink.newWTDocumentDependencyLink(evnForm, doc);

        		  evnLink = (WTDocumentDependencyLink) PersistenceHelper.manager.save(evnLink);
        	  }
          }
          
          Vector addFiles			 = (Vector) form.get("addFiles");
          Vector delFiles			 = (Vector) form.get("fileId");
          Vector fileDescVec 		 = new Vector();
          for(int i=0;i<addFiles.size();i++){
        	  fileDescVec.add("");
          }
          PLMContentHelper.service.updateContent(evnForm, addFiles, delFiles, fileDescVec, false);
          
          //Start checkin ...
          //System.out.println("DB checkin start...");
          evnForm = (EVNotice)wt.vc.wip.WorkInProgressHelper.service.checkin(evnForm, "");
          //System.out.println("DB checkin end...");
          //System.out.println("DB refresh start...");
          evnForm = (EVNotice)PersistenceHelper.manager.refresh(evnForm, true, true);
          //System.out.println("DB refresh end...");
          //End checkin ...

          result += " : " + evnForm.getNumber();
          //System.out.println("@ created EVRequest =" + result);

          trx.commit();

       } catch (Exception e) {
          trx.rollback();
          
          System.out.println("Start UndoCheckout EVNotice Doc...");
          try {
              if (wt.vc.wip.WorkInProgressHelper.isCheckedOut((wt.vc.wip.Workable)evnForm)) {
                  wt.vc.wip.WorkInProgressHelper.service.undoCheckout(evnForm);
              }
          } catch(Exception ee) {
              ee.printStackTrace();
          }
          System.out.println("End UndoCheckout EVNotice Doc...");
          
          e.printStackTrace();
          result = CommonUtil.FAIL + " : " + e.getMessage();
          //throw new WTException(e);

       } finally {
          trx = null;
       }
       return result;
      //##end updateEVN%4CABE0360183.body
   }

   //##begin deleteEVN%4CABE03B023C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEVN%4CABE03B023C.doc

   public String deleteEVN( HashMap form )
            throws WTException {
      //##begin deleteEVN%4CABE03B023C.body preserve=yes

      return null;
      //##end deleteEVN%4CABE03B023C.body
   }

   //##begin searchEVN%4CABE0420012.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEVN%4CABE0420012.doc

   public HashMap searchEVN( HashMap form )
            throws WTException {
      //##begin searchEVN%4CABE0420012.body preserve=yes
       PagingQueryResult pagingResults = null;

       try {
	       String sCmd = (String) form.get("cmd");
	       String sPage = (String) form.get("page");
	       String sTotalPage = (String) form.get("totalPage");
	       String sSessionID = (String) form.get("sessionID");
	
	       String sNumber = (String) form.get("shNumber");				//number
	       String sTitle = (String) form.get("shTitle");				//title
	
	       String sState = (String) form.get("shApprovalStatus");		//state
	
	       String sCreatorName = (String) form.get("shIssueUserNm");	
	       String sCreator = "";
	       if( sCreatorName != null && !sCreatorName.equals("") ) {
	           LdapSearchUser searchUserId = new LdapSearchUser();
	
	           sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
	       }
	
	       String sTestResult     = (String) form.get("shTestResult");
	       
	       String sFromRegDate   = (String) form.get("shFromRegDate");
	       String sToRegDate   = (String) form.get("shToRegDate");
	
	       String sFromUpDate   = (String) form.get("shFromUpDate");
	       String sToUpDate   = (String) form.get("shToUpDate");

           QuerySpec query = new QuerySpec();
           query.setAdvancedQueryEnabled(true);

           if (query.getConditionCount() > 0)
               query.appendAnd();

           Class classType = EVNotice.class;
           int pskChangeIndex = query.appendClassList(classType, true);

           query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });
           
           if (sNumber != null && !sNumber.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, EVNotice.NUMBER, SearchCondition.LIKE, "%" + sNumber + "%"), new int[] { pskChangeIndex });
           }
           
           if (sTitle != null && !sTitle.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "master>name", SearchCondition.LIKE, "%" + sTitle + "%"), new int[] { pskChangeIndex });
           }
           
           if (sState != null && !sState.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
           }
           
           if (sTestResult != null && !sTestResult.equals("")) {
               if (query.getConditionCount() > 0) query.appendAnd();
               
               query.appendWhere(new SearchCondition(classType, EVNotice.DESCRIPTION, SearchCondition.LIKE, "%" + sTestResult + "%"), new int[] { pskChangeIndex });
           }

           if (sCreator != null && !sCreator.equals("")) {
               long lcreator = 0;
               WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
               if( creator != null ) { 
                   lcreator = creator.getPersistInfo().getObjectIdentifier().getId();

                   if (query.getConditionCount() > 0) query.appendAnd();
                   query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
               }
           }
                       
           //RegistDate from to Start
           if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
           }
             
           if ( sToRegDate != null && !sToRegDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
           }
           //RegistDate from to End
           
           //UpdateDate from to Start
           if ( sFromUpDate != null && !sFromUpDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromUpDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
           }
             
           if ( sToUpDate != null && !sToUpDate.equals("") ) {
               if (query.getConditionCount()>0) query.appendAnd();
               query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToUpDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
           }
           //UpdateDate From To End
           
           ClassAttribute classattribute = new ClassAttribute();
           OrderBy orderby = null;
           classattribute = new ClassAttribute(classType, "thePersistInfo.createStamp");
           orderby = new OrderBy(classattribute, true);

           query.appendOrderBy(orderby, new int[] { 0 });

           //System.out.println("## REQUEST Query:" + query.toString());

           QueryResult queryResult = PersistenceHelper.manager.find(query);
           
           if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
               pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
               
           } else if (sCmd != null && sCmd.equals("EXPORT")) {
               pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
               
           } else {
               int PAGE = Integer.parseInt(sPage);
               long pagingSessionID = Long.parseLong(sSessionID);
               pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
               
           }
           
       } catch (Exception e) {
           e.printStackTrace();
       }

       HashMap results = new HashMap();
       results.put("results", pagingResults);

       return results;
      //##end searchEVN%4CABE0420012.body
   }

   //##begin viewEVN%4CABE04A0053.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEVN%4CABE04A0053.doc

   public HashMap viewEVN( HashMap form )
            throws WTException {
      //##begin viewEVN%4CABE04A0053.body preserve=yes
       ReferenceFactory rf = new ReferenceFactory();
       String sOid = (String) form.get("oid");
       HashMap ecrMap = new HashMap();
       
       try {
	       EVNotice evnForm = (EVNotice) rf.getReference(sOid).getObject();
	       Vector docLinkList = this.getWTDocumentDependencyLink( evnForm.getPersistInfo().getObjectIdentifier().getId(), "EVN" );
	       
	       ecrMap.put("evnForm", evnForm);
	       ecrMap.put("docLinkList", docLinkList);
       } catch( Exception e) {
    	   e.printStackTrace();
    	   //throw new WTException(e);
       }

       return ecrMap;
      //##end viewEVN%4CABE04A0053.body
   }

   //##begin user.operations preserve=yes
	public Vector getEotoEVRLink(long Oid) throws WTException {
		Vector results = new Vector();
		EOtoEVRLink link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();
			
			Class linkType = EOtoEVRLink.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class evrType = EVRequest.class;
			int evrIndex = query.appendClassList(evrType, false);
			
			query.appendJoin(linkIndex, EOtoEVRLink.EVR_ROLE, evrIndex);
			query.appendWhere(new SearchCondition(evrType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { evrIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				//System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (EOtoEVRLink)obj[0];
					results.add(link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return results;
	}
	
	public void deleteEotoEVRLink(long Oid) throws WTException {
		try {
			Vector eoList = getEotoEVRLink(Oid);
			EOtoEVRLink links = null;
			
			for(int i=0; i<eoList.size(); i++) {
				links = (EOtoEVRLink) eoList.get(i);
				PersistenceHelper.manager.delete(links);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
	}
	
	public Vector getWTDocumentDependencyLink(long Oid, String type) throws WTException {
		Vector results = new Vector();
		WTDocumentDependencyLink form = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = WTDocumentDependencyLink.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class evType = null;
			
			if( type.equals("EVR") ) {
				evType = EVRequest.class;
			} else {
				evType = EVNotice.class;
			}
			
			int evIndex = query.appendClassList(evType, false);
			
			query.appendJoin(linkIndex, WTDocumentDependencyLink.ROLE_AOBJECT_ROLE, evIndex);
			query.appendWhere(new SearchCondition(evType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { evIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					form = (WTDocumentDependencyLink)obj[0];
					results.add(form);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		
		return results;
	}

	public void deleteWTDocumentDependencyLink(long Oid, String type) throws WTException {
		try {
			Vector evrList = getWTDocumentDependencyLink(Oid, type);
			WTDocumentDependencyLink evrLink = null;
			
			for(int i=0; i < evrList.size(); i++) {
				evrLink = (WTDocumentDependencyLink) evrList.get(i);
				
				PersistenceHelper.manager.delete(evrLink);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
	}
   //##end user.operations
}
