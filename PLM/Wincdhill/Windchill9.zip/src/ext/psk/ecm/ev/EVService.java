// Generated EVService%4CAAE4BF030A: ? 10/06/10 12:24:14
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ev;

import java.lang.String;
import java.util.HashMap;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EVService%4CAAE4BF030A.doc preserve=no
/**
 * est
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/
//##end EVService%4CAAE4BF030A.doc

@RemoteInterface
public interface EVService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createEVR%4CAAE50603AB.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEVR%4CAAE50603AB.doc

   public String createEVR( HashMap form )
            throws WTException;

   //##begin updateEVR%4CAAE51003DD.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEVR%4CAAE51003DD.doc

   public String updateEVR( HashMap form )
            throws WTException;

   //##begin deleteEVR%4CAAE52E0334.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEVR%4CAAE52E0334.doc

   public String deleteEVR( HashMap form )
            throws WTException;

   //##begin searchEVR%4CAAE53A01D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEVR%4CAAE53A01D8.doc

   public HashMap searchEVR( HashMap form )
            throws WTException;

   //##begin viewEVR%4CAAE5400129.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEVR%4CAAE5400129.doc

   public HashMap viewEVR( HashMap form )
            throws WTException;

   //##begin creatorEVN%4CABE02F02C3.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end creatorEVN%4CABE02F02C3.doc

   public String creatorEVN( HashMap form )
            throws WTException;

   //##begin updateEVN%4CABE0360183.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEVN%4CABE0360183.doc

   public String updateEVN( HashMap form )
            throws WTException;

   //##begin deleteEVN%4CABE03B023C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEVN%4CABE03B023C.doc

   public String deleteEVN( HashMap form )
            throws WTException;

   //##begin searchEVN%4CABE0420012.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEVN%4CABE0420012.doc

   public HashMap searchEVN( HashMap form )
            throws WTException;

   //##begin viewEVN%4CABE04A0053.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEVN%4CABE04A0053.doc

   public HashMap viewEVN( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
