// Generated StandardEOService%4C57718E02CE: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import ext.psk.ecm.eo.EOService;
import java.io.Serializable;
import java.lang.String;
import java.util.HashMap;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.query.*;
import wt.change2.AddressedBy2;
import wt.change2.AffectedActivityData;
import wt.change2.ChangeNoticeComplexity;
import wt.change2.ChangeRecord2;
import wt.change2.IncludedIn2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeOrder2Master;
import wt.change2.WTChangeOrder2MasterIteration;
import wt.clients.folder.FolderTaskLogic;
import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory; // Preserved unmodeled dependency
import wt.fc.WTObject;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.org.OrganizationServicesHelper;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference; // Preserved unmodeled dependency
import wt.org.WTUser;
import wt.session.SessionHelper; // Preserved unmodeled dependency
import wt.team.TeamTemplate;
import ext.psk.util.CommonUtil;  // Preserved unmodeled dependency
import ext.psk.util.CreateNumberRuleUtil;
import ext.psk.util.LdapSearchUser;
import ext.psk.util.PSKCommonUtil;  // Preserved unmodeled dependency
import ext.psk.util.PageControl;  // Preserved unmodeled dependency
import ext.psk.util.upload.PLMContentHelper;

import java.util.Enumeration;  // Preserved unmodeled dependency

import oracle.sql.DATE;
import ext.psk.ecm.ecr.ECRequest;  // Preserved unmodeled dependency
import java.util.Collections;  // Preserved unmodeled dependency
import java.util.Hashtable;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
import wt.vc.VersionControlHelper;  // Preserved unmodeled dependency
import wt.vc.config.LatestConfigSpec;  // Preserved unmodeled dependency
//##end user.imports

//##begin StandardEOService%4C57718E02CE.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardEOService</code> static factory method(s), not
 * the <code>StandardEOService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardEOService%4C57718E02CE.doc

public class StandardEOService extends StandardManager implements EOService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.eo.eoResource";
   private static final String CLASSNAME = StandardEOService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardEOService%newStandardEOServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardEOService
    * @exception wt.util.WTException
    **/
   //##end newStandardEOService%newStandardEOServicef.doc

   public static StandardEOService newStandardEOService()
            throws WTException {
      //##begin newStandardEOService%newStandardEOServicef.body preserve=no

      StandardEOService instance = new StandardEOService();
      instance.initialize();
      return instance;
      //##end newStandardEOService%newStandardEOServicef.body
   }

   //##begin createEOAlphaForm%4C5A686302CE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOAlphaForm%4C5A686302CE.doc

   public String createEOAlphaForm( HashMap form )
            throws WTException {
      //##begin createEOAlphaForm%4C5A686302CE.body preserve=yes
		EOAlphaForm eoForm = EOAlphaForm.newEOAlphaForm();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;
		
		Transaction trx = new Transaction();
		try {
			trx.start();

			String sNumber = (String) form.get("number");
			String sTitle = (String) form.get("title");
			String sChangeReason = (String) form.get("changeReason");
			String sDepartment = (String) form.get("department");

			String sStockMgt = (String) form.get("stockMgt");
			String sApplyDate = (String) form.get("applyDate");
			String sEOContent = (String) form.get("eoContent");
			String sEOType = (String) form.get("eoType");
			String sNeedEVR = (String) form.get("needEVR");

			String sEVRTitle = (String) form.get("evrTitle");
			String sEVRTestList = (String) form.get("evrTestList");
			String sEvrWtUserOid = (String) form.get("evrWtUserOid");
			String sNoEpi = (String) form.get("noEpi");
			
			// check eotype duplicate
			String sECROid = (String) form.get("ecrOid");
			if( sECROid != null && !sECROid.equals("")) {
				ECRequest ecr = (ECRequest) rf.getReference(sECROid).getObject();
				boolean checkEOType = this.existDuplicateEoType(ecr.getPersistInfo().getObjectIdentifier().getId(), sEOType);
				
				if( checkEOType ) {
					throw new Exception("Error : EOType " + sEOType + "는 이미 등록되어 있습니다.");
				}
			}
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
			WTUser evrUser = null;

			if (sTitle != null && !sTitle.equals("")) eoForm.setName(sTitle); // EO
			//if (sNumber != null && !sNumber.equals("")) eoForm.setNumber(sNumber); // EO No

			eoForm.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);

			if (sChangeReason != null && !sChangeReason.equals("")) eoForm.setChangeReason(sChangeReason); // change reason A
			if (sDepartment != null && !sDepartment.equals("")) eoForm.setDepartment(sDepartment); // creator's department
			if (sStockMgt != null && !sStockMgt.equals("")) eoForm.setStockMgt(sStockMgt); // stock management
			if (sEOContent != null && !sEOContent.equals("")) eoForm.setEoContent(sEOContent); // EO content
			if (sEOType != null && !sEOType.equals("")) eoForm.setEoType(sEOType); // EO type
			if (sNoEpi != null && !sNoEpi.equals("")) eoForm.setNoEPI(sNoEpi); // EO type
			
			if (sNeedEVR != null && !sNeedEVR.equals("")) {
				eoForm.setNeedEVR(sNeedEVR); // need evr
				
				if (sEVRTitle != null && !sEVRTitle.equals("")) eoForm.setEvrTitle(sEVRTitle); // evr title
				if (sEVRTestList != null && !sEVRTestList.equals("")) eoForm.setEvrTestList(sEVRTestList); // evr test list
				if (sEvrWtUserOid != null && !sEvrWtUserOid.equals("") ) {
					evrUser = (WTUser) rf.getReference(sEvrWtUserOid).getObject();
					eoForm.setEvrcreator(evrUser); // evr test list
				}
			}
			
			if (sApplyDate != null && !sApplyDate.equals("") ) eoForm.setApplyDate( CommonUtil.formatString2Timestamp( sApplyDate, "yyyy-MM-dd") );	//

			// set Number
	        String eoNumber = "EO" + CommonUtil.getCurrentTime("yyMM") + CommonUtil.getSeq("EO_SEQ");
	        eoForm.setNumber(eoNumber);
			
			// save content
			String liftCycle = "LC_PSK_ECM";
			
			WTLibrary product = PSKCommonUtil.getWTLibrary("Document");
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

			String yy = CommonUtil.getCurrentTime("yyyy");
			String mm = CommonUtil.getCurrentTime("MM");
			String sFolderPath = "/Default/EO/" + yy + "/" + mm;

			// Folder assign
			Folder folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
			FolderHelper.assignLocation((FolderEntry) eoForm, folder);
			
			eoForm.setContainer(product);
			LifeCycleHelper.setLifeCycle(eoForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

			String teamName = "PSK_APPROVE_TEMPLATE";
			TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);

			try {
				eoForm = (EOAlphaForm) wt.team.TeamHelper.setTeamTemplate(eoForm, mainTeam);
			} catch(WTPropertyVetoException pve) {
				throw new WTException(pve);
			}
			
	        WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
	        SessionHelper.manager.setAdministrator();
			
	        eoForm = (EOAlphaForm) PersistenceHelper.manager.save(eoForm);

			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			
			//ECR <-> Pre-EO AlphaForm Link
			if( sECROid != null && !sECROid.equals("")) {
				ECRequest ecr = (ECRequest) rf.getReference(sECROid).getObject();
				AddressedBy2 ecrLink = AddressedBy2.newAddressedBy2(ecr, eoForm);

				ecrLink = (AddressedBy2) PersistenceHelper.manager.save(ecrLink);
			}
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(eoForm, addFiles, delFiles, fileDescVec, false);
			
			result += " : " + eoForm.getNumber();
			//System.out.println("@ created EOAlphaForm =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		
		return result;
      //##end createEOAlphaForm%4C5A686302CE.body
   }

   //##begin updateEOAlphaForm%4C5A68F203A9.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOAlphaForm%4C5A68F203A9.doc

   public String updateEOAlphaForm( HashMap form )
            throws WTException {
      //##begin updateEOAlphaForm%4C5A68F203A9.body preserve=yes
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sOid = (String) form.get("oid");
			EOAlphaForm eoForm = (EOAlphaForm) rf.getReference(sOid).getObject();
			
			String sTitle = (String) form.get("title");
			String sNumber = (String) form.get("number");
			String sChangeReason = (String) form.get("changeReason");
			
			String sDepartment = (String) form.get("department");

			String sStockMgt = (String) form.get("stockMgt");
			String sApplyDate = (String) form.get("applyDate");
			String sEOContent = (String) form.get("eoContent");
			String sEOType = (String) form.get("eoType");
			String sNeedEVR = (String) form.get("needEVR");

			String sEVRTitle = (String) form.get("evrTitle");
			String sEVRTestList = (String) form.get("evrTestList");
			String sEvrWtUserOid = (String) form.get("evrWtUserOid");
			String sNoEpi = (String) form.get("noEpi");
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
			WTUser evrUser = null;
			
			eoForm.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);

			if (sChangeReason != null && !sChangeReason.equals("")) eoForm.setChangeReason(sChangeReason); // change reason A
			
			if (sDepartment != null && !sDepartment.equals("")) eoForm.setDepartment(sDepartment); // creator's department
			if (sStockMgt != null && !sStockMgt.equals("")) eoForm.setStockMgt(sStockMgt); // stock management
			if (sEOContent != null && !sEOContent.equals("")) eoForm.setEoContent(sEOContent); // EO content
			if (sEOType != null && !sEOType.equals("")) eoForm.setEoType(sEOType); // EO type
			if (sNoEpi != null && !sNoEpi.equals("")) eoForm.setNoEPI(sNoEpi); // EO type
			
			if (sNeedEVR != null && !sNeedEVR.equals("")) {
				eoForm.setNeedEVR(sNeedEVR); // need evr
				
				if (sEVRTitle != null && !sEVRTitle.equals("")) eoForm.setEvrTitle(sEVRTitle); // evr title
				if (sEVRTestList != null && !sEVRTestList.equals("")) eoForm.setEvrTestList(sEVRTestList); // evr test list
				if (sEvrWtUserOid != null && !sEvrWtUserOid.equals("") ) {
					evrUser = (WTUser) rf.getReference(sEvrWtUserOid).getObject();
					eoForm.setEvrcreator(evrUser); // evr test list
				}
			} else {
				sNeedEVR = "";
				sEVRTitle = "";
				sEVRTestList = "";
				evrUser = null;
				
				eoForm.setNeedEVR(sNeedEVR); // need evr
				eoForm.setEvrTitle(sEVRTitle);
				eoForm.setEvrTestList(sEVRTestList);
				eoForm.setEvrcreator(evrUser);
			}
			
			if( sApplyDate != null && !sApplyDate.equals("") ) eoForm.setApplyDate( CommonUtil.formatString2Timestamp( sApplyDate, "yyyy-MM-dd") );	//

			// save content
			eoForm = (EOAlphaForm) PersistenceHelper.manager.save(eoForm);

			/**
			 * UPDATE
			 *  ECR <-> Pre-EO Alpha Link
			 */
			// 1. query & delte
			AddressedBy2 ecrLink = getAddressedBy2( eoForm.getPersistInfo().getObjectIdentifier().getId() ); 
			ECRequest oldEcr = null;
			if( ecrLink != null ) oldEcr = (ECRequest)ecrLink.getChangeRequest2();

			// 2. add
			String sECROid = (String) form.get("ecrOid");
			ECRequest newECR = null;
			if( sECROid != null && !sECROid.equals("")) {
				newECR = (ECRequest) rf.getReference(sECROid).getObject();
				boolean checkEOType = false;
				
				if( oldEcr != null ) {
					checkEOType = this.existDuplicateEoType( oldEcr.getPersistInfo().getObjectIdentifier().getId(), sEOType );
				} else if( newECR != null ) {
					checkEOType = this.existDuplicateEoType( newECR.getPersistInfo().getObjectIdentifier().getId(), sEOType );
				} 
				
				if( checkEOType ) {
					throw new Exception("Error : EOType " + sEOType + "는 이미 등록되어 있습니다.");
				}
			}

			if( oldEcr!= null && newECR != null && (oldEcr.getPersistInfo().getObjectIdentifier().getId() == 
				newECR.getPersistInfo().getObjectIdentifier().getId()) ) {
				 //is Same
			} else {
				if( oldEcr != null ) PersistenceHelper.manager.delete(ecrLink);	
				if( newECR != null ) {
					System.out.println( "new ECR in = " + newECR );
					ecrLink = AddressedBy2.newAddressedBy2(newECR, eoForm);
					ecrLink = (AddressedBy2) PersistenceHelper.manager.save(ecrLink);
				}
			}
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(eoForm, addFiles, delFiles, fileDescVec, false);
			
			result += " : " + eoForm.getNumber();
			System.out.println("@ updated EOAlphaForm =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end updateEOAlphaForm%4C5A68F203A9.body
   }

   //##begin deleteEOAlphaForm%4C5A6908032C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOAlphaForm%4C5A6908032C.doc

   public String deleteEOAlphaForm( HashMap form ) throws WTException {
      //##begin deleteEOAlphaForm%4C5A6908032C.body preserve=yes
	   String result = CommonUtil.SUCC;
	   Transaction trx = new Transaction();
	   
	   try {
		   trx.start();
		   
	       ReferenceFactory rf = new ReferenceFactory();
	       String sOid = (String) form.get("eoAlphaFormOid");
	       EOAlphaForm eoForm = (EOAlphaForm) rf.getReference(sOid).getObject();
	       
	       Vector abFormLink = this.getABFormLink( eoForm.getPersistInfo().getObjectIdentifier().getId() );
	       
	       for(int i=0; i < abFormLink.size(); i++ ) {
	    	   IncludedIn2 link = (IncludedIn2)abFormLink.get(i);
	    	   Object[] obj = link.getAllObjects();
	    	   
	    	   for(int j=0; j < obj.length; j++ ) {
	    		   if( obj[j] instanceof EOBetaAForm ) {
	    			   String aFormOid = ((EOBetaAForm)obj[j]).toString();
	    			   EOBetaAForm betaAForm = (EOBetaAForm) rf.getReference(aFormOid).getObject();

	    			   AffectedActivityData oldPartLink = this.getAFFDataLinkforBetaA( betaAForm.getPersistInfo().getObjectIdentifier().getId() );
	    			   if( oldPartLink != null ) PersistenceHelper.manager.delete(oldPartLink);

	    			   IncludedIn2 betaBLink = this.getIncludedIn2( betaAForm.getPersistInfo().getObjectIdentifier().getId() );
	    			   if( betaBLink != null ) PersistenceHelper.manager.delete(betaBLink);

	    			   PersistenceHelper.manager.delete(betaAForm);
	    		   }

	    		   if( obj[j] instanceof EOBetaBForm ) {
	    			   String bFormOid = ((EOBetaBForm)obj[j]).toString();
	    			   EOBetaBForm betaBForm = betaBForm = (EOBetaBForm) rf.getReference(bFormOid).getObject();
	    			   
	    			   HashMap partMap = this.getAFFDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 

	    			   if( partMap != null ) {
	    			       AffectedActivityData partOldLink = (AffectedActivityData)partMap.get("partOld");
	    			       if( partOldLink != null ) PersistenceHelper.manager.delete(partOldLink);
	    			       
	    			       AffectedActivityData assySourceLink = (AffectedActivityData)partMap.get("assySource");
	    			       if( assySourceLink != null ) PersistenceHelper.manager.delete(assySourceLink);
	    			   }

	    			   // 3. get ChangeRecord2
	    			   HashMap partMap2 = this.getChangeDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 

	    			   if( partMap2 != null ) {
	    			       ChangeRecord2 assyNewLink = (ChangeRecord2)partMap2.get("assyNew");
	    			       if( assyNewLink != null ) PersistenceHelper.manager.delete(assyNewLink);
	    			       
	    			       ChangeRecord2 partNewLink = (ChangeRecord2)partMap2.get("partNew");
	    			       if( partNewLink != null ) PersistenceHelper.manager.delete(partNewLink);
	    			   }

	    			   IncludedIn2 betaBLink = this.getIncludedIn2( betaBForm.getPersistInfo().getObjectIdentifier().getId() );
	    			   if( betaBLink != null ) PersistenceHelper.manager.delete(betaBLink);

	    			   PersistenceHelper.manager.delete(betaBForm);
    			   }
	    	   }
	       }

	       AddressedBy2 ecrLink = this.getAddressedBy2( eoForm.getPersistInfo().getObjectIdentifier().getId() );
	       if( ecrLink != null ) PersistenceHelper.manager.delete(ecrLink);
	       
	       PersistenceHelper.manager.delete(eoForm);
	       
	       trx.commit();

	   } catch(Exception e){
		   trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();
	   } finally {
		   trx = null;
	   }

	   return result;
      //##end deleteEOAlphaForm%4C5A6908032C.body
   }

   //##begin viewEOAlphaForm%4C74D53A0109.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOAlphaForm%4C74D53A0109.doc

   public HashMap viewEOAlphaForm( HashMap form )
            throws WTException {
      //##begin viewEOAlphaForm%4C74D53A0109.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String sOid = (String) form.get("oid");
	   
	   EOAlphaForm alForm = (EOAlphaForm) rf.getReference(sOid).getObject();

	   AddressedBy2 ecrLink = getAddressedBy2( alForm.getPersistInfo().getObjectIdentifier().getId() ); 
	   ECRequest ecr = null;
	   if( ecrLink != null ) ecr = (ECRequest)ecrLink.getChangeRequest2();
	   
	   HashMap alphaMap = new HashMap();
	   
	   alphaMap.put("alphaForm", alForm);
	   
	   if( ecrLink != null ) alphaMap.put("ecrForm", ecr);
	   
       return alphaMap;
      //##end viewEOAlphaForm%4C74D53A0109.body
   }

   //##begin searchEOAlphaForm%4C5A69170261.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOAlphaForm%4C5A69170261.doc

   public HashMap searchEOAlphaForm( HashMap form )
            throws WTException {
      //##begin searchEOAlphaForm%4C5A69170261.body preserve=yes
		PagingQueryResult pagingResults = null;

		String sCmd = (String) form.get("cmd");
		String sPage = (String) form.get("page");
		String sTotalPage = (String) form.get("totalPage");
		String sSessionID = (String) form.get("sessionID");
		
		String sNumber = (String) form.get("shNumber");				//number
		String sTitle = (String) form.get("shTitle");				//title
		
		String sState = (String) form.get("shApprovalStatus");		//state
		
		String sCreatorName = (String) form.get("shIssueUserNm");	
		String sCreator = "";
		if( sCreatorName != null && !sCreatorName.equals("") ) {
			LdapSearchUser searchUserId = new LdapSearchUser();

			sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
		}
		
		String sChangeReason     = (String) form.get("shChangeReason");
		String sFromRegDate   = (String) form.get("shFromRegDate");
		String sToRegDate   = (String) form.get("shToRegDate");

		String sFromUpDate   = (String) form.get("shFromUpDate");
		String sToUpDate   = (String) form.get("shToUpDate");
		
		String sDepartment = (String) form.get("shIssueDepartNm");	//department

		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class classType = EOAlphaForm.class;
			int pskChangeIndex = query.appendClassList(classType, true);

			query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });
			
			if (sNumber != null && !sNumber.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, EOAlphaForm.NUMBER, SearchCondition.LIKE, "%" + sNumber + "%"), new int[] { pskChangeIndex });
			}
			
			if (sTitle != null && !sTitle.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "master>name", SearchCondition.LIKE, "%" + sTitle + "%"), new int[] { pskChangeIndex });
			}
			
			if (sState != null && !sState.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
			}
			
			if (sChangeReason != null && !sChangeReason.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				
				query.appendWhere(new SearchCondition(classType, ECRequest.CHANGE_REASON, SearchCondition.EQUAL, sChangeReason), new int[] { pskChangeIndex });
			}
			
			if (sCreator != null && !sCreator.equals("")) {
				long lcreator = 0;
				WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
				if( creator != null ) { 
					lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
	
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
				}
			}
						
			//RegistDate from to Start
			if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
			}
	          
			if ( sToRegDate != null && !sToRegDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
			}
			//RegistDate from to End
			
			//UpdateDate from to Start
			if ( sFromUpDate != null && !sFromUpDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromUpDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
			}
	          
			if ( sToUpDate != null && !sToUpDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToUpDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
			}
			//UpdateDate From To End
			
			if (sDepartment != null && !sDepartment.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "writeDept", SearchCondition.LIKE, "%" + sDepartment + "%"), new int[] { pskChangeIndex });
			}
			
			ClassAttribute classattribute = new ClassAttribute();
			OrderBy orderby = null;
			classattribute = new ClassAttribute(classType, "thePersistInfo.createStamp");
			orderby = new OrderBy(classattribute, true);

			query.appendOrderBy(orderby, new int[] { 0 });

			//System.out.println("## REQUEST Query:" + query.toString());

			QueryResult queryResult = PersistenceHelper.manager.find(query);
			
			if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
				pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
				
			} else if (sCmd != null && sCmd.equals("EXPORT")) {
				pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
				
			} else {
				int PAGE = Integer.parseInt(sPage);
				long pagingSessionID = Long.parseLong(sSessionID);
				pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		HashMap results = new HashMap();
		results.put("results", pagingResults);

		return results;
      //##end searchEOAlphaForm%4C5A69170261.body
   }

   //##begin createEOBetaAForm%4C5A692A0290.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOBetaAForm%4C5A692A0290.doc

   public String createEOBetaAForm( HashMap form )
            throws WTException {
      //##begin createEOBetaAForm%4C5A692A0290.body preserve=yes
		EOBetaAForm betaAForm = EOBetaAForm.newEOBetaAForm();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			String sNumber = (String) form.get("number");
			String sTitle = (String) form.get("title");

			String sEOType = (String) form.get("eoType");
			String sBOMMaintDate = (String) form.get("bomMaintDate");
			String sBOMMaintStatus = (String) form.get("bomMaintStatus");

			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();			 
			
			if (sTitle != null && !sTitle.equals("")) betaAForm.setName(sTitle); // EO

			if (sBOMMaintStatus != null && !sBOMMaintStatus.equals("")) betaAForm.setBomMaintStatue(sBOMMaintStatus); //
			if (sBOMMaintDate != null && !sBOMMaintDate.equals("") ) betaAForm.setBomMaintDate( CommonUtil.formatString2Timestamp( sBOMMaintDate, "yyyy-MM-dd") ); //

			String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");
			EOAlphaForm alForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();
			
			// set Number
	        String eoNumber = alForm.getNumber() + "A";
	        eoNumber += CreateNumberRuleUtil.getEOEulFormNo(eoNumber);
	        betaAForm.setNumber(eoNumber);
			
			// save content
			String liftCycle = "LC_PSK_ECM";

			// Folder && LifeCycle Setting
			Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
			FolderHelper.assignLocation((FolderEntry) betaAForm, folder);
			PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);
			
			betaAForm.setContainer(product);
			LifeCycleHelper.setLifeCycle(betaAForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

			betaAForm = (EOBetaAForm) PersistenceHelper.manager.save(betaAForm);

			//alpha <-> betaA Link
			IncludedIn2 eoLink = IncludedIn2.newIncludedIn2(alForm, betaAForm);
			eoLink = (IncludedIn2) PersistenceHelper.manager.save(eoLink);
			
			//betaA's Part <-> Part Link
			String sPartOid = (String) form.get("partOid");
			WTPart part = null;
			if( sPartOid != null && !sPartOid.equals("")) { 
				part = (WTPart) rf.getReference(sPartOid).getObject();
			
				AffectedActivityData partLink = AffectedActivityData.newAffectedActivityData(part, betaAForm);
				partLink.setDescription("ADD");
				partLink = (AffectedActivityData) PersistenceHelper.manager.save(partLink);
			}
			
			result += " : " + betaAForm.getNumber();
			//System.out.println("@ created EOBetaAForm =" + result);

			trx.commit();
			
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		
		return result;
      //##end createEOBetaAForm%4C5A692A0290.body
   }

   //##begin updateEOBetaAForm%4C5A6945036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOBetaAForm%4C5A6945036B.doc

   public String updateEOBetaAForm( HashMap form )
            throws WTException {
      //##begin updateEOBetaAForm%4C5A6945036B.body preserve=yes
		ReferenceFactory rf = new ReferenceFactory();
		String sOid = (String) form.get("oid");
		EOBetaAForm betaAForm = (EOBetaAForm) rf.getReference(sOid).getObject();
		
		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			String sNumber = (String) form.get("number");
			String sTitle = (String) form.get("title");
			
			String sBOMMaintDate = (String) form.get("bomMaintDate");
			String sBOMMaintStatus = (String) form.get("bomMaintStatus");
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

			if (sBOMMaintStatus != null) betaAForm.setBomMaintStatue(sBOMMaintStatus); //
			if (sBOMMaintDate != null ) betaAForm.setBomMaintDate( CommonUtil.formatString2Timestamp( sBOMMaintDate, "yyyy-MM-dd") ); //

			betaAForm = (EOBetaAForm) PersistenceHelper.manager.save(betaAForm);

			String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");

			/**
			 * UPDATE
			 *  betaA's Part <-> Part Link
			 */
			// 1. query & delte
			AffectedActivityData oldPartLink = getAFFDataLinkforBetaA( betaAForm.getPersistInfo().getObjectIdentifier().getId() ); 
			WTPart oldPart = null;
			if( oldPartLink != null ) oldPart = (WTPart)oldPartLink.getChangeable2();

			// 2. add
			String sPartOid = (String) form.get("partOid");
			WTPart part = null;
			if( sPartOid != null && !sPartOid.equals("") ) part = (WTPart) rf.getReference(sPartOid).getObject();
			
			if( oldPart != null && part != null && ( oldPart.getPersistInfo().getObjectIdentifier().getId() == 
				part.getPersistInfo().getObjectIdentifier().getId() ) ) {
				// is Same
			} else {
				if( oldPartLink != null ) PersistenceHelper.manager.delete(oldPartLink);
					
				if( part != null ) {
					AffectedActivityData partLink = AffectedActivityData.newAffectedActivityData(part, betaAForm);
					//partLink.setDescription(arg0)
					partLink = (AffectedActivityData) PersistenceHelper.manager.save(partLink);
				}
			}
			
			result += " : " + betaAForm.getNumber();
			//System.out.println("@ updated EOBetaAForm =" + result);

			trx.commit();
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
			
		}
		return result;
      //##end updateEOBetaAForm%4C5A6945036B.body
   }

   //##begin deleteEOBetaAForm%4C5A694E035B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOBetaAForm%4C5A694E035B.doc

   public String deleteEOBetaAForm( HashMap form )
            throws WTException {
      //##begin deleteEOBetaAForm%4C5A694E035B.body preserve=yes
	   String result = CommonUtil.SUCC;
	   Transaction trx = new Transaction();
	   
	   try {
		   trx.start();
		  ReferenceFactory rf = new ReferenceFactory();
		  String sOid = (String) form.get("oid");
		  EOBetaAForm betaAForm = (EOBetaAForm) rf.getReference(sOid).getObject();

		  AffectedActivityData oldPartLink = this.getAFFDataLinkforBetaA( betaAForm.getPersistInfo().getObjectIdentifier().getId() );
		  if( oldPartLink != null ) PersistenceHelper.manager.delete(oldPartLink);
   
		  IncludedIn2 betaBLink = this.getIncludedIn2( betaAForm.getPersistInfo().getObjectIdentifier().getId() );
		  if( betaBLink != null ) PersistenceHelper.manager.delete(betaBLink);
		  
		  PersistenceHelper.manager.delete(betaAForm);
		  
	       trx.commit();

	   } catch(Exception e){
		   trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();
	   } finally {
		   trx = null;
	   }

      return result;
      //##end deleteEOBetaAForm%4C5A694E035B.body
   }

   //##begin viewEOBetaAForm%4C74D54D037A.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOBetaAForm%4C74D54D037A.doc

   public HashMap viewEOBetaAForm( HashMap form )
            throws WTException {
      //##begin viewEOBetaAForm%4C74D54D037A.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String sOid = (String) form.get("oid");
	   String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");
	   
	   EOBetaAForm betaaForm = null; 
	   if( sOid != null && !sOid.equals("") ) betaaForm = (EOBetaAForm) rf.getReference(sOid).getObject();
	   
	   EOAlphaForm alphaForm = null;
	   if( sEOAlphaFormOid != null && !sEOAlphaFormOid.equals("") ) alphaForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();
	   
	   AffectedActivityData partLink = null; 
	   if( betaaForm != null ) partLink = getAFFDataLinkforBetaA(betaaForm.getPersistInfo().getObjectIdentifier().getId()); 		
	   
	   HashMap aMap = new HashMap();
	   
	   aMap.put("betaaForm", betaaForm);
	   aMap.put("alphaForm", alphaForm);
	   
	   if( partLink != null ) aMap.put("partLink", partLink);
	   
       return aMap;
      //##end viewEOBetaAForm%4C74D54D037A.body
   }

   //##begin searchEOBetaAForm%4C5A695401C5.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOBetaAForm%4C5A695401C5.doc

   public HashMap searchEOBetaAForm( HashMap form )
            throws WTException {
      //##begin searchEOBetaAForm%4C5A695401C5.body preserve=yes
		QueryResult queryResult = null;
		
		ReferenceFactory rf = new ReferenceFactory();

		String sCmd = (String) form.get("cmd");
		String sPage = (String) form.get("page");
		String sTotalPage = (String) form.get("totalPage");
		String sSessionID = (String) form.get("sessionID");

		String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");
		
		String sTitle = (String) form.get("shTitle");						//EO Title
		String sEOATitle = (String) form.get("shEOATitle");						//EO A Title
		String sEOANumber = (String) form.get("shEOANumber");						//EO A Number
		
		String sFromMaintDate = (String) form.get("shFromMaintDate");		//bomMaintDate
		String sToMaintDate = (String) form.get("shToMaintDate");			//bomMaintDate
		
		String sBOMMaintStatus = (String) form.get("shBomMaintStatus");		//bomMaintStatus

        WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
        SessionHelper.manager.setAdministrator();
		
		EOAlphaForm alphaForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();

		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class alphaType = EOAlphaForm.class;
			Class linkType = IncludedIn2.class;
			Class betaType = EOBetaAForm.class;
			Class acLinkType = AffectedActivityData.class;
			Class partType = WTPart.class;
			
			int alphaIndex = query.appendClassList(alphaType, false);
			int linkIndex = query.appendClassList(linkType, false);
			int assyLinkIndex = query.appendClassList(acLinkType, false);
			int betaIndex = query.appendClassList(betaType, true);
			int partIndex = query.appendClassList(partType, true);

			query.appendJoin(linkIndex, IncludedIn2.CHANGE_ORDER2_ROLE, alphaIndex);
			query.appendJoin(linkIndex, IncludedIn2.CHANGE_ACTIVITY2_ROLE, betaIndex);
			query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGEABLE2_ROLE, partIndex);
			query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaIndex);

			query.appendWhere(new SearchCondition(alphaType, "iterationInfo.latest", "TRUE"), new int[] { alphaIndex });

			if (query.getConditionCount() > 0)	query.appendAnd();
			query.appendWhere(new SearchCondition(alphaType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, alphaForm.getPersistInfo().getObjectIdentifier().getId()), new int[] { alphaIndex });
			
			if (sEOANumber != null && !sEOANumber.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.NUMBER, SearchCondition.LIKE,  "%" + sEOANumber + "%"), new int[] { betaIndex });
			}
			
			if (sEOATitle != null && !sEOATitle.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.NAME, SearchCondition.LIKE,  "%" + sEOATitle + "%"), new int[] { betaIndex });
			}

			if (sBOMMaintStatus != null && !sBOMMaintStatus.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.BOM_MAINT_STATUE, SearchCondition.EQUAL, sBOMMaintStatus), new int[] { betaIndex });
			}
			
			//MaintDate From to Start
			if ( sFromMaintDate != null && !sFromMaintDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.BOM_MAINT_DATE, SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromMaintDate, "yyyy-MM-dd")), new int[]{betaIndex});
			}

			if ( sToMaintDate != null && !sToMaintDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.BOM_MAINT_DATE, SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToMaintDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{betaIndex});
			}
			//MaintDate From to End

			ClassAttribute classattribute = new ClassAttribute();
			OrderBy orderby = null;
			classattribute = new ClassAttribute(betaType, "thePersistInfo.createStamp");
			orderby = new OrderBy(classattribute, true);

			query.appendOrderBy(orderby, new int[] { betaIndex });
			//System.out.println("## REQUEST Query:" + query.toString());
		       
			queryResult = PersistenceHelper.manager.find(query);

		} catch (Exception e) {
			e.printStackTrace();
		}

		HashMap results = new HashMap();
		results.put("results", queryResult);
		
		SessionHelper.manager.setPrincipal(orgPrincipal.getName());

		return results;
      //##end searchEOBetaAForm%4C5A695401C5.body
   }

   //##begin createEOBetaBForm%4C5A696D029F.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOBetaBForm%4C5A696D029F.doc

   public String createEOBetaBForm( HashMap form )
            throws WTException {
      //##begin createEOBetaBForm%4C5A696D029F.body preserve=yes
		EOBetaBForm betaBForm = EOBetaBForm.newEOBetaBForm();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sName = (String) form.get("title");			
			String sUpgvcCopy = (String) form.get("upgvcCopy");		//UPGVC Copy Type Parameter
			String sReasonCode = (String) form.get("reasonCode");
			
			String sNewPartQty = (String) form.get("newPartQty");
			
			String sCheckCompatibility = (String) form.get("checkCompatibility");
			String sEPIRecommendDate = (String) form.get("epiRecommendDate");
			String sCreationStatus = (String) form.get("creationStatus");

			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

			if (sName != null && !sName.equals("")) betaBForm.setName(sName); // EO Name
			if (sReasonCode != null && !sReasonCode.equals("")) betaBForm.setReasonCode(sReasonCode); //
			if (sNewPartQty != null && !sNewPartQty.equals("")) betaBForm.setNewPartQty(sNewPartQty); //

			if (sCheckCompatibility != null && !sCheckCompatibility.equals("")) betaBForm.setCheckCompatibility(sCheckCompatibility); //
			if (sEPIRecommendDate != null && !sEPIRecommendDate.equals("") ) betaBForm.setEpiRecommendDate( CommonUtil.formatString2Timestamp( sEPIRecommendDate, "yyyy-MM-dd") ); //
			if (sCreationStatus != null && !sCreationStatus.equals("")) betaBForm.setCreationStatus(sCreationStatus); //
			
			String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");
			EOAlphaForm alForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();

			//System.out.println("=================== sUpgvcCopy is ON !");
			
			if (sUpgvcCopy != null && sUpgvcCopy.equals("on")) {
				String sNewAssyOid = (String) form.get("newAssyOid");
				
				//System.out.println("newAssyOid = " + sNewAssyOid);
				
				WTPart sNewAssy = null;
				if (sNewAssyOid != null && !sNewAssyOid.equals("")) {
					sNewAssy = (WTPart) rf.getReference(sNewAssyOid).getObject();
				} else {
					throw new WTException("Error : New Assy is NULL!");
				}

				// assy source
				String sSourceAssyOid = (String) form.get("sourceAssyOid");
				
				//System.out.println("sourceAssyOid = " + sSourceAssyOid);
				
				WTPart sSourceAssy = null;
				if (sSourceAssyOid != null && !sSourceAssyOid.equals("")) {
					sSourceAssy = (WTPart) rf.getReference(sSourceAssyOid).getObject();
				} else {
					throw new WTException("Error : Source Assy is NULL!");
				}
				
				QueryResult queryResult = this.getPartList(sSourceAssy);
				
				//System.out.println("queryResult.size() " + queryResult.size());
				
				if ( queryResult == null || (queryResult.size() < 0) ) {
					System.out.println("result is null!!");
					
				} else if ( queryResult.size() > 0) {
					for (int i = 0; i < queryResult.size(); i++) {
						Persistable[] objs = (Persistable[])queryResult.nextElement();
						
						//System.out.println(" i = " + i + " ,,,, " + objs);
						
						WTPartUsageLink usageLink = null;
						WTPartMaster partMaster = null;
						WTPart	subPart = null;
						
						usageLink = (WTPartUsageLink)objs[0];
						partMaster = (WTPartMaster)objs[1];
						
						subPart = findPart(partMaster.getNumber());
							
						HashMap subMap = new HashMap();
						
						subMap.put("upgvcCopy", "");
						
						subMap.put("title", "");
						subMap.put("reasonCode", "");
						subMap.put("newPartQty", "");
						subMap.put("checkCompatibility", "");
						subMap.put("epiRecommendDate", "");
						subMap.put("creationStatus", "");
						
						if (sName != null && !sName.equals("")) subMap.put("title", sName);
						if (sReasonCode != null && !sReasonCode.equals("")) subMap.put("reasonCode", sReasonCode);
						if (sNewPartQty != null && !sNewPartQty.equals("")) subMap.put("newPartQty", sNewPartQty);
						if (sCheckCompatibility != null && !sCheckCompatibility.equals("")) subMap.put("checkCompatibility", sCheckCompatibility);
						if (sEPIRecommendDate != null && !sEPIRecommendDate.equals("") ) subMap.put("epiRecommendDate", sEPIRecommendDate);
						if (sCreationStatus != null && !sCreationStatus.equals("")) subMap.put("creationStatus", sCreationStatus);
						
						//System.out.println("sNewAssyOid = " + sNewAssyOid);
						//System.out.println("subPart.toString() = " + subPart.toString());
						//System.out.println("sEOAlphaFormOid = " + sEOAlphaFormOid);
						
//						if (sOldPartQty != null && !sOldPartQty.equals("")) subMap.put("oldPartQty", sOldPartQty);
//						else subMap.put("oldPartQty", "");

						subMap.put("newAssyOid", sNewAssyOid);
						subMap.put("newPartOid", subPart.toString());
						subMap.put("eoAlphaFormOid", sEOAlphaFormOid);
						
						this.createEOBetaBForm(subMap);
					}
				}
				
			} else {
				//System.out.println("sUpgvcCopy is OFF !");

				// set Number
				String eoNumber = alForm.getNumber() + "B";
				eoNumber += CreateNumberRuleUtil.getEOEulFormNo(alForm,  eoNumber);
				betaBForm.setNumber(eoNumber);

				// save content
				String liftCycle = "LC_PSK_ECM";

				// Folder && LifeCycle Setting
				Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
				FolderHelper.assignLocation((FolderEntry) betaBForm, folder);
				PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
				WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

				betaBForm.setContainer(product);
				LifeCycleHelper.setLifeCycle(betaBForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

				betaBForm = (EOBetaBForm) PersistenceHelper.manager.save(betaBForm);

				//eoAlpha link eoBetaB
				IncludedIn2 eoLink = IncludedIn2.newIncludedIn2(alForm, betaBForm);
				eoLink = (IncludedIn2) PersistenceHelper.manager.save(eoLink);

				//betaB's Part <-> Part Link
				// assy new
				String sPartOid = (String) form.get("newAssyOid");
				WTPart part = null;
				if (sPartOid != null && !sPartOid.equals("")) part = (WTPart) rf.getReference(sPartOid).getObject();

				AffectedActivityData partLink = null;
				if (part != null) {
					partLink = AffectedActivityData.newAffectedActivityData(part, betaBForm);
					partLink.setDescription("partOld");
					partLink = (AffectedActivityData) PersistenceHelper.manager.save(partLink);
				}

				// assy source
				sPartOid = (String) form.get("sourceAssyOid");
				part = null;
				if (sPartOid != null && !sPartOid.equals("")) part = (WTPart) rf.getReference(sPartOid).getObject();

				if (part != null) {
					partLink = AffectedActivityData.newAffectedActivityData(part, betaBForm);
					partLink.setDescription("assySource");
					partLink = (AffectedActivityData) PersistenceHelper.manager.save(partLink);
				}

				// part new
				sPartOid = (String) form.get("newPartOid");
				part = null;
				if (sPartOid != null && !sPartOid.equals("")) part = (WTPart) rf.getReference(sPartOid).getObject();

				ChangeRecord2 part2Link = null;
				if (part != null) {
					part2Link = ChangeRecord2.newChangeRecord2(part, betaBForm);
					part2Link.setDescription("assyNew");
					part2Link = (ChangeRecord2) PersistenceHelper.manager.save(part2Link);
				}

				// part old
				sPartOid = (String) form.get("oldPartOid");
				part = null;
				if (sPartOid != null && !sPartOid.equals("")) part = (WTPart) rf.getReference(sPartOid).getObject();

				if (part != null) {
					part2Link = ChangeRecord2.newChangeRecord2(part, betaBForm);
					part2Link.setDescription("partNew");
					part2Link = (ChangeRecord2) PersistenceHelper.manager.save(part2Link);
				}

				result += " : " + betaBForm.getNumber();
				//System.out.println("@ created EOBetaBForm =" + result);
			}

			trx.commit();
			
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			
			if( !CommonUtil.checkNull( (String)form.get("CRE") ).equals("Y") ) {
				throw new WTException(e);
			}

		} finally {
			trx = null;

		}
		return result;
      //##end createEOBetaBForm%4C5A696D029F.body
   }

   //##begin updateEOBetaBForm%4C5A69740280.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOBetaBForm%4C5A69740280.doc

   public String updateEOBetaBForm( HashMap form )
            throws WTException {
      //##begin updateEOBetaBForm%4C5A69740280.body preserve=yes
		ReferenceFactory rf = new ReferenceFactory();
		String sOid = (String) form.get("oid");
		EOBetaBForm betaBForm = (EOBetaBForm) rf.getReference(sOid).getObject();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sNewPartQty = (String) form.get("newPartQty");

			String sOldPartType = (String) form.get("oldPartType");
			String sOldPartQty = (String) form.get("oldPartQty");
			
			String sCheckCompatibility = (String) form.get("checkCompatibility");
			String sEPIRecommendDate = (String) form.get("epiRecommendDate");
			String sCreationStatus = (String) form.get("creationStatus");

			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

			if (sOldPartType != null) betaBForm.setOldPartType(sOldPartType); //
			
			if (sCheckCompatibility != null) betaBForm.setCheckCompatibility(sCheckCompatibility); //
			if (sEPIRecommendDate != null && !sEPIRecommendDate.equals("") ) betaBForm.setEpiRecommendDate( CommonUtil.formatString2Timestamp( sEPIRecommendDate, "yyyy-MM-dd") ); //
			if (sCreationStatus != null) betaBForm.setCreationStatus(sCreationStatus); //

			betaBForm = (EOBetaBForm) PersistenceHelper.manager.save(betaBForm);

			/**
			 * UPDATE
			 *  betaA's Part <-> Part Link
			 */
			// 1. get AffectedActivityData
			HashMap partMap = getAFFDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 
			AffectedActivityData partOldLink = null;
			if( partMap != null ) {
				try {
					partOldLink = (AffectedActivityData)partMap.get("partOld");
				}catch(Exception e){
					throw new WTException(e);
				}
			}
			
			WTPart partOld = null;
			if( partOldLink != null ) partOld = (WTPart)partOldLink.getChangeable2();
			
			AffectedActivityData assySourceLink = null;
			if( partMap != null ) {
				try {
					assySourceLink = (AffectedActivityData)partMap.get("assySource");
				}catch(Exception e){
					throw new WTException(e);
				}
			}
			
			WTPart assySource = null;
			if( assySourceLink != null ) assySource = (WTPart)assySourceLink.getChangeable2();
			
			// 2. update AffectedActivityData
			String sPartOid = (String) form.get("newAssyOid");
			WTPart getPartOld = null;
			if( sPartOid != null && !sPartOid.equals("") ) getPartOld = (WTPart)rf.getReference(sPartOid).getObject();
			
			if( partOld != null 
				&& getPartOld != null 
				&& (getPartOld.getPersistInfo().getObjectIdentifier().getId() == partOld.getPersistInfo().getObjectIdentifier().getId() ) ) {
				// is Same
			} else {
				if( partOldLink != null ) PersistenceHelper.manager.delete(partOldLink);
					
				if( getPartOld != null ) {
					partOldLink = AffectedActivityData.newAffectedActivityData(getPartOld, betaBForm);
					partOldLink.setDescription("partOld");
					partOldLink = (AffectedActivityData) PersistenceHelper.manager.save(partOldLink);
				}
			}
			
			sPartOid = (String) form.get("assySourceOid");
			WTPart getAssySource = null;
			if( sPartOid != null && !sPartOid.equals("") ) getAssySource = (WTPart) rf.getReference(sPartOid).getObject();
			
			if( assySource != null 
				&& getAssySource != null 
				&& (getAssySource.getPersistInfo().getObjectIdentifier().getId() == assySource.getPersistInfo().getObjectIdentifier().getId() ) ) {
				// is Same
			} else {
				if( assySourceLink != null ) PersistenceHelper.manager.delete(assySourceLink);
					
				if( getAssySource != null ) {
					assySourceLink = AffectedActivityData.newAffectedActivityData(getAssySource, betaBForm);
					assySourceLink.setDescription("assySource");
					assySourceLink = (AffectedActivityData) PersistenceHelper.manager.save(assySourceLink);
				}
			}
			
			// 3. get ChangeRecord2
			HashMap partMap2 = getChangeDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 
			ChangeRecord2 assyNewLink = null;
			if( partMap2 != null ) {
				try {
					assyNewLink = (ChangeRecord2)partMap2.get("assyNew");
				}catch(Exception e){
					throw new WTException(e);
				}
			}
			
			WTPart assyNew = null;
			if( assyNewLink != null ) assyNew = (WTPart)assyNewLink.getChangeable2();

			ChangeRecord2 partNewLink = null;
			if( partMap2 != null ) {
				try {
					partNewLink = (ChangeRecord2)partMap2.get("partNew");
				}catch(Exception e){
					throw new WTException(e);
				}
			}
			
			WTPart partNew = null;
			if( partNewLink != null ) partNew = (WTPart)partNewLink.getChangeable2();
			
			// 4. update ChangeRecord2
			sPartOid = (String) form.get("newPartOid");
			WTPart getAssyNew = null;
			if( sPartOid != null && !sPartOid.equals("") ) getAssyNew = (WTPart)rf.getReference(sPartOid).getObject();
			
			if( assyNew != null 
				&& assyNew != null 
				&& (getAssyNew.getPersistInfo().getObjectIdentifier().getId() == assyNew.getPersistInfo().getObjectIdentifier().getId() ) ) {
				// is Same
			} else {
				if( assyNewLink != null ) PersistenceHelper.manager.delete(assyNewLink);
					
				if( getAssyNew != null ) {
					assyNewLink = ChangeRecord2.newChangeRecord2(getAssyNew, betaBForm);
					assyNewLink.setDescription("assyNew");
					assyNewLink = (ChangeRecord2) PersistenceHelper.manager.save(assyNewLink);
				}
			}
			
			sPartOid = (String) form.get("oldPartOid");
			WTPart getPartNew = null;
			if( sPartOid != null && !sPartOid.equals("") ) getPartNew = (WTPart)rf.getReference(sPartOid).getObject();
			
			if( partNew != null 
				&& getPartNew != null 
				&& (getPartNew.getPersistInfo().getObjectIdentifier().getId() == partNew.getPersistInfo().getObjectIdentifier().getId() ) ) {
				// is Same
			} else {
				if( partNewLink != null ) PersistenceHelper.manager.delete(partNewLink);
					
				if( getPartNew != null ) {
					partNewLink = ChangeRecord2.newChangeRecord2(getPartNew, betaBForm);
					partNewLink.setDescription("partNew");
					partNewLink = (ChangeRecord2) PersistenceHelper.manager.save(partNewLink);
				}
			}
			
			result += " : " + betaBForm.getNumber();
			//System.out.println("@ updated EOBetaBForm =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end updateEOBetaBForm%4C5A69740280.body
   }

   //##begin deleteEOBetaBForm%4C5A697D006D.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOBetaBForm%4C5A697D006D.doc

   public String deleteEOBetaBForm( HashMap form )
            throws WTException {
      //##begin deleteEOBetaBForm%4C5A697D006D.body preserve=yes
	   
	   String result = CommonUtil.SUCC;
	   Transaction trx = new Transaction();
	   
	   try {
		   trx.start();
		   ReferenceFactory rf = new ReferenceFactory();
		   String sOid = (String) form.get("oid");
		   
		   EOBetaBForm betaBForm = (EOBetaBForm) rf.getReference(sOid).getObject();
		   
		   HashMap partMap = this.getAFFDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 

		   if( partMap != null ) {
		       AffectedActivityData partOldLink = (AffectedActivityData)partMap.get("partOld");
		       if( partOldLink != null ) PersistenceHelper.manager.delete(partOldLink);
		       
		       AffectedActivityData assySourceLink = (AffectedActivityData)partMap.get("assySource");
		       if( assySourceLink != null ) PersistenceHelper.manager.delete(assySourceLink);
		   }

		   // 3. get ChangeRecord2
		   HashMap partMap2 = this.getChangeDataLinkforBetaB( betaBForm.getPersistInfo().getObjectIdentifier().getId() ); 

		   if( partMap2 != null ) {
		       ChangeRecord2 assyNewLink = (ChangeRecord2)partMap2.get("assyNew");
		       if( assyNewLink != null ) PersistenceHelper.manager.delete(assyNewLink);
		       
		       ChangeRecord2 partNewLink = (ChangeRecord2)partMap2.get("partNew");
		       if( partNewLink != null ) PersistenceHelper.manager.delete(partNewLink);
		   }

		   IncludedIn2 betaBLink = this.getIncludedIn2( betaBForm.getPersistInfo().getObjectIdentifier().getId() );
		   if( betaBLink != null ) PersistenceHelper.manager.delete(betaBLink);

		   PersistenceHelper.manager.delete(betaBForm);

		   trx.commit();

	   } catch(Exception e){
		   trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();
	   } finally {
		   trx = null;
	   }
      return result;
      //##end deleteEOBetaBForm%4C5A697D006D.body
   }

   //##begin viewEOBetaBForm%4C74D55700CB.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOBetaBForm%4C74D55700CB.doc

   public HashMap viewEOBetaBForm( HashMap form )
            throws WTException {
      //##begin viewEOBetaBForm%4C74D55700CB.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String sOid = (String) form.get("oid");
	   String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");
	   HashMap bMap = new HashMap();
	   
	   try {
		   EOBetaBForm betabForm = null;
		   if( sOid != null && !sOid.equals("") ) betabForm = (EOBetaBForm) rf.getReference(sOid).getObject();
	
		   EOAlphaForm alphaForm = null;
		   if( sEOAlphaFormOid != null && !sEOAlphaFormOid.equals("") ) alphaForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();
		   
		   // 1. get ChangeRecord2
			HashMap partMap = null;
			if( betabForm != null) partMap = this.getAFFDataLinkforBetaB( betabForm.getPersistInfo().getObjectIdentifier().getId() ); 
			AffectedActivityData partOldLink = null;
			AffectedActivityData assySourceLink = null;
			if( partMap != null ) {
				try {
					partOldLink = (AffectedActivityData)partMap.get("partOld");
					assySourceLink = (AffectedActivityData)partMap.get("assySource");
				}catch(Exception e){
					e.printStackTrace();
					throw new WTException(e);
				}
			}
	
			// 3. get ChangeRecord2
			HashMap partMap2 = null;
			if( betabForm != null) partMap2 = this.getChangeDataLinkforBetaB( betabForm.getPersistInfo().getObjectIdentifier().getId() );
			ChangeRecord2 assyNewLink = null;
			Vector partNewLink = null;
			if( partMap2 != null ) {
				try {
					assyNewLink = (ChangeRecord2)partMap2.get("assyNew");
					ChangeRecord2 tempLink = (ChangeRecord2)partMap2.get("partNew"); 
					if( tempLink != null && partOldLink != null) {
						partNewLink = this.getSubPart( (WTPart)tempLink.getChangeable2(), (WTPart)partOldLink.getChangeable2() );
					}
				}catch(Exception e){
					e.printStackTrace();
					throw new WTException(e);
				}
			}
		   
		   bMap.put("betabForm", betabForm);
		   bMap.put("alphaForm", alphaForm);
		   
		   if( partOldLink != null ) bMap.put("newAssy", partOldLink);
		   if( assySourceLink != null ) bMap.put("sourceAssy", assySourceLink);
		   
		   if( assyNewLink != null ) bMap.put("newPart", assyNewLink);
		   if( partNewLink != null ) bMap.put("oldPart", partNewLink);
		   
	   } catch(Exception e){
	       e.printStackTrace();
	   } 
	   
       return bMap;
      //##end viewEOBetaBForm%4C74D55700CB.body
   }

   //##begin searchEOBetaBForm%4C5A698B0186.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOBetaBForm%4C5A698B0186.doc

   public HashMap searchEOBetaBForm( HashMap form )
            throws WTException {
      //##begin searchEOBetaBForm%4C5A698B0186.body preserve=yes

	   QueryResult queryResult = null;
	   ReferenceFactory rf = new ReferenceFactory();

	   String sCmd = (String) form.get("cmd");
	   String sPage = (String) form.get("page");
	   String sTotalPage = (String) form.get("totalPage");
	   String sSessionID = (String) form.get("sessionID");

	   String sEOAlphaFormOid = (String) form.get("eoAlphaFormOid");

	   String sTitle = (String) form.get("shEOBTitle");
	   String sEOBNumber = (String) form.get("shEOBNumber");

	   String sReasonCode = (String) form.get("shReasonCode");
	   String sCheckCompatibility = (String) form.get("shCheckCompatibility");
	   String sCreationStatus = (String) form.get("shCreationStatus");
	   String sFromEpiDate = (String) form.get("shFromEpiDate");
	   String sToEpiDate = (String) form.get("shToEpiDate");

	   WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
	   SessionHelper.manager.setAdministrator();

	   EOAlphaForm alphaForm = (EOAlphaForm) rf.getReference(sEOAlphaFormOid).getObject();

	   try {
	       QuerySpec query = new QuerySpec();
	       query.setAdvancedQueryEnabled(true);

	       if (query.getConditionCount() > 0) query.appendAnd();

	       Class alphaType = EOAlphaForm.class;
	       Class linkType = IncludedIn2.class;
	       Class betaType = EOBetaBForm.class;
	       Class acLinkType = AffectedActivityData.class;
	       Class partType = WTPart.class;
	       
	       int alphaIndex = query.appendClassList(alphaType, false);
	       int linkIndex = query.appendClassList(linkType, false);
	       int assyLinkIndex = query.appendClassList(acLinkType, false);
	       int betaIndex = query.appendClassList(betaType, true);
	       int partIndex = query.appendClassList(partType, true);

	       query.appendJoin(linkIndex, IncludedIn2.CHANGE_ORDER2_ROLE, alphaIndex);
	       query.appendJoin(linkIndex, IncludedIn2.CHANGE_ACTIVITY2_ROLE, betaIndex);
	       query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGEABLE2_ROLE, partIndex);
	       query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaIndex);
	       
	       //query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaIndex);
	       //query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGEABLE2_ROLE, betaIndex);

	       query.appendWhere(new SearchCondition(alphaType, "iterationInfo.latest", "TRUE"), new int[] { alphaIndex });

	       if (query.getConditionCount() > 0) query.appendAnd();
	       
	       query.appendWhere(new SearchCondition(alphaType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, alphaForm.getPersistInfo().getObjectIdentifier().getId()), new int[] { alphaIndex });
	       
	       if (query.getConditionCount() > 0) query.appendAnd();
	       query.appendWhere(new SearchCondition(acLinkType, AffectedActivityData.DESCRIPTION, SearchCondition.EQUAL, "partOld"), new int[] { assyLinkIndex });

	       if (sEOBNumber != null && !sEOBNumber.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.NUMBER, SearchCondition.LIKE, "%" + sEOBNumber + "%"), new int[] { betaIndex });
	       }
	       
	       if (sTitle != null && !sTitle.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.NAME, SearchCondition.LIKE, "%" + sTitle + "%"), new int[] { betaIndex });
	       }

	       if (sReasonCode != null && !sReasonCode.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.REASON_CODE, SearchCondition.EQUAL, sReasonCode), new int[] { betaIndex });
	       }

	       if (sCheckCompatibility != null && !sCheckCompatibility.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.CHECK_COMPATIBILITY, SearchCondition.EQUAL, sCheckCompatibility), new int[] { betaIndex });
	       }

	       if (sCreationStatus != null && !sCreationStatus.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.CREATION_STATUS, SearchCondition.EQUAL, sCreationStatus), new int[] { betaIndex });
	       }

	       //EpiDate from to Start
	       if (sFromEpiDate != null && !sFromEpiDate.equals("")) {
	           if (query.getConditionCount() > 0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.EPI_RECOMMEND_DATE, SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromEpiDate, "yyyy-MM-dd")), new int[]{betaIndex});
	       }
	       
	       if ( sToEpiDate != null && !sToEpiDate.equals("") ) {
	           if (query.getConditionCount()>0) query.appendAnd();
	           query.appendWhere(new SearchCondition(betaType, EOBetaBForm.EPI_RECOMMEND_DATE, SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToEpiDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{betaIndex});
	       }
	       //EpiDate from to End
	       
	       ClassAttribute classattribute = new ClassAttribute();
	       OrderBy orderby = null;
	       classattribute = new ClassAttribute(betaType, "thePersistInfo.createStamp");
	       orderby = new OrderBy(classattribute, true);

	       query.appendOrderBy(orderby, new int[] { betaIndex });

	       //System.out.println("## REQUEST Query:" + query.toString());

	       queryResult = PersistenceHelper.manager.find(query);

	   } catch (Exception e) {
	       e.printStackTrace();
	   }

	   HashMap results = new HashMap();
	   results.put("results", queryResult);
	   
	   SessionHelper.manager.setPrincipal(orgPrincipal.getName());

	   return results;
      //##end searchEOBetaBForm%4C5A698B0186.body
   }

   //##begin user.operations preserve=yes
	public Vector getABFormLink(long Oid) throws WTException {
		Vector<IncludedIn2> result = new Vector<IncludedIn2>();
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();
			
			Class linkEOAType = IncludedIn2.class;
			int linkEOAIndex = query.appendClassList(linkEOAType, true);
			Class EOType = EOAlphaForm.class;
			int classEOIndex = query.appendClassList(EOType, false);

			query.appendJoin(linkEOAIndex, IncludedIn2.CHANGE_ORDER2_ROLE, classEOIndex);

			query.appendWhere(new SearchCondition(EOType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { classEOIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			
			Object[] obj = null; 
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					
					System.out.println("getABFormLink : " +  obj );
					result.add( (IncludedIn2)obj[0] );
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return result;
	}
	
	public AddressedBy2 getAddressedBy2(long Oid)  throws WTException  {
		AddressedBy2 link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = AddressedBy2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class aType = EOAlphaForm.class;
			int aIndex = query.appendClassList(aType, false);

			query.appendJoin(linkIndex, AddressedBy2.CHANGE_ORDER2_ROLE, aIndex);

			query.appendWhere(new SearchCondition(aType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { aIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			
			Object[] obj = null; 
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (AddressedBy2)obj[0];
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return link;
	}
	
	public AffectedActivityData getAFFDataLinkforBetaA(long Oid) throws WTException  {
		AffectedActivityData link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = AffectedActivityData.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class betaAType = EOBetaAForm.class;
			int betaAIndex = query.appendClassList(betaAType, false);

			query.appendJoin(linkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaAIndex);

			query.appendWhere(new SearchCondition(betaAType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { betaAIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (AffectedActivityData)obj[0];
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return link;
	}
	
	public HashMap getAFFDataLinkforBetaB(long Oid) throws WTException {
		HashMap results = new HashMap();
		AffectedActivityData link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = AffectedActivityData.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class betaBType = EOBetaBForm.class;
			int betaBIndex = query.appendClassList(betaBType, false);

			query.appendJoin(linkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaBIndex);

			query.appendWhere(new SearchCondition(betaBType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { betaBIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (AffectedActivityData)obj[0];
					
					results.put(link.getDescription(), link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return results;
	}
	
	public HashMap getChangeDataLinkforBetaB(long Oid) throws WTException {
		HashMap results = new HashMap();
		ChangeRecord2 link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = ChangeRecord2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class betaBType = EOBetaBForm.class;
			int betaBIndex = query.appendClassList(betaBType, false);

			query.appendJoin(linkIndex, ChangeRecord2.CHANGE_ACTIVITY2_ROLE, betaBIndex);

			query.appendWhere(new SearchCondition(betaBType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { betaBIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (ChangeRecord2)obj[0];
					
					results.put(link.getDescription(), link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return results;
	}
	
	public Vector getSubPart(WTPart part, WTPart upPart) throws WTException {
		Vector rtnList = new Vector();
		QuerySpec query = new QuerySpec();
		query.setAdvancedQueryEnabled(true);
		
		try {
			if (query.getConditionCount() > 0) query.appendAnd();
			
			ReferenceFactory rf = new ReferenceFactory();
	
			Class classType = WTPart.class;
			int pskChangeIndex = query.appendClassList(classType, false);
			
			Class linkType = WTPartUsageLink.class;
			int PskChangeLinkIndex = query.appendClassList(linkType, true);
			
			Class masterType = WTPartMaster.class;
			int pskMasterIndex = query.appendClassList(masterType, true);
	
			query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_AOBJECT_ROLE, pskChangeIndex);
			query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_BOBJECT_ROLE, pskMasterIndex);
			
			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, upPart.getPersistInfo().getObjectIdentifier().getId() ), new int[] { pskChangeIndex });
			
			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(masterType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, part.getMaster().getPersistInfo().getObjectIdentifier().getId() ), new int[] { pskMasterIndex });
	
			ClassAttribute classattribute = new ClassAttribute(WTPartMaster.class, WTPartMaster.NUMBER);
			OrderBy orderby = new OrderBy(classattribute, true);	
			query.appendOrderBy(orderby, pskMasterIndex );
	
			//System.out.println("## REQUEST Query:" + query.toString());
	
			QueryResult queryResult = PersistenceHelper.manager.find(query);
	
			if ( queryResult == null || (queryResult.size() < 0) ) {
				System.out.println("result is null!!");
			} else if ( queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					Persistable[] objs = (Persistable[])queryResult.nextElement();
					
					for (int j = 0; j < objs.length ; j++) {						
						rtnList.addElement(objs);
						//System.out.println(" index = " + j + " ,,,, " + objs[j]);
					}
				}
			}
		} catch( Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		
		return rtnList;
	}

	public IncludedIn2 getIncludedIn2(long Oid) throws Exception {
		IncludedIn2 link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = IncludedIn2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class abType = EOBetaBForm.class;
			int aIndex = query.appendClassList(abType, false);

			query.appendJoin(linkIndex, IncludedIn2.CHANGE_ORDER2_ROLE, aIndex);

			query.appendWhere(new SearchCondition(abType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { aIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			
			Object[] obj = null; 
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (IncludedIn2)obj[0];
				}
			}
		} catch( Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return link;
	}

	public boolean existDuplicateEoType(long ecrOid, String eoType) throws Exception {
		boolean ret = false;

		QuerySpec query = new QuerySpec();
		query.setAdvancedQueryEnabled(true);
		try {

			if (query.getConditionCount() > 0) query.appendAnd();
	
			Class linkType = AddressedBy2.class;
			int linkIndex = query.appendClassList(linkType, false);
			
			Class aType = ECRequest.class;
			int aIndex = query.appendClassList(aType, false);
			
			Class bType = EOAlphaForm.class;
			int bIndex = query.appendClassList(bType, true);
	
			query.appendJoin(linkIndex, AddressedBy2.CHANGE_REQUEST2_ROLE, aIndex);
			query.appendJoin(linkIndex, AddressedBy2.CHANGE_ORDER2_ROLE, bIndex);
	
			query.appendWhere(new SearchCondition(aType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, ecrOid), new int[] { aIndex });
			query.appendAnd();
			query.appendWhere(new SearchCondition(bType, EOAlphaForm.EO_TYPE, SearchCondition.EQUAL, eoType), new int[] { bIndex });
			query.appendAnd();
			query.appendWhere(new SearchCondition(bType, "state.state", SearchCondition.NOT_EQUAL, "REJECTED"), new int[] { bIndex });
	
			QueryResult queryResult = PersistenceHelper.manager.find(query);
	
			System.out.println("@existDuplicateEoType=" + query);
			
			System.out.println("queryResult=" + queryResult);
	
			if (queryResult == null) {
				ret = false;
	
			} else if (queryResult.size() > 0) {
				ret = true;
			}
		} catch( Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		return ret;
	}
	
	public QueryResult getPartList(WTPart part) throws WTException{
		QuerySpec query = new QuerySpec();
		query.setAdvancedQueryEnabled(true);
		QueryResult queryResult = null;
		
		try {
			if (query.getConditionCount() > 0) query.appendAnd();
			
			Class classType = WTPart.class;
			Class linkType = WTPartUsageLink.class;
			Class masterType = WTPartMaster.class;
			int pskChangeIndex = query.appendClassList(classType, false);
			int PskChangeLinkIndex = query.appendClassList(linkType, true);
			int pskMasterIndex = query.appendClassList(masterType, true);
			
			query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_AOBJECT_ROLE, pskChangeIndex);
			query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_BOBJECT_ROLE, pskMasterIndex);
			
			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, part.getPersistInfo().getObjectIdentifier().getId() ), new int[] { pskChangeIndex });
	
			ClassAttribute classattribute = new ClassAttribute(WTPartMaster.class, WTPartMaster.NUMBER);
			OrderBy orderby = new OrderBy(classattribute, true);	
			query.appendOrderBy(orderby, pskMasterIndex );
			
			//System.out.println("## getPartList :" + query.toString());
			queryResult = PersistenceHelper.manager.find(query);
			
		} catch( Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		
		return queryResult;
	}

	public WTPart findPart(String number) throws WTException {
		WTPart part = null;
		
		try {
			QuerySpec spec = new QuerySpec(WTPart.class);
			spec.appendWhere(new SearchCondition(WTPart.class, "master>number", SearchCondition.EQUAL, number));
			LatestConfigSpec latestCSpec = new LatestConfigSpec();
			spec = latestCSpec.appendSearchCriteria(spec);
	
			QueryResult result = PersistenceHelper.manager.find(spec);
	
			Hashtable hashtable = null;
	
			if (result != null && result.size() > 0) {
				hashtable = new Hashtable();
				while (result.hasMoreElements()) {
					WTPart one = (WTPart) result.nextElement();
					hashtable.put(VersionControlHelper.getVersionIdentifier(one).getValue(), one);
				}
	
				// Get Latest
				String hashKey = this.getLatestVersion(hashtable);
				part = (WTPart) hashtable.get(hashKey);
			}
		} catch( Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		
		return part;
	}

	private String getLatestVersion(Hashtable versions) {
		Enumeration dKey = versions.keys();
		Vector v = new Vector();
		while (dKey.hasMoreElements()) {
			String dStr = (String) dKey.nextElement();
			v.add(dStr);
		}
		Collections.sort(v);

		return (String) v.get(v.size() - 1);
	}
   //##end user.operations
}
