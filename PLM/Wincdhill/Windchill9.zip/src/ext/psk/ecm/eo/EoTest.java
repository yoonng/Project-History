package ext.psk.ecm.eo;

import java.util.Enumeration;
import java.util.HashMap;

import wt.fc.PagingQueryResult;
import wt.fc.WTObject;

public class EoTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			HashMap hash = new HashMap();
			
			// 갑지 테스트
/*			
			hash.put("title", "Create Test EOAlphaForm");
			hash.put("number", "EO000001");
	
			hash.put("changeReasonA", "test changeReasonA");
			hash.put("changeReasonB", "test changeReasonB");
			hash.put("department", "test department");
			hash.put("stockMgt", "test stockMgt");
			//hash.put("applyDate", "2010-0101");
			hash.put("eoContent", "test eoContent");
			hash.put("eoType", "test eoType");
			hash.put("needEVR", "test needEVR");
			hash.put("evrTitle", "test evrTitle");
			hash.put("evrTestList", "test evrTestList");
			hash.put("evrCreator", "test evrCreator");
			
			String alphaFormOid = EOHelper.service.createEOAlphaForm(hash);
		
			String alphaFormOid = "ext.psk.ecm.eo.EOAlphaForm:15641";
			//String alphaFormOid = "ext.psk.ecm.eo.EOAlphsForm:15579";
			
			// 을A 테스트
			
			hash.put("eoType", "test EOBetaAForm eoType");
			hash.put("partNumber", "BetaA001");
			hash.put("partName", "test sPartName");
			hash.put("partModule", "test sPartModule");
			hash.put("partSerial", "test sPartSerial");
			
			hash.put("partSuffix", "test sPartSuffix");
			hash.put("partProcess", "test sPartProcess");
			hash.put("partMass", "test sPartMass");
			hash.put("partMaterial", "test sPartMaterial");
			hash.put("partModel", "test sPartModel");
			
			hash.put("partSpec", "test sPartSpec");
			hash.put("partUnit", "test sPartUnit");
			hash.put("temporaryCAD", "test sTemporaryCAD");
			//hash.put("bomMaintDate", "test sBOMMaintDate");
			hash.put("bomMaintStatus", "test sBOMMaintStatus");
			
			hash.put("eoAlphaFormOid", alphaFormOid);
			
			String betaAFormOid = EOHelper.service.createEOBetaAForm(hash);
*/	
			String alphaFormOid = "ext.psk.ecm.eo.EOAlphaForm:15641";
			
			// 을B 테스트			
	        hash.put("eoType", "test EOBetaBForm eoType");
	        hash.put("sequence", "test sSequence");
	        hash.put("reasonCode", "test sReasonCode");
	        hash.put("checkCompatibility", "test sCheckCompatibility");
	        //hash.put("epiRecommendDate", "test sEPIRecommendDate");	        
	        hash.put("creationStatus", "test sCreationStatus");
	        
	        hash.put("newPartNumber", "test sNewPartNumber");
	        hash.put("newPartRevision", "test sNewPartRevision");
	        hash.put("newPartQuantity", "test sNewPartQuantity");
	        
	        hash.put("oldPartType", "test sOldPartType");
	        hash.put("oldPartNumber", "test sOldPartNumber");
	        hash.put("oldPartRevision", "test sOldPartRevision");
	        hash.put("oldPartQuantity", "test sOldPartQuantity");
	        
			hash.put("eoAlphaFormOid", alphaFormOid);
//			hash.put("eoBetaAFormOid", betaAFormOid);
			
			EOHelper.service.createEOBetaBForm(hash);

			hash.put("title", "test");
			hash.put("number", "000");
			hash.put("page", "1");
			hash.put("sessionID", "1");
			
			HashMap result = EOHelper.service.searchEOAlphaForm(hash);
			
			PagingQueryResult pagingResult = (PagingQueryResult)result.get("results");
			Enumeration enums = pagingResult.getEnumeration();
			while( enums.hasMoreElements() ){
				WTObject obj = (WTObject) enums.nextElement();
				System.out.println(obj.toString());
			}
  
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
