// Generated EOBetaAForm%4C5767E0001F: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.change2.WTChangeActivity2;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EOBetaAForm%4C5767E0001F.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newEOBetaAForm</code> static factory method(s), not the
 * <code>EOBetaAForm</code> constructor, to construct instances of this
 * class.  Instances must be constructed using the static factory(s), in
 * order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end EOBetaAForm%4C5767E0001F.doc

public class EOBetaAForm extends WTChangeActivity2 implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.eo.eoResource";
   private static final String CLASSNAME = EOBetaAForm.class.getName();

   //##begin BOM_MAINT_DATE%BOM_MAINT_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end BOM_MAINT_DATE%BOM_MAINT_DATE.doc
   public static final String BOM_MAINT_DATE = "bomMaintDate";

   private Timestamp bomMaintDate;

   //##begin BOM_MAINT_STATUE%BOM_MAINT_STATUE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end BOM_MAINT_STATUE%BOM_MAINT_STATUE.doc
   public static final String BOM_MAINT_STATUE = "bomMaintStatue";

   private static int BOM_MAINT_STATUE_UPPER_LIMIT = -1;
   private String bomMaintStatue;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = -4736829471313190390L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( bomMaintDate );
      output.writeObject( bomMaintStatue );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         bomMaintDate = (Timestamp)input.readObject();
         bomMaintStatue = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setTimestamp( "bomMaintDate", bomMaintDate );
      output.setString( "bomMaintStatue", bomMaintStatue );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      bomMaintDate = input.getTimestamp( "bomMaintDate" );
      bomMaintStatue = input.getString( "bomMaintStatue" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getBomMaintDate%4C5A21D7037Ag.doc preserve=no
   /**
    * Gets the value of the attribute: BOM_MAINT_DATE.
    *
    * @return    Timestamp
    **/
   //##end getBomMaintDate%4C5A21D7037Ag.doc

   public Timestamp getBomMaintDate() {
      //##begin getBomMaintDate%4C5A21D7037Ag.body preserve=no

      return bomMaintDate;
      //##end getBomMaintDate%4C5A21D7037Ag.body
   }

   //##begin setBomMaintDate%4C5A21D7037As.doc preserve=no
   /**
    * Sets the value of the attribute: BOM_MAINT_DATE.
    *
    * @param     a_BomMaintDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setBomMaintDate%4C5A21D7037As.doc

   public void setBomMaintDate( Timestamp a_BomMaintDate )
            throws WTPropertyVetoException {
      //##begin setBomMaintDate%4C5A21D7037As.body preserve=no

      bomMaintDate = a_BomMaintDate;
      //##end setBomMaintDate%4C5A21D7037As.body
   }

   //##begin getBomMaintStatue%4C5A21E701A5g.doc preserve=no
   /**
    * Gets the value of the attribute: BOM_MAINT_STATUE.
    *
    * @return    String
    **/
   //##end getBomMaintStatue%4C5A21E701A5g.doc

   public String getBomMaintStatue() {
      //##begin getBomMaintStatue%4C5A21E701A5g.body preserve=no

      return bomMaintStatue;
      //##end getBomMaintStatue%4C5A21E701A5g.body
   }

   //##begin setBomMaintStatue%4C5A21E701A5s.doc preserve=no
   /**
    * Sets the value of the attribute: BOM_MAINT_STATUE.
    *
    * @param     a_BomMaintStatue
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setBomMaintStatue%4C5A21E701A5s.doc

   public void setBomMaintStatue( String a_BomMaintStatue )
            throws WTPropertyVetoException {
      //##begin setBomMaintStatue%4C5A21E701A5s.body preserve=no

      bomMaintStatueValidate( a_BomMaintStatue );   // throws exception if not valid
      bomMaintStatue = a_BomMaintStatue;
      //##end setBomMaintStatue%4C5A21E701A5s.body
   }

   //##begin bomMaintStatueValidate%4C5A21E701A5.doc preserve=no
   /**
    * @param     a_BomMaintStatue
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end bomMaintStatueValidate%4C5A21E701A5.doc

   private void bomMaintStatueValidate( String a_BomMaintStatue )
            throws WTPropertyVetoException {
      if ( BOM_MAINT_STATUE_UPPER_LIMIT < 1 ) {
         try { BOM_MAINT_STATUE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "bomMaintStatue" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { BOM_MAINT_STATUE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_BomMaintStatue != null && !wt.fc.PersistenceHelper.checkStoredLength( a_BomMaintStatue, BOM_MAINT_STATUE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "bomMaintStatue" ), String.valueOf( Math.min ( BOM_MAINT_STATUE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "bomMaintStatue", bomMaintStatue, a_BomMaintStatue ) );
      }
   }

   //##begin newEOBetaAForm%newEOBetaAFormf.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    EOBetaAForm
    * @exception wt.util.WTException
    **/
   //##end newEOBetaAForm%newEOBetaAFormf.doc

   public static EOBetaAForm newEOBetaAForm()
            throws WTException {
      //##begin newEOBetaAForm%newEOBetaAFormf.body preserve=no

      EOBetaAForm instance = new EOBetaAForm();
      instance.initialize();
      return instance;
      //##end newEOBetaAForm%newEOBetaAFormf.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
