// Generated EOAlphaForm%4C576827032C: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.change2.WTChangeOrder2;
import wt.fc.ObjectReference;
import wt.org.WTUser;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EOAlphaForm%4C576827032C.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newEOAlphaForm</code> static factory method(s), not the
 * <code>EOAlphaForm</code> constructor, to construct instances of this
 * class.  Instances must be constructed using the static factory(s), in
 * order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end EOAlphaForm%4C576827032C.doc

public class EOAlphaForm extends WTChangeOrder2 implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.eo.eoResource";
   private static final String CLASSNAME = EOAlphaForm.class.getName();

   //##begin CHANGE_REASON%CHANGE_REASON.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CHANGE_REASON%CHANGE_REASON.doc
   public static final String CHANGE_REASON = "changeReason";

   private static int CHANGE_REASON_UPPER_LIMIT = -1;
   private String changeReason;

   //##begin STOCK_MGT%STOCK_MGT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end STOCK_MGT%STOCK_MGT.doc
   public static final String STOCK_MGT = "stockMgt";

   private static int STOCK_MGT_UPPER_LIMIT = -1;
   private String stockMgt;

   //##begin EO_CONTENT%EO_CONTENT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EO_CONTENT%EO_CONTENT.doc
   public static final String EO_CONTENT = "eoContent";

   private static int EO_CONTENT_UPPER_LIMIT = -1;
   private String eoContent;

   //##begin DEPARTMENT%DEPARTMENT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end DEPARTMENT%DEPARTMENT.doc
   public static final String DEPARTMENT = "department";

   private static int DEPARTMENT_UPPER_LIMIT = -1;
   private String department;

   //##begin APPLY_DATE%APPLY_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end APPLY_DATE%APPLY_DATE.doc
   public static final String APPLY_DATE = "applyDate";

   private Timestamp applyDate;

   //##begin EO_TYPE%EO_TYPE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EO_TYPE%EO_TYPE.doc
   public static final String EO_TYPE = "eoType";

   private static int EO_TYPE_UPPER_LIMIT = -1;
   private String eoType;

   //##begin NEED_EVR%NEED_EVR.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end NEED_EVR%NEED_EVR.doc
   public static final String NEED_EVR = "needEVR";

   private static int NEED_EVR_UPPER_LIMIT = -1;
   private String needEVR;

   //##begin EVR_TITLE%EVR_TITLE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EVR_TITLE%EVR_TITLE.doc
   public static final String EVR_TITLE = "evrTitle";

   private static int EVR_TITLE_UPPER_LIMIT = -1;
   private String evrTitle;

   //##begin EVR_TEST_LIST%EVR_TEST_LIST.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EVR_TEST_LIST%EVR_TEST_LIST.doc
   public static final String EVR_TEST_LIST = "evrTestList";

   private static int EVR_TEST_LIST_UPPER_LIMIT = -1;
   private String evrTestList;

   //##begin RELEASE_DATE%RELEASE_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RELEASE_DATE%RELEASE_DATE.doc
   public static final String RELEASE_DATE = "releaseDate";

   private Timestamp releaseDate;

   //##begin NO_EPI%NO_EPI.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end NO_EPI%NO_EPI.doc
   public static final String NO_EPI = "noEPI";

   private static int NO_EPI_UPPER_LIMIT = -1;
   private String noEPI;

   //##begin EVRCREATOR%EVRCREATOR.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EVRCREATOR%EVRCREATOR.doc
   public static final String EVRCREATOR = "evrcreator";


   //##begin EVRCREATOR_REFERENCE%EVRCREATOR_REFERENCE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EVRCREATOR_REFERENCE%EVRCREATOR_REFERENCE.doc
   public static final String EVRCREATOR_REFERENCE = "evrcreatorReference";

   private ObjectReference evrcreatorReference;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 4812246238579150832L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( applyDate );
      output.writeObject( changeReason );
      output.writeObject( department );
      output.writeObject( eoContent );
      output.writeObject( eoType );
      output.writeObject( evrTestList );
      output.writeObject( evrTitle );
      output.writeObject( evrcreatorReference );
      output.writeObject( needEVR );
      output.writeObject( noEPI );
      output.writeObject( releaseDate );
      output.writeObject( stockMgt );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         applyDate = (Timestamp)input.readObject();
         changeReason = (String)input.readObject();
         department = (String)input.readObject();
         eoContent = (String)input.readObject();
         eoType = (String)input.readObject();
         evrTestList = (String)input.readObject();
         evrTitle = (String)input.readObject();
         evrcreatorReference = (ObjectReference)input.readObject();
         needEVR = (String)input.readObject();
         noEPI = (String)input.readObject();
         releaseDate = (Timestamp)input.readObject();
         stockMgt = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "changeReason", changeReason );
      output.setString( "stockMgt", stockMgt );
      output.setString( "eoContent", eoContent );
      output.setString( "department", department );
      output.setTimestamp( "applyDate", applyDate );
      output.setString( "eoType", eoType );
      output.setString( "needEVR", needEVR );
      output.setString( "evrTitle", evrTitle );
      output.setString( "evrTestList", evrTestList );
      output.setTimestamp( "releaseDate", releaseDate );
      output.setString( "noEPI", noEPI );
      output.writeObject( "evrcreatorReference", evrcreatorReference, wt.fc.ObjectReference.class, true );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      changeReason = input.getString( "changeReason" );
      stockMgt = input.getString( "stockMgt" );
      eoContent = input.getString( "eoContent" );
      department = input.getString( "department" );
      applyDate = input.getTimestamp( "applyDate" );
      eoType = input.getString( "eoType" );
      needEVR = input.getString( "needEVR" );
      evrTitle = input.getString( "evrTitle" );
      evrTestList = input.getString( "evrTestList" );
      releaseDate = input.getTimestamp( "releaseDate" );
      noEPI = input.getString( "noEPI" );
      evrcreatorReference = (wt.fc.ObjectReference)input.readObject( "evrcreatorReference", evrcreatorReference, wt.fc.ObjectReference.class, true );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getChangeReason%4C57687400FAg.doc preserve=no
   /**
    * Gets the value of the attribute: CHANGE_REASON.
    *
    * @return    String
    **/
   //##end getChangeReason%4C57687400FAg.doc

   public String getChangeReason() {
      //##begin getChangeReason%4C57687400FAg.body preserve=no

      return changeReason;
      //##end getChangeReason%4C57687400FAg.body
   }

   //##begin setChangeReason%4C57687400FAs.doc preserve=no
   /**
    * Sets the value of the attribute: CHANGE_REASON.
    *
    * @param     a_ChangeReason
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setChangeReason%4C57687400FAs.doc

   public void setChangeReason( String a_ChangeReason )
            throws WTPropertyVetoException {
      //##begin setChangeReason%4C57687400FAs.body preserve=no

      changeReasonValidate( a_ChangeReason );   // throws exception if not valid
      changeReason = a_ChangeReason;
      //##end setChangeReason%4C57687400FAs.body
   }

   //##begin changeReasonValidate%4C57687400FA.doc preserve=no
   /**
    * @param     a_ChangeReason
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end changeReasonValidate%4C57687400FA.doc

   private void changeReasonValidate( String a_ChangeReason )
            throws WTPropertyVetoException {
      if ( CHANGE_REASON_UPPER_LIMIT < 1 ) {
         try { CHANGE_REASON_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "changeReason" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CHANGE_REASON_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_ChangeReason != null && !wt.fc.PersistenceHelper.checkStoredLength( a_ChangeReason, CHANGE_REASON_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "changeReason" ), String.valueOf( Math.min ( CHANGE_REASON_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "changeReason", changeReason, a_ChangeReason ) );
      }
   }

   //##begin getStockMgt%4C57689A02DEg.doc preserve=no
   /**
    * Gets the value of the attribute: STOCK_MGT.
    *
    * @return    String
    **/
   //##end getStockMgt%4C57689A02DEg.doc

   public String getStockMgt() {
      //##begin getStockMgt%4C57689A02DEg.body preserve=no

      return stockMgt;
      //##end getStockMgt%4C57689A02DEg.body
   }

   //##begin setStockMgt%4C57689A02DEs.doc preserve=no
   /**
    * Sets the value of the attribute: STOCK_MGT.
    *
    * @param     a_StockMgt
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setStockMgt%4C57689A02DEs.doc

   public void setStockMgt( String a_StockMgt )
            throws WTPropertyVetoException {
      //##begin setStockMgt%4C57689A02DEs.body preserve=no

      stockMgtValidate( a_StockMgt );   // throws exception if not valid
      stockMgt = a_StockMgt;
      //##end setStockMgt%4C57689A02DEs.body
   }

   //##begin stockMgtValidate%4C57689A02DE.doc preserve=no
   /**
    * @param     a_StockMgt
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end stockMgtValidate%4C57689A02DE.doc

   private void stockMgtValidate( String a_StockMgt )
            throws WTPropertyVetoException {
      if ( STOCK_MGT_UPPER_LIMIT < 1 ) {
         try { STOCK_MGT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "stockMgt" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { STOCK_MGT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_StockMgt != null && !wt.fc.PersistenceHelper.checkStoredLength( a_StockMgt, STOCK_MGT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "stockMgt" ), String.valueOf( Math.min ( STOCK_MGT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "stockMgt", stockMgt, a_StockMgt ) );
      }
   }

   //##begin getEoContent%4C5768DF02AFg.doc preserve=no
   /**
    * Gets the value of the attribute: EO_CONTENT.
    *
    * @return    String
    **/
   //##end getEoContent%4C5768DF02AFg.doc

   public String getEoContent() {
      //##begin getEoContent%4C5768DF02AFg.body preserve=no

      return eoContent;
      //##end getEoContent%4C5768DF02AFg.body
   }

   //##begin setEoContent%4C5768DF02AFs.doc preserve=no
   /**
    * Sets the value of the attribute: EO_CONTENT.
    *
    * @param     a_EoContent
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEoContent%4C5768DF02AFs.doc

   public void setEoContent( String a_EoContent )
            throws WTPropertyVetoException {
      //##begin setEoContent%4C5768DF02AFs.body preserve=no

      eoContentValidate( a_EoContent );   // throws exception if not valid
      eoContent = a_EoContent;
      //##end setEoContent%4C5768DF02AFs.body
   }

   //##begin eoContentValidate%4C5768DF02AF.doc preserve=no
   /**
    * @param     a_EoContent
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end eoContentValidate%4C5768DF02AF.doc

   private void eoContentValidate( String a_EoContent )
            throws WTPropertyVetoException {
      if ( EO_CONTENT_UPPER_LIMIT < 1 ) {
         try { EO_CONTENT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "eoContent" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EO_CONTENT_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_EoContent != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EoContent, EO_CONTENT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "eoContent" ), String.valueOf( Math.min ( EO_CONTENT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "eoContent", eoContent, a_EoContent ) );
      }
   }

   //##begin getDepartment%4C5A0907035Bg.doc preserve=no
   /**
    * Gets the value of the attribute: DEPARTMENT.
    *
    * @return    String
    **/
   //##end getDepartment%4C5A0907035Bg.doc

   public String getDepartment() {
      //##begin getDepartment%4C5A0907035Bg.body preserve=no

      return department;
      //##end getDepartment%4C5A0907035Bg.body
   }

   //##begin setDepartment%4C5A0907035Bs.doc preserve=no
   /**
    * Sets the value of the attribute: DEPARTMENT.
    *
    * @param     a_Department
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setDepartment%4C5A0907035Bs.doc

   public void setDepartment( String a_Department )
            throws WTPropertyVetoException {
      //##begin setDepartment%4C5A0907035Bs.body preserve=no

      departmentValidate( a_Department );   // throws exception if not valid
      department = a_Department;
      //##end setDepartment%4C5A0907035Bs.body
   }

   //##begin departmentValidate%4C5A0907035B.doc preserve=no
   /**
    * @param     a_Department
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end departmentValidate%4C5A0907035B.doc

   private void departmentValidate( String a_Department )
            throws WTPropertyVetoException {
      if ( DEPARTMENT_UPPER_LIMIT < 1 ) {
         try { DEPARTMENT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "department" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { DEPARTMENT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Department != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Department, DEPARTMENT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "department" ), String.valueOf( Math.min ( DEPARTMENT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "department", department, a_Department ) );
      }
   }

   //##begin getApplyDate%4C5A0917008Cg.doc preserve=no
   /**
    * Gets the value of the attribute: APPLY_DATE.
    *
    * @return    Timestamp
    **/
   //##end getApplyDate%4C5A0917008Cg.doc

   public Timestamp getApplyDate() {
      //##begin getApplyDate%4C5A0917008Cg.body preserve=no

      return applyDate;
      //##end getApplyDate%4C5A0917008Cg.body
   }

   //##begin setApplyDate%4C5A0917008Cs.doc preserve=no
   /**
    * Sets the value of the attribute: APPLY_DATE.
    *
    * @param     a_ApplyDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setApplyDate%4C5A0917008Cs.doc

   public void setApplyDate( Timestamp a_ApplyDate )
            throws WTPropertyVetoException {
      //##begin setApplyDate%4C5A0917008Cs.body preserve=no

      applyDate = a_ApplyDate;
      //##end setApplyDate%4C5A0917008Cs.body
   }

   //##begin getEoType%4C5A095A02CEg.doc preserve=no
   /**
    * Gets the value of the attribute: EO_TYPE.
    *
    * @return    String
    **/
   //##end getEoType%4C5A095A02CEg.doc

   public String getEoType() {
      //##begin getEoType%4C5A095A02CEg.body preserve=no

      return eoType;
      //##end getEoType%4C5A095A02CEg.body
   }

   //##begin setEoType%4C5A095A02CEs.doc preserve=no
   /**
    * Sets the value of the attribute: EO_TYPE.
    *
    * @param     a_EoType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEoType%4C5A095A02CEs.doc

   public void setEoType( String a_EoType )
            throws WTPropertyVetoException {
      //##begin setEoType%4C5A095A02CEs.body preserve=no

      eoTypeValidate( a_EoType );   // throws exception if not valid
      eoType = a_EoType;
      //##end setEoType%4C5A095A02CEs.body
   }

   //##begin eoTypeValidate%4C5A095A02CE.doc preserve=no
   /**
    * @param     a_EoType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end eoTypeValidate%4C5A095A02CE.doc

   private void eoTypeValidate( String a_EoType )
            throws WTPropertyVetoException {
      if ( EO_TYPE_UPPER_LIMIT < 1 ) {
         try { EO_TYPE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "eoType" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EO_TYPE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EoType != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EoType, EO_TYPE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "eoType" ), String.valueOf( Math.min ( EO_TYPE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "eoType", eoType, a_EoType ) );
      }
   }

   //##begin getNeedEVR%4C5A096C030Dg.doc preserve=no
   /**
    * Gets the value of the attribute: NEED_EVR.
    *
    * @return    String
    **/
   //##end getNeedEVR%4C5A096C030Dg.doc

   public String getNeedEVR() {
      //##begin getNeedEVR%4C5A096C030Dg.body preserve=no

      return needEVR;
      //##end getNeedEVR%4C5A096C030Dg.body
   }

   //##begin setNeedEVR%4C5A096C030Ds.doc preserve=no
   /**
    * Sets the value of the attribute: NEED_EVR.
    *
    * @param     a_NeedEVR
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setNeedEVR%4C5A096C030Ds.doc

   public void setNeedEVR( String a_NeedEVR )
            throws WTPropertyVetoException {
      //##begin setNeedEVR%4C5A096C030Ds.body preserve=no

      needEVRValidate( a_NeedEVR );   // throws exception if not valid
      needEVR = a_NeedEVR;
      //##end setNeedEVR%4C5A096C030Ds.body
   }

   //##begin needEVRValidate%4C5A096C030D.doc preserve=no
   /**
    * @param     a_NeedEVR
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end needEVRValidate%4C5A096C030D.doc

   private void needEVRValidate( String a_NeedEVR )
            throws WTPropertyVetoException {
      if ( NEED_EVR_UPPER_LIMIT < 1 ) {
         try { NEED_EVR_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "needEVR" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { NEED_EVR_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_NeedEVR != null && !wt.fc.PersistenceHelper.checkStoredLength( a_NeedEVR, NEED_EVR_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "needEVR" ), String.valueOf( Math.min ( NEED_EVR_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "needEVR", needEVR, a_NeedEVR ) );
      }
   }

   //##begin getEvrTitle%4C5A09D10138g.doc preserve=no
   /**
    * Gets the value of the attribute: EVR_TITLE.
    *
    * @return    String
    **/
   //##end getEvrTitle%4C5A09D10138g.doc

   public String getEvrTitle() {
      //##begin getEvrTitle%4C5A09D10138g.body preserve=no

      return evrTitle;
      //##end getEvrTitle%4C5A09D10138g.body
   }

   //##begin setEvrTitle%4C5A09D10138s.doc preserve=no
   /**
    * Sets the value of the attribute: EVR_TITLE.
    *
    * @param     a_EvrTitle
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEvrTitle%4C5A09D10138s.doc

   public void setEvrTitle( String a_EvrTitle )
            throws WTPropertyVetoException {
      //##begin setEvrTitle%4C5A09D10138s.body preserve=no

      evrTitleValidate( a_EvrTitle );   // throws exception if not valid
      evrTitle = a_EvrTitle;
      //##end setEvrTitle%4C5A09D10138s.body
   }

   //##begin evrTitleValidate%4C5A09D10138.doc preserve=no
   /**
    * @param     a_EvrTitle
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end evrTitleValidate%4C5A09D10138.doc

   private void evrTitleValidate( String a_EvrTitle )
            throws WTPropertyVetoException {
      if ( EVR_TITLE_UPPER_LIMIT < 1 ) {
         try { EVR_TITLE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "evrTitle" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EVR_TITLE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EvrTitle != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EvrTitle, EVR_TITLE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "evrTitle" ), String.valueOf( Math.min ( EVR_TITLE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "evrTitle", evrTitle, a_EvrTitle ) );
      }
   }

   //##begin getEvrTestList%4C5A09DB005Dg.doc preserve=no
   /**
    * Gets the value of the attribute: EVR_TEST_LIST.
    *
    * @return    String
    **/
   //##end getEvrTestList%4C5A09DB005Dg.doc

   public String getEvrTestList() {
      //##begin getEvrTestList%4C5A09DB005Dg.body preserve=no

      return evrTestList;
      //##end getEvrTestList%4C5A09DB005Dg.body
   }

   //##begin setEvrTestList%4C5A09DB005Ds.doc preserve=no
   /**
    * Sets the value of the attribute: EVR_TEST_LIST.
    *
    * @param     a_EvrTestList
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEvrTestList%4C5A09DB005Ds.doc

   public void setEvrTestList( String a_EvrTestList )
            throws WTPropertyVetoException {
      //##begin setEvrTestList%4C5A09DB005Ds.body preserve=no

      evrTestListValidate( a_EvrTestList );   // throws exception if not valid
      evrTestList = a_EvrTestList;
      //##end setEvrTestList%4C5A09DB005Ds.body
   }

   //##begin evrTestListValidate%4C5A09DB005D.doc preserve=no
   /**
    * @param     a_EvrTestList
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end evrTestListValidate%4C5A09DB005D.doc

   private void evrTestListValidate( String a_EvrTestList )
            throws WTPropertyVetoException {
      if ( EVR_TEST_LIST_UPPER_LIMIT < 1 ) {
         try { EVR_TEST_LIST_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "evrTestList" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EVR_TEST_LIST_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EvrTestList != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EvrTestList, EVR_TEST_LIST_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "evrTestList" ), String.valueOf( Math.min ( EVR_TEST_LIST_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "evrTestList", evrTestList, a_EvrTestList ) );
      }
   }

   //##begin getReleaseDate%4C75AAC8037Ag.doc preserve=no
   /**
    * Gets the value of the attribute: RELEASE_DATE.
    *
    * @return    Timestamp
    **/
   //##end getReleaseDate%4C75AAC8037Ag.doc

   public Timestamp getReleaseDate() {
      //##begin getReleaseDate%4C75AAC8037Ag.body preserve=no

      return releaseDate;
      //##end getReleaseDate%4C75AAC8037Ag.body
   }

   //##begin setReleaseDate%4C75AAC8037As.doc preserve=no
   /**
    * Sets the value of the attribute: RELEASE_DATE.
    *
    * @param     a_ReleaseDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReleaseDate%4C75AAC8037As.doc

   public void setReleaseDate( Timestamp a_ReleaseDate )
            throws WTPropertyVetoException {
      //##begin setReleaseDate%4C75AAC8037As.body preserve=no

      releaseDate = a_ReleaseDate;
      //##end setReleaseDate%4C75AAC8037As.body
   }

   //##begin getNoEPI%4CBE46760111g.doc preserve=no
   /**
    * Gets the value of the attribute: NO_EPI.
    *
    * @return    String
    **/
   //##end getNoEPI%4CBE46760111g.doc

   public String getNoEPI() {
      //##begin getNoEPI%4CBE46760111g.body preserve=no

      return noEPI;
      //##end getNoEPI%4CBE46760111g.body
   }

   //##begin setNoEPI%4CBE46760111s.doc preserve=no
   /**
    * Sets the value of the attribute: NO_EPI.
    *
    * @param     a_NoEPI
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setNoEPI%4CBE46760111s.doc

   public void setNoEPI( String a_NoEPI )
            throws WTPropertyVetoException {
      //##begin setNoEPI%4CBE46760111s.body preserve=no

      noEPIValidate( a_NoEPI );   // throws exception if not valid
      noEPI = a_NoEPI;
      //##end setNoEPI%4CBE46760111s.body
   }

   //##begin noEPIValidate%4CBE46760111.doc preserve=no
   /**
    * @param     a_NoEPI
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end noEPIValidate%4CBE46760111.doc

   private void noEPIValidate( String a_NoEPI )
            throws WTPropertyVetoException {
      if ( NO_EPI_UPPER_LIMIT < 1 ) {
         try { NO_EPI_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "noEPI" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { NO_EPI_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_NoEPI != null && !wt.fc.PersistenceHelper.checkStoredLength( a_NoEPI, NO_EPI_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "noEPI" ), String.valueOf( Math.min ( NO_EPI_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "noEPI", noEPI, a_NoEPI ) );
      }
   }

   //##begin getEvrcreator%4C5A0AA702FDd.doc preserve=no
   /**
    * Gets the object for the association that plays role: EVRCREATOR.
    *
    * @return    WTUser
    **/
   //##end getEvrcreator%4C5A0AA702FDd.doc

   public WTUser getEvrcreator() {
      //##begin getEvrcreator%4C5A0AA702FDd.body preserve=no

      if ( evrcreatorReference == null )
         return null;

      return (WTUser)evrcreatorReference.getObject();
      //##end getEvrcreator%4C5A0AA702FDd.body
   }

   //##begin setEvrcreator%4C5A0AA702FDp.doc preserve=no
   /**
    * Sets the object for the association that plays role: EVRCREATOR.
    *
    * @param     a_Evrcreator
    * @exception wt.util.WTPropertyVetoException
    * @exception wt.util.WTException
    **/
   //##end setEvrcreator%4C5A0AA702FDp.doc

   public void setEvrcreator( WTUser a_Evrcreator )
            throws WTPropertyVetoException, WTException {
      //##begin setEvrcreator%4C5A0AA702FDp.body preserve=no

      setEvrcreatorReference( a_Evrcreator == null ? null : ObjectReference.newObjectReference( a_Evrcreator ) );
      //##end setEvrcreator%4C5A0AA702FDp.body
   }

   //##begin getEvrcreatorReference%4C5A0AA702FDg.doc preserve=no
   /**
    * Gets the value of the attribute: EVRCREATOR_REFERENCE.
    *
    * @return    ObjectReference
    **/
   //##end getEvrcreatorReference%4C5A0AA702FDg.doc

   public ObjectReference getEvrcreatorReference() {
      //##begin getEvrcreatorReference%4C5A0AA702FDg.body preserve=no

      return evrcreatorReference;
      //##end getEvrcreatorReference%4C5A0AA702FDg.body
   }

   //##begin setEvrcreatorReference%4C5A0AA702FDs.doc preserve=no
   /**
    * Sets the value of the attribute: EVRCREATOR_REFERENCE.
    *
    * @param     a_EvrcreatorReference
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEvrcreatorReference%4C5A0AA702FDs.doc

   public void setEvrcreatorReference( ObjectReference a_EvrcreatorReference )
            throws WTPropertyVetoException {
      //##begin setEvrcreatorReference%4C5A0AA702FDs.body preserve=no

      evrcreatorReferenceValidate( a_EvrcreatorReference );   // throws exception if not valid
      evrcreatorReference = a_EvrcreatorReference;
      //##end setEvrcreatorReference%4C5A0AA702FDs.body
   }

   //##begin evrcreatorReferenceValidate%4C5A0AA702FD.doc preserve=no
   /**
    * @param     a_EvrcreatorReference
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end evrcreatorReferenceValidate%4C5A0AA702FD.doc

   private void evrcreatorReferenceValidate( ObjectReference a_EvrcreatorReference )
            throws WTPropertyVetoException {
      if ( a_EvrcreatorReference != null && a_EvrcreatorReference.getReferencedClass() != null &&  // type check
               !( wt.org.WTUser.class.isAssignableFrom( a_EvrcreatorReference.getReferencedClass() ) ) ) {
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "evrcreatorReference" ), "ObjectReference" };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.WRONG_TYPE, args,
               new java.beans.PropertyChangeEvent( this, "evrcreatorReference", evrcreatorReference, a_EvrcreatorReference ) );
      }
   }

   //##begin newEOAlphaForm%newEOAlphaFormf.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    EOAlphaForm
    * @exception wt.util.WTException
    **/
   //##end newEOAlphaForm%newEOAlphaFormf.doc

   public static EOAlphaForm newEOAlphaForm()
            throws WTException {
      //##begin newEOAlphaForm%newEOAlphaFormf.body preserve=no

      EOAlphaForm instance = new EOAlphaForm();
      instance.initialize();
      return instance;
      //##end newEOAlphaForm%newEOAlphaFormf.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
