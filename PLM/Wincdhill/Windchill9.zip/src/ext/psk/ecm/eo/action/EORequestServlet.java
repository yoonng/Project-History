package ext.psk.ecm.eo.action;

import java.io.IOException;
import java.io.PrintWriter;
import wt.util.WTPropertyVetoException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.change2.AffectedActivityData;
import wt.change2.ChangeRecord2;
import wt.util.WTException;
import ext.psk.util.PageControl;
import ext.psk.util.upload.FileUploader;

import ext.psk.ecm.eo.*;
import ext.psk.ecm.ecr.*;

public class EORequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String contentType = req.getContentType();
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		FileUploader uploader = null;
		String cmd = "";
		String returnURI = "";
		String strReturn = "";
		boolean fileFlag = false;
		
		if ( contentType != null && contentType.indexOf("multipart/form-data") >= 0 ) {
			uploader = FileUploader.newFileUploader( null, req, res );
			//System.out.println("uploader = " + uploader);
			cmd = uploader.getFormParameter("cmd");
			System.out.println("addFiles : " +  uploader.getFiles() );
			form.put("addFiles", uploader.getFiles() == null ? new Vector() : uploader.getFiles() );
			
			fileFlag = true;
			
		} else {
			cmd = req.getParameter("cmd");
		}
		
		System.out.println("Request Start ===== " + cmd);

		Enumeration itor = null;
		if( fileFlag ) {
			itor = uploader.getFormParameter();
		} else {
			itor = req.getParameterNames();
		}
		
		while( itor.hasMoreElements() ) {
			String key = (String)itor.nextElement();
			String[] tempValues = null;
			if( fileFlag ) {
				tempValues = uploader.getFormValues(key);
			} else {
				tempValues = req.getParameterValues(key);
			}
			
			//when update, target put form
			if( key.equals("delFiles") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				
				Vector delFiles = new Vector();
				for(int i=0; i < values.length; i++ ) {
					HashMap hp = new HashMap();
					hp.put("fileId", values[i]);
					delFiles.addElement(hp);
				}
				form.put("fileId", delFiles);
				
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을 때 처리함 : 무조건 배열로 처리해야함
			} else if( key.equals("reference") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("only key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을때 처리함 : 무조건 문자열로 처리해야함
			} else if( key.equals("customerSite") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				String tempSite = "";
				
				for(int i = 0; i < values.length; i++) {
					tempSite += values[i] + "__/";
				}
				
				System.out.println("only key : " + key + " ____  value = " + tempSite );
				
				form.put(key, tempSite);
				
			} else if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}
		
		if( cmd.equals("registEO") || cmd.equals("deleteEO") || cmd.equals("updateEO") ) {
			returnURI = "/Windchill/extcore/psk/jsp/ecm/eo/preEO-list.jsp";
			
		} else if( cmd.equals("registEOA") || cmd.equals("deleteEOA") || cmd.equals("updateEOA")  ) {
			returnURI += "/Windchill/extcore/psk/jsp/ecm/eo/preEOA-list.jsp";
			
		} else if( cmd.equals("registEOB") || cmd.equals("deleteEOB") || cmd.equals("updateEOB")  ) {
			returnURI += "/Windchill/extcore/psk/jsp/ecm/eo/preEOB-list.jsp";
			
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";
			
			if( cmd.equals("listEO") || cmd.equals("listEOPopup")) {
				if( cmd.equals("listEO") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEO-list.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/ecm/eo/eo-Popup.jsp";
				}

				HashMap resultMap = EOHelper.service.searchEOAlphaForm(form);
				PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
				PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
				session.setAttribute("control", control);
				req.setAttribute("return", strReturn);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("listEOA") ) {
				returnURI = "/extcore/psk/jsp/ecm/eo/preEOA-list.jsp";
				
				HashMap resultMap = EOHelper.service.searchEOBetaAForm(form);
				QueryResult pagingResult = (QueryResult)resultMap.get("results");
				session.setAttribute("control", pagingResult);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("listEOB") ) {
				returnURI = "/extcore/psk/jsp/ecm/eo/preEOB-list.jsp";
				
				HashMap resultMap = EOHelper.service.searchEOBetaBForm(form);
				QueryResult pagingResult = (QueryResult)resultMap.get("results");
				session.setAttribute("control", pagingResult);
				
				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("registEOA") ) {				//EO A
				strReturn = EOHelper.service.createEOBetaAForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("updateEOAForm") || cmd.equals("viewEOA") || cmd.equals("registEOAForm") ) {
				if( cmd.equals("updateEOAForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOA-update.jsp";
				} else if( cmd.equals("viewEOA") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOA-view.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOA-regist.jsp";
				}
				
				HashMap resultMap = EOHelper.service.viewEOBetaAForm(form);
				EOBetaAForm betaaForm = (EOBetaAForm)resultMap.get("betaaForm");
				EOAlphaForm alphaForm = (EOAlphaForm)resultMap.get("alphaForm");
				
				AffectedActivityData partLink = (AffectedActivityData) resultMap.get("partLink");
				
				session.setAttribute("betaaForm", betaaForm);
				session.setAttribute("alphaForm", alphaForm);
				
				session.setAttribute("partLink", partLink);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateEOA") ) {				
				strReturn = EOHelper.service.updateEOBetaAForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			}  else if( cmd.equals("deleteEOA") ) {
				strReturn = EOHelper.service.deleteEOBetaAForm(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			
			} else if( cmd.equals("registEOB") ) {		//EO B
				//for process exception
				form.put("CRE", "Y");
				strReturn = EOHelper.service.createEOBetaBForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
			
			} else if( cmd.equals("updateEOBForm") || cmd.equals("viewEOB") || cmd.equals("registEOBForm") ) {
				if( cmd.equals("updateEOBForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOB-update.jsp";
				} else if( cmd.equals("viewEOB") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOB-view.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEOB-regist.jsp";
				}
				
				HashMap resultMap = EOHelper.service.viewEOBetaBForm(form);
				EOBetaBForm betabForm = (EOBetaBForm)resultMap.get("betabForm");
				EOAlphaForm alphaForm = (EOAlphaForm)resultMap.get("alphaForm");

				AffectedActivityData partOldLink = (AffectedActivityData) resultMap.get("newAssy");
				AffectedActivityData assySourceLink = (AffectedActivityData) resultMap.get("sourceAssy");
				ChangeRecord2 assyNewLink = (ChangeRecord2) resultMap.get("newPart");
				Vector partNewLink = (Vector) resultMap.get("oldPart"); 

				session.setAttribute("betabForm", betabForm);
				session.setAttribute("alphaForm", alphaForm);
				
				session.setAttribute("newAssy", partOldLink);
				session.setAttribute("sourceAssy", assySourceLink);
				session.setAttribute("newPart", assyNewLink);
				session.setAttribute("oldPart", partNewLink);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateEOB") ) {				
				strReturn = EOHelper.service.updateEOBetaBForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("deleteEOB") ) {				
				strReturn = EOHelper.service.deleteEOBetaBForm(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
				
			} else if( cmd.equals("registEO") ) {			//EO
				strReturn = EOHelper.service.createEOAlphaForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("registEOForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/ecm/eo/preEO-regist.jsp";
				
				this.gotoResult( req, res, returnURI);
								
			} else if( cmd.equals("updateEOForm") || cmd.equals("viewEO") ) {
				if( cmd.equals("updateEOForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEO-update.jsp";
				} else if( cmd.equals("viewEO") ) {
					returnURI = "/extcore/psk/jsp/ecm/eo/preEO-view.jsp";
				}

				HashMap resultMap = EOHelper.service.viewEOAlphaForm(form);
				EOAlphaForm alphaForm = (EOAlphaForm)resultMap.get("alphaForm");
				ECRequest ecrForm = (ECRequest)resultMap.get("ecrForm");
				
				session.setAttribute("alphaForm", alphaForm);
				session.setAttribute("ecrForm", ecrForm);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateEO") ) {
				strReturn = EOHelper.service.updateEOAlphaForm(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("deleteEO") ) {
				strReturn = EOHelper.service.deleteEOAlphaForm(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			}
			
			System.out.println("Request End ===== " + cmd);
			
		} catch( Exception e ) {
			e.printStackTrace();
			//throw new Exception(e);
		}
	}	
}