// Generated EOBetaBForm%4C57686601B5: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.change2.WTChangeActivity2;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EOBetaBForm%4C57686601B5.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newEOBetaBForm</code> static factory method(s), not the
 * <code>EOBetaBForm</code> constructor, to construct instances of this
 * class.  Instances must be constructed using the static factory(s), in
 * order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end EOBetaBForm%4C57686601B5.doc

public class EOBetaBForm extends WTChangeActivity2 implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.eo.eoResource";
   private static final String CLASSNAME = EOBetaBForm.class.getName();

   //##begin REASON_CODE%REASON_CODE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end REASON_CODE%REASON_CODE.doc
   public static final String REASON_CODE = "reasonCode";

   private static int REASON_CODE_UPPER_LIMIT = -1;
   private String reasonCode;

   //##begin CHECK_COMPATIBILITY%CHECK_COMPATIBILITY.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CHECK_COMPATIBILITY%CHECK_COMPATIBILITY.doc
   public static final String CHECK_COMPATIBILITY = "checkCompatibility";

   private static int CHECK_COMPATIBILITY_UPPER_LIMIT = -1;
   private String checkCompatibility;

   //##begin EPI_RECOMMEND_DATE%EPI_RECOMMEND_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EPI_RECOMMEND_DATE%EPI_RECOMMEND_DATE.doc
   public static final String EPI_RECOMMEND_DATE = "epiRecommendDate";

   private Timestamp epiRecommendDate;

   //##begin CREATION_STATUS%CREATION_STATUS.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CREATION_STATUS%CREATION_STATUS.doc
   public static final String CREATION_STATUS = "creationStatus";

   private static int CREATION_STATUS_UPPER_LIMIT = -1;
   private String creationStatus;

   //##begin NEW_PART_QTY%NEW_PART_QTY.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end NEW_PART_QTY%NEW_PART_QTY.doc
   public static final String NEW_PART_QTY = "newPartQty";

   private static int NEW_PART_QTY_UPPER_LIMIT = -1;
   private String newPartQty;

   //##begin OLD_PART_TYPE%OLD_PART_TYPE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end OLD_PART_TYPE%OLD_PART_TYPE.doc
   public static final String OLD_PART_TYPE = "oldPartType";

   private static int OLD_PART_TYPE_UPPER_LIMIT = -1;
   private String oldPartType;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = -6285120668394968758L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( checkCompatibility );
      output.writeObject( creationStatus );
      output.writeObject( epiRecommendDate );
      output.writeObject( newPartQty );
      output.writeObject( oldPartType );
      output.writeObject( reasonCode );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         checkCompatibility = (String)input.readObject();
         creationStatus = (String)input.readObject();
         epiRecommendDate = (Timestamp)input.readObject();
         newPartQty = (String)input.readObject();
         oldPartType = (String)input.readObject();
         reasonCode = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "reasonCode", reasonCode );
      output.setString( "checkCompatibility", checkCompatibility );
      output.setTimestamp( "epiRecommendDate", epiRecommendDate );
      output.setString( "creationStatus", creationStatus );
      output.setString( "newPartQty", newPartQty );
      output.setString( "oldPartType", oldPartType );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      reasonCode = input.getString( "reasonCode" );
      checkCompatibility = input.getString( "checkCompatibility" );
      epiRecommendDate = input.getTimestamp( "epiRecommendDate" );
      creationStatus = input.getString( "creationStatus" );
      newPartQty = input.getString( "newPartQty" );
      oldPartType = input.getString( "oldPartType" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getReasonCode%4C5A488B03D8g.doc preserve=no
   /**
    * Gets the value of the attribute: REASON_CODE.
    *
    * @return    String
    **/
   //##end getReasonCode%4C5A488B03D8g.doc

   public String getReasonCode() {
      //##begin getReasonCode%4C5A488B03D8g.body preserve=no

      return reasonCode;
      //##end getReasonCode%4C5A488B03D8g.body
   }

   //##begin setReasonCode%4C5A488B03D8s.doc preserve=no
   /**
    * Sets the value of the attribute: REASON_CODE.
    *
    * @param     a_ReasonCode
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReasonCode%4C5A488B03D8s.doc

   public void setReasonCode( String a_ReasonCode )
            throws WTPropertyVetoException {
      //##begin setReasonCode%4C5A488B03D8s.body preserve=no

      reasonCodeValidate( a_ReasonCode );   // throws exception if not valid
      reasonCode = a_ReasonCode;
      //##end setReasonCode%4C5A488B03D8s.body
   }

   //##begin reasonCodeValidate%4C5A488B03D8.doc preserve=no
   /**
    * @param     a_ReasonCode
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end reasonCodeValidate%4C5A488B03D8.doc

   private void reasonCodeValidate( String a_ReasonCode )
            throws WTPropertyVetoException {
      if ( REASON_CODE_UPPER_LIMIT < 1 ) {
         try { REASON_CODE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "reasonCode" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { REASON_CODE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_ReasonCode != null && !wt.fc.PersistenceHelper.checkStoredLength( a_ReasonCode, REASON_CODE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "reasonCode" ), String.valueOf( Math.min ( REASON_CODE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "reasonCode", reasonCode, a_ReasonCode ) );
      }
   }

   //##begin getCheckCompatibility%4C5A48940196g.doc preserve=no
   /**
    * Gets the value of the attribute: CHECK_COMPATIBILITY.
    *
    * @return    String
    **/
   //##end getCheckCompatibility%4C5A48940196g.doc

   public String getCheckCompatibility() {
      //##begin getCheckCompatibility%4C5A48940196g.body preserve=no

      return checkCompatibility;
      //##end getCheckCompatibility%4C5A48940196g.body
   }

   //##begin setCheckCompatibility%4C5A48940196s.doc preserve=no
   /**
    * Sets the value of the attribute: CHECK_COMPATIBILITY.
    *
    * @param     a_CheckCompatibility
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCheckCompatibility%4C5A48940196s.doc

   public void setCheckCompatibility( String a_CheckCompatibility )
            throws WTPropertyVetoException {
      //##begin setCheckCompatibility%4C5A48940196s.body preserve=no

      checkCompatibilityValidate( a_CheckCompatibility );   // throws exception if not valid
      checkCompatibility = a_CheckCompatibility;
      //##end setCheckCompatibility%4C5A48940196s.body
   }

   //##begin checkCompatibilityValidate%4C5A48940196.doc preserve=no
   /**
    * @param     a_CheckCompatibility
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end checkCompatibilityValidate%4C5A48940196.doc

   private void checkCompatibilityValidate( String a_CheckCompatibility )
            throws WTPropertyVetoException {
      if ( CHECK_COMPATIBILITY_UPPER_LIMIT < 1 ) {
         try { CHECK_COMPATIBILITY_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "checkCompatibility" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CHECK_COMPATIBILITY_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CheckCompatibility != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CheckCompatibility, CHECK_COMPATIBILITY_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "checkCompatibility" ), String.valueOf( Math.min ( CHECK_COMPATIBILITY_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "checkCompatibility", checkCompatibility, a_CheckCompatibility ) );
      }
   }

   //##begin getEpiRecommendDate%4C5A49E1037Ag.doc preserve=no
   /**
    * Gets the value of the attribute: EPI_RECOMMEND_DATE.
    *
    * @return    Timestamp
    **/
   //##end getEpiRecommendDate%4C5A49E1037Ag.doc

   public Timestamp getEpiRecommendDate() {
      //##begin getEpiRecommendDate%4C5A49E1037Ag.body preserve=no

      return epiRecommendDate;
      //##end getEpiRecommendDate%4C5A49E1037Ag.body
   }

   //##begin setEpiRecommendDate%4C5A49E1037As.doc preserve=no
   /**
    * Sets the value of the attribute: EPI_RECOMMEND_DATE.
    *
    * @param     a_EpiRecommendDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEpiRecommendDate%4C5A49E1037As.doc

   public void setEpiRecommendDate( Timestamp a_EpiRecommendDate )
            throws WTPropertyVetoException {
      //##begin setEpiRecommendDate%4C5A49E1037As.body preserve=no

      epiRecommendDate = a_EpiRecommendDate;
      //##end setEpiRecommendDate%4C5A49E1037As.body
   }

   //##begin getCreationStatus%4C5A49F701D4g.doc preserve=no
   /**
    * Gets the value of the attribute: CREATION_STATUS.
    *
    * @return    String
    **/
   //##end getCreationStatus%4C5A49F701D4g.doc

   public String getCreationStatus() {
      //##begin getCreationStatus%4C5A49F701D4g.body preserve=no

      return creationStatus;
      //##end getCreationStatus%4C5A49F701D4g.body
   }

   //##begin setCreationStatus%4C5A49F701D4s.doc preserve=no
   /**
    * Sets the value of the attribute: CREATION_STATUS.
    *
    * @param     a_CreationStatus
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCreationStatus%4C5A49F701D4s.doc

   public void setCreationStatus( String a_CreationStatus )
            throws WTPropertyVetoException {
      //##begin setCreationStatus%4C5A49F701D4s.body preserve=no

      creationStatusValidate( a_CreationStatus );   // throws exception if not valid
      creationStatus = a_CreationStatus;
      //##end setCreationStatus%4C5A49F701D4s.body
   }

   //##begin creationStatusValidate%4C5A49F701D4.doc preserve=no
   /**
    * @param     a_CreationStatus
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end creationStatusValidate%4C5A49F701D4.doc

   private void creationStatusValidate( String a_CreationStatus )
            throws WTPropertyVetoException {
      if ( CREATION_STATUS_UPPER_LIMIT < 1 ) {
         try { CREATION_STATUS_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "creationStatus" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CREATION_STATUS_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CreationStatus != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CreationStatus, CREATION_STATUS_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "creationStatus" ), String.valueOf( Math.min ( CREATION_STATUS_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "creationStatus", creationStatus, a_CreationStatus ) );
      }
   }

   //##begin getNewPartQty%4C64AD6000B1g.doc preserve=no
   /**
    * Gets the value of the attribute: NEW_PART_QTY.
    *
    * @return    String
    **/
   //##end getNewPartQty%4C64AD6000B1g.doc

   public String getNewPartQty() {
      //##begin getNewPartQty%4C64AD6000B1g.body preserve=no

      return newPartQty;
      //##end getNewPartQty%4C64AD6000B1g.body
   }

   //##begin setNewPartQty%4C64AD6000B1s.doc preserve=no
   /**
    * Sets the value of the attribute: NEW_PART_QTY.
    *
    * @param     a_NewPartQty
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setNewPartQty%4C64AD6000B1s.doc

   public void setNewPartQty( String a_NewPartQty )
            throws WTPropertyVetoException {
      //##begin setNewPartQty%4C64AD6000B1s.body preserve=no

      newPartQtyValidate( a_NewPartQty );   // throws exception if not valid
      newPartQty = a_NewPartQty;
      //##end setNewPartQty%4C64AD6000B1s.body
   }

   //##begin newPartQtyValidate%4C64AD6000B1.doc preserve=no
   /**
    * @param     a_NewPartQty
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end newPartQtyValidate%4C64AD6000B1.doc

   private void newPartQtyValidate( String a_NewPartQty )
            throws WTPropertyVetoException {
      if ( NEW_PART_QTY_UPPER_LIMIT < 1 ) {
         try { NEW_PART_QTY_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "newPartQty" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { NEW_PART_QTY_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_NewPartQty != null && !wt.fc.PersistenceHelper.checkStoredLength( a_NewPartQty, NEW_PART_QTY_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "newPartQty" ), String.valueOf( Math.min ( NEW_PART_QTY_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "newPartQty", newPartQty, a_NewPartQty ) );
      }
   }

   //##begin getOldPartType%4C64AD6502A5g.doc preserve=no
   /**
    * Gets the value of the attribute: OLD_PART_TYPE.
    *
    * @return    String
    **/
   //##end getOldPartType%4C64AD6502A5g.doc

   public String getOldPartType() {
      //##begin getOldPartType%4C64AD6502A5g.body preserve=no

      return oldPartType;
      //##end getOldPartType%4C64AD6502A5g.body
   }

   //##begin setOldPartType%4C64AD6502A5s.doc preserve=no
   /**
    * Sets the value of the attribute: OLD_PART_TYPE.
    *
    * @param     a_OldPartType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setOldPartType%4C64AD6502A5s.doc

   public void setOldPartType( String a_OldPartType )
            throws WTPropertyVetoException {
      //##begin setOldPartType%4C64AD6502A5s.body preserve=no

      oldPartTypeValidate( a_OldPartType );   // throws exception if not valid
      oldPartType = a_OldPartType;
      //##end setOldPartType%4C64AD6502A5s.body
   }

   //##begin oldPartTypeValidate%4C64AD6502A5.doc preserve=no
   /**
    * @param     a_OldPartType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end oldPartTypeValidate%4C64AD6502A5.doc

   private void oldPartTypeValidate( String a_OldPartType )
            throws WTPropertyVetoException {
      if ( OLD_PART_TYPE_UPPER_LIMIT < 1 ) {
         try { OLD_PART_TYPE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "oldPartType" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { OLD_PART_TYPE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_OldPartType != null && !wt.fc.PersistenceHelper.checkStoredLength( a_OldPartType, OLD_PART_TYPE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "oldPartType" ), String.valueOf( Math.min ( OLD_PART_TYPE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "oldPartType", oldPartType, a_OldPartType ) );
      }
   }

   //##begin newEOBetaBForm%newEOBetaBFormf.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    EOBetaBForm
    * @exception wt.util.WTException
    **/
   //##end newEOBetaBForm%newEOBetaBFormf.doc

   public static EOBetaBForm newEOBetaBForm()
            throws WTException {
      //##begin newEOBetaBForm%newEOBetaBFormf.body preserve=no

      EOBetaBForm instance = new EOBetaBForm();
      instance.initialize();
      return instance;
      //##end newEOBetaBForm%newEOBetaBFormf.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
