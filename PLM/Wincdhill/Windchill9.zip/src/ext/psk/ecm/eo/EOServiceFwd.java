// Generated EOServiceFwd%4C5771B501E4: ? 08/26/10 09:28:07
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import ext.psk.ecm.eo.EOService;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class EOServiceFwd implements RemoteAccess, EOService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = EOServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.psk.ecm.eo.EOService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.psk.ecm.eo.EOService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createEOAlphaForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).createEOAlphaForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createEOAlphaForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createEOAlphaForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createEOAlphaForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateEOAlphaForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).updateEOAlphaForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateEOAlphaForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateEOAlphaForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateEOAlphaForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteEOAlphaForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).deleteEOAlphaForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteEOAlphaForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteEOAlphaForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteEOAlphaForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewEOAlphaForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).viewEOAlphaForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewEOAlphaForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewEOAlphaForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewEOAlphaForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchEOAlphaForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).searchEOAlphaForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchEOAlphaForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchEOAlphaForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchEOAlphaForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createEOBetaAForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).createEOBetaAForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createEOBetaAForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createEOBetaAForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createEOBetaAForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateEOBetaAForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).updateEOBetaAForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateEOBetaAForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateEOBetaAForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateEOBetaAForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteEOBetaAForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).deleteEOBetaAForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteEOBetaAForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteEOBetaAForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteEOBetaAForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewEOBetaAForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).viewEOBetaAForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewEOBetaAForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewEOBetaAForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewEOBetaAForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchEOBetaAForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).searchEOBetaAForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchEOBetaAForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchEOBetaAForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchEOBetaAForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createEOBetaBForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).createEOBetaBForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createEOBetaBForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createEOBetaBForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createEOBetaBForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateEOBetaBForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).updateEOBetaBForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateEOBetaBForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateEOBetaBForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateEOBetaBForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteEOBetaBForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).deleteEOBetaBForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteEOBetaBForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteEOBetaBForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteEOBetaBForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewEOBetaBForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).viewEOBetaBForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewEOBetaBForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewEOBetaBForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewEOBetaBForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchEOBetaBForm( HashMap form )
            throws WTException {

      if (SERVER)
         return ((EOService)getManager()).searchEOBetaBForm( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchEOBetaBForm", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchEOBetaBForm" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchEOBetaBForm" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
