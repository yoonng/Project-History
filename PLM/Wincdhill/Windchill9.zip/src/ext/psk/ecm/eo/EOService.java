// Generated EOService%4C5771B501E4: ? 08/26/10 09:28:07
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.eo;

import java.lang.String;
import java.util.HashMap;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin EOService%4C5771B501E4.doc preserve=no
/**
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/
//##end EOService%4C5771B501E4.doc

@RemoteInterface
public interface EOService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createEOAlphaForm%4C5A686302CE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOAlphaForm%4C5A686302CE.doc

   public String createEOAlphaForm( HashMap form )
            throws WTException;

   //##begin updateEOAlphaForm%4C5A68F203A9.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOAlphaForm%4C5A68F203A9.doc

   public String updateEOAlphaForm( HashMap form )
            throws WTException;

   //##begin deleteEOAlphaForm%4C5A6908032C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOAlphaForm%4C5A6908032C.doc

   public String deleteEOAlphaForm( HashMap form )
            throws WTException;

   //##begin viewEOAlphaForm%4C74D53A0109.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOAlphaForm%4C74D53A0109.doc

   public HashMap viewEOAlphaForm( HashMap form )
            throws WTException;

   //##begin searchEOAlphaForm%4C5A69170261.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOAlphaForm%4C5A69170261.doc

   public HashMap searchEOAlphaForm( HashMap form )
            throws WTException;

   //##begin createEOBetaAForm%4C5A692A0290.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOBetaAForm%4C5A692A0290.doc

   public String createEOBetaAForm( HashMap form )
            throws WTException;

   //##begin updateEOBetaAForm%4C5A6945036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOBetaAForm%4C5A6945036B.doc

   public String updateEOBetaAForm( HashMap form )
            throws WTException;

   //##begin deleteEOBetaAForm%4C5A694E035B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOBetaAForm%4C5A694E035B.doc

   public String deleteEOBetaAForm( HashMap form )
            throws WTException;

   //##begin viewEOBetaAForm%4C74D54D037A.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOBetaAForm%4C74D54D037A.doc

   public HashMap viewEOBetaAForm( HashMap form )
            throws WTException;

   //##begin searchEOBetaAForm%4C5A695401C5.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOBetaAForm%4C5A695401C5.doc

   public HashMap searchEOBetaAForm( HashMap form )
            throws WTException;

   //##begin createEOBetaBForm%4C5A696D029F.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createEOBetaBForm%4C5A696D029F.doc

   public String createEOBetaBForm( HashMap form )
            throws WTException;

   //##begin updateEOBetaBForm%4C5A69740280.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateEOBetaBForm%4C5A69740280.doc

   public String updateEOBetaBForm( HashMap form )
            throws WTException;

   //##begin deleteEOBetaBForm%4C5A697D006D.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteEOBetaBForm%4C5A697D006D.doc

   public String deleteEOBetaBForm( HashMap form )
            throws WTException;

   //##begin viewEOBetaBForm%4C74D55700CB.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewEOBetaBForm%4C74D55700CB.doc

   public HashMap viewEOBetaBForm( HashMap form )
            throws WTException;

   //##begin searchEOBetaBForm%4C5A698B0186.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchEOBetaBForm%4C5A698B0186.doc

   public HashMap searchEOBetaBForm( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
