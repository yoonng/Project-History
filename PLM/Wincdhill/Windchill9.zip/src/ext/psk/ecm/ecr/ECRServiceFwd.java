// Generated ECRServiceFwd%4C74DF90037A: ? 08/26/10 09:28:39
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ecr;

import ext.psk.ecm.ecr.ECRService;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class ECRServiceFwd implements RemoteAccess, ECRService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = ECRServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.psk.ecm.ecr.ECRService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.psk.ecm.ecr.ECRService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createECR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((ECRService)getManager()).createECR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createECR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createECR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createECR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateECR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((ECRService)getManager()).updateECR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateECR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateECR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateECR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteECR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((ECRService)getManager()).deleteECR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteECR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteECR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteECR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap viewECR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((ECRService)getManager()).viewECR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "viewECR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "viewECR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "viewECR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchECR( HashMap form )
            throws WTException {

      if (SERVER)
         return ((ECRService)getManager()).searchECR( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchECR", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchECR" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchECR" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
