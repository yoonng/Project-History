package ext.psk.ecm.ecr.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;
import ext.psk.util.upload.FileUploader;

import ext.psk.ecm.ecr.*;
import ext.psk.part.*;

public class ECRRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String contentType = req.getContentType();
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		FileUploader uploader = null;
		String cmd = "";
		String returnURI = "";
		String strReturn = "";
		boolean fileFlag = false;
		
		if ( contentType != null && contentType.indexOf("multipart/form-data") >= 0 ) {
			uploader = FileUploader.newFileUploader( null, req, res );
			//System.out.println("uploader = " + uploader);
			cmd = uploader.getFormParameter("cmd");
			form.put("addFiles", uploader.getFiles() == null ? new Vector() : uploader.getFiles() );
			
			fileFlag = true;
			
		} else {
			cmd = req.getParameter("cmd");
		}
		
		System.out.println("Request Start ===== " + cmd);

		Enumeration itor = null;
		if( fileFlag ) {
			itor = uploader.getFormParameter();
		} else {
			itor = req.getParameterNames();
		}
		
		while( itor.hasMoreElements() ) {
			String key = (String)itor.nextElement();
			String[] tempValues = null;
			if( fileFlag ) {
				tempValues = uploader.getFormValues(key);
			} else {
				tempValues = req.getParameterValues(key);
			}
			
			//when update, target put form
			if( key.equals("delFiles") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				
				Vector delFiles = new Vector();
				for(int i=0; i < values.length; i++ ) {
					HashMap hp = new HashMap();
					hp.put("fileId", values[i]);
					delFiles.addElement(hp);
				}
				form.put("fileId", delFiles);
				
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을 때 처리함 : 무조건 배열로 처리해야함
			} else if( key.equals("reviewItem") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("only key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을때 처리함 : 무조건 문자열로 처리해야함
			} else if( key.equals("customerSite") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				String tempSite = "";
				
				for(int i = 0; i < values.length; i++) {
					tempSite += values[i] + "__/";
				}
				
				System.out.println("only key : " + key + " ____  value = " + tempSite );
				
				form.put(key, tempSite);
				
			} else if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}
		
		if( cmd.equals("registECR") || cmd.equals("deleteECR") || cmd.equals("updateECR") ) {
			returnURI = "/Windchill/extcore/psk/jsp/ecm/ecr/ecr-list.jsp";
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";
			
			if( cmd.equals("listECR") || cmd.equals("listECRPopup") || cmd.equals("listECRCCB") ) {
				if ( cmd.equals("listECR") ) {
					returnURI = "/extcore/psk/jsp/ecm/ecr/ecr-list.jsp";
				} else if( cmd.equals("listECRPopup") ) {
					returnURI = "/extcore/psk/jsp/ecm/ecr/ecr-Popup.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/workflow/CCB-list.jsp";
				}

				HashMap resultMap = ECRHelper.service.searchECR(form);
				
				if( cmd.equals("listECRCCB") ) {
					QueryResult pagingResult = (QueryResult)resultMap.get("results");
					session.setAttribute("control", pagingResult);
					
				} else {
					PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
					PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
					session.setAttribute("control", control);
					
				}
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("registECR") ) {			//ECR Regist ( new, revise, suffix )
				strReturn = ECRHelper.service.createECR(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
			
			} else if( cmd.equals("registECRForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/ecm/ecr/ecr-regist.jsp";
				
				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("updateECRForm") || cmd.equals("viewECR") ) {			//update Form Data Call
				if( cmd.equals("updateECRForm") ) {
					returnURI = "/extcore/psk/jsp/ecm/ecr/ecr-update.jsp";
				} else if( cmd.equals("viewECR") ){
					returnURI = "/extcore/psk/jsp/ecm/ecr/ecr-view.jsp";
				}

				HashMap resultMap = ECRHelper.service.viewECR(form);
				ECRequest ecrForm = (ECRequest)resultMap.get("ecrForm");
				Vector partList = (Vector)resultMap.get("partList");
				
				session.setAttribute("ecrForm", ecrForm);
				session.setAttribute("partList", partList);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateECR") ) {
				strReturn = ECRHelper.service.updateECR(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("deleteECR") ) {
				strReturn = ECRHelper.service.deleteECR(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			}
			
			System.out.println("Request End ===== " + cmd);
			
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}