// Generated ECRequest%4C5784CD033C: ? 11/01/10 16:08:25
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ecr;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.change2.WTChangeRequest2;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin ECRequest%4C5784CD033C.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newECRequest</code> static factory method(s), not the <code>ECRequest</code>
 * constructor, to construct instances of this class.  Instances must be
 * constructed using the static factory(s), in order to ensure proper initialization
 * of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end ECRequest%4C5784CD033C.doc

public class ECRequest extends WTChangeRequest2 implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.ecr.ecrResource";
   private static final String CLASSNAME = ECRequest.class.getName();

   //##begin CHANGE_REASON%CHANGE_REASON.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CHANGE_REASON%CHANGE_REASON.doc
   public static final String CHANGE_REASON = "changeReason";

   private static int CHANGE_REASON_UPPER_LIMIT = -1;
   private String changeReason;

   //##begin DEPARTMENT%DEPARTMENT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end DEPARTMENT%DEPARTMENT.doc
   public static final String DEPARTMENT = "department";

   private static int DEPARTMENT_UPPER_LIMIT = -1;
   private String department;

   //##begin COMPLETE_REQ_DATE%COMPLETE_REQ_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end COMPLETE_REQ_DATE%COMPLETE_REQ_DATE.doc
   public static final String COMPLETE_REQ_DATE = "completeReqDate";

   private Timestamp completeReqDate;

   //##begin RELEASE_DATE%RELEASE_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RELEASE_DATE%RELEASE_DATE.doc
   public static final String RELEASE_DATE = "releaseDate";

   private Timestamp releaseDate;

   //##begin REFERENCE_NUMBER%REFERENCE_NUMBER.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end REFERENCE_NUMBER%REFERENCE_NUMBER.doc
   public static final String REFERENCE_NUMBER = "referenceNumber";

   private static int REFERENCE_NUMBER_UPPER_LIMIT = -1;
   private String referenceNumber;

   //##begin IMPROVEMENT_EFFECT%IMPROVEMENT_EFFECT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end IMPROVEMENT_EFFECT%IMPROVEMENT_EFFECT.doc
   public static final String IMPROVEMENT_EFFECT = "improvementEffect";

   private static int IMPROVEMENT_EFFECT_UPPER_LIMIT = -1;
   private String improvementEffect;

   //##begin CUSTOMER_SITE%CUSTOMER_SITE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CUSTOMER_SITE%CUSTOMER_SITE.doc
   public static final String CUSTOMER_SITE = "customerSite";

   private static int CUSTOMER_SITE_UPPER_LIMIT = -1;
   private String customerSite;

   //##begin CCB_RESULT%CCB_RESULT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CCB_RESULT%CCB_RESULT.doc
   public static final String CCB_RESULT = "ccbResult";

   private static int CCB_RESULT_UPPER_LIMIT = -1;
   private String ccbResult;

   //##begin CCB_RECEIVE_TEAM%CCB_RECEIVE_TEAM.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CCB_RECEIVE_TEAM%CCB_RECEIVE_TEAM.doc
   public static final String CCB_RECEIVE_TEAM = "ccbReceiveTeam";

   private static int CCB_RECEIVE_TEAM_UPPER_LIMIT = -1;
   private String ccbReceiveTeam;

   //##begin CCB_DESCRIPTION%CCB_DESCRIPTION.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CCB_DESCRIPTION%CCB_DESCRIPTION.doc
   public static final String CCB_DESCRIPTION = "ccbDescription";

   private static int CCB_DESCRIPTION_UPPER_LIMIT = -1;
   private String ccbDescription;

   //##begin CCB_REVIEW_DATE%CCB_REVIEW_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CCB_REVIEW_DATE%CCB_REVIEW_DATE.doc
   public static final String CCB_REVIEW_DATE = "ccbReviewDate";

   private Timestamp ccbReviewDate;

   //##begin CCB_REVIEW_DUE_DATE%CCB_REVIEW_DUE_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CCB_REVIEW_DUE_DATE%CCB_REVIEW_DUE_DATE.doc
   public static final String CCB_REVIEW_DUE_DATE = "ccbReviewDueDate";

   private static int CCB_REVIEW_DUE_DATE_UPPER_LIMIT = -1;
   private String ccbReviewDueDate;

   //##begin AS_IS_COMMENT%AS_IS_COMMENT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end AS_IS_COMMENT%AS_IS_COMMENT.doc
   public static final String AS_IS_COMMENT = "asIsComment";

   private static int AS_IS_COMMENT_UPPER_LIMIT = -1;
   private String asIsComment;

   //##begin RECOMMENDATION%RECOMMENDATION.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RECOMMENDATION%RECOMMENDATION.doc
   public static final String RECOMMENDATION = "recommendation";

   private static int RECOMMENDATION_UPPER_LIMIT = -1;
   private String recommendation;

   //##begin REMARK%REMARK.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end REMARK%REMARK.doc
   public static final String REMARK = "remark";

   private static int REMARK_UPPER_LIMIT = -1;
   private String remark;

   //##begin NO_EPI%NO_EPI.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end NO_EPI%NO_EPI.doc
   public static final String NO_EPI = "noEpi";

   private static int NO_EPI_UPPER_LIMIT = -1;
   private String noEpi;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 2386167447312842637L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( asIsComment );
      output.writeObject( ccbDescription );
      output.writeObject( ccbReceiveTeam );
      output.writeObject( ccbResult );
      output.writeObject( ccbReviewDate );
      output.writeObject( ccbReviewDueDate );
      output.writeObject( changeReason );
      output.writeObject( completeReqDate );
      output.writeObject( customerSite );
      output.writeObject( department );
      output.writeObject( improvementEffect );
      output.writeObject( noEpi );
      output.writeObject( recommendation );
      output.writeObject( referenceNumber );
      output.writeObject( releaseDate );
      output.writeObject( remark );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         asIsComment = (String)input.readObject();
         ccbDescription = (String)input.readObject();
         ccbReceiveTeam = (String)input.readObject();
         ccbResult = (String)input.readObject();
         ccbReviewDate = (Timestamp)input.readObject();
         ccbReviewDueDate = (String)input.readObject();
         changeReason = (String)input.readObject();
         completeReqDate = (Timestamp)input.readObject();
         customerSite = (String)input.readObject();
         department = (String)input.readObject();
         improvementEffect = (String)input.readObject();
         noEpi = (String)input.readObject();
         recommendation = (String)input.readObject();
         referenceNumber = (String)input.readObject();
         releaseDate = (Timestamp)input.readObject();
         remark = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "changeReason", changeReason );
      output.setString( "department", department );
      output.setTimestamp( "completeReqDate", completeReqDate );
      output.setTimestamp( "releaseDate", releaseDate );
      output.setString( "referenceNumber", referenceNumber );
      output.setString( "improvementEffect", improvementEffect );
      output.setString( "customerSite", customerSite );
      output.setString( "ccbResult", ccbResult );
      output.setString( "ccbReceiveTeam", ccbReceiveTeam );
      output.setString( "ccbDescription", ccbDescription );
      output.setTimestamp( "ccbReviewDate", ccbReviewDate );
      output.setString( "ccbReviewDueDate", ccbReviewDueDate );
      output.setString( "asIsComment", asIsComment );
      output.setString( "recommendation", recommendation );
      output.setString( "remark", remark );
      output.setString( "noEpi", noEpi );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      changeReason = input.getString( "changeReason" );
      department = input.getString( "department" );
      completeReqDate = input.getTimestamp( "completeReqDate" );
      releaseDate = input.getTimestamp( "releaseDate" );
      referenceNumber = input.getString( "referenceNumber" );
      improvementEffect = input.getString( "improvementEffect" );
      customerSite = input.getString( "customerSite" );
      ccbResult = input.getString( "ccbResult" );
      ccbReceiveTeam = input.getString( "ccbReceiveTeam" );
      ccbDescription = input.getString( "ccbDescription" );
      ccbReviewDate = input.getTimestamp( "ccbReviewDate" );
      ccbReviewDueDate = input.getString( "ccbReviewDueDate" );
      asIsComment = input.getString( "asIsComment" );
      recommendation = input.getString( "recommendation" );
      remark = input.getString( "remark" );
      noEpi = input.getString( "noEpi" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getChangeReason%4C74D6A7032Cg.doc preserve=no
   /**
    * Gets the value of the attribute: CHANGE_REASON.
    *
    * @return    String
    **/
   //##end getChangeReason%4C74D6A7032Cg.doc

   public String getChangeReason() {
      //##begin getChangeReason%4C74D6A7032Cg.body preserve=no

      return changeReason;
      //##end getChangeReason%4C74D6A7032Cg.body
   }

   //##begin setChangeReason%4C74D6A7032Cs.doc preserve=no
   /**
    * Sets the value of the attribute: CHANGE_REASON.
    *
    * @param     a_ChangeReason
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setChangeReason%4C74D6A7032Cs.doc

   public void setChangeReason( String a_ChangeReason )
            throws WTPropertyVetoException {
      //##begin setChangeReason%4C74D6A7032Cs.body preserve=no

      changeReasonValidate( a_ChangeReason );   // throws exception if not valid
      changeReason = a_ChangeReason;
      //##end setChangeReason%4C74D6A7032Cs.body
   }

   //##begin changeReasonValidate%4C74D6A7032C.doc preserve=no
   /**
    * @param     a_ChangeReason
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end changeReasonValidate%4C74D6A7032C.doc

   private void changeReasonValidate( String a_ChangeReason )
            throws WTPropertyVetoException {
      if ( CHANGE_REASON_UPPER_LIMIT < 1 ) {
         try { CHANGE_REASON_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "changeReason" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CHANGE_REASON_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_ChangeReason != null && !wt.fc.PersistenceHelper.checkStoredLength( a_ChangeReason, CHANGE_REASON_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "changeReason" ), String.valueOf( Math.min ( CHANGE_REASON_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "changeReason", changeReason, a_ChangeReason ) );
      }
   }

   //##begin getDepartment%4C74D6E1032Cg.doc preserve=no
   /**
    * Gets the value of the attribute: DEPARTMENT.
    *
    * @return    String
    **/
   //##end getDepartment%4C74D6E1032Cg.doc

   public String getDepartment() {
      //##begin getDepartment%4C74D6E1032Cg.body preserve=no

      return department;
      //##end getDepartment%4C74D6E1032Cg.body
   }

   //##begin setDepartment%4C74D6E1032Cs.doc preserve=no
   /**
    * Sets the value of the attribute: DEPARTMENT.
    *
    * @param     a_Department
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setDepartment%4C74D6E1032Cs.doc

   public void setDepartment( String a_Department )
            throws WTPropertyVetoException {
      //##begin setDepartment%4C74D6E1032Cs.body preserve=no

      departmentValidate( a_Department );   // throws exception if not valid
      department = a_Department;
      //##end setDepartment%4C74D6E1032Cs.body
   }

   //##begin departmentValidate%4C74D6E1032C.doc preserve=no
   /**
    * @param     a_Department
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end departmentValidate%4C74D6E1032C.doc

   private void departmentValidate( String a_Department )
            throws WTPropertyVetoException {
      if ( DEPARTMENT_UPPER_LIMIT < 1 ) {
         try { DEPARTMENT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "department" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { DEPARTMENT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Department != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Department, DEPARTMENT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "department" ), String.valueOf( Math.min ( DEPARTMENT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "department", department, a_Department ) );
      }
   }

   //##begin getCompleteReqDate%4C74D6EE00DAg.doc preserve=no
   /**
    * Gets the value of the attribute: COMPLETE_REQ_DATE.
    *
    * @return    Timestamp
    **/
   //##end getCompleteReqDate%4C74D6EE00DAg.doc

   public Timestamp getCompleteReqDate() {
      //##begin getCompleteReqDate%4C74D6EE00DAg.body preserve=no

      return completeReqDate;
      //##end getCompleteReqDate%4C74D6EE00DAg.body
   }

   //##begin setCompleteReqDate%4C74D6EE00DAs.doc preserve=no
   /**
    * Sets the value of the attribute: COMPLETE_REQ_DATE.
    *
    * @param     a_CompleteReqDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCompleteReqDate%4C74D6EE00DAs.doc

   public void setCompleteReqDate( Timestamp a_CompleteReqDate )
            throws WTPropertyVetoException {
      //##begin setCompleteReqDate%4C74D6EE00DAs.body preserve=no

      completeReqDate = a_CompleteReqDate;
      //##end setCompleteReqDate%4C74D6EE00DAs.body
   }

   //##begin getReleaseDate%4C74D7A903D8g.doc preserve=no
   /**
    * Gets the value of the attribute: RELEASE_DATE.
    *
    * @return    Timestamp
    **/
   //##end getReleaseDate%4C74D7A903D8g.doc

   public Timestamp getReleaseDate() {
      //##begin getReleaseDate%4C74D7A903D8g.body preserve=no

      return releaseDate;
      //##end getReleaseDate%4C74D7A903D8g.body
   }

   //##begin setReleaseDate%4C74D7A903D8s.doc preserve=no
   /**
    * Sets the value of the attribute: RELEASE_DATE.
    *
    * @param     a_ReleaseDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReleaseDate%4C74D7A903D8s.doc

   public void setReleaseDate( Timestamp a_ReleaseDate )
            throws WTPropertyVetoException {
      //##begin setReleaseDate%4C74D7A903D8s.body preserve=no

      releaseDate = a_ReleaseDate;
      //##end setReleaseDate%4C74D7A903D8s.body
   }

   //##begin getReferenceNumber%4C74D7240280g.doc preserve=no
   /**
    * Gets the value of the attribute: REFERENCE_NUMBER.
    *
    * @return    String
    **/
   //##end getReferenceNumber%4C74D7240280g.doc

   public String getReferenceNumber() {
      //##begin getReferenceNumber%4C74D7240280g.body preserve=no

      return referenceNumber;
      //##end getReferenceNumber%4C74D7240280g.body
   }

   //##begin setReferenceNumber%4C74D7240280s.doc preserve=no
   /**
    * Sets the value of the attribute: REFERENCE_NUMBER.
    *
    * @param     a_ReferenceNumber
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setReferenceNumber%4C74D7240280s.doc

   public void setReferenceNumber( String a_ReferenceNumber )
            throws WTPropertyVetoException {
      //##begin setReferenceNumber%4C74D7240280s.body preserve=no

      referenceNumberValidate( a_ReferenceNumber );   // throws exception if not valid
      referenceNumber = a_ReferenceNumber;
      //##end setReferenceNumber%4C74D7240280s.body
   }

   //##begin referenceNumberValidate%4C74D7240280.doc preserve=no
   /**
    * @param     a_ReferenceNumber
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end referenceNumberValidate%4C74D7240280.doc

   private void referenceNumberValidate( String a_ReferenceNumber )
            throws WTPropertyVetoException {
      if ( REFERENCE_NUMBER_UPPER_LIMIT < 1 ) {
         try { REFERENCE_NUMBER_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "referenceNumber" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { REFERENCE_NUMBER_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_ReferenceNumber != null && !wt.fc.PersistenceHelper.checkStoredLength( a_ReferenceNumber, REFERENCE_NUMBER_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "referenceNumber" ), String.valueOf( Math.min ( REFERENCE_NUMBER_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "referenceNumber", referenceNumber, a_ReferenceNumber ) );
      }
   }

   //##begin getImprovementEffect%4C74D731007Dg.doc preserve=no
   /**
    * Gets the value of the attribute: IMPROVEMENT_EFFECT.
    *
    * @return    String
    **/
   //##end getImprovementEffect%4C74D731007Dg.doc

   public String getImprovementEffect() {
      //##begin getImprovementEffect%4C74D731007Dg.body preserve=no

      return improvementEffect;
      //##end getImprovementEffect%4C74D731007Dg.body
   }

   //##begin setImprovementEffect%4C74D731007Ds.doc preserve=no
   /**
    * Sets the value of the attribute: IMPROVEMENT_EFFECT.
    *
    * @param     a_ImprovementEffect
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setImprovementEffect%4C74D731007Ds.doc

   public void setImprovementEffect( String a_ImprovementEffect )
            throws WTPropertyVetoException {
      //##begin setImprovementEffect%4C74D731007Ds.body preserve=no

      improvementEffectValidate( a_ImprovementEffect );   // throws exception if not valid
      improvementEffect = a_ImprovementEffect;
      //##end setImprovementEffect%4C74D731007Ds.body
   }

   //##begin improvementEffectValidate%4C74D731007D.doc preserve=no
   /**
    * @param     a_ImprovementEffect
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end improvementEffectValidate%4C74D731007D.doc

   private void improvementEffectValidate( String a_ImprovementEffect )
            throws WTPropertyVetoException {
      if ( IMPROVEMENT_EFFECT_UPPER_LIMIT < 1 ) {
         try { IMPROVEMENT_EFFECT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "improvementEffect" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { IMPROVEMENT_EFFECT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_ImprovementEffect != null && !wt.fc.PersistenceHelper.checkStoredLength( a_ImprovementEffect, IMPROVEMENT_EFFECT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "improvementEffect" ), String.valueOf( Math.min ( IMPROVEMENT_EFFECT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "improvementEffect", improvementEffect, a_ImprovementEffect ) );
      }
   }

   //##begin getCustomerSite%4CA0058C0280g.doc preserve=no
   /**
    * Gets the value of the attribute: CUSTOMER_SITE.
    *
    * @return    String
    **/
   //##end getCustomerSite%4CA0058C0280g.doc

   public String getCustomerSite() {
      //##begin getCustomerSite%4CA0058C0280g.body preserve=no

      return customerSite;
      //##end getCustomerSite%4CA0058C0280g.body
   }

   //##begin setCustomerSite%4CA0058C0280s.doc preserve=no
   /**
    * Sets the value of the attribute: CUSTOMER_SITE.
    *
    * @param     a_CustomerSite
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCustomerSite%4CA0058C0280s.doc

   public void setCustomerSite( String a_CustomerSite )
            throws WTPropertyVetoException {
      //##begin setCustomerSite%4CA0058C0280s.body preserve=no

      customerSiteValidate( a_CustomerSite );   // throws exception if not valid
      customerSite = a_CustomerSite;
      //##end setCustomerSite%4CA0058C0280s.body
   }

   //##begin customerSiteValidate%4CA0058C0280.doc preserve=no
   /**
    * @param     a_CustomerSite
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end customerSiteValidate%4CA0058C0280.doc

   private void customerSiteValidate( String a_CustomerSite )
            throws WTPropertyVetoException {
      if ( CUSTOMER_SITE_UPPER_LIMIT < 1 ) {
         try { CUSTOMER_SITE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "customerSite" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CUSTOMER_SITE_UPPER_LIMIT = 1000; } // resort to modeled value
      }
      if ( a_CustomerSite != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CustomerSite, CUSTOMER_SITE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "customerSite" ), String.valueOf( Math.min ( CUSTOMER_SITE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "customerSite", customerSite, a_CustomerSite ) );
      }
   }

   //##begin getCcbResult%4CAC366F033Cg.doc preserve=no
   /**
    * Gets the value of the attribute: CCB_RESULT.
    *
    * @return    String
    **/
   //##end getCcbResult%4CAC366F033Cg.doc

   public String getCcbResult() {
      //##begin getCcbResult%4CAC366F033Cg.body preserve=no

      return ccbResult;
      //##end getCcbResult%4CAC366F033Cg.body
   }

   //##begin setCcbResult%4CAC366F033Cs.doc preserve=no
   /**
    * Sets the value of the attribute: CCB_RESULT.
    *
    * @param     a_CcbResult
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCcbResult%4CAC366F033Cs.doc

   public void setCcbResult( String a_CcbResult )
            throws WTPropertyVetoException {
      //##begin setCcbResult%4CAC366F033Cs.body preserve=no

      ccbResultValidate( a_CcbResult );   // throws exception if not valid
      ccbResult = a_CcbResult;
      //##end setCcbResult%4CAC366F033Cs.body
   }

   //##begin ccbResultValidate%4CAC366F033C.doc preserve=no
   /**
    * @param     a_CcbResult
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end ccbResultValidate%4CAC366F033C.doc

   private void ccbResultValidate( String a_CcbResult )
            throws WTPropertyVetoException {
      if ( CCB_RESULT_UPPER_LIMIT < 1 ) {
         try { CCB_RESULT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "ccbResult" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CCB_RESULT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CcbResult != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CcbResult, CCB_RESULT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "ccbResult" ), String.valueOf( Math.min ( CCB_RESULT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "ccbResult", ccbResult, a_CcbResult ) );
      }
   }

   //##begin getCcbReceiveTeam%4CAC36930157g.doc preserve=no
   /**
    * Gets the value of the attribute: CCB_RECEIVE_TEAM.
    *
    * @return    String
    **/
   //##end getCcbReceiveTeam%4CAC36930157g.doc

   public String getCcbReceiveTeam() {
      //##begin getCcbReceiveTeam%4CAC36930157g.body preserve=no

      return ccbReceiveTeam;
      //##end getCcbReceiveTeam%4CAC36930157g.body
   }

   //##begin setCcbReceiveTeam%4CAC36930157s.doc preserve=no
   /**
    * Sets the value of the attribute: CCB_RECEIVE_TEAM.
    *
    * @param     a_CcbReceiveTeam
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCcbReceiveTeam%4CAC36930157s.doc

   public void setCcbReceiveTeam( String a_CcbReceiveTeam )
            throws WTPropertyVetoException {
      //##begin setCcbReceiveTeam%4CAC36930157s.body preserve=no

      ccbReceiveTeamValidate( a_CcbReceiveTeam );   // throws exception if not valid
      ccbReceiveTeam = a_CcbReceiveTeam;
      //##end setCcbReceiveTeam%4CAC36930157s.body
   }

   //##begin ccbReceiveTeamValidate%4CAC36930157.doc preserve=no
   /**
    * @param     a_CcbReceiveTeam
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end ccbReceiveTeamValidate%4CAC36930157.doc

   private void ccbReceiveTeamValidate( String a_CcbReceiveTeam )
            throws WTPropertyVetoException {
      if ( CCB_RECEIVE_TEAM_UPPER_LIMIT < 1 ) {
         try { CCB_RECEIVE_TEAM_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "ccbReceiveTeam" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CCB_RECEIVE_TEAM_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CcbReceiveTeam != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CcbReceiveTeam, CCB_RECEIVE_TEAM_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "ccbReceiveTeam" ), String.valueOf( Math.min ( CCB_RECEIVE_TEAM_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "ccbReceiveTeam", ccbReceiveTeam, a_CcbReceiveTeam ) );
      }
   }

   //##begin getCcbDescription%4CAC369D0261g.doc preserve=no
   /**
    * Gets the value of the attribute: CCB_DESCRIPTION.
    *
    * @return    String
    **/
   //##end getCcbDescription%4CAC369D0261g.doc

   public String getCcbDescription() {
      //##begin getCcbDescription%4CAC369D0261g.body preserve=no

      return ccbDescription;
      //##end getCcbDescription%4CAC369D0261g.body
   }

   //##begin setCcbDescription%4CAC369D0261s.doc preserve=no
   /**
    * Sets the value of the attribute: CCB_DESCRIPTION.
    *
    * @param     a_CcbDescription
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCcbDescription%4CAC369D0261s.doc

   public void setCcbDescription( String a_CcbDescription )
            throws WTPropertyVetoException {
      //##begin setCcbDescription%4CAC369D0261s.body preserve=no

      ccbDescriptionValidate( a_CcbDescription );   // throws exception if not valid
      ccbDescription = a_CcbDescription;
      //##end setCcbDescription%4CAC369D0261s.body
   }

   //##begin ccbDescriptionValidate%4CAC369D0261.doc preserve=no
   /**
    * @param     a_CcbDescription
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end ccbDescriptionValidate%4CAC369D0261.doc

   private void ccbDescriptionValidate( String a_CcbDescription )
            throws WTPropertyVetoException {
      if ( CCB_DESCRIPTION_UPPER_LIMIT < 1 ) {
         try { CCB_DESCRIPTION_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "ccbDescription" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CCB_DESCRIPTION_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_CcbDescription != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CcbDescription, CCB_DESCRIPTION_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "ccbDescription" ), String.valueOf( Math.min ( CCB_DESCRIPTION_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "ccbDescription", ccbDescription, a_CcbDescription ) );
      }
   }

   //##begin getCcbReviewDate%4CAD24F102AFg.doc preserve=no
   /**
    * Gets the value of the attribute: CCB_REVIEW_DATE.
    *
    * @return    Timestamp
    **/
   //##end getCcbReviewDate%4CAD24F102AFg.doc

   public Timestamp getCcbReviewDate() {
      //##begin getCcbReviewDate%4CAD24F102AFg.body preserve=no

      return ccbReviewDate;
      //##end getCcbReviewDate%4CAD24F102AFg.body
   }

   //##begin setCcbReviewDate%4CAD24F102AFs.doc preserve=no
   /**
    * Sets the value of the attribute: CCB_REVIEW_DATE.
    *
    * @param     a_CcbReviewDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCcbReviewDate%4CAD24F102AFs.doc

   public void setCcbReviewDate( Timestamp a_CcbReviewDate )
            throws WTPropertyVetoException {
      //##begin setCcbReviewDate%4CAD24F102AFs.body preserve=no

      ccbReviewDate = a_CcbReviewDate;
      //##end setCcbReviewDate%4CAD24F102AFs.body
   }

   //##begin getCcbReviewDueDate%4CCE5C240028g.doc preserve=no
   /**
    * Gets the value of the attribute: CCB_REVIEW_DUE_DATE.
    *
    * @return    String
    **/
   //##end getCcbReviewDueDate%4CCE5C240028g.doc

   public String getCcbReviewDueDate() {
      //##begin getCcbReviewDueDate%4CCE5C240028g.body preserve=no

      return ccbReviewDueDate;
      //##end getCcbReviewDueDate%4CCE5C240028g.body
   }

   //##begin setCcbReviewDueDate%4CCE5C240028s.doc preserve=no
   /**
    * Sets the value of the attribute: CCB_REVIEW_DUE_DATE.
    *
    * @param     a_CcbReviewDueDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCcbReviewDueDate%4CCE5C240028s.doc

   public void setCcbReviewDueDate( String a_CcbReviewDueDate )
            throws WTPropertyVetoException {
      //##begin setCcbReviewDueDate%4CCE5C240028s.body preserve=no

      ccbReviewDueDateValidate( a_CcbReviewDueDate );   // throws exception if not valid
      ccbReviewDueDate = a_CcbReviewDueDate;
      //##end setCcbReviewDueDate%4CCE5C240028s.body
   }

   //##begin ccbReviewDueDateValidate%4CCE5C240028.doc preserve=no
   /**
    * @param     a_CcbReviewDueDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end ccbReviewDueDateValidate%4CCE5C240028.doc

   private void ccbReviewDueDateValidate( String a_CcbReviewDueDate )
            throws WTPropertyVetoException {
      if ( CCB_REVIEW_DUE_DATE_UPPER_LIMIT < 1 ) {
         try { CCB_REVIEW_DUE_DATE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "ccbReviewDueDate" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CCB_REVIEW_DUE_DATE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CcbReviewDueDate != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CcbReviewDueDate, CCB_REVIEW_DUE_DATE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "ccbReviewDueDate" ), String.valueOf( Math.min ( CCB_REVIEW_DUE_DATE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "ccbReviewDueDate", ccbReviewDueDate, a_CcbReviewDueDate ) );
      }
   }

   //##begin getAsIsComment%4CCE5C380142g.doc preserve=no
   /**
    * Gets the value of the attribute: AS_IS_COMMENT.
    *
    * @return    String
    **/
   //##end getAsIsComment%4CCE5C380142g.doc

   public String getAsIsComment() {
      //##begin getAsIsComment%4CCE5C380142g.body preserve=no

      return asIsComment;
      //##end getAsIsComment%4CCE5C380142g.body
   }

   //##begin setAsIsComment%4CCE5C380142s.doc preserve=no
   /**
    * Sets the value of the attribute: AS_IS_COMMENT.
    *
    * @param     a_AsIsComment
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setAsIsComment%4CCE5C380142s.doc

   public void setAsIsComment( String a_AsIsComment )
            throws WTPropertyVetoException {
      //##begin setAsIsComment%4CCE5C380142s.body preserve=no

      asIsCommentValidate( a_AsIsComment );   // throws exception if not valid
      asIsComment = a_AsIsComment;
      //##end setAsIsComment%4CCE5C380142s.body
   }

   //##begin asIsCommentValidate%4CCE5C380142.doc preserve=no
   /**
    * @param     a_AsIsComment
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end asIsCommentValidate%4CCE5C380142.doc

   private void asIsCommentValidate( String a_AsIsComment )
            throws WTPropertyVetoException {
      if ( AS_IS_COMMENT_UPPER_LIMIT < 1 ) {
         try { AS_IS_COMMENT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "asIsComment" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { AS_IS_COMMENT_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_AsIsComment != null && !wt.fc.PersistenceHelper.checkStoredLength( a_AsIsComment, AS_IS_COMMENT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "asIsComment" ), String.valueOf( Math.min ( AS_IS_COMMENT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "asIsComment", asIsComment, a_AsIsComment ) );
      }
   }

   //##begin getRecommendation%4CCE5C4203E2g.doc preserve=no
   /**
    * Gets the value of the attribute: RECOMMENDATION.
    *
    * @return    String
    **/
   //##end getRecommendation%4CCE5C4203E2g.doc

   public String getRecommendation() {
      //##begin getRecommendation%4CCE5C4203E2g.body preserve=no

      return recommendation;
      //##end getRecommendation%4CCE5C4203E2g.body
   }

   //##begin setRecommendation%4CCE5C4203E2s.doc preserve=no
   /**
    * Sets the value of the attribute: RECOMMENDATION.
    *
    * @param     a_Recommendation
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setRecommendation%4CCE5C4203E2s.doc

   public void setRecommendation( String a_Recommendation )
            throws WTPropertyVetoException {
      //##begin setRecommendation%4CCE5C4203E2s.body preserve=no

      recommendationValidate( a_Recommendation );   // throws exception if not valid
      recommendation = a_Recommendation;
      //##end setRecommendation%4CCE5C4203E2s.body
   }

   //##begin recommendationValidate%4CCE5C4203E2.doc preserve=no
   /**
    * @param     a_Recommendation
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end recommendationValidate%4CCE5C4203E2.doc

   private void recommendationValidate( String a_Recommendation )
            throws WTPropertyVetoException {
      if ( RECOMMENDATION_UPPER_LIMIT < 1 ) {
         try { RECOMMENDATION_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "recommendation" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { RECOMMENDATION_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_Recommendation != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Recommendation, RECOMMENDATION_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "recommendation" ), String.valueOf( Math.min ( RECOMMENDATION_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "recommendation", recommendation, a_Recommendation ) );
      }
   }

   //##begin getRemark%4CCE5C59019Fg.doc preserve=no
   /**
    * Gets the value of the attribute: REMARK.
    *
    * @return    String
    **/
   //##end getRemark%4CCE5C59019Fg.doc

   public String getRemark() {
      //##begin getRemark%4CCE5C59019Fg.body preserve=no

      return remark;
      //##end getRemark%4CCE5C59019Fg.body
   }

   //##begin setRemark%4CCE5C59019Fs.doc preserve=no
   /**
    * Sets the value of the attribute: REMARK.
    *
    * @param     a_Remark
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setRemark%4CCE5C59019Fs.doc

   public void setRemark( String a_Remark )
            throws WTPropertyVetoException {
      //##begin setRemark%4CCE5C59019Fs.body preserve=no

      remarkValidate( a_Remark );   // throws exception if not valid
      remark = a_Remark;
      //##end setRemark%4CCE5C59019Fs.body
   }

   //##begin remarkValidate%4CCE5C59019F.doc preserve=no
   /**
    * @param     a_Remark
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end remarkValidate%4CCE5C59019F.doc

   private void remarkValidate( String a_Remark )
            throws WTPropertyVetoException {
      if ( REMARK_UPPER_LIMIT < 1 ) {
         try { REMARK_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "remark" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { REMARK_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_Remark != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Remark, REMARK_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "remark" ), String.valueOf( Math.min ( REMARK_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "remark", remark, a_Remark ) );
      }
   }

   //##begin getNoEpi%4CCE5C5F020Dg.doc preserve=no
   /**
    * Gets the value of the attribute: NO_EPI.
    *
    * @return    String
    **/
   //##end getNoEpi%4CCE5C5F020Dg.doc

   public String getNoEpi() {
      //##begin getNoEpi%4CCE5C5F020Dg.body preserve=no

      return noEpi;
      //##end getNoEpi%4CCE5C5F020Dg.body
   }

   //##begin setNoEpi%4CCE5C5F020Ds.doc preserve=no
   /**
    * Sets the value of the attribute: NO_EPI.
    *
    * @param     a_NoEpi
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setNoEpi%4CCE5C5F020Ds.doc

   public void setNoEpi( String a_NoEpi )
            throws WTPropertyVetoException {
      //##begin setNoEpi%4CCE5C5F020Ds.body preserve=no

      noEpiValidate( a_NoEpi );   // throws exception if not valid
      noEpi = a_NoEpi;
      //##end setNoEpi%4CCE5C5F020Ds.body
   }

   //##begin noEpiValidate%4CCE5C5F020D.doc preserve=no
   /**
    * @param     a_NoEpi
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end noEpiValidate%4CCE5C5F020D.doc

   private void noEpiValidate( String a_NoEpi )
            throws WTPropertyVetoException {
      if ( NO_EPI_UPPER_LIMIT < 1 ) {
         try { NO_EPI_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "noEpi" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { NO_EPI_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_NoEpi != null && !wt.fc.PersistenceHelper.checkStoredLength( a_NoEpi, NO_EPI_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "noEpi" ), String.valueOf( Math.min ( NO_EPI_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "noEpi", noEpi, a_NoEpi ) );
      }
   }

   //##begin newECRequest%newECRequestf.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    ECRequest
    * @exception wt.util.WTException
    **/
   //##end newECRequest%newECRequestf.doc

   public static ECRequest newECRequest()
            throws WTException {
      //##begin newECRequest%newECRequestf.body preserve=no

      ECRequest instance = new ECRequest();
      instance.initialize();
      return instance;
      //##end newECRequest%newECRequestf.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
