// Generated ECRService%4C74DF90037A: ? 08/26/10 09:28:39
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ecr;

import java.lang.String;
import java.util.HashMap;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
import java.io.Externalizable;  // Preserved unmodeled dependency
import java.io.IOException;  // Preserved unmodeled dependency
import java.io.ObjectInput;  // Preserved unmodeled dependency
import java.io.ObjectOutput;  // Preserved unmodeled dependency
import java.lang.ClassNotFoundException;  // Preserved unmodeled dependency
import java.lang.String;  // Preserved unmodeled dependency
import ext.psk.ecm.ecr.ECRHelper;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
import java.lang.String;  // Preserved unmodeled dependency
import java.util.HashMap;  // Preserved unmodeled dependency
import wt.util.WTException;  // Preserved unmodeled dependency
import ext.psk.ecm.ecr.ECRHelper;  // Preserved unmodeled dependency
import java.lang.String;  // Preserved unmodeled dependency
import wt.util.WTException;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
//##end user.imports

//##begin ECRService%4C74DF90037A.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end ECRService%4C74DF90037A.doc

@RemoteInterface
public interface ECRService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createECR%4C75B4BD00EA.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createECR%4C75B4BD00EA.doc

   public String createECR( HashMap form )
            throws WTException;

   //##begin updateECR%4C75B4C4036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateECR%4C75B4C4036B.doc

   public String updateECR( HashMap form )
            throws WTException;

   //##begin deleteECR%4C75B4CC0242.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteECR%4C75B4CC0242.doc

   public String deleteECR( HashMap form )
            throws WTException;

   //##begin viewECR%4C75B4D80203.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewECR%4C75B4D80203.doc

   public HashMap viewECR( HashMap form )
            throws WTException;

   //##begin searchECR%4C75B4E7001F.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchECR%4C75B4E7001F.doc

   public HashMap searchECR( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
