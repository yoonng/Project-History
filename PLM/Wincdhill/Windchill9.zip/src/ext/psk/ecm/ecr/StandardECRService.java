// Generated StandardECRService%4C74DEEC0271: ? 10/06/10 17:44:45
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.ecm.ecr;

import ext.psk.ecm.ecr.ECRService;
import java.io.Serializable;
import java.lang.String;
import java.util.HashMap;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import java.io.IOException;  // Preserved unmodeled dependency
import java.io.ObjectInput;  // Preserved unmodeled dependency
import java.io.ObjectOutput;  // Preserved unmodeled dependency
import java.lang.ClassNotFoundException;  // Preserved unmodeled dependency
import ext.psk.ecm.ecr.ECRHelper;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
import wt.session.SessionHelper;
import wt.team.TeamTemplate;

import java.io.Externalizable;  // Preserved unmodeled dependency
import ext.psk.ecm.eo.EOAlphaForm;
import ext.psk.util.CommonUtil;
import ext.psk.util.LdapSearchUser;
import ext.psk.util.PSKCommonUtil;
import ext.psk.util.PageControl;  // Preserved unmodeled dependency
import ext.psk.util.upload.PLMContentHelper;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.*;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.org.OrganizationServicesHelper;

import wt.change2.AddressedBy2;
import wt.change2.ChangeNoticeComplexity;  // Preserved unmodeled dependency
import wt.change2.RelevantRequestData2;
import wt.clients.folder.FolderTaskLogic;  // Preserved unmodeled dependency
import wt.fc.PersistenceHelper;  // Preserved unmodeled dependency
import wt.fc.ReferenceFactory;  // Preserved unmodeled dependency
import wt.folder.Folder;  // Preserved unmodeled dependency
import wt.folder.FolderEntry;  // Preserved unmodeled dependency
import wt.folder.FolderHelper;  // Preserved unmodeled dependency
import wt.inf.container.WTContainerRef;  // Preserved unmodeled dependency
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;  // Preserved unmodeled dependency
import wt.org.WTPrincipalReference;  // Preserved unmodeled dependency
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;  // Preserved unmodeled dependency
import wt.pom.Transaction;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency
//##end user.imports

//##begin StandardECRService%4C74DEEC0271.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardECRService</code> static factory method(s),
 * not the <code>StandardECRService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardECRService%4C74DEEC0271.doc

public class StandardECRService extends StandardManager implements ECRService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.ecm.ecr.ecrResource";
   private static final String CLASSNAME = StandardECRService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardECRService%newStandardECRServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardECRService
    * @exception wt.util.WTException
    **/
   //##end newStandardECRService%newStandardECRServicef.doc

   public static StandardECRService newStandardECRService()
            throws WTException {
      //##begin newStandardECRService%newStandardECRServicef.body preserve=no

      StandardECRService instance = new StandardECRService();
      instance.initialize();
      return instance;
      //##end newStandardECRService%newStandardECRServicef.body
   }

   //##begin createECR%4C75B4BD00EA.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createECR%4C75B4BD00EA.doc

   public String createECR( HashMap form )
            throws WTException {
      //##begin createECR%4C75B4BD00EA.body preserve=yes
	   ECRequest ecrForm = ECRequest.newECRequest();
	   ReferenceFactory rf = new ReferenceFactory();

	   String result = CommonUtil.SUCC;

	   Transaction trx = new Transaction();
	   try {
	       trx.start();

	       String sNumber            = (String) form.get("number");
	       String sName              = (String) form.get("name");
	       String sChangeReason     = (String) form.get("changeReason");
	       String sDepartment        = (String) form.get("department");
	       
	       String sCustomerSite 		= (String) form.get("customerSite");
	       String sCompleteReqDate   = (String) form.get("completeReqDate");
	       String sReferenceNumber   = (String) form.get("referenceNumber");
	       
	       String sImprovementEffect = (String) form.get("improvementEffect");
	       String sNoEpi     			= (String) form.get("noEpi");
	       String sRemark          		= (String) form.get("remark");
	       String sAsIsComment          = (String) form.get("asisComment");
	       String sRecommendation       = (String) form.get("recommendation");
	       
	       WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

	       if (sNumber != null && !sNumber.equals("")) ecrForm.setNumber(sNumber); // Ecr No
	       if (sName != null && !sName.equals("")) ecrForm.setName(sName); // Ecr
	       if (sChangeReason != null && !sChangeReason.equals("")) ecrForm.setChangeReason(sChangeReason); // change reason A
	       if (sDepartment != null && !sDepartment.equals("")) ecrForm.setDepartment(sDepartment); // creator's department
	       
	       System.out.println( "Customer Site : " + sCustomerSite);
	       
	       if (sCustomerSite != null && !sCustomerSite.equals("")) ecrForm.setCustomerSite(sCustomerSite); // stock management
	       if (sCompleteReqDate != null && !sCompleteReqDate.equals("")) ecrForm.setCompleteReqDate( CommonUtil.formatString2Timestamp( sCompleteReqDate, "yyyy-MM-dd") ); // EO content
	       if (sReferenceNumber != null && !sReferenceNumber.equals("")) ecrForm.setReferenceNumber(sReferenceNumber); // EO type
	       
	       if (sImprovementEffect != null && !sImprovementEffect.equals("")) ecrForm.setImprovementEffect(sImprovementEffect); // need evr
	       if (sNoEpi != null && !sNoEpi.equals("")) ecrForm.setNoEpi(sNoEpi);
	       if (sAsIsComment != null && !sAsIsComment.equals("")) ecrForm.setAsIsComment(sAsIsComment);
	       if (sRecommendation != null && !sRecommendation.equals("")) ecrForm.setRecommendation(sRecommendation);
	       if (sRemark != null && !sRemark.equals("")) ecrForm.setRemark(sRemark);

			// set Number
	        String eoNumber = "ER" + CommonUtil.getCurrentTime("yyMM") + CommonUtil.getSeq("ECR_SEQ");
	        ecrForm.setNumber(eoNumber);
	       
	       // save content
	        String liftCycle = "LC_PSK_ECM";

	       // Folder && LifeCycle Setting
	       // WTContainer DefaultContainer = PSKCommonUtil.getDefaultFolder();
//	       Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
//	       FolderHelper.assignLocation((FolderEntry) ecrForm, folder);
//	       PDMLinkProduct pskProduct = PSKCommonUtil.getPDMLinkProduct();
//	       WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(pskProduct);
	        

	       WTLibrary product = PSKCommonUtil.getWTLibrary("Document");
	       WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(product);

	       String yy = CommonUtil.getCurrentTime("yyyy");
	       String mm = CommonUtil.getCurrentTime("MM");
	       String sFolderPath = "/Default/ECR/" + yy + "/" + mm;

	       //Folder assign
	       Folder folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
	       FolderHelper.assignLocation((FolderEntry) ecrForm, folder);
	        
	       ecrForm.setContainer(product);
	       LifeCycleHelper.setLifeCycle(ecrForm, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

	       String teamName = "PSK_APPROVE_TEMPLATE";
	       TeamTemplate mainTeam = CommonUtil.getTeamTemplate(teamName);

	       try {
	    	   ecrForm = (ECRequest) wt.team.TeamHelper.setTeamTemplate(ecrForm, mainTeam);
	       } catch(WTPropertyVetoException pve) {
	    	   //pve.printStackTrace();
	    	   throw new WTException(pve);
	       }

			WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();

			ecrForm = (ECRequest) PersistenceHelper.manager.save(ecrForm);

			SessionHelper.manager.setPrincipal(orgPrincipal.getName());

	       //ECR <-> Part Link : review Item(Part)
	       String[] sPartOid = (String[]) form.get("reviewItem");
	       if( sPartOid != null && (sPartOid.length > 0) ) {
	    	   for(int j=0; j<sPartOid.length; j++) {
	    		   WTPart wtPart = (WTPart) rf.getReference(sPartOid[j]).getObject();
	    		   RelevantRequestData2 ecrLink = RelevantRequestData2.newRelevantRequestData2(wtPart, ecrForm);
	
	    		   ecrLink = (RelevantRequestData2) PersistenceHelper.manager.save(ecrLink);
	    	   }
	       }

	       Vector addFiles			 = (Vector) form.get("addFiles");
	       Vector delFiles			 = (Vector) form.get("fileId");
	       Vector fileDescVec 		 = new Vector();
		   for(int i=0;i<addFiles.size();i++){
			   fileDescVec.add("");
		   }
		   PLMContentHelper.service.updateContent(ecrForm, addFiles, delFiles, fileDescVec, false);
	       
	       result += " : " + ecrForm.getNumber();
	       System.out.println("@ created ECRequest =" + result);

	       trx.commit();

	   } catch (Exception e) {
	       trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();

	   } finally {
	       trx = null;
	   }
	   return result;
      //##end createECR%4C75B4BD00EA.body
   }

   //##begin updateECR%4C75B4C4036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateECR%4C75B4C4036B.doc

   public String updateECR( HashMap form )
            throws WTException {
      //##begin updateECR%4C75B4C4036B.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();

	   String result = CommonUtil.SUCC;

	   Transaction trx = new Transaction();
	   try {
	       trx.start();
	       
	       String sOid = (String) form.get("oid");
	       ECRequest ecrForm = (ECRequest) rf.getReference(sOid).getObject();

	       String sNumber            = (String) form.get("number");
	       String sName              = (String) form.get("name");
	       String sChangeReason     = (String) form.get("changeReason");
	       String sDepartment        = (String) form.get("department");
	       
	       String sCustomerSite 		= (String) form.get("customerSite");
	       String sCompleteReqDate   = (String) form.get("completeReqDate");
	       String sReferenceNumber   = (String) form.get("referenceNumber");
	       
	       String sImprovementEffect = (String) form.get("improvementEffect");
	       String sNoEpi     			= (String) form.get("noEpi");
	       String sRemark          		= (String) form.get("remark");
	       String sAsIsComment          = (String) form.get("asisComment");
	       String sRecommendation       = (String) form.get("recommendation");
	       
	       WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

	       if (sNumber != null && !sNumber.equals("")) ecrForm.setNumber(sNumber); // Ecr No
	       if (sName != null && !sName.equals("")) ecrForm.setName(sName); // Ecr
	       if (sChangeReason != null && !sChangeReason.equals("")) ecrForm.setChangeReason(sChangeReason); // change reason A
	       if (sDepartment != null && !sDepartment.equals("")) ecrForm.setDepartment(sDepartment); // creator's department
	       
	       System.out.println( "Customer Site : " + sCustomerSite);
	       
	       if (sCustomerSite != null && !sCustomerSite.equals("")) ecrForm.setCustomerSite(sCustomerSite); // stock management
	       if (sCompleteReqDate != null && !sCompleteReqDate.equals("")) ecrForm.setCompleteReqDate( CommonUtil.formatString2Timestamp( sCompleteReqDate, "yyyy-MM-dd") ); // EO content
	       if (sReferenceNumber != null && !sReferenceNumber.equals("")) ecrForm.setReferenceNumber(sReferenceNumber); // EO type
	       
	       if (sImprovementEffect != null && !sImprovementEffect.equals("")) ecrForm.setImprovementEffect(sImprovementEffect); // need evr
	       if (sNoEpi != null && !sNoEpi.equals("")) ecrForm.setNoEpi(sNoEpi);
	       if (sAsIsComment != null && !sAsIsComment.equals("")) ecrForm.setAsIsComment(sAsIsComment);
	       if (sRecommendation != null && !sRecommendation.equals("")) ecrForm.setRecommendation(sRecommendation);
	       if (sRemark != null && !sRemark.equals("")) ecrForm.setRemark(sRemark);

	       //save content
	       ecrForm = (ECRequest) PersistenceHelper.manager.save(ecrForm);

	       // delete old link 
	       this.deleteRequestData2Link(ecrForm.getPersistInfo().getObjectIdentifier().getId() );

			//ECR <-> Part Link
	       String[] sPartOid = (String[]) form.get("reviewItem");
	       if( sPartOid != null && (sPartOid.length > 0) ) {
	    	   for(int j=0; j<sPartOid.length; j++) {
	    		   WTPart wtPart = (WTPart) rf.getReference(sPartOid[j]).getObject();
	    		   RelevantRequestData2 ecrLink = RelevantRequestData2.newRelevantRequestData2(wtPart, ecrForm);
	
	    		   ecrLink = (RelevantRequestData2) PersistenceHelper.manager.save(ecrLink);
	    	   }
	       }
	       
	       Vector addFiles			 = (Vector) form.get("addFiles");
	       Vector delFiles			 = (Vector) form.get("fileId");
	       Vector fileDescVec 		 = new Vector();
		   for(int i=0;i<addFiles.size();i++){
			   fileDescVec.add("");
		   }
		   PLMContentHelper.service.updateContent(ecrForm, addFiles, delFiles, fileDescVec, false);
	       
	       result += " : " + ecrForm.getNumber();
	       System.out.println("@ created ECRequest =" + result);

	       trx.commit();

	   } catch (Exception e) {
	       trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();
	       //throw new WTException(e);

	   } finally {
	       trx = null;
	   }
	   return result;
      //##end updateECR%4C75B4C4036B.body
   }

   //##begin deleteECR%4C75B4CC0242.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteECR%4C75B4CC0242.doc

   public String deleteECR( HashMap form )
            throws WTException {
      //##begin deleteECR%4C75B4CC0242.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String result = CommonUtil.SUCC;
	   Transaction trx = new Transaction();
	   
	   try {
		   trx.start();
		   String sOid = (String) form.get("oid");
	       ECRequest ecrForm = (ECRequest) rf.getReference(sOid).getObject();
	       
	       this.deleteRequestData2Link( ecrForm.getPersistInfo().getObjectIdentifier().getId() );
	       
	       PersistenceHelper.manager.delete(ecrForm);

	       trx.commit();

	   } catch(Exception e){
		   trx.rollback();
	       e.printStackTrace();
	       result = CommonUtil.FAIL + " : " + e.getMessage();
	   } finally {
		   trx = null;
	   }

	   return result;
      //##end deleteECR%4C75B4CC0242.body
   }

   //##begin viewECR%4C75B4D80203.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewECR%4C75B4D80203.doc

   public HashMap viewECR( HashMap form )
            throws WTException {
      //##begin viewECR%4C75B4D80203.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String sOid = (String) form.get("oid");

	   ECRequest ecrForm = (ECRequest) rf.getReference(sOid).getObject();
	   Vector partList = getRequestData2Link(ecrForm.getPersistInfo().getObjectIdentifier().getId() );
	   HashMap ecrMap = new HashMap();

	   ecrMap.put("ecrForm", ecrForm);
	   ecrMap.put("partList", partList);
	   
	   return ecrMap;
      //##end viewECR%4C75B4D80203.body
   }

   //##begin searchECR%4C75B4E7001F.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchECR%4C75B4E7001F.doc

   public HashMap searchECR( HashMap form )
            throws WTException {
      //##begin searchECR%4C75B4E7001F.body preserve=yes
	   PagingQueryResult pagingResults = null;
	   HashMap results = new HashMap();

	   String sCmd = (String) form.get("cmd");
	   String sPage = (String) form.get("page");
	   String sTotalPage = (String) form.get("totalPage");
	   String sSessionID = (String) form.get("sessionID");

       String sNumber            = (String) form.get("shNumber");
       String sName              = (String) form.get("shName");
       
       String sState     = (String) form.get("shApprovalStatus");
       String sImprovementEffect = (String) form.get("shImprovementEffect");
       
       String sChangeReason     = (String) form.get("shChangeReason");
       
       String sFromRegDate   = (String) form.get("shFromRegDate");
       String sToRegDate   = (String) form.get("shToRegDate");
       
		String sCreatorName = (String) form.get("shIssueUserNm");	
		String sCreator = "";
		if( sCreatorName != null && !sCreatorName.equals("") ) {
			LdapSearchUser searchUserId = new LdapSearchUser();

			sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
		}
		
		String sFromUpDate   = (String) form.get("shFromUpDate");
		String sToUpDate   = (String) form.get("shToUpDate");
       
		String sDepartment   = (String) form.get("shDepartment");

	   try {
	       QuerySpec query = new QuerySpec();
	       query.setAdvancedQueryEnabled(true);

	       if (query.getConditionCount() > 0) query.appendAnd();

	       Class classType = ECRequest.class;
	       int pskChangeIndex = query.appendClassList(classType, true);

	       query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });

			if (sNumber != null && !sNumber.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, ECRequest.NUMBER, SearchCondition.LIKE,  "%" + sNumber + "%"), new int[] { pskChangeIndex });
			}

			if (sName != null && !sName.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				
				query.appendWhere(new SearchCondition(classType, ECRequest.NAME, SearchCondition.LIKE, "%" + sName + "%"), new int[] { pskChangeIndex });
			}
			
			System.out.println("sState : " +  sState );
			
			if (sState != null && !sState.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
			}
			
			if ( sImprovementEffect != null && !sImprovementEffect.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, ECRequest.IMPROVEMENT_EFFECT, SearchCondition.EQUAL, sImprovementEffect), new int[] { pskChangeIndex });
			}
			
			if (sChangeReason != null && !sChangeReason.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				
				query.appendWhere(new SearchCondition(classType, ECRequest.CHANGE_REASON, SearchCondition.EQUAL, sChangeReason), new int[] { pskChangeIndex });
			}
			
			if (sCreator != null && !sCreator.equals("")) {
				long lcreator = 0;
				WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
				if( creator != null ) {
					lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
	
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
				}
			}
						
			//RegistDate from to Start
			if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
			}
	          
			if ( sToRegDate != null && !sToRegDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
			}
			//RegistDate from to End
			
			//UpdateDate from to Start
			if ( sFromUpDate != null && !sFromUpDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromUpDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
			}
	          
			if ( sToUpDate != null && !sToUpDate.equals("") ) {
				if (query.getConditionCount()>0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToUpDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
			}
			//UpdateDate From To End
			
			if (sDepartment != null && !sDepartment.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "writeDept", SearchCondition.LIKE, "%" + sDepartment + "%"), new int[] { pskChangeIndex });
			}
			
			if( sCmd.equals("listECRCCB") ) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, "CCBREVIEW"), new int[] { pskChangeIndex });
			}
			
	       ClassAttribute classattribute = new ClassAttribute();
	       OrderBy orderby = null;
	       classattribute = new ClassAttribute(classType, "thePersistInfo.createStamp");
	       orderby = new OrderBy(classattribute, true);

	       query.appendOrderBy(orderby, new int[] { 0 });

	       //System.out.println("## REQUEST Query:" + query.toString());

	       QueryResult queryResult = PersistenceHelper.manager.find(query);

	       if( !sCmd.equals("listECRCCB") ) {
		       if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
		           pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
		       } else if (sCmd != null && sCmd.equals("EXPORT")) {
		           pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
		       } else {
		           int PAGE = Integer.parseInt(sPage);
		           long pagingSessionID = Long.parseLong(sSessionID);
		           pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
		       }
		       
		       results.put("results", pagingResults);
	       } else {
	    	   results.put("results", queryResult);
	    	   
	       }
	       
	   } catch (Exception e) {
	       e.printStackTrace();
	   }	   

	   return results;
      //##end searchECR%4C75B4E7001F.body
   }

   //##begin user.operations preserve=yes
	public Vector getRequestData2Link(long Oid) throws WTException {
		Vector results = new Vector();
		RelevantRequestData2 link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = RelevantRequestData2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class ecrType = ECRequest.class;
			int ecrIndex = query.appendClassList(ecrType, false);

			query.appendJoin(linkIndex, RelevantRequestData2.CHANGE_REQUEST2_ROLE, ecrIndex);

			query.appendWhere(new SearchCondition(ecrType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { ecrIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (RelevantRequestData2)obj[0];
					
					results.add(link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
			
		return results;
	}
	
	public void deleteRequestData2Link(long Oid) throws WTException {
		try {
			Vector parts = getRequestData2Link(Oid);
			RelevantRequestData2 links = null;
			
			for(int i=0; i<parts.size(); i++) {
				links = (RelevantRequestData2) parts.get(i);
				
				PersistenceHelper.manager.delete(links);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
	}
   //##end user.operations
}
