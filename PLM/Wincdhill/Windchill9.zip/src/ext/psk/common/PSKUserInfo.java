// Generated PSKUserInfo%4C7DFE5100CB: ? 09/01/10 16:48:32
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import wt.fc.ObjectReference;
import wt.fc.WTObject;
import wt.org.WTUser;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin PSKUserInfo%4C7DFE5100CB.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newPSKUserInfo</code> static factory method(s), not the
 * <code>PSKUserInfo</code> constructor, to construct instances of this
 * class.  Instances must be constructed using the static factory(s), in
 * order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end PSKUserInfo%4C7DFE5100CB.doc

public class PSKUserInfo extends WTObject implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.common.commonResource";
   private static final String CLASSNAME = PSKUserInfo.class.getName();

   //##begin ID%ID.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end ID%ID.doc
   public static final String ID = "id";

   private static int ID_UPPER_LIMIT = -1;
   private String id;

   //##begin KR_NAME%KR_NAME.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end KR_NAME%KR_NAME.doc
   public static final String KR_NAME = "krName";

   private static int KR_NAME_UPPER_LIMIT = -1;
   private String krName;

   //##begin EN_NAME%EN_NAME.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EN_NAME%EN_NAME.doc
   public static final String EN_NAME = "enName";

   private static int EN_NAME_UPPER_LIMIT = -1;
   private String enName;

   //##begin TEL_PHONE%TEL_PHONE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TEL_PHONE%TEL_PHONE.doc
   public static final String TEL_PHONE = "telPhone";

   private static int TEL_PHONE_UPPER_LIMIT = -1;
   private String telPhone;

   //##begin CELL_PHONE%CELL_PHONE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CELL_PHONE%CELL_PHONE.doc
   public static final String CELL_PHONE = "cellPhone";

   private static int CELL_PHONE_UPPER_LIMIT = -1;
   private String cellPhone;

   //##begin INTERNAL_PHONE%INTERNAL_PHONE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end INTERNAL_PHONE%INTERNAL_PHONE.doc
   public static final String INTERNAL_PHONE = "internalPhone";

   private static int INTERNAL_PHONE_UPPER_LIMIT = -1;
   private String internalPhone;

   //##begin SECURE_ID%SECURE_ID.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end SECURE_ID%SECURE_ID.doc
   public static final String SECURE_ID = "secureID";

   private static int SECURE_ID_UPPER_LIMIT = -1;
   private String secureID;

   //##begin KR_ADDRESS%KR_ADDRESS.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end KR_ADDRESS%KR_ADDRESS.doc
   public static final String KR_ADDRESS = "krAddress";

   private static int KR_ADDRESS_UPPER_LIMIT = -1;
   private String krAddress;

   //##begin EN_ADDRESS%EN_ADDRESS.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end EN_ADDRESS%EN_ADDRESS.doc
   public static final String EN_ADDRESS = "enAddress";

   private static int EN_ADDRESS_UPPER_LIMIT = -1;
   private String enAddress;

   //##begin E_MAIL%E_MAIL.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end E_MAIL%E_MAIL.doc
   public static final String E_MAIL = "eMail";

   private static int E_MAIL_UPPER_LIMIT = -1;
   private String eMail;

   //##begin POSITION%POSITION.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end POSITION%POSITION.doc
   public static final String POSITION = "position";

   private static int POSITION_UPPER_LIMIT = -1;
   private String position;

   //##begin TITLE%TITLE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TITLE%TITLE.doc
   public static final String TITLE = "title";

   private static int TITLE_UPPER_LIMIT = -1;
   private String title;

   //##begin TITLE_INDEX%TITLE_INDEX.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TITLE_INDEX%TITLE_INDEX.doc
   public static final String TITLE_INDEX = "titleIndex";

   private static int TITLE_INDEX_UPPER_LIMIT = -1;
   private String titleIndex;

   //##begin IS_RETIREMENT%IS_RETIREMENT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end IS_RETIREMENT%IS_RETIREMENT.doc
   public static final String IS_RETIREMENT = "isRetirement";

   private static int IS_RETIREMENT_UPPER_LIMIT = -1;
   private String isRetirement;

   //##begin RETIREMENT_DATE%RETIREMENT_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RETIREMENT_DATE%RETIREMENT_DATE.doc
   public static final String RETIREMENT_DATE = "retirementDate";

   private static int RETIREMENT_DATE_UPPER_LIMIT = -1;
   private String retirementDate;

   //##begin JOINING_DATE%JOINING_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end JOINING_DATE%JOINING_DATE.doc
   public static final String JOINING_DATE = "joiningDate";

   private static int JOINING_DATE_UPPER_LIMIT = -1;
   private String joiningDate;

   //##begin WT_USER%WT_USER.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end WT_USER%WT_USER.doc
   public static final String WT_USER = "wtUser";


   //##begin WT_USER_REFERENCE%WT_USER_REFERENCE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end WT_USER_REFERENCE%WT_USER_REFERENCE.doc
   public static final String WT_USER_REFERENCE = "wtUserReference";

   private ObjectReference wtUserReference;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = -3924998540469361985L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( cellPhone );
      output.writeObject( eMail );
      output.writeObject( enAddress );
      output.writeObject( enName );
      output.writeObject( id );
      output.writeObject( internalPhone );
      output.writeObject( isRetirement );
      output.writeObject( joiningDate );
      output.writeObject( krAddress );
      output.writeObject( krName );
      output.writeObject( position );
      output.writeObject( retirementDate );
      output.writeObject( secureID );
      output.writeObject( telPhone );
      output.writeObject( title );
      output.writeObject( titleIndex );
      output.writeObject( wtUserReference );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         cellPhone = (String)input.readObject();
         eMail = (String)input.readObject();
         enAddress = (String)input.readObject();
         enName = (String)input.readObject();
         id = (String)input.readObject();
         internalPhone = (String)input.readObject();
         isRetirement = (String)input.readObject();
         joiningDate = (String)input.readObject();
         krAddress = (String)input.readObject();
         krName = (String)input.readObject();
         position = (String)input.readObject();
         retirementDate = (String)input.readObject();
         secureID = (String)input.readObject();
         telPhone = (String)input.readObject();
         title = (String)input.readObject();
         titleIndex = (String)input.readObject();
         wtUserReference = (ObjectReference)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "id", id );
      output.setString( "krName", krName );
      output.setString( "enName", enName );
      output.setString( "telPhone", telPhone );
      output.setString( "cellPhone", cellPhone );
      output.setString( "internalPhone", internalPhone );
      output.setString( "secureID", secureID );
      output.setString( "krAddress", krAddress );
      output.setString( "enAddress", enAddress );
      output.setString( "eMail", eMail );
      output.setString( "position", position );
      output.setString( "title", title );
      output.setString( "titleIndex", titleIndex );
      output.setString( "isRetirement", isRetirement );
      output.setString( "retirementDate", retirementDate );
      output.setString( "joiningDate", joiningDate );
      output.writeObject( "wtUserReference", wtUserReference, wt.fc.ObjectReference.class, true );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      id = input.getString( "id" );
      krName = input.getString( "krName" );
      enName = input.getString( "enName" );
      telPhone = input.getString( "telPhone" );
      cellPhone = input.getString( "cellPhone" );
      internalPhone = input.getString( "internalPhone" );
      secureID = input.getString( "secureID" );
      krAddress = input.getString( "krAddress" );
      enAddress = input.getString( "enAddress" );
      eMail = input.getString( "eMail" );
      position = input.getString( "position" );
      title = input.getString( "title" );
      titleIndex = input.getString( "titleIndex" );
      isRetirement = input.getString( "isRetirement" );
      retirementDate = input.getString( "retirementDate" );
      joiningDate = input.getString( "joiningDate" );
      wtUserReference = (wt.fc.ObjectReference)input.readObject( "wtUserReference", wtUserReference, wt.fc.ObjectReference.class, true );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getId%4C7DFE81030Dg.doc preserve=no
   /**
    * Gets the value of the attribute: ID.
    *
    * @return    String
    **/
   //##end getId%4C7DFE81030Dg.doc

   public String getId() {
      //##begin getId%4C7DFE81030Dg.body preserve=no

      return id;
      //##end getId%4C7DFE81030Dg.body
   }

   //##begin setId%4C7DFE81030Ds.doc preserve=no
   /**
    * Sets the value of the attribute: ID.
    *
    * @param     a_Id
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setId%4C7DFE81030Ds.doc

   public void setId( String a_Id )
            throws WTPropertyVetoException {
      //##begin setId%4C7DFE81030Ds.body preserve=no

      idValidate( a_Id );   // throws exception if not valid
      id = a_Id;
      //##end setId%4C7DFE81030Ds.body
   }

   //##begin idValidate%4C7DFE81030D.doc preserve=no
   /**
    * @param     a_Id
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end idValidate%4C7DFE81030D.doc

   private void idValidate( String a_Id )
            throws WTPropertyVetoException {
      if ( ID_UPPER_LIMIT < 1 ) {
         try { ID_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "id" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { ID_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Id != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Id, ID_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "id" ), String.valueOf( Math.min ( ID_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "id", id, a_Id ) );
      }
   }

   //##begin getKrName%4C7DFF47007Dg.doc preserve=no
   /**
    * Gets the value of the attribute: KR_NAME.
    *
    * @return    String
    **/
   //##end getKrName%4C7DFF47007Dg.doc

   public String getKrName() {
      //##begin getKrName%4C7DFF47007Dg.body preserve=no

      return krName;
      //##end getKrName%4C7DFF47007Dg.body
   }

   //##begin setKrName%4C7DFF47007Ds.doc preserve=no
   /**
    * Sets the value of the attribute: KR_NAME.
    *
    * @param     a_KrName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setKrName%4C7DFF47007Ds.doc

   public void setKrName( String a_KrName )
            throws WTPropertyVetoException {
      //##begin setKrName%4C7DFF47007Ds.body preserve=no

      krNameValidate( a_KrName );   // throws exception if not valid
      krName = a_KrName;
      //##end setKrName%4C7DFF47007Ds.body
   }

   //##begin krNameValidate%4C7DFF47007D.doc preserve=no
   /**
    * @param     a_KrName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end krNameValidate%4C7DFF47007D.doc

   private void krNameValidate( String a_KrName )
            throws WTPropertyVetoException {
      if ( KR_NAME_UPPER_LIMIT < 1 ) {
         try { KR_NAME_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "krName" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { KR_NAME_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_KrName != null && !wt.fc.PersistenceHelper.checkStoredLength( a_KrName, KR_NAME_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "krName" ), String.valueOf( Math.min ( KR_NAME_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "krName", krName, a_KrName ) );
      }
   }

   //##begin getEnName%4C7DFF4F0232g.doc preserve=no
   /**
    * Gets the value of the attribute: EN_NAME.
    *
    * @return    String
    **/
   //##end getEnName%4C7DFF4F0232g.doc

   public String getEnName() {
      //##begin getEnName%4C7DFF4F0232g.body preserve=no

      return enName;
      //##end getEnName%4C7DFF4F0232g.body
   }

   //##begin setEnName%4C7DFF4F0232s.doc preserve=no
   /**
    * Sets the value of the attribute: EN_NAME.
    *
    * @param     a_EnName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEnName%4C7DFF4F0232s.doc

   public void setEnName( String a_EnName )
            throws WTPropertyVetoException {
      //##begin setEnName%4C7DFF4F0232s.body preserve=no

      enNameValidate( a_EnName );   // throws exception if not valid
      enName = a_EnName;
      //##end setEnName%4C7DFF4F0232s.body
   }

   //##begin enNameValidate%4C7DFF4F0232.doc preserve=no
   /**
    * @param     a_EnName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end enNameValidate%4C7DFF4F0232.doc

   private void enNameValidate( String a_EnName )
            throws WTPropertyVetoException {
      if ( EN_NAME_UPPER_LIMIT < 1 ) {
         try { EN_NAME_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "enName" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EN_NAME_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EnName != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EnName, EN_NAME_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "enName" ), String.valueOf( Math.min ( EN_NAME_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "enName", enName, a_EnName ) );
      }
   }

   //##begin getTelPhone%4C7DFF5400CBg.doc preserve=no
   /**
    * Gets the value of the attribute: TEL_PHONE.
    *
    * @return    String
    **/
   //##end getTelPhone%4C7DFF5400CBg.doc

   public String getTelPhone() {
      //##begin getTelPhone%4C7DFF5400CBg.body preserve=no

      return telPhone;
      //##end getTelPhone%4C7DFF5400CBg.body
   }

   //##begin setTelPhone%4C7DFF5400CBs.doc preserve=no
   /**
    * Sets the value of the attribute: TEL_PHONE.
    *
    * @param     a_TelPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTelPhone%4C7DFF5400CBs.doc

   public void setTelPhone( String a_TelPhone )
            throws WTPropertyVetoException {
      //##begin setTelPhone%4C7DFF5400CBs.body preserve=no

      telPhoneValidate( a_TelPhone );   // throws exception if not valid
      telPhone = a_TelPhone;
      //##end setTelPhone%4C7DFF5400CBs.body
   }

   //##begin telPhoneValidate%4C7DFF5400CB.doc preserve=no
   /**
    * @param     a_TelPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end telPhoneValidate%4C7DFF5400CB.doc

   private void telPhoneValidate( String a_TelPhone )
            throws WTPropertyVetoException {
      if ( TEL_PHONE_UPPER_LIMIT < 1 ) {
         try { TEL_PHONE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "telPhone" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TEL_PHONE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_TelPhone != null && !wt.fc.PersistenceHelper.checkStoredLength( a_TelPhone, TEL_PHONE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "telPhone" ), String.valueOf( Math.min ( TEL_PHONE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "telPhone", telPhone, a_TelPhone ) );
      }
   }

   //##begin getCellPhone%4C7DFF630109g.doc preserve=no
   /**
    * Gets the value of the attribute: CELL_PHONE.
    *
    * @return    String
    **/
   //##end getCellPhone%4C7DFF630109g.doc

   public String getCellPhone() {
      //##begin getCellPhone%4C7DFF630109g.body preserve=no

      return cellPhone;
      //##end getCellPhone%4C7DFF630109g.body
   }

   //##begin setCellPhone%4C7DFF630109s.doc preserve=no
   /**
    * Sets the value of the attribute: CELL_PHONE.
    *
    * @param     a_CellPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCellPhone%4C7DFF630109s.doc

   public void setCellPhone( String a_CellPhone )
            throws WTPropertyVetoException {
      //##begin setCellPhone%4C7DFF630109s.body preserve=no

      cellPhoneValidate( a_CellPhone );   // throws exception if not valid
      cellPhone = a_CellPhone;
      //##end setCellPhone%4C7DFF630109s.body
   }

   //##begin cellPhoneValidate%4C7DFF630109.doc preserve=no
   /**
    * @param     a_CellPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end cellPhoneValidate%4C7DFF630109.doc

   private void cellPhoneValidate( String a_CellPhone )
            throws WTPropertyVetoException {
      if ( CELL_PHONE_UPPER_LIMIT < 1 ) {
         try { CELL_PHONE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "cellPhone" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CELL_PHONE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CellPhone != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CellPhone, CELL_PHONE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "cellPhone" ), String.valueOf( Math.min ( CELL_PHONE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "cellPhone", cellPhone, a_CellPhone ) );
      }
   }

   //##begin getInternalPhone%4C7DFF78003Eg.doc preserve=no
   /**
    * Gets the value of the attribute: INTERNAL_PHONE.
    *
    * @return    String
    **/
   //##end getInternalPhone%4C7DFF78003Eg.doc

   public String getInternalPhone() {
      //##begin getInternalPhone%4C7DFF78003Eg.body preserve=no

      return internalPhone;
      //##end getInternalPhone%4C7DFF78003Eg.body
   }

   //##begin setInternalPhone%4C7DFF78003Es.doc preserve=no
   /**
    * Sets the value of the attribute: INTERNAL_PHONE.
    *
    * @param     a_InternalPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setInternalPhone%4C7DFF78003Es.doc

   public void setInternalPhone( String a_InternalPhone )
            throws WTPropertyVetoException {
      //##begin setInternalPhone%4C7DFF78003Es.body preserve=no

      internalPhoneValidate( a_InternalPhone );   // throws exception if not valid
      internalPhone = a_InternalPhone;
      //##end setInternalPhone%4C7DFF78003Es.body
   }

   //##begin internalPhoneValidate%4C7DFF78003E.doc preserve=no
   /**
    * @param     a_InternalPhone
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end internalPhoneValidate%4C7DFF78003E.doc

   private void internalPhoneValidate( String a_InternalPhone )
            throws WTPropertyVetoException {
      if ( INTERNAL_PHONE_UPPER_LIMIT < 1 ) {
         try { INTERNAL_PHONE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "internalPhone" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { INTERNAL_PHONE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_InternalPhone != null && !wt.fc.PersistenceHelper.checkStoredLength( a_InternalPhone, INTERNAL_PHONE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "internalPhone" ), String.valueOf( Math.min ( INTERNAL_PHONE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "internalPhone", internalPhone, a_InternalPhone ) );
      }
   }

   //##begin getSecureID%4C7DFF8600ABg.doc preserve=no
   /**
    * Gets the value of the attribute: SECURE_ID.
    *
    * @return    String
    **/
   //##end getSecureID%4C7DFF8600ABg.doc

   public String getSecureID() {
      //##begin getSecureID%4C7DFF8600ABg.body preserve=no

      return secureID;
      //##end getSecureID%4C7DFF8600ABg.body
   }

   //##begin setSecureID%4C7DFF8600ABs.doc preserve=no
   /**
    * Sets the value of the attribute: SECURE_ID.
    *
    * @param     a_SecureID
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setSecureID%4C7DFF8600ABs.doc

   public void setSecureID( String a_SecureID )
            throws WTPropertyVetoException {
      //##begin setSecureID%4C7DFF8600ABs.body preserve=no

      secureIDValidate( a_SecureID );   // throws exception if not valid
      secureID = a_SecureID;
      //##end setSecureID%4C7DFF8600ABs.body
   }

   //##begin secureIDValidate%4C7DFF8600AB.doc preserve=no
   /**
    * @param     a_SecureID
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end secureIDValidate%4C7DFF8600AB.doc

   private void secureIDValidate( String a_SecureID )
            throws WTPropertyVetoException {
      if ( SECURE_ID_UPPER_LIMIT < 1 ) {
         try { SECURE_ID_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "secureID" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { SECURE_ID_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_SecureID != null && !wt.fc.PersistenceHelper.checkStoredLength( a_SecureID, SECURE_ID_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "secureID" ), String.valueOf( Math.min ( SECURE_ID_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "secureID", secureID, a_SecureID ) );
      }
   }

   //##begin getKrAddress%4C7DFF940138g.doc preserve=no
   /**
    * Gets the value of the attribute: KR_ADDRESS.
    *
    * @return    String
    **/
   //##end getKrAddress%4C7DFF940138g.doc

   public String getKrAddress() {
      //##begin getKrAddress%4C7DFF940138g.body preserve=no

      return krAddress;
      //##end getKrAddress%4C7DFF940138g.body
   }

   //##begin setKrAddress%4C7DFF940138s.doc preserve=no
   /**
    * Sets the value of the attribute: KR_ADDRESS.
    *
    * @param     a_KrAddress
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setKrAddress%4C7DFF940138s.doc

   public void setKrAddress( String a_KrAddress )
            throws WTPropertyVetoException {
      //##begin setKrAddress%4C7DFF940138s.body preserve=no

      krAddressValidate( a_KrAddress );   // throws exception if not valid
      krAddress = a_KrAddress;
      //##end setKrAddress%4C7DFF940138s.body
   }

   //##begin krAddressValidate%4C7DFF940138.doc preserve=no
   /**
    * @param     a_KrAddress
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end krAddressValidate%4C7DFF940138.doc

   private void krAddressValidate( String a_KrAddress )
            throws WTPropertyVetoException {
      if ( KR_ADDRESS_UPPER_LIMIT < 1 ) {
         try { KR_ADDRESS_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "krAddress" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { KR_ADDRESS_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_KrAddress != null && !wt.fc.PersistenceHelper.checkStoredLength( a_KrAddress, KR_ADDRESS_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "krAddress" ), String.valueOf( Math.min ( KR_ADDRESS_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "krAddress", krAddress, a_KrAddress ) );
      }
   }

   //##begin getEnAddress%4C7DFF9E02DEg.doc preserve=no
   /**
    * Gets the value of the attribute: EN_ADDRESS.
    *
    * @return    String
    **/
   //##end getEnAddress%4C7DFF9E02DEg.doc

   public String getEnAddress() {
      //##begin getEnAddress%4C7DFF9E02DEg.body preserve=no

      return enAddress;
      //##end getEnAddress%4C7DFF9E02DEg.body
   }

   //##begin setEnAddress%4C7DFF9E02DEs.doc preserve=no
   /**
    * Sets the value of the attribute: EN_ADDRESS.
    *
    * @param     a_EnAddress
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEnAddress%4C7DFF9E02DEs.doc

   public void setEnAddress( String a_EnAddress )
            throws WTPropertyVetoException {
      //##begin setEnAddress%4C7DFF9E02DEs.body preserve=no

      enAddressValidate( a_EnAddress );   // throws exception if not valid
      enAddress = a_EnAddress;
      //##end setEnAddress%4C7DFF9E02DEs.body
   }

   //##begin enAddressValidate%4C7DFF9E02DE.doc preserve=no
   /**
    * @param     a_EnAddress
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end enAddressValidate%4C7DFF9E02DE.doc

   private void enAddressValidate( String a_EnAddress )
            throws WTPropertyVetoException {
      if ( EN_ADDRESS_UPPER_LIMIT < 1 ) {
         try { EN_ADDRESS_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "enAddress" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { EN_ADDRESS_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EnAddress != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EnAddress, EN_ADDRESS_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "enAddress" ), String.valueOf( Math.min ( EN_ADDRESS_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "enAddress", enAddress, a_EnAddress ) );
      }
   }

   //##begin getEMail%4C7DFFA302BFg.doc preserve=no
   /**
    * Gets the value of the attribute: E_MAIL.
    *
    * @return    String
    **/
   //##end getEMail%4C7DFFA302BFg.doc

   public String getEMail() {
      //##begin getEMail%4C7DFFA302BFg.body preserve=no

      return eMail;
      //##end getEMail%4C7DFFA302BFg.body
   }

   //##begin setEMail%4C7DFFA302BFs.doc preserve=no
   /**
    * Sets the value of the attribute: E_MAIL.
    *
    * @param     a_EMail
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setEMail%4C7DFFA302BFs.doc

   public void setEMail( String a_EMail )
            throws WTPropertyVetoException {
      //##begin setEMail%4C7DFFA302BFs.body preserve=no

      eMailValidate( a_EMail );   // throws exception if not valid
      eMail = a_EMail;
      //##end setEMail%4C7DFFA302BFs.body
   }

   //##begin eMailValidate%4C7DFFA302BF.doc preserve=no
   /**
    * @param     a_EMail
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end eMailValidate%4C7DFFA302BF.doc

   private void eMailValidate( String a_EMail )
            throws WTPropertyVetoException {
      if ( E_MAIL_UPPER_LIMIT < 1 ) {
         try { E_MAIL_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "eMail" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { E_MAIL_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_EMail != null && !wt.fc.PersistenceHelper.checkStoredLength( a_EMail, E_MAIL_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "eMail" ), String.valueOf( Math.min ( E_MAIL_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "eMail", eMail, a_EMail ) );
      }
   }

   //##begin getPosition%4C7DFFA8036Bg.doc preserve=no
   /**
    * Gets the value of the attribute: POSITION.
    *
    * @return    String
    **/
   //##end getPosition%4C7DFFA8036Bg.doc

   public String getPosition() {
      //##begin getPosition%4C7DFFA8036Bg.body preserve=no

      return position;
      //##end getPosition%4C7DFFA8036Bg.body
   }

   //##begin setPosition%4C7DFFA8036Bs.doc preserve=no
   /**
    * Sets the value of the attribute: POSITION.
    *
    * @param     a_Position
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setPosition%4C7DFFA8036Bs.doc

   public void setPosition( String a_Position )
            throws WTPropertyVetoException {
      //##begin setPosition%4C7DFFA8036Bs.body preserve=no

      positionValidate( a_Position );   // throws exception if not valid
      position = a_Position;
      //##end setPosition%4C7DFFA8036Bs.body
   }

   //##begin positionValidate%4C7DFFA8036B.doc preserve=no
   /**
    * @param     a_Position
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end positionValidate%4C7DFFA8036B.doc

   private void positionValidate( String a_Position )
            throws WTPropertyVetoException {
      if ( POSITION_UPPER_LIMIT < 1 ) {
         try { POSITION_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "position" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { POSITION_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Position != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Position, POSITION_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "position" ), String.valueOf( Math.min ( POSITION_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "position", position, a_Position ) );
      }
   }

   //##begin getTitle%4C7E002203D8g.doc preserve=no
   /**
    * Gets the value of the attribute: TITLE.
    *
    * @return    String
    **/
   //##end getTitle%4C7E002203D8g.doc

   public String getTitle() {
      //##begin getTitle%4C7E002203D8g.body preserve=no

      return title;
      //##end getTitle%4C7E002203D8g.body
   }

   //##begin setTitle%4C7E002203D8s.doc preserve=no
   /**
    * Sets the value of the attribute: TITLE.
    *
    * @param     a_Title
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTitle%4C7E002203D8s.doc

   public void setTitle( String a_Title )
            throws WTPropertyVetoException {
      //##begin setTitle%4C7E002203D8s.body preserve=no

      titleValidate( a_Title );   // throws exception if not valid
      title = a_Title;
      //##end setTitle%4C7E002203D8s.body
   }

   //##begin titleValidate%4C7E002203D8.doc preserve=no
   /**
    * @param     a_Title
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end titleValidate%4C7E002203D8.doc

   private void titleValidate( String a_Title )
            throws WTPropertyVetoException {
      if ( TITLE_UPPER_LIMIT < 1 ) {
         try { TITLE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "title" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TITLE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Title != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Title, TITLE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "title" ), String.valueOf( Math.min ( TITLE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "title", title, a_Title ) );
      }
   }

   //##begin getTitleIndex%4C7E0026030Dg.doc preserve=no
   /**
    * Gets the value of the attribute: TITLE_INDEX.
    *
    * @return    String
    **/
   //##end getTitleIndex%4C7E0026030Dg.doc

   public String getTitleIndex() {
      //##begin getTitleIndex%4C7E0026030Dg.body preserve=no

      return titleIndex;
      //##end getTitleIndex%4C7E0026030Dg.body
   }

   //##begin setTitleIndex%4C7E0026030Ds.doc preserve=no
   /**
    * Sets the value of the attribute: TITLE_INDEX.
    *
    * @param     a_TitleIndex
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTitleIndex%4C7E0026030Ds.doc

   public void setTitleIndex( String a_TitleIndex )
            throws WTPropertyVetoException {
      //##begin setTitleIndex%4C7E0026030Ds.body preserve=no

      titleIndexValidate( a_TitleIndex );   // throws exception if not valid
      titleIndex = a_TitleIndex;
      //##end setTitleIndex%4C7E0026030Ds.body
   }

   //##begin titleIndexValidate%4C7E0026030D.doc preserve=no
   /**
    * @param     a_TitleIndex
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end titleIndexValidate%4C7E0026030D.doc

   private void titleIndexValidate( String a_TitleIndex )
            throws WTPropertyVetoException {
      if ( TITLE_INDEX_UPPER_LIMIT < 1 ) {
         try { TITLE_INDEX_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "titleIndex" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TITLE_INDEX_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_TitleIndex != null && !wt.fc.PersistenceHelper.checkStoredLength( a_TitleIndex, TITLE_INDEX_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "titleIndex" ), String.valueOf( Math.min ( TITLE_INDEX_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "titleIndex", titleIndex, a_TitleIndex ) );
      }
   }

   //##begin getIsRetirement%4C7E00BF0203g.doc preserve=no
   /**
    * Gets the value of the attribute: IS_RETIREMENT.
    *
    * @return    String
    **/
   //##end getIsRetirement%4C7E00BF0203g.doc

   public String getIsRetirement() {
      //##begin getIsRetirement%4C7E00BF0203g.body preserve=no

      return isRetirement;
      //##end getIsRetirement%4C7E00BF0203g.body
   }

   //##begin setIsRetirement%4C7E00BF0203s.doc preserve=no
   /**
    * Sets the value of the attribute: IS_RETIREMENT.
    *
    * @param     a_IsRetirement
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setIsRetirement%4C7E00BF0203s.doc

   public void setIsRetirement( String a_IsRetirement )
            throws WTPropertyVetoException {
      //##begin setIsRetirement%4C7E00BF0203s.body preserve=no

      isRetirementValidate( a_IsRetirement );   // throws exception if not valid
      isRetirement = a_IsRetirement;
      //##end setIsRetirement%4C7E00BF0203s.body
   }

   //##begin isRetirementValidate%4C7E00BF0203.doc preserve=no
   /**
    * @param     a_IsRetirement
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end isRetirementValidate%4C7E00BF0203.doc

   private void isRetirementValidate( String a_IsRetirement )
            throws WTPropertyVetoException {
      if ( IS_RETIREMENT_UPPER_LIMIT < 1 ) {
         try { IS_RETIREMENT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "isRetirement" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { IS_RETIREMENT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_IsRetirement != null && !wt.fc.PersistenceHelper.checkStoredLength( a_IsRetirement, IS_RETIREMENT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "isRetirement" ), String.valueOf( Math.min ( IS_RETIREMENT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "isRetirement", isRetirement, a_IsRetirement ) );
      }
   }

   //##begin getRetirementDate%4C7E00D20186g.doc preserve=no
   /**
    * Gets the value of the attribute: RETIREMENT_DATE.
    *
    * @return    String
    **/
   //##end getRetirementDate%4C7E00D20186g.doc

   public String getRetirementDate() {
      //##begin getRetirementDate%4C7E00D20186g.body preserve=no

      return retirementDate;
      //##end getRetirementDate%4C7E00D20186g.body
   }

   //##begin setRetirementDate%4C7E00D20186s.doc preserve=no
   /**
    * Sets the value of the attribute: RETIREMENT_DATE.
    *
    * @param     a_RetirementDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setRetirementDate%4C7E00D20186s.doc

   public void setRetirementDate( String a_RetirementDate )
            throws WTPropertyVetoException {
      //##begin setRetirementDate%4C7E00D20186s.body preserve=no

      retirementDateValidate( a_RetirementDate );   // throws exception if not valid
      retirementDate = a_RetirementDate;
      //##end setRetirementDate%4C7E00D20186s.body
   }

   //##begin retirementDateValidate%4C7E00D20186.doc preserve=no
   /**
    * @param     a_RetirementDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end retirementDateValidate%4C7E00D20186.doc

   private void retirementDateValidate( String a_RetirementDate )
            throws WTPropertyVetoException {
      if ( RETIREMENT_DATE_UPPER_LIMIT < 1 ) {
         try { RETIREMENT_DATE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "retirementDate" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { RETIREMENT_DATE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_RetirementDate != null && !wt.fc.PersistenceHelper.checkStoredLength( a_RetirementDate, RETIREMENT_DATE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "retirementDate" ), String.valueOf( Math.min ( RETIREMENT_DATE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "retirementDate", retirementDate, a_RetirementDate ) );
      }
   }

   //##begin getJoiningDate%4C7E0114030Dg.doc preserve=no
   /**
    * Gets the value of the attribute: JOINING_DATE.
    *
    * @return    String
    **/
   //##end getJoiningDate%4C7E0114030Dg.doc

   public String getJoiningDate() {
      //##begin getJoiningDate%4C7E0114030Dg.body preserve=no

      return joiningDate;
      //##end getJoiningDate%4C7E0114030Dg.body
   }

   //##begin setJoiningDate%4C7E0114030Ds.doc preserve=no
   /**
    * Sets the value of the attribute: JOINING_DATE.
    *
    * @param     a_JoiningDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setJoiningDate%4C7E0114030Ds.doc

   public void setJoiningDate( String a_JoiningDate )
            throws WTPropertyVetoException {
      //##begin setJoiningDate%4C7E0114030Ds.body preserve=no

      joiningDateValidate( a_JoiningDate );   // throws exception if not valid
      joiningDate = a_JoiningDate;
      //##end setJoiningDate%4C7E0114030Ds.body
   }

   //##begin joiningDateValidate%4C7E0114030D.doc preserve=no
   /**
    * @param     a_JoiningDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end joiningDateValidate%4C7E0114030D.doc

   private void joiningDateValidate( String a_JoiningDate )
            throws WTPropertyVetoException {
      if ( JOINING_DATE_UPPER_LIMIT < 1 ) {
         try { JOINING_DATE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "joiningDate" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { JOINING_DATE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_JoiningDate != null && !wt.fc.PersistenceHelper.checkStoredLength( a_JoiningDate, JOINING_DATE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "joiningDate" ), String.valueOf( Math.min ( JOINING_DATE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "joiningDate", joiningDate, a_JoiningDate ) );
      }
   }

   //##begin getWtUser%4C7E014602EEd.doc preserve=no
   /**
    * Gets the object for the association that plays role: WT_USER.
    *
    * @return    WTUser
    **/
   //##end getWtUser%4C7E014602EEd.doc

   public WTUser getWtUser() {
      //##begin getWtUser%4C7E014602EEd.body preserve=no

      if ( wtUserReference == null )
         return null;

      return (WTUser)wtUserReference.getObject();
      //##end getWtUser%4C7E014602EEd.body
   }

   //##begin setWtUser%4C7E014602EEp.doc preserve=no
   /**
    * Sets the object for the association that plays role: WT_USER.
    *
    * @param     a_WtUser
    * @exception wt.util.WTPropertyVetoException
    * @exception wt.util.WTException
    **/
   //##end setWtUser%4C7E014602EEp.doc

   public void setWtUser( WTUser a_WtUser )
            throws WTPropertyVetoException, WTException {
      //##begin setWtUser%4C7E014602EEp.body preserve=no

      setWtUserReference( a_WtUser == null ? null : ObjectReference.newObjectReference( a_WtUser ) );
      //##end setWtUser%4C7E014602EEp.body
   }

   //##begin getWtUserReference%4C7E014602EEg.doc preserve=no
   /**
    * Gets the value of the attribute: WT_USER_REFERENCE.
    *
    * @return    ObjectReference
    **/
   //##end getWtUserReference%4C7E014602EEg.doc

   public ObjectReference getWtUserReference() {
      //##begin getWtUserReference%4C7E014602EEg.body preserve=no

      return wtUserReference;
      //##end getWtUserReference%4C7E014602EEg.body
   }

   //##begin setWtUserReference%4C7E014602EEs.doc preserve=no
   /**
    * Sets the value of the attribute: WT_USER_REFERENCE.
    *
    * @param     a_WtUserReference
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setWtUserReference%4C7E014602EEs.doc

   public void setWtUserReference( ObjectReference a_WtUserReference )
            throws WTPropertyVetoException {
      //##begin setWtUserReference%4C7E014602EEs.body preserve=no

      wtUserReferenceValidate( a_WtUserReference );   // throws exception if not valid
      wtUserReference = a_WtUserReference;
      //##end setWtUserReference%4C7E014602EEs.body
   }

   //##begin wtUserReferenceValidate%4C7E014602EE.doc preserve=no
   /**
    * @param     a_WtUserReference
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end wtUserReferenceValidate%4C7E014602EE.doc

   private void wtUserReferenceValidate( ObjectReference a_WtUserReference )
            throws WTPropertyVetoException {
      if ( a_WtUserReference == null || a_WtUserReference.getReferencedClass() == null ) { // required attribute check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "wtUserReference" ) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.REQUIRED_ATTRIBUTE, args,
               new java.beans.PropertyChangeEvent( this, "wtUserReference", wtUserReference, a_WtUserReference ) );
      }
      if ( a_WtUserReference != null && a_WtUserReference.getReferencedClass() != null &&  // type check
               !( wt.org.WTUser.class.isAssignableFrom( a_WtUserReference.getReferencedClass() ) ) ) {
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "wtUserReference" ), "ObjectReference" };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.WRONG_TYPE, args,
               new java.beans.PropertyChangeEvent( this, "wtUserReference", wtUserReference, a_WtUserReference ) );
      }
   }

   //##begin newPSKUserInfo%newPSKUserInfof.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    PSKUserInfo
    * @exception wt.util.WTException
    **/
   //##end newPSKUserInfo%newPSKUserInfof.doc

   public static PSKUserInfo newPSKUserInfo()
            throws WTException {
      //##begin newPSKUserInfo%newPSKUserInfof.body preserve=no

      PSKUserInfo instance = new PSKUserInfo();
      instance.initialize();
      return instance;
      //##end newPSKUserInfo%newPSKUserInfof.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
