package ext.psk.common.loader;

import java.io.File;
import java.io.IOException;

import ext.psk.common.CommonCode;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import wt.fc.PersistenceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class CommonCodeLoader {

	public static void main(String[] args) {
		if (args.length == 0 || args.length != 1) {
			System.out.println("Usage : java ext.psk.spec.beans.PSKPartTypeCodeLoad loading_File!");
			return;
		}

		CommonCodeLoader loader = new CommonCodeLoader();

		String file = args[0];
		File newfile = null;
		try {
			newfile = new File(file);
			if (!newfile.getName().endsWith(".xls"))
				return;
		} catch (Exception e) {
			return;
		}

		System.out.println(newfile.getName());
		Workbook wb = getWorkbook(newfile);
		loader.load(wb);
		System.exit(0);
	}

	private void printLog(String msg) {
		System.out.println(msg);
	}

	public static Workbook getWorkbook(File file) {
		if (file == null)
			return null;
		try {
			if (!file.getName().endsWith(".xls"))
				return null;
		} catch (Exception e) {
			return null;
		}

		Workbook wb = null;
		try {
			wb = Workbook.getWorkbook(file);
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return wb;
	}

	public static boolean checkLine(Cell[] cell) {
		String value = null;
		try {
			value = cell[0].getContents().trim();
		} catch (ArrayIndexOutOfBoundsException e) {
			e.getMessage();
			return false;
		}
		if (value == null || value.length() == 0)
			return false;
		return true;
	}

	private void load(Workbook wb) {
		Sheet[] sheets = wb.getSheets();
		for (int i = 0; i < sheets.length; i++) {
			printLog("## Sheet[" + i + "]>>>> " + sheets[i].getName());
			int rows = sheets[i].getRows();
			printLog("## rows.length >>>> " + rows);

			for (int j = 2; j < rows; j++) {
				printLog("Load CommonCode!![" + j + " row]");
				createCommonCode(sheets[0].getRow(j), j + 1);
				if (checkLine(sheets[i].getRow(j))) {
				}
			}
		}
	}

	private void createCommonCode(Cell[] row, int i) {
		System.out.println("cell = " + row.length);
		String[] cellValue = new String[12];
		CommonCode makerCode = null;
		for (int j = 0; j < 11; j++) {
			cellValue[j] = getContent(row, j);
		}
		try {
			makerCode = CommonCode.newCommonCode();
			if (cellValue[0] != null && cellValue[0].length() > 0)
				makerCode.setCodeType(cellValue[0]);
			if (cellValue[1] != null && cellValue[1].length() > 0)
				makerCode.setCode(cellValue[1]);
			if (cellValue[2] != null && cellValue[2].length() > 0)
				makerCode.setCodeName(cellValue[2]);
			if (cellValue[3] != null && cellValue[3].length() > 0)
				makerCode.setCodeNameEn(cellValue[3]);
			if (cellValue[4] != null && cellValue[4].length() > 0)
				makerCode.setCodeValue(cellValue[4]);

			if (cellValue[5] != null && cellValue[5].length() > 0)
				makerCode.setCodeValueEn(cellValue[5]);
			if (cellValue[6] != null && cellValue[6].length() > 0)
				makerCode.setIsDelete(cellValue[6]);
			if (cellValue[7] != null && cellValue[7].length() > 0)
				makerCode.setDescription(cellValue[7]);

			if (cellValue[8] != null && cellValue[8].length() > 0)
				makerCode.setCodeOne(cellValue[8]);
			if (cellValue[9] != null && cellValue[9].length() > 0)
				makerCode.setCodeTwo(cellValue[9]);
			if (cellValue[10] != null && cellValue[10].length() > 0)
				makerCode.setCodeThree(cellValue[10]);
			// } else
			// return;

			makerCode = (CommonCode) PersistenceHelper.manager.save(makerCode);
		} catch (WTException e) {
			e.printStackTrace();
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		}
		if (makerCode != null)
			System.out.println(makerCode + " was created!!!");
		else
			System.out.println(row + " line load failed!!!");
	}

	public static String getContent(Cell[] cell, int idx) {
		try {
			String val = cell[idx].getContents();
			if (val == null)
				return "";
			return val.trim();
		} catch (ArrayIndexOutOfBoundsException e) {
		}
		return "";
	}

}
