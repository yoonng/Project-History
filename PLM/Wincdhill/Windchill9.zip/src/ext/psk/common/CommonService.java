// Generated CommonService%4C7C9D8E001F: ? 10/18/10 11:01:36
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import java.lang.String;
import java.util.HashMap;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin CommonService%4C7C9D8E001F.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end CommonService%4C7C9D8E001F.doc

@RemoteInterface
public interface CommonService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createCode%4C7C9E26007D.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createCode%4C7C9E26007D.doc

   public String createCode( HashMap form )
            throws WTException;

   //##begin deleteCode%4C7C9E3E036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteCode%4C7C9E3E036B.doc

   public String deleteCode( HashMap form )
            throws WTException;

   //##begin updateCode%4C7C9E820280.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateCode%4C7C9E820280.doc

   public String updateCode( HashMap form )
            throws WTException;

   //##begin searchCode%4C7C9E930290.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchCode%4C7C9E930290.doc

   public HashMap searchCode( HashMap form )
            throws WTException;

   //##begin createLinkCode%4C7C9EA60232.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createLinkCode%4C7C9EA60232.doc

   public String createLinkCode( HashMap form )
            throws WTException;

   //##begin deleteLinkCode%4C7C9ED10128.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteLinkCode%4C7C9ED10128.doc

   public String deleteLinkCode( HashMap form )
            throws WTException;

   //##begin searchChildCode%4C7C9EDE005D.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchChildCode%4C7C9EDE005D.doc

   public HashMap searchChildCode( HashMap form )
            throws WTException;

   //##begin createPSKUserInfo%4C7E033802EE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createPSKUserInfo%4C7E033802EE.doc

   public String createPSKUserInfo( HashMap form )
            throws WTException;

   //##begin updatePSKUserInfo%4C7E03630399.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updatePSKUserInfo%4C7E03630399.doc

   public String updatePSKUserInfo( HashMap form )
            throws WTException;

   //##begin deletePSKUserInfo%4C7E03740167.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deletePSKUserInfo%4C7E03740167.doc

   public String deletePSKUserInfo( HashMap form )
            throws WTException;

   //##begin searchPSKUserInfo%4C7E0387004E.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchPSKUserInfo%4C7E0387004E.doc

   public HashMap searchPSKUserInfo( HashMap form )
            throws WTException;

   //##begin createInterface%4CBBA80F0112.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createInterface%4CBBA80F0112.doc

   public String createInterface( HashMap form )
            throws WTException;

   //##begin updateInterface%4CBBA829017F.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateInterface%4CBBA829017F.doc

   public String updateInterface( HashMap form )
            throws WTException;

   //##begin restartInterface%4CBBA8390076.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end restartInterface%4CBBA8390076.doc

   public String restartInterface( HashMap form )
            throws WTException;

   //##begin searchInterface%4CBBA84903A2.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchInterface%4CBBA84903A2.doc

   public HashMap searchInterface( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   
   //##end user.operations
}
