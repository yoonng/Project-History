// Generated InterfaceState%4CBBA79A0151: ? 11/12/10 14:44:14
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import java.sql.Timestamp;
import wt.fc.WTObject;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin InterfaceState%4CBBA79A0151.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newInterfaceState</code> static factory method(s), not
 * the <code>InterfaceState</code> constructor, to construct instances of
 * this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end InterfaceState%4CBBA79A0151.doc

public class InterfaceState extends WTObject implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.common.commonResource";
   private static final String CLASSNAME = InterfaceState.class.getName();

   //##begin CATEGORY%CATEGORY.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CATEGORY%CATEGORY.doc
   public static final String CATEGORY = "category";

   private static int CATEGORY_UPPER_LIMIT = -1;
   private String category;

   //##begin TITLE%TITLE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end TITLE%TITLE.doc
   public static final String TITLE = "title";

   private static int TITLE_UPPER_LIMIT = -1;
   private String title;

   //##begin RESULT%RESULT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RESULT%RESULT.doc
   public static final String RESULT = "result";

   private static int RESULT_UPPER_LIMIT = -1;
   private String result;

   //##begin LOG%LOG.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end LOG%LOG.doc
   public static final String LOG = "log";

   private static int LOG_UPPER_LIMIT = -1;
   private String log;

   //##begin RUN_DATE%RUN_DATE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end RUN_DATE%RUN_DATE.doc
   public static final String RUN_DATE = "runDate";

   private Timestamp runDate;

   //##begin WT_OBJECT%WT_OBJECT.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end WT_OBJECT%WT_OBJECT.doc
   public static final String WT_OBJECT = "wtObject";

   private static int WT_OBJECT_UPPER_LIMIT = -1;
   private String wtObject;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 1576851724110188064L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( category );
      output.writeObject( log );
      output.writeObject( result );
      output.writeObject( runDate );
      output.writeObject( title );
      output.writeObject( wtObject );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         category = (String)input.readObject();
         log = (String)input.readObject();
         result = (String)input.readObject();
         runDate = (Timestamp)input.readObject();
         title = (String)input.readObject();
         wtObject = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "category", category );
      output.setString( "title", title );
      output.setString( "result", result );
      output.setString( "log", log );
      output.setTimestamp( "runDate", runDate );
      output.setString( "wtObject", wtObject );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      category = input.getString( "category" );
      title = input.getString( "title" );
      result = input.getString( "result" );
      log = input.getString( "log" );
      runDate = input.getTimestamp( "runDate" );
      wtObject = input.getString( "wtObject" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getCategory%4CBBA7B8019Fg.doc preserve=no
   /**
    * Gets the value of the attribute: CATEGORY.
    *
    * @return    String
    **/
   //##end getCategory%4CBBA7B8019Fg.doc

   public String getCategory() {
      //##begin getCategory%4CBBA7B8019Fg.body preserve=no

      return category;
      //##end getCategory%4CBBA7B8019Fg.body
   }

   //##begin setCategory%4CBBA7B8019Fs.doc preserve=no
   /**
    * Sets the value of the attribute: CATEGORY.
    *
    * @param     a_Category
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCategory%4CBBA7B8019Fs.doc

   public void setCategory( String a_Category )
            throws WTPropertyVetoException {
      //##begin setCategory%4CBBA7B8019Fs.body preserve=no

      categoryValidate( a_Category );   // throws exception if not valid
      category = a_Category;
      //##end setCategory%4CBBA7B8019Fs.body
   }

   //##begin categoryValidate%4CBBA7B8019F.doc preserve=no
   /**
    * @param     a_Category
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end categoryValidate%4CBBA7B8019F.doc

   private void categoryValidate( String a_Category )
            throws WTPropertyVetoException {
      if ( CATEGORY_UPPER_LIMIT < 1 ) {
         try { CATEGORY_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "category" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CATEGORY_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Category != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Category, CATEGORY_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "category" ), String.valueOf( Math.min ( CATEGORY_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "category", category, a_Category ) );
      }
   }

   //##begin getTitle%4CBBA7C10095g.doc preserve=no
   /**
    * Gets the value of the attribute: TITLE.
    *
    * @return    String
    **/
   //##end getTitle%4CBBA7C10095g.doc

   public String getTitle() {
      //##begin getTitle%4CBBA7C10095g.body preserve=no

      return title;
      //##end getTitle%4CBBA7C10095g.body
   }

   //##begin setTitle%4CBBA7C10095s.doc preserve=no
   /**
    * Sets the value of the attribute: TITLE.
    *
    * @param     a_Title
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setTitle%4CBBA7C10095s.doc

   public void setTitle( String a_Title )
            throws WTPropertyVetoException {
      //##begin setTitle%4CBBA7C10095s.body preserve=no

      titleValidate( a_Title );   // throws exception if not valid
      title = a_Title;
      //##end setTitle%4CBBA7C10095s.body
   }

   //##begin titleValidate%4CBBA7C10095.doc preserve=no
   /**
    * @param     a_Title
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end titleValidate%4CBBA7C10095.doc

   private void titleValidate( String a_Title )
            throws WTPropertyVetoException {
      if ( TITLE_UPPER_LIMIT < 1 ) {
         try { TITLE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "title" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { TITLE_UPPER_LIMIT = 1000; } // resort to modeled value
      }
      if ( a_Title != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Title, TITLE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "title" ), String.valueOf( Math.min ( TITLE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "title", title, a_Title ) );
      }
   }

   //##begin getResult%4CBBA7C90095g.doc preserve=no
   /**
    * Gets the value of the attribute: RESULT.
    *
    * @return    String
    **/
   //##end getResult%4CBBA7C90095g.doc

   public String getResult() {
      //##begin getResult%4CBBA7C90095g.body preserve=no

      return result;
      //##end getResult%4CBBA7C90095g.body
   }

   //##begin setResult%4CBBA7C90095s.doc preserve=no
   /**
    * Sets the value of the attribute: RESULT.
    *
    * @param     a_Result
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setResult%4CBBA7C90095s.doc

   public void setResult( String a_Result )
            throws WTPropertyVetoException {
      //##begin setResult%4CBBA7C90095s.body preserve=no

      resultValidate( a_Result );   // throws exception if not valid
      result = a_Result;
      //##end setResult%4CBBA7C90095s.body
   }

   //##begin resultValidate%4CBBA7C90095.doc preserve=no
   /**
    * @param     a_Result
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end resultValidate%4CBBA7C90095.doc

   private void resultValidate( String a_Result )
            throws WTPropertyVetoException {
      if ( RESULT_UPPER_LIMIT < 1 ) {
         try { RESULT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "result" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { RESULT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Result != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Result, RESULT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "result" ), String.valueOf( Math.min ( RESULT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "result", result, a_Result ) );
      }
   }

   //##begin getLog%4CBBA7D2020Cg.doc preserve=no
   /**
    * Gets the value of the attribute: LOG.
    *
    * @return    String
    **/
   //##end getLog%4CBBA7D2020Cg.doc

   public String getLog() {
      //##begin getLog%4CBBA7D2020Cg.body preserve=no

      return log;
      //##end getLog%4CBBA7D2020Cg.body
   }

   //##begin setLog%4CBBA7D2020Cs.doc preserve=no
   /**
    * Sets the value of the attribute: LOG.
    *
    * @param     a_Log
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setLog%4CBBA7D2020Cs.doc

   public void setLog( String a_Log )
            throws WTPropertyVetoException {
      //##begin setLog%4CBBA7D2020Cs.body preserve=no

      logValidate( a_Log );   // throws exception if not valid
      log = a_Log;
      //##end setLog%4CBBA7D2020Cs.body
   }

   //##begin logValidate%4CBBA7D2020C.doc preserve=no
   /**
    * @param     a_Log
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end logValidate%4CBBA7D2020C.doc

   private void logValidate( String a_Log )
            throws WTPropertyVetoException {
      if ( LOG_UPPER_LIMIT < 1 ) {
         try { LOG_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "log" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { LOG_UPPER_LIMIT = 4000; } // resort to modeled value
      }
      if ( a_Log != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Log, LOG_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "log" ), String.valueOf( Math.min ( LOG_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "log", log, a_Log ) );
      }
   }

   //##begin getRunDate%4CBBA7DD01EDg.doc preserve=no
   /**
    * Gets the value of the attribute: RUN_DATE.
    *
    * @return    Timestamp
    **/
   //##end getRunDate%4CBBA7DD01EDg.doc

   public Timestamp getRunDate() {
      //##begin getRunDate%4CBBA7DD01EDg.body preserve=no

      return runDate;
      //##end getRunDate%4CBBA7DD01EDg.body
   }

   //##begin setRunDate%4CBBA7DD01EDs.doc preserve=no
   /**
    * Sets the value of the attribute: RUN_DATE.
    *
    * @param     a_RunDate
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setRunDate%4CBBA7DD01EDs.doc

   public void setRunDate( Timestamp a_RunDate )
            throws WTPropertyVetoException {
      //##begin setRunDate%4CBBA7DD01EDs.body preserve=no

      runDate = a_RunDate;
      //##end setRunDate%4CBBA7DD01EDs.body
   }

   //##begin getWtObject%4CBBA99D0047g.doc preserve=no
   /**
    * Gets the value of the attribute: WT_OBJECT.
    *
    * @return    String
    **/
   //##end getWtObject%4CBBA99D0047g.doc

   public String getWtObject() {
      //##begin getWtObject%4CBBA99D0047g.body preserve=no

      return wtObject;
      //##end getWtObject%4CBBA99D0047g.body
   }

   //##begin setWtObject%4CBBA99D0047s.doc preserve=no
   /**
    * Sets the value of the attribute: WT_OBJECT.
    *
    * @param     a_WtObject
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setWtObject%4CBBA99D0047s.doc

   public void setWtObject( String a_WtObject )
            throws WTPropertyVetoException {
      //##begin setWtObject%4CBBA99D0047s.body preserve=no

      wtObjectValidate( a_WtObject );   // throws exception if not valid
      wtObject = a_WtObject;
      //##end setWtObject%4CBBA99D0047s.body
   }

   //##begin wtObjectValidate%4CBBA99D0047.doc preserve=no
   /**
    * @param     a_WtObject
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end wtObjectValidate%4CBBA99D0047.doc

   private void wtObjectValidate( String a_WtObject )
            throws WTPropertyVetoException {
      if ( WT_OBJECT_UPPER_LIMIT < 1 ) {
         try { WT_OBJECT_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "wtObject" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { WT_OBJECT_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_WtObject != null && !wt.fc.PersistenceHelper.checkStoredLength( a_WtObject, WT_OBJECT_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "wtObject" ), String.valueOf( Math.min ( WT_OBJECT_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "wtObject", wtObject, a_WtObject ) );
      }
   }

   //##begin newInterfaceState%newInterfaceStatef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    InterfaceState
    * @exception wt.util.WTException
    **/
   //##end newInterfaceState%newInterfaceStatef.doc

   public static InterfaceState newInterfaceState()
            throws WTException {
      //##begin newInterfaceState%newInterfaceStatef.body preserve=no

      InterfaceState instance = new InterfaceState();
      instance.initialize();
      return instance;
      //##end newInterfaceState%newInterfaceStatef.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
