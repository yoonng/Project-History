package ext.psk.common.util;

import java.util.HashMap;

import ext.psk.wf.WFHelper;
import wt.method.RemoteMethodServer;

public class RunInterfaceToNexus {

	public static void main(String[] args) throws Exception {
		// wcadmin
		// plmadmin
		try {

			RemoteMethodServer methodServer = RemoteMethodServer.getDefault();
			if (methodServer.getUserName() == null) {
				String [] userInfo = {"wcadmin", "plmadmin"};
				
				System.out.println("args.length " + args.length);
				for( int i=0; i<args.length; i++) {
					System.out.println(i + " = " + args[i]);
				}
				if( args.length >= 2 ) {
					userInfo[0] = args[0];
					userInfo[1] = args[1];
				}

				methodServer.setUserName(userInfo[0]);
				methodServer.setPassword(userInfo[1]);

				System.out.println("AUTHENTICATION SUCCESS");
				
			} else {
				System.out.println("AUTHENTICATION FAILE");
				
			}
			//SessionHelper.manager.setAdministrator();
			System.out.println("===============================================");
			System.out.println("=========== Start to send PressingTaskMail!");
			
			// ApprovalHelper.manager.sendPressingTaskMail();
			HashMap map = new HashMap();
			map.put("cmd", "GetMasterData");
			WFHelper.service.interfacePLM(map);
				
			System.out.println("=========== End to send PressingTaskMail!");

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
