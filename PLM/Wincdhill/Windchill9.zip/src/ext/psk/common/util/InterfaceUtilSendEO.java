package ext.psk.common.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Hashtable;

import ext.psk.common.CommonHelper;
import ext.psk.common.InterfaceState;
import ext.psk.ecm.ecr.ECRequest;
import ext.psk.ecm.eo.EOAlphaForm;
import ext.psk.ecm.eo.EOBetaAForm;
import ext.psk.ecm.eo.EOBetaBForm;
import ext.psk.util.CommonUtil;

import wt.change2.AddressedBy2;
import wt.change2.AffectedActivityData;
import wt.change2.ChangeRecord2;
import wt.change2.IncludedIn2;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.iba.value.IBAHolder;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

public class InterfaceUtilSendEO {


	public void sendEO(String eoOid) throws WTException {
		sendEO(eoOid, "");
	}
	
	public void sendEO(String eoOid, String interfaceStateOid) throws WTException {

		ReferenceFactory rf = new ReferenceFactory();
		EOAlphaForm alForm = (EOAlphaForm) rf.getReference(eoOid).getObject();

		/**
		 * InterfaceState Save
		 */
		InterfaceState interForm = null;
		String interFormOid = interfaceStateOid;
		try {
			if( !interFormOid.equals("") )
				interForm = (InterfaceState) rf.getReference(interFormOid).getObject();
			
			HashMap map = new HashMap();
			if( interForm != null )
				map.put("oid", interFormOid);
			map.put("category", "EO");
			map.put("result", "start");
			map.put("title", alForm.getName());
			map.put("log", "");
			map.put("wtObject", alForm.toString());

			if( interForm != null )
				interFormOid = CommonHelper.service.updateInterface(map);
			else 
				interFormOid = CommonHelper.service.createInterface(map);
			
			interForm = (InterfaceState) rf.getReference(interFormOid).getObject();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);

		}

		try {
			/**
			 * get EO Alpha Form Info
			 */
			AddressedBy2 ecrLink = getAddressedBy2(alForm.getPersistInfo().getObjectIdentifier().getId());
			ECRequest ecr = null;
			if (ecrLink != null)
				ecr = (ECRequest) ecrLink.getChangeRequest2();

			String[] alphaForm = new String[19];

			System.out.println("======== EOAlphaForm ========");
			System.out.println(" applyRequestDate = " + CommonUtil.getTimeToString(alForm.getApplyDate(), "yyyyMMdd"));
			alphaForm[0] = CommonUtil.getTimeToString(alForm.getApplyDate(), "yyyyMMdd");
			System.out.println(" changeReason = " + CommonUtil.checkNull(alForm.getChangeReason()));
			alphaForm[1] = CommonUtil.checkNull(alForm.getChangeReason());
			System.out.println(" creator department = " + CommonUtil.checkNull(alForm.getDepartment()));
			alphaForm[2] = CommonUtil.checkNull(alForm.getDepartment());
			System.out.println(" eoContent = " + CommonUtil.checkNull(alForm.getEoContent()));
			alphaForm[3] = CommonUtil.checkNull(alForm.getEoContent());
			System.out.println(" eotype = " + CommonUtil.checkNull(alForm.getEoType()));
			alphaForm[4] = CommonUtil.checkNull(alForm.getEoType());
			if (alForm.getNoEPI() != null && alForm.getNoEPI().equals("on")) {
				System.out.println(" noepi = " + CommonUtil.checkNull(alForm.getNoEPI()));
				alphaForm[8] = CommonUtil.checkNull(alForm.getNoEPI());
			} else {
				System.out.println(" noepi = " + "off");
				alphaForm[8] = "off";
			}
			System.out.println(" releasedDate = " + CommonUtil.getTimeToString(alForm.getReleaseDate(), "yyyyMMdd"));
			alphaForm[9] = CommonUtil.getTimeToString(alForm.getReleaseDate(), "yyyyMMdd");
			System.out.println(" stockmgt = " + CommonUtil.checkNull(alForm.getStockMgt()));
			alphaForm[10] = CommonUtil.checkNull(alForm.getStockMgt());
			System.out.println(" eoNumber = " + alForm.getNumber());
			alphaForm[11] = alForm.getNumber();
			System.out.println(" eoName = " + alForm.getName());
			alphaForm[12] = alForm.getName();
			System.out.println(" creatorId = " + alForm.getCreatorName());
			alphaForm[13] = alForm.getCreatorName();
			System.out.println(" createDate = " + CommonUtil.getTimeToString(alForm.getCreateTimestamp(), "yyyyMMdd"));
			alphaForm[14] = CommonUtil.getTimeToString(alForm.getCreateTimestamp(), "yyyyMMdd");
			if (ecr != null) {
				System.out.println("---------ECR Info----------");
				System.out.println(" ecrNo = " + ecr.getNumber());
				alphaForm[16] = ecr.getNumber();
				System.out.println(" ecrCompleteReqDate = " + CommonUtil.getTimeToString(ecr.getCompleteReqDate(), "yyyyMMdd"));
				alphaForm[17] = CommonUtil.getTimeToString(ecr.getCompleteReqDate(), "yyyyMMdd");
				System.out.println(" ecrTitle = " + CommonUtil.checkNull(ecr.getName()));
				alphaForm[18] = CommonUtil.checkNull(ecr.getName());
			}
			System.out.println("---------EVR Info----------");
			if (alForm.getNeedEVR() != null && alForm.getNeedEVR().equals("on")) {
				System.out.println(" needEVR = " + CommonUtil.checkNull(alForm.getNeedEVR()));
				alphaForm[7] = CommonUtil.checkNull(alForm.getNeedEVR());
			} else {
				System.out.println(" needEVR = " + "off");
				alphaForm[7] = "off";
			}
			System.out.println(" evrTestList = " + CommonUtil.checkNull(alForm.getEvrTestList()));
			alphaForm[5] = CommonUtil.checkNull(alForm.getEvrTestList());
			System.out.println(" evrTitle = " + CommonUtil.checkNull(alForm.getEvrTitle()));
			alphaForm[6] = CommonUtil.checkNull(alForm.getEvrTitle());
			if (alForm.getEvrcreator() != null) {
				System.out.println(" evrCreatorId = " + alForm.getEvrcreator().getName());
				alphaForm[15] = alForm.getEvrcreator().getName();
			} else {
				alphaForm[15] = "";
			}

			this.insertAlphaForm(alphaForm);

			/**
			 * get EO A List
			 */

			String sEOANumber = alForm.getNumber();
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0)
				query.appendAnd();

			Class alphaType = EOAlphaForm.class;
			Class linkType = IncludedIn2.class;
			Class betaType = EOBetaAForm.class;
			Class acLinkType = AffectedActivityData.class;
			Class partType = WTPart.class;

			int alphaIndex = query.appendClassList(alphaType, false);
			int linkIndex = query.appendClassList(linkType, false);
			int assyLinkIndex = query.appendClassList(acLinkType, false);
			int betaIndex = query.appendClassList(betaType, true);
			int partIndex = query.appendClassList(partType, true);

			query.appendJoin(linkIndex, IncludedIn2.CHANGE_ORDER2_ROLE, alphaIndex);
			query.appendJoin(linkIndex, IncludedIn2.CHANGE_ACTIVITY2_ROLE, betaIndex);
			query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGEABLE2_ROLE, partIndex);
			query.appendJoin(assyLinkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaIndex);

			query.appendWhere(new SearchCondition(alphaType, "iterationInfo.latest", "TRUE"), new int[] { alphaIndex });

			if (query.getConditionCount() > 0)
				query.appendAnd();

			query.appendWhere(new SearchCondition(alphaType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, alForm.getPersistInfo()
					.getObjectIdentifier().getId()), new int[] { alphaIndex });

			if (sEOANumber != null && !sEOANumber.equals("")) {
				if (query.getConditionCount() > 0)
					query.appendAnd();
				query.appendWhere(new SearchCondition(betaType, EOBetaAForm.NUMBER, SearchCondition.LIKE, "%" + sEOANumber + "%"),
						new int[] { betaIndex });
			}

			System.out.println("## REQUEST Query:" + query.toString());

			QueryResult queryResult = PersistenceHelper.manager.find(query);

			System.out.println("============== EOBetaA Form ================");
			Object[] obj = null;
			EOBetaAForm aForm = null;
			WTPart wtPart = null;
			String[] betaAForm = null;

			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[]) queryResult.nextElement();
					aForm = (EOBetaAForm) obj[0];
					wtPart = (WTPart) obj[1];
					betaAForm = new String[8];

					System.out.println("----------- " + i + " -----------");
					System.out.println(" beta A No = " + aForm.getNumber());
					betaAForm[0] = aForm.getNumber();
					System.out.println(" partNo = " + wtPart.getNumber());
					betaAForm[1] = wtPart.getNumber();
					System.out.println(" partVersion1 = " + wtPart.getVersionIdentifier().getValue());
					betaAForm[2] = wtPart.getVersionIdentifier().getValue();
					System.out.println(" partName = " + wtPart.getName());
					betaAForm[3] = wtPart.getName();
					System.out.println(" partUnit = " + wtPart.getDefaultUnit());
					betaAForm[6] = wtPart.getDefaultUnit().toString();

					Hashtable wtForm = CommonUtil.getIBAList((IBAHolder) wtPart);

					System.out.println(" partModel = " + CommonUtil.checkNull((String) wtForm.get("MODEL")));
					betaAForm[4] = CommonUtil.checkNull((String) wtForm.get("MODEL"));
					System.out.println(" part spec = " + CommonUtil.checkNull((String) wtForm.get("PART_SPEC")));
					betaAForm[5] = CommonUtil.checkNull((String) wtForm.get("PART_SPEC"));
					System.out.println(" part material = " + CommonUtil.checkNull((String) wtForm.get("MATERIAL")));
					betaAForm[7] = CommonUtil.checkNull((String) wtForm.get("MATERIAL"));

					this.insertBetaAForm(betaAForm);
				}
			}

			/**
			 * get EO B Form List
			 */
			QuerySpec query2 = new QuerySpec();
			query2.setAdvancedQueryEnabled(true);

			if (query2.getConditionCount() > 0)
				query2.appendAnd();

			Class alphaType2 = EOAlphaForm.class;
			Class linkType2 = IncludedIn2.class;
			Class betaType2 = EOBetaBForm.class;
			Class acLinkType2 = AffectedActivityData.class;
			Class partType2 = WTPart.class;

			int alphaIndex2 = query2.appendClassList(alphaType2, false);
			int linkIndex2 = query2.appendClassList(linkType2, false);
			int assyLinkIndex2 = query2.appendClassList(acLinkType2, false);
			int betaIndex2 = query2.appendClassList(betaType2, true);
			int partIndex2 = query2.appendClassList(partType2, true);

			query2.appendJoin(linkIndex2, IncludedIn2.CHANGE_ORDER2_ROLE, alphaIndex2);
			query2.appendJoin(linkIndex2, IncludedIn2.CHANGE_ACTIVITY2_ROLE, betaIndex2);
			query2.appendJoin(assyLinkIndex2, AffectedActivityData.CHANGEABLE2_ROLE, partIndex2);
			query2.appendJoin(assyLinkIndex2, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaIndex2);

			query2.appendWhere(new SearchCondition(alphaType2, "iterationInfo.latest", "TRUE"), new int[] { alphaIndex2 });

			if (query2.getConditionCount() > 0)
				query2.appendAnd();

			query2.appendWhere(new SearchCondition(alphaType2, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, alForm
					.getPersistInfo().getObjectIdentifier().getId()), new int[] { alphaIndex2 });

			if (query2.getConditionCount() > 0)
				query2.appendAnd();
			query2.appendWhere(new SearchCondition(acLinkType2, AffectedActivityData.DESCRIPTION, SearchCondition.EQUAL, "partOld"),
					new int[] { assyLinkIndex2 });

			System.out.println("## REQUEST Query:" + query2.toString());

			QueryResult queryResult2 = PersistenceHelper.manager.find(query2);

			System.out.println("============== EOBeta B Form ================");
			Object[] obj2 = null;
			EOBetaBForm bForm = null;
			WTPart assyPart = null;
			WTPart sourcePart = null;
			WTPart newPart = null;
			WTPart oldPart = null;
			String[] betaBForm = null;

			if (queryResult2 == null || (queryResult2.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult2.size() > 0) {
				for (int i = 0; i < queryResult2.size(); i++) {
					obj2 = (Object[]) queryResult2.nextElement();
					bForm = (EOBetaBForm) obj2[0];
					wtPart = (WTPart) obj2[1];
					betaBForm = new String[12];

					System.out.println("----------- " + i + " -----------");
					System.out.println(" beta B No = " + bForm.getNumber());
					betaBForm[0] = bForm.getNumber();

					if (bForm.getReasonCode() == null) {
						System.out.println(" reasoncode = " + CommonUtil.checkNull(bForm.getReasonCode()));
						betaBForm[1] = "";
					} else if (bForm.getReasonCode() != null && bForm.getReasonCode().equals("qtyChange")) {
						System.out.println(" reasoncode = " + "Q");
						betaBForm[1] = "Q";
					} else if (bForm.getReasonCode() != null && bForm.getReasonCode().equals("close")) {
						System.out.println(" reasoncode = " + "O");
						betaBForm[1] = "O";
					} else if (bForm.getReasonCode() != null && bForm.getReasonCode().equals("change")) {
						System.out.println(" reasoncode = " + "C");
						betaBForm[1] = "C";
					} else if (bForm.getReasonCode() != null && bForm.getReasonCode().equals("add")) {
						System.out.println(" reasoncode = " + "N");
						betaBForm[1] = "N";
					}
					// System.out.println(" reasoncode = " +
					// CommonUtil.checkNull(bForm.getReasonCode()));
					// System.out.println(" createdate = " +
					// CommonUtil.getTimeToString(bForm.getCreateTimestamp(),
					// "yyyyMMdd"));

					// 1. get ChangeRecord2
					HashMap partMap = null;
					if (bForm != null)
						partMap = this.getAFFDataLinkforBetaB(bForm.getPersistInfo().getObjectIdentifier().getId());
					AffectedActivityData partOldLink = null;
					AffectedActivityData assySourceLink = null;
					if (partMap != null) {
						try {
							partOldLink = (AffectedActivityData) partMap.get("partOld");
							if (partOldLink != null)
								oldPart = (WTPart) partOldLink.getChangeable2();
							assySourceLink = (AffectedActivityData) partMap.get("assySource");
							if (assySourceLink != null)
								sourcePart = (WTPart) assySourceLink.getChangeable2();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					// 3. get ChangeRecord2
					HashMap partMap2 = null;
					if (bForm != null)
						partMap2 = this.getChangeDataLinkforBetaB(bForm.getPersistInfo().getObjectIdentifier().getId());
					ChangeRecord2 assyNewLink = null;
					ChangeRecord2 partNewLink = null;
					if (partMap2 != null) {
						try {
							assyNewLink = (ChangeRecord2) partMap2.get("assyNew");
							if (assyNewLink != null)
								assyPart = (WTPart) assyNewLink.getChangeable2();
							partNewLink = (ChangeRecord2) partMap2.get("partNew");
							if (partNewLink != null)
								newPart = (WTPart) partNewLink.getChangeable2();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					if (assyPart != null) {
						System.out.println("----------- " + i + " -----------");
						System.out.println(" assyPartNumber = " + assyPart.getNumber());
						betaBForm[2] = assyPart.getNumber();
						System.out.println(" assyPartName = " + assyPart.getName());
						betaBForm[3] = assyPart.getName();
						System.out.println(" assyPartVersion = " + assyPart.getVersionIdentifier().getValue());
						betaBForm[4] = assyPart.getVersionIdentifier().getValue();

					} else {
						betaBForm[2] = "";
						betaBForm[3] = "";
						betaBForm[4] = "";
					}
					if (newPart != null) {
						System.out.println("----------- " + i + " -----------");
						System.out.println(" newPartNumber = " + newPart.getNumber());
						betaBForm[5] = newPart.getNumber();
						System.out.println(" newPartName = " + newPart.getName());
						betaBForm[6] = newPart.getName();
						System.out.println(" newPartVersion = " + newPart.getVersionIdentifier().getValue());
						betaBForm[7] = newPart.getVersionIdentifier().getValue();

						System.out.println(" newPart Quantity = " + bForm.getNewPartQty());
						betaBForm[8] = bForm.getNewPartQty();

					} else {
						betaBForm[5] = "";
						betaBForm[6] = "";
						betaBForm[7] = "";
						betaBForm[8] = "0";
					}
					if (oldPart != null) {
						System.out.println("----------- " + i + " -----------");
						System.out.println(" oldPartNumber = " + oldPart.getNumber());
						betaBForm[9] = oldPart.getNumber();
						System.out.println(" oldPartName = " + oldPart.getName());
						betaBForm[10] = oldPart.getName();
						System.out.println(" oldPartVersion = " + oldPart.getVersionIdentifier().getValue());
						betaBForm[11] = oldPart.getVersionIdentifier().getValue();

					} else {
						betaBForm[9] = "";
						betaBForm[10] = "";
						betaBForm[11] = "";
					}

					this.insertBetaBForm(betaBForm);
				}
			}
		} catch (Exception e) { // end try
			e.printStackTrace();

			/**
			 * InterfaceState Update
			 */
			try {
				HashMap map = new HashMap();
				map.put("oid", interFormOid);
				map.put("category", "EO");
				map.put("result", "fail");
				map.put("title", alForm.getName());
				map.put("log", e.getMessage());
				map.put("wtObject", alForm.toString());

				interFormOid = CommonHelper.service.updateInterface(map);

				interForm = (InterfaceState) rf.getReference(interFormOid).getObject();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new WTException(ex);
			}
			throw new WTException(e);
		}

		/**
		 * InterfaceState Update
		 */
		try {
			HashMap map = new HashMap();
			map.put("oid", interFormOid);
			map.put("category", "EO");
			map.put("result", "completed");
			map.put("title", alForm.getName());
			map.put("log", "");
			map.put("wtObject", alForm.toString());

			interFormOid = CommonHelper.service.updateInterface(map);

			interForm = (InterfaceState) rf.getReference(interFormOid).getObject();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);

		}
	}

	public AddressedBy2 getAddressedBy2(long Oid) {
		AddressedBy2 link = null;

		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0)
				query.appendAnd();

			Class linkType = AddressedBy2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class aType = EOAlphaForm.class;
			int aIndex = query.appendClassList(aType, false);

			query.appendJoin(linkIndex, AddressedBy2.CHANGE_ORDER2_ROLE, aIndex);

			query.appendWhere(new SearchCondition(aType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid), new int[] { aIndex });

			QueryResult queryResult = PersistenceHelper.manager.find(query);

			Object[] obj = null;
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[]) queryResult.nextElement();
					link = (AddressedBy2) obj[0];

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return link;
	}
	

	public HashMap getAFFDataLinkforBetaB(long Oid) {
		HashMap results = new HashMap();
		AffectedActivityData link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = AffectedActivityData.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class betaBType = EOBetaBForm.class;
			int betaBIndex = query.appendClassList(betaBType, false);

			query.appendJoin(linkIndex, AffectedActivityData.CHANGE_ACTIVITY2_ROLE, betaBIndex);

			query.appendWhere(new SearchCondition(betaBType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { betaBIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (AffectedActivityData)obj[0];
					
					results.put(link.getDescription(), link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
			
		return results;
	}
	

	public HashMap getChangeDataLinkforBetaB(long Oid) {
		HashMap results = new HashMap();
		ChangeRecord2 link = null;
		
		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = ChangeRecord2.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class betaBType = EOBetaBForm.class;
			int betaBIndex = query.appendClassList(betaBType, false);

			query.appendJoin(linkIndex, ChangeRecord2.CHANGE_ACTIVITY2_ROLE, betaBIndex);

			query.appendWhere(new SearchCondition(betaBType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid)	, new int[] { betaBIndex });
			
			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null; 
			
			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[])queryResult.nextElement();
					link = (ChangeRecord2)obj[0];
					
					results.put(link.getDescription(), link);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
			
		return results;
	}
	
	public String insertAlphaForm(String[] formValue) throws WTException {

		try {
			StringBuffer sb = new StringBuffer();
			String result = "SUCCESS";

			for(int i=0; i<formValue.length; i++) {
//				if( formValue[i] == null || formValue[i].equals("") )
//					formValue[i] = "n/a";
				System.out.println("i=" + i + " = " + formValue[i]);
			}
			
			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			//Statement pstmt = conn.createStatement();
	        PreparedStatement pstmt = null; //conn.prepareStatement(sb);

			String type = "";
//			EOHEADER 
//			EOPARTMST 
//			EOSTRUCTER
			sb = new StringBuffer();
			sb.append(" INSERT INTO EOHEADER ( ");
			
            sb.append("DSGN_EFF_REQ_DT, ");      
            sb.append("EO_ISS_RSN, ");        
            sb.append("ISS_DEPT_NM, ");            
            sb.append("EO_CONT, ");            
            sb.append("EO_TYPE, ");       
            sb.append("EVR_TEST_LIST, ");          
            sb.append("EVR_TITL, ");          
            sb.append("EVR_NEED_STTS, ");               
            sb.append("NO_EPI_STTS, ");     
            sb.append("EO_ISS_DT, ");    
            sb.append("STCK_DSPS_MTHD, ");       
            sb.append("EO_NO, ");  
            sb.append("EO_TITL, ");  
            sb.append("ISSR_EMPNO, ");       
            sb.append("EO_REG_DT, ");        
            sb.append("EVR_ISSR_EMPNO, ");       
            sb.append("ECR_NO, ");          
            sb.append("ECR_CMPL_REQ_DT, ");          
            sb.append("ECR_TITL");     
            sb.append(") ");     
            
            sb.append("VALUES(");
            sb.append("?, ");                  
            sb.append("?, ");         
            sb.append("?, ");                
            sb.append("?, ");                
            sb.append("?, ");           
            sb.append("?, ");              
            sb.append("?, ");              
            sb.append("?, ");                   
            sb.append("?, ");         
            sb.append("?, ");        
            sb.append("?, ");           
            sb.append("?, ");      
            sb.append("?, ");      
            sb.append("?, ");           
            sb.append("?, ");              
            sb.append("?, ");           
            sb.append("?, ");             
            sb.append("?, ");  
            sb.append("?) ");
            
            String sql = sb.toString();
            System.out.println("SQL = " + sb);
            pstmt = conn.prepareStatement(sb.toString());
            
            pstmt.setString(1, formValue[0]);
            pstmt.setString(2, formValue[1]);
            pstmt.setString(3, formValue[2]);
            pstmt.setString(4, formValue[3]);
            pstmt.setString(5, formValue[4]);
            pstmt.setString(6, formValue[5]);
            pstmt.setString(7, formValue[6]);
            pstmt.setString(8, formValue[7]);
            pstmt.setString(9, formValue[8]);
            pstmt.setString(10,formValue[9]);
            pstmt.setString(11,formValue[10]);
            pstmt.setString(12,formValue[11]);
            pstmt.setString(13,formValue[12]);
            pstmt.setString(14,formValue[13]);
            pstmt.setString(15,formValue[14]); 
            pstmt.setString(16,formValue[15]);
            pstmt.setString(17,formValue[16]);
            pstmt.setString(18,formValue[17]);
            pstmt.setString(19,formValue[18]);

			int results = pstmt.executeUpdate();
			System.out.println("@2 execute insertAlphaForm result = " + results);

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

		return "";
	}
	

	public String insertBetaAForm(String[] formValue) throws WTException {

		try {
			StringBuffer sb = new StringBuffer();
			String result = "SUCCESS";

			for(int i=0; i<formValue.length; i++) {
//				if( formValue[i] == null || formValue[i].equals("") )
//					formValue[i] = "n/a";
				System.out.println("i=" + i + " = " + formValue[i]);
			}
			
			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			//Statement pstmt = conn.createStatement();
	        PreparedStatement pstmt = null; //conn.prepareStatement(sb);

			String type = "";
//			EOHEADER 
//			EOPARTMST 
//			EOSTRUCTER
			sb = new StringBuffer();
			sb.append(" INSERT INTO EOPARTMST ( ");
			
            sb.append("EO_ULA_NO, ");
            sb.append("PART_NO, ");
            sb.append("PART_VER, ");
            sb.append("PART_NM, ");
            sb.append("PART_MDL_NM, ");
            sb.append("PART_SPEC, ");
            sb.append("UNIT_CD, ");
            sb.append("MTRL_GRP_CD ");
            sb.append(") ");
            
            sb.append("VALUES(");
            sb.append("?, ");
            sb.append("?, ");         
            sb.append("?, ");                
            sb.append("?, ");                
            sb.append("?, ");           
            sb.append("?, ");              
            sb.append("?, ");              
            sb.append("?) ");   
            
            String sql = sb.toString();
            System.out.println("SQL = " + sb);
            pstmt = conn.prepareStatement(sb.toString());
            
            pstmt.setString(1, formValue[0]);
            pstmt.setString(2, formValue[1]);
            pstmt.setString(3, formValue[2]);
            pstmt.setString(4, formValue[3]);
            pstmt.setString(5, formValue[4]);
            pstmt.setString(6, formValue[5]);
            pstmt.setString(7, formValue[6]);
            pstmt.setString(8, formValue[7]);

			int results = pstmt.executeUpdate();
			System.out.println("@2 execute insertBetaAForm result = " + results);

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

		return "";
	}
	
	public String insertBetaBForm(String[] formValue) throws WTException {

		try {
			StringBuffer sb = new StringBuffer();
			String result = "SUCCESS";

			for(int i=0; i<formValue.length; i++) {
//				if( formValue[i] == null || formValue[i].equals("") )
//					formValue[i] = "n/a";
				System.out.println("i=" + i + " = " + formValue[i]);
			}
			
			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			//Statement pstmt = conn.createStatement();
	        PreparedStatement pstmt = null; //conn.prepareStatement(sb);

			String type = "";
			sb = new StringBuffer();
			sb.append(" INSERT INTO EOSTRUCTER ( ");
			
            sb.append("EO_ULB_NO, ");      
            sb.append("EO_ULB_ISS_RSN_CD, ");        
            sb.append("ASSY_PART_NO, ");            
            sb.append("ASSY_PART_NM, ");            
            sb.append("ASSY_PART_VER, ");       
            sb.append("NEW_COMP_PART_NO, ");          
            sb.append("NEW_COMP_PART_NM, ");          
            sb.append("NEW_COMP_PART_VER, ");     
            sb.append("NEW_COMP_QTY, ");       
            sb.append("OLD_COMP_PART_NO, ");          
            sb.append("OLD_COMP_PART_NM, ");          
            sb.append("OLD_COMP_PART_VER ");     
            sb.append(") ");        
            
            sb.append("VALUES(");
            sb.append("?, ");                  
            sb.append("?, ");         
            sb.append("?, ");                
            sb.append("?, ");                
            sb.append("?, ");           
            sb.append("?, ");              
            sb.append("?, ");              
            sb.append("?, ");               
            sb.append("?, ");           
            sb.append("?, ");              
            sb.append("?, ");              
            sb.append("?) ");   
            
            String sql = sb.toString();
            System.out.println("SQL = " + sb);
            pstmt = conn.prepareStatement(sb.toString());

            pstmt.setString(1, formValue[0]);
            pstmt.setString(2, formValue[1]);
            pstmt.setString(3, formValue[2]);
            pstmt.setString(4, formValue[3]);
            pstmt.setString(5, formValue[4]);
            pstmt.setString(6, formValue[5]);
            pstmt.setString(7, formValue[6]);
            pstmt.setString(8, formValue[7]);
            pstmt.setInt(9, new Integer(formValue[8]).intValue() );
            pstmt.setString(10,formValue[9]);
            pstmt.setString(11,formValue[10]);
            pstmt.setString(12,formValue[11]);

			int results = pstmt.executeUpdate();
			System.out.println("@2 execute insertBetaBForm result = " + results);

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

		return "";
	}
}
