package ext.psk.common.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;

import ext.psk.common.CommonCode;
import ext.psk.common.CommonHelper;
import ext.psk.common.InterfaceState;
import ext.psk.util.CommonUtil;
import ext.psk.util.PSKCommonUtil;

import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleHelper;
import wt.part.PartType;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtility;
import wt.type.TypedUtilityInterface;
import wt.type.TypedUtilityService;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

public class InterfaceUtil {

	public void getMasterDataFromNexus() throws WTException {

		try {

			StringBuffer sql = new StringBuffer();
			String result = "SUCCESS";

			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();

			// CD_TYPE Y CODE TYPE VARCHAR2 2 FC: FSC, MD:Module, UG:UPG, UC:UPGVC
			// CD_DATA Y CODE DATA VARCHAR2 20
			// DESC DESCRIPTION VARCHAR2 200
			// PLM_TRNS_YN PLM 전송 여부 VARCHAR2 1 "Y: 전송완료  N: 전송미완료"

			String type = "";
			String data = "";
			String desc = "";

			sql = new StringBuffer();
			sql.append(" select CD_TYPE type, CD_DATA data, CD_DESC descs ");
			sql.append(" from IFNXTPLMAT ");
			sql.append(" where PLM_TRNS_YN = 'N' and CD_TYPE = 'UC' ");
			System.out.println("sql:" + sql.toString());
			ResultSet rs = stmt.executeQuery(sql.toString());

			Vector mainEnum = new Vector();
			Vector subEnum = null;

			if (rs.next()) {
				
				type = rs.getString("type");
				data = rs.getString("data");
				desc = rs.getString("descs");

				subEnum = new Vector();
				subEnum.add(type);
				subEnum.add(data);
				subEnum.add(desc);

				mainEnum.add(subEnum);
			}

			for (int i = 0; i < mainEnum.size(); i++) {
				subEnum = (Vector) mainEnum.get(i);
				type = (String) subEnum.get(0);
				data = (String) subEnum.get(1);
				desc = (String) subEnum.get(2);

				/*
				 * 중복된 코드가 존재하면 
				 * 정상 처리로 진행.
				 */	
				if (type.equals("FC")) {
					// FSC Code 추가
					HashMap map = new HashMap();
					map.put("codeType", "fsc");
					map.put("code", data);
					map.put("codeNameKr", desc);
					map.put("description", "Add to Nexus");
					map.put("isDeleted", "N");
					try {
						CommonHelper.service.createCode(map);
					} catch(WTException wte) {
						wte.printStackTrace();
						
						if( wte.getMessage().endsWith("Code is duplicated!") ){
							System.out.println("@create Pass");
						} else {
							continue;
						}
					}

				} else if (type.equals("MD")) {
					// Module Code 추가
					HashMap map = new HashMap();
					map.put("codeType", "module2");
					map.put("code", data);
					map.put("codeNameKr", desc);
					map.put("description", "Add to Nexus");
					map.put("isDeleted", "N");
					
					try {
						CommonHelper.service.createCode(map);
					} catch(WTException wte) {
						wte.printStackTrace();
						
						System.out.println("@@@" + wte.getMessage() + "@@@");
						
						if( wte.getMessage().endsWith("Code is duplicated!") ){
							System.out.println("@create Pass");
						} else {
							continue;
						}
					}

				} else if (type.equals("UG")) {
					// UPG Code 추가
					HashMap map = new HashMap();
					map.put("codeType", "upg");
					map.put("code", data);
					map.put("codeName", desc);
					map.put("description", "Add to Nexus");
					map.put("isDeleted", "N");

					try {
						CommonHelper.service.createCode(map);
					} catch(WTException wte) {
						wte.printStackTrace();
						
						if( wte.getMessage().endsWith("Code is duplicated!") ){
							System.out.println("@create Pass");
						} else {
							continue;
						}
					}

				} else if (type.equals("UC")) {
					// UPGVC Part 추가
					HashMap map = new HashMap();
					map.put("codeType", "module2");
					map.put("code", data);
					map.put("codeName", desc);
					map.put("description", "Add to Nexus");

					if( !existPart(data) ) {
						Transaction trx = new Transaction();
						try {
							trx.start();
	
							WTPart part = WTPart.newWTPart(data, desc);
							part.setPartType( PartType.toPartType("UPGVC") );

							String liftCycle = "Default";
							WTContainerRef wtContainerRef = null;
							Folder folder = null;
							
							// get Segment CodeName
							String segmentCode = data.substring(4,5);
							String sSegment = getSegmentCode(segmentCode);
							String upg = data.substring(0, 1) + data.substring(2, 4);

							PDMLinkProduct product = null;
							// PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct(sSegment);
							if( sSegment.equals("")) {
								product = PSKCommonUtil.getPDMLinkProduct();
							} else {
								product = PSKCommonUtil.getPDMLinkProduct();
							}
							wtContainerRef = WTContainerRef.newWTContainerRef(product);
							part.setContainer(product);
							
							String typeRef = "wt.part.WTPart|com.psk_inc.UPGVC";
							TypeDefinitionReference tdr = TypedUtility.getTypeDefinitionReference(typeRef);							
							part.setTypeDefinitionReference(tdr);

							String sFolderPath = "/Default/UPG/" + upg;
							folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);

							// Folder assign
							FolderHelper.assignLocation((FolderEntry) part, folder);
							
							LifeCycleHelper.setLifeCycle(part, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef));

							part = (WTPart) PersistenceHelper.manager.save(part);
							
							trx.commit();
	
						} catch (Exception e) {
							trx.rollback();
							e.printStackTrace();
							result = CommonUtil.FAIL + " : " + e.getMessage();
							throw new WTException(e);
	
						} finally {
							trx = null;
						}
					}
				}

				// 에러 없이 추가되면 Flag 'Y'로 변경
				sql = new StringBuffer();
				sql.append(" update IFNXTPLMAT set PLM_TRNS_YN = 'Y' ");
				sql.append(" where CD_TYPE = '" + type + "' ");
				sql.append(" and CD_DATA = '" + data + "' ");
				System.out.println("@1 sql:" + sql.toString());
				
				int results = stmt.executeUpdate(sql.toString());
				System.out.println("@2 execute result = " + results);

			}

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();
			
		} catch (SQLException ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

	}
	
	public void updatePSCState(String docOid, String pscNumber, String docState) throws WTException {
		updatePSCState(docOid, pscNumber, docState, "");
	}

	public void updatePSCState(String docOid, String pscNumber, String docState, String interfaceStateOid) throws WTException {

		ReferenceFactory rf = new ReferenceFactory();
		
		try {
			StringBuffer sql = new StringBuffer();
			String result = "SUCCESS";

			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();

			String stateValue = "";
			if (docState.equals("INAPPROVAL")) {
				stateValue = "1";
			} else if (docState.equals("RELEASED")) {
				stateValue = "2";
			} else if (docState.equals("REJECTED")) {
				stateValue = "4";
			}

			String type = "";
			String data = "";
			String desc = "";

			if (!stateValue.equals("")) {
				if (pscNumber.startsWith("PR")) {
					sql = new StringBuffer();
					sql.append(" update pscrmst set PSCR_STTS_CD = '" + stateValue + "' ");
					sql.append(" where pscr_no = '" + pscNumber + "' ");
					System.out.println("@1 sql:" + sql.toString());

					int results = stmt.executeUpdate(sql.toString());
					System.out.println("@2 execute result = " + results);

				} else if (pscNumber.startsWith("PN")) {
					sql = new StringBuffer();
					sql.append(" update pscnmst set PSCN_STTS_CD = '" + stateValue + "' ");
					sql.append(" where pscn_no = '" + pscNumber + "' ");
					System.out.println("@1 sql:" + sql.toString());

					int results = stmt.executeUpdate(sql.toString());
					System.out.println("@2 execute result = " + results);

				}
			}

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

			
		} catch (SQLException ex) {
			ex.printStackTrace();
			
			/**
			 * InterfaceState Save
			 */
			InterfaceState interForm = null;
			WTDocument pscDoc = null;
			String sInterFormOid = interfaceStateOid;
			try {
				if( !sInterFormOid.equals("") )
					interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
				if( docOid != null && !docOid.equals("")) 
					pscDoc = (WTDocument) rf.getReference(docOid).getObject();
				
				HashMap map = new HashMap();
				if( interForm != null )
					map.put("oid", sInterFormOid);
				map.put("category", "PSC");
				map.put("result", "fail");
				map.put("title", pscDoc.getName());
				map.put("log", ex.getMessage());
				map.put("wtObject", docOid);

				if( interForm != null )
					sInterFormOid = CommonHelper.service.updateInterface(map);
				else 
					sInterFormOid = CommonHelper.service.createInterface(map);
				
				interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
			} catch (Exception e) {
				e.printStackTrace();
				throw new WTException(e);

			}
			
			new WTException(ex.getMessage());

		} catch (Exception ex) {
			ex.printStackTrace();
			
			/**
			 * InterfaceState Save
			 */
			InterfaceState interForm = null;
			WTDocument pscDoc = null;
			String sInterFormOid = interfaceStateOid;
			try {
				if( !sInterFormOid.equals("") )
					interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
				if( docOid != null && !docOid.equals("")) 
					pscDoc = (WTDocument) rf.getReference(docOid).getObject();
				
				HashMap map = new HashMap();
				if( interForm != null )
					map.put("oid", sInterFormOid);
				map.put("category", "PSC");
				map.put("result", "fail");
				map.put("title", pscDoc.getName());
				map.put("log", ex.getMessage());
				map.put("wtObject", docOid);

				if( interForm != null )
					sInterFormOid = CommonHelper.service.updateInterface(map);
				else 
					sInterFormOid = CommonHelper.service.createInterface(map);
				
				interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
			} catch (Exception e) {
				e.printStackTrace();
				throw new WTException(e);

			}
			
			new WTException(ex.getMessage());

		}
		
		/**
		 * InterfaceState Save
		 */
		InterfaceState interForm = null;
		WTDocument pscDoc = null;
		String sInterFormOid = interfaceStateOid;
		try {
			if( !sInterFormOid.equals("") )
				interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
			if( docOid != null && !docOid.equals("")) 
				pscDoc = (WTDocument) rf.getReference(docOid).getObject();
			
			HashMap map = new HashMap();
			if( interForm != null )
				map.put("oid", sInterFormOid);
			map.put("category", "PSC");
			map.put("result", "complete");
			map.put("title", pscDoc.getName());
			map.put("log", "");
			map.put("wtObject", docOid);

			if( interForm != null )
				sInterFormOid = CommonHelper.service.updateInterface(map);
			else 
				sInterFormOid = CommonHelper.service.createInterface(map);
			
			interForm = (InterfaceState) rf.getReference(sInterFormOid).getObject();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);

		}
	}

	public Vector getGLforFSC(String fscCode) throws WTException{

		Vector vcList = new Vector();

		try {
			StringBuffer sql = new StringBuffer();
			String result = "SUCCESS";

			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();

			String type = "";

			sql = new StringBuffer();
			sql.append(" select upgvc_no upgvc");
			sql.append(" from VIEW_PLMDMU_FSC ");
			sql.append(" where fsc_cd = '" + fscCode + "' ");
			System.out.println("sql:" + sql.toString());

			ResultSet rs = stmt.executeQuery(sql.toString());

			while (rs.next()) {
				vcList.add(rs.getString("upgvc"));

			}

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

		return vcList;
	}


	public Vector getGLforModule(String moduleCode, String segmentCode) throws WTException {

		Vector vcList = new Vector();

		try {
			StringBuffer sql = new StringBuffer();
			String result = "SUCCESS";

			Connection conn = PSKDBConnect.connectNEXUS();

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();

			String type = "";

			sql = new StringBuffer();
			sql.append(" select upgvc_no upgvc");
			sql.append(" from VIEW_PLMDMU_MDUL  ");
			sql.append(" where sgmt_cd = '" + segmentCode + "' ");
			if( moduleCode != null && !moduleCode.equals("")) {
				sql.append(" and mdul_cd = '" + moduleCode + "' ");
			}
			System.out.println("sql:" + sql.toString());

			ResultSet rs = stmt.executeQuery(sql.toString());

			while (rs.next()) {
				vcList.add(rs.getString("upgvc"));

			}

			conn.commit();
			conn.setAutoCommit(true);
			conn.close();

		} catch (Exception ex) {
			ex.printStackTrace();
			new WTException(ex.getMessage());

		}

		return vcList;
	}
	
	public boolean existPart(String partNumber) throws WTException {
		boolean isExist = false;

		HashMap results = new HashMap();
		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec();

			if (query.getConditionCount() > 0)
				query.appendAnd();

			Class classType = WTPart.class;
			int pskIndex = query.appendClassList(classType, true);

			if (query.getConditionCount() > 0)
				query.appendAnd();
			query.appendWhere(new SearchCondition(classType, WTPart.NUMBER, SearchCondition.EQUAL, partNumber), new int[] { pskIndex });

			System.out.println("## REQUEST Query existCode :" + query.toString());

			queryResult = PersistenceHelper.manager.find(query);

			if (queryResult == null || (queryResult.size() < 0)) {
			} else if (queryResult.size() > 0) {
				System.out.println(" ,,,, " + queryResult.nextElement());
				isExist = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isExist;

	}
	
	public String getSegmentCode(String segmentValue) throws WTException {
		String segmentCode = "";
		
		HashMap results = new HashMap();
		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec();

			if (query.getConditionCount() > 0)
				query.appendAnd();

			Class classType = CommonCode.class;
			int pskIndex = query.appendClassList(classType, true);

			if (query.getConditionCount() > 0)
				query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE_TYPE, SearchCondition.EQUAL, "segment"), new int[] { pskIndex });
			if (query.getConditionCount() > 0)
				query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE_NAME_EN, SearchCondition.EQUAL, segmentValue), new int[] { pskIndex });

			System.out.println("## REQUEST Query existCode :" + query.toString());

			queryResult = PersistenceHelper.manager.find(query);

			Persistable[] objs = null;
			if (queryResult == null || (queryResult.size() < 0)) {
			} else if (queryResult.size() > 0) {
				objs = (Persistable[])queryResult.nextElement();
				CommonCode code = (CommonCode)objs[0];
				segmentCode = code.getCode(); 
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return segmentCode;
	}
	
	public WTPart makeDMUPart(String sSegment, String partNumber, String partName, Vector upgList) throws WTException {
		WTPart dmuPart = null;
		if( !existPart(partNumber) ) {
			Transaction trx = new Transaction();
			try {
				trx.start();

				dmuPart = WTPart.newWTPart(partNumber, partName);
//				dmuPart.setPartType( PartType.toPartType("DMU") );
				dmuPart.setPartType( PartType.toPartType("UPGVC") );

				String liftCycle = "Default";
				WTContainerRef wtContainerRef = null;
				Folder folder = null;
				
				// get Segment CodeName
//				String segmentCode = data.substring(4,5);
//				String sSegment = getSegmentCode(segmentCode);
//				String upg = data.substring(0, 1) + data.substring(2, 4);

				PDMLinkProduct product = null;
				// PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct(sSegment);
				if( sSegment.equals("")) {
					product = PSKCommonUtil.getPDMLinkProduct();
				} else {
					product = PSKCommonUtil.getPDMLinkProduct();
				}
				wtContainerRef = WTContainerRef.newWTContainerRef(product);
				dmuPart.setContainer(product);

				//String typeRef = "wt.part.WTPart|com.psk_inc.DMU";
				String typeRef = "wt.part.WTPart|com.psk_inc.UPGVC";
				TypeDefinitionReference tdr = TypedUtility.getTypeDefinitionReference(typeRef);							
				dmuPart.setTypeDefinitionReference(tdr);
				
				String yy = CommonUtil.getCurrentTime("yyyy");
				String mm = CommonUtil.getCurrentTime("MM");
				String sFolderPath = "/Default/DMU/" + yy + "/" + mm;
				folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);

				// Folder assign
				FolderHelper.assignLocation((FolderEntry) dmuPart, folder);
				
				LifeCycleHelper.setLifeCycle(dmuPart, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef));

				
				dmuPart = (WTPart) PersistenceHelper.manager.save(dmuPart);
				

				if( upgList != null && upgList.size() > 0) {
					   WTPartUsageLink usageLink = null;
					   WTPartMaster usagePart = null;
					   for(int k=0; k<upgList.size(); k++) {
						   usagePart = queryWTPartMaster((String)upgList.get(k)); 
						   if( usagePart != null ) {
							   usageLink = WTPartUsageLink.newWTPartUsageLink(dmuPart, usagePart);
							   PersistenceHelper.manager.save(usageLink);
						   }
					   }
				   }
				
				trx.commit();

			} catch (Exception e) {
				trx.rollback();
				e.printStackTrace();
				throw new WTException(e);

			} finally {
				trx = null;
			}
		}
		
		return dmuPart;
	}
	

	public WTPartMaster queryWTPartMaster(String number) throws WTException {

		WTPartMaster master = null;
		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec(WTPartMaster.class);

			if (query.getConditionCount() > 0)
				query.appendAnd();

			query.appendWhere(new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER, SearchCondition.EQUAL, number), new int[] { 0 });

			System.out.println("## REQUEST Query queryWTPartMaster :" + query.toString());

			queryResult = PersistenceHelper.manager.find(query);

			 if (queryResult == null || (queryResult.size() < 0)) {
				 System.out.println("@ master = null");
			 } else if (queryResult.size() > 0) {
				 master = (WTPartMaster)queryResult.nextElement();
				 System.out.println("@ master = " + master);
			 }

		} catch (Exception e) {
			e.printStackTrace();
		}

		return master;
	}
}
