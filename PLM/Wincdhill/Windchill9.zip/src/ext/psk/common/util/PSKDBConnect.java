package ext.psk.common.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import wt.fc.ReferenceFactory;
import wt.util.WTException;

public class PSKDBConnect {

	/******
   <Property name="psk.ebom.classname" overridable="true" targetFile="codebase/wt.properties" value="com.microsoft.sqlserver.jdbc.SQLServerDriver"/>
   <Property name="psk.ebom.url" overridable="true" targetFile="codebase/wt.properties" value="jdbc:sqlserver://192.168.232.11:1433;SelectMethod=cursor;DataBaseName=MIS_EBOM"/>
   <Property name="psk.ebom.user" overridable="true" targetFile="codebase/wt.properties" value="sa"/>
   <Property name="psk.ebom.pass" overridable="true" targetFile="codebase/wt.properties" value="psk8611"/>
   <Property name="psk.erp.classname" overridable="true" targetFile="codebase/wt.properties" value="com.microsoft.sqlserver.jdbc.SQLServerDriver"/>
   <Property name="psk.erp.url" overridable="true" targetFile="codebase/wt.properties" value="jdbc:sqlserver://192.168.232.11:1433;SelectMethod=cursor;DataBaseName=MIS_HDQT"/>
   <Property name="psk.erp.user" overridable="true" targetFile="codebase/wt.properties" value="sa"/>
   <Property name="psk.erp.pass" overridable="true" targetFile="codebase/wt.properties" value="psk8611"/>

        String classForName = "oracle.jdbc.driver.OracleDriver";
        //String URL = "jdbc:oracle:thin:@172.20.10.18:1521:wind";
        //String user = "wcadmin";
        //String pass = "wcadmin";
	 */
	public static Connection connectEBOM() throws WTException {
		return connectMSSQL("EBOM");
	}

	public static Connection connectERP() throws WTException {
		return connectMSSQL("ERP");
	}

	public static Connection connectNEXUS() throws WTException {
		return connectOracle("NEXUS");
	}

	/**
	 * MS-SQL(EBOM, ERP)�� ����
	 * 
	 * @param flag
	 * @return
	 * @throws WTException
	 */
	private static Connection connectMSSQL(String flag) throws WTException {
		Connection conn = null;
		String userName = "";
		String userPass = "";
		String ebomURL = "";
		String className = "";

		try {
			wt.util.WTProperties props = wt.util.WTProperties
					.getLocalProperties();
			if (flag != null && flag.equals("EBOM")) {
				className = props.getProperty("psk.ebom.classname");
				userName = props.getProperty("psk.ebom.user");
				userPass = props.getProperty("psk.ebom.pass");
				ebomURL = props.getProperty("psk.ebom.url");
			} else if (flag != null && flag.equals("ERP")) {
				className = props.getProperty("psk.erp.classname");
				userName = props.getProperty("psk.erp.user");
				userPass = props.getProperty("psk.erp.pass");
				ebomURL = props.getProperty("psk.erp.url");
			}
			System.out.println("className:" + className);
			System.out.println("userName:" + userName);
			System.out.println("userPass:" + userPass);
			System.out.println("ebomURL:" + ebomURL);

			Class.forName(className);
			// DriverManager.registerDriver (new
			// com.microsoft.sqlserver.jdbc.SQLServerDriver());
			conn = DriverManager.getConnection(ebomURL, userName, userPass);
			System.out.println("ebom con:" + conn);

		} catch (SQLException e) {
			e.printStackTrace();
			throw new WTException(e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		return conn;
	}

	private static Connection connectOracle(String flag) throws WTException {
		Connection conn = null;
		String userName = "";
		String userPass = "";
		String nexusURL = "";
		String className = "";
		try {
			wt.util.WTProperties props = wt.util.WTProperties
					.getLocalProperties();
			

	        String classForName = "oracle.jdbc.driver.OracleDriver";
	        String URL = "jdbc:oracle:thin:@192.168.232.21:1521:orcl";
	        String user = "testnewnexus";
	        String pass = "psk002";
			
			className = classForName; // props.getProperty("psk.nexus.classname");
			userName = user; //props.getProperty("psk.nexus.user");
			userPass = pass; //props.getProperty("psk.nexus.pass");
			nexusURL = URL; //props.getProperty("psk.nexus.url");

			Class.forName(className);
			conn = DriverManager.getConnection(nexusURL, userName, userPass);
			System.out.println("nexus con:" + conn);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;

	}

	public static void main(String args[]) {
		PSKDBConnect op = new PSKDBConnect();
		try {
			connectNEXUS();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
