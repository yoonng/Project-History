package ext.psk.common.util;

import java.util.Vector;

public class CommonCodeUtil {

	public static Vector getCodeType() {
		Vector codeType = new Vector();   
		
		codeType.add("product");
		codeType.add("segment");
		codeType.add("changeReason");		// change Reason
		codeType.add("eoType");				// Eo Type
		codeType.add("module");				// module
		codeType.add("serial");				// serial
		codeType.add("model");				//
		codeType.add("unit");				// 
		codeType.add("temporaryCADType");	// Temporary Cad 
		codeType.add("yesNo");
		codeType.add("yesNoNA");				
		codeType.add("improvementEffect");	// 
		codeType.add("customerSite");		// customer site
		codeType.add("inspectionResult"); 	// EVN
		codeType.add("trueFalse");
		codeType.add("trueFalseNA");
		codeType.add("stockMgt");
		codeType.add("reasonCode");
		codeType.add("maker");
		
		return codeType;
	}
}
