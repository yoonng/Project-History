package ext.psk.common.util;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class PSKUserInfoUtil {   

	public static Hashtable titleTable = new Hashtable();
	public static Vector titleNameList = new Vector();
	public static Vector titleCodeList = new Vector();
	public static Vector positionCodeList = new Vector();

		static {
		String positionNameStr = "임원;상근고문;팀장;팀원";
		String titleNameStr = "회장;부회장;대표이사;부사장;상임감사;전무;상무;이사;실장;부장;수석연구원;지사장;리더;차장;팀장;책임연구원;과장;대리;선임연구원;계장;주임;사원;연구원;협력사;계약직;임시직";
		String titleCodeStr = "10;20;30;40;50;60;70;80;90;100;110;120;130;140;150;160;170;180;190;200;210;220;230;240;250;260";
		
		StringTokenizer positionToken = new StringTokenizer(positionNameStr,";");
		StringTokenizer nameToken = new StringTokenizer(titleNameStr,";");
		StringTokenizer codeToken = new StringTokenizer(titleCodeStr,";");
		
		while(nameToken.hasMoreTokens()){
		    String name = (String)nameToken.nextElement();
		    String code = (String)codeToken.nextElement();
		    titleTable.put(code,name);
		    titleNameList.add(name);
		    titleCodeList.add(code);
		}
		
		while(positionToken.hasMoreTokens()){
		    String name = (String)positionToken.nextElement();
		    positionCodeList.add(name);
		}
	}

}
