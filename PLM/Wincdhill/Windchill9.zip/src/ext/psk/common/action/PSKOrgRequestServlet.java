package ext.psk.common.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;

import ext.psk.common.*;

public class PSKOrgRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getParameter("cmd");
		String returnURI = "";
		String strReturn = "";
		
		
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		
		System.out.println("Request Start ===== " + cmd);
		Iterator itor = (Iterator)req.getParameterNames();
		while( itor.hasNext() ) {
			String shKey = "";
			
			String key = itor.next().toString();
			String value = CommonUtil.checkNull( req.getParameter(key) );
			
			if( key.equals("sessionID") && value.equals("0") ) value = "";
			
			form.put(key, value); 
			
			System.out.println("key : " + key + " ____  value = " + value );
		}
		
		//System.out.println("getRequestURI : " + req.getRequestURI() );
		//System.out.println("getContextPath : " + req.getContextPath() );

		if( cmd.equals("registCommon") || cmd.equals("deleteCommon") || cmd.equals("updateCommon") ) {
			returnURI = "/Windchill/extcore/psk/jsp/common/common-list.jsp";
		}
		
		try{
			if( cmd.equals("orgApproval") ) {
				returnURI = "/extcore/psk/jsp/common/org-approval.jsp";
				
				HashMap resultMap = CommonHelper.service.searchPSKUserInfo(form);
				session.setAttribute("appForm", resultMap);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("orgTree") ) {
				returnURI = "/extcore/psk/jsp/common/org-tree.jsp";
				
				HashMap resultMap = CommonHelper.service.searchPSKUserInfo(form);
				session.setAttribute("deptTree", resultMap);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("teamUserSearch") ) {
				returnURI = "/extcore/psk/jsp/common/org-user.jsp";
				
				HashMap resultMap = CommonHelper.service.searchPSKUserInfo(form);
				session.setAttribute("userList", resultMap);
				
				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("teamSearch") ) {			//update Form Data Call
				returnURI = "/extcore/psk/jsp/common/org-dept.jsp";

				HashMap resultMap = CommonHelper.service.searchPSKUserInfo(form);
				session.setAttribute("userList", resultMap);
				
				this.gotoResult( req, res, returnURI);

			}
			
			System.out.println("Request End ===== " + cmd);
			
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}
