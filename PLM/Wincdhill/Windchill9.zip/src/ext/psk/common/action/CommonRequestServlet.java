package ext.psk.common.action;

import ilog.views.faces.internalutil.IlvPortletUtil.REQUEST;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;

import ext.psk.common.*;

public class CommonRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getParameter("cmd");
		String returnURI = "";
		String strReturn = "";
		
		
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		
		System.out.println("Request Start ===== " + cmd);
		Iterator itor = (Iterator)req.getParameterNames();
		while( itor.hasNext() ) {
			String shKey = "";
			
			String key = itor.next().toString();
			String value = CommonUtil.checkNull( req.getParameter(key) );
			
			if( key.equals("sessionID") && value.equals("0") ) value = "";
			
			form.put(key, value); 
			
			System.out.println("key : " + key + " ____  value = " + value );
		}
		
		if( cmd.equals("registCommon") || cmd.equals("deleteCommon") || cmd.equals("updateCommon") ) {
			returnURI = "/Windchill/extcore/psk/jsp/common/common-list.jsp";
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";
			
			if( cmd.equals("listCommon") || cmd.equals("listCommonPopup") ) {
				if ( cmd.equals("listCommon") ) {
					returnURI = "/extcore/psk/jsp/common/common-list.jsp";
				} else if( cmd.equals("listCommonPopup") ) {
					returnURI = "/extcore/psk/jsp/common/common-Popup.jsp";
				}
				
				HashMap resultMap = CommonHelper.service.searchCode(form);
				QueryResult queryResult = (QueryResult)resultMap.get("results");
				session.setAttribute("control", queryResult);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("listECM") ) {
				returnURI = "/extcore/psk/jsp/ecm/ecm-list.jsp";

				HashMap resultMap = CommonHelper.service.searchChildCode(form);
				
				int totalCount = Integer.parseInt( (String)resultMap.get("totalCount") );
				PageControl control = new PageControl( (Vector)resultMap.get("results") , CommonUtil.parseInt( CommonUtil.checkNull( form.get("page").toString() ), 1), totalCount );
				session.setAttribute("control", control);
				
				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("registCommon") ) {			//Common Regist
				strReturn = CommonHelper.service.createCode(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("registCommonForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/common/common-regist.jsp";
				
				this.gotoResult( req, res, returnURI);
			
			} else if( cmd.equals("updateCommonForm") || cmd.equals("viewCommon") ) {			//update Form Data Call
				if( cmd.equals("updateCommonForm") ) {
					returnURI = "/extcore/psk/jsp/common/common-update.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/common/common-view.jsp";
				}

				HashMap resultMap = CommonHelper.service.searchCode(form);
				QueryResult queryResult = (QueryResult)resultMap.get("results");
				queryResult.reset();
				Object[] obj = (Object[])queryResult.nextElement();
				CommonCode commonCode = (CommonCode)obj[0];
				session.setAttribute("commonCode", commonCode);
				
				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updateCommon") ) {
				strReturn = CommonHelper.service.updateCode(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc(res, strReturn, errCallMathod);
				}

			} else if( cmd.equals("deleteCommon") ) {			//not yet
				strReturn = CommonHelper.service.deleteCode(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			}
			
			System.out.println("Request End ===== " + cmd);
			
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}
