// Generated StandardCommonService%4C7C9D4B038A: ? 10/18/10 11:01:36
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import ext.psk.common.CommonService;
import ext.psk.common.util.PSKDBConnect;

import java.io.Serializable;
import java.lang.String;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import ext.psk.util.CommonUtil;  // Preserved unmodeled dependency
import ext.psk.util.LdapSearchUser;

import java.util.Enumeration;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency

import oracle.jdbc.driver.OracleResultSetMetaData;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;  // Preserved unmodeled dependency
import wt.fc.QueryResult;  // Preserved unmodeled dependency
import wt.fc.ReferenceFactory;  // Preserved unmodeled dependency
import wt.org.OrganizationServicesHelper;  // Preserved unmodeled dependency
import wt.org.WTGroup;  // Preserved unmodeled dependency
import wt.org.WTPrincipal;  // Preserved unmodeled dependency
import wt.org.WTUser;  // Preserved unmodeled dependency
import wt.pds.oracle81.OraclePds81;
import wt.pom.Transaction;  // Preserved unmodeled dependency
import wt.query.ClassAttribute;  // Preserved unmodeled dependency
import wt.query.OrderBy;  // Preserved unmodeled dependency
import wt.query.QuerySpec;  // Preserved unmodeled dependency
import wt.query.SearchCondition;  // Preserved unmodeled dependency
//##end user.imports

//##begin StandardCommonService%4C7C9D4B038A.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardCommonService</code> static factory method(s),
 * not the <code>StandardCommonService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardCommonService%4C7C9D4B038A.doc

public class StandardCommonService extends StandardManager implements CommonService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.common.commonResource";
   private static final String CLASSNAME = StandardCommonService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardCommonService%newStandardCommonServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardCommonService
    * @exception wt.util.WTException
    **/
   //##end newStandardCommonService%newStandardCommonServicef.doc

   public static StandardCommonService newStandardCommonService()
            throws WTException {
      //##begin newStandardCommonService%newStandardCommonServicef.body preserve=no

      StandardCommonService instance = new StandardCommonService();
      instance.initialize();
      return instance;
      //##end newStandardCommonService%newStandardCommonServicef.body
   }

   //##begin createCode%4C7C9E26007D.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createCode%4C7C9E26007D.doc

   public String createCode( HashMap form )
            throws WTException {
      //##begin createCode%4C7C9E26007D.body preserve=yes
		CommonCode codeForm = CommonCode.newCommonCode();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sCodeType = (String) form.get("codeType");
			String sCode = (String) form.get("code");
			String sCodeNameKr = (String) form.get("codeNameKr");
			String sCodeNameEn = (String) form.get("codeNameEn");
			String sCodeValueKr = (String) form.get("codeValueKr");
			String sCodeValueEn = (String) form.get("codeValueEn");
			
			String sIsDeleted = (String) form.get("isDeleted");
			String sDescription = (String) form.get("description");

			String sCodeOne = (String) form.get("codeOne");
			String sCodeTwo = (String) form.get("codeTwo");
			String sCodeThree = (String) form.get("codeThree");
			
			if (sCode != null && !sCode.equals("")) codeForm.setCode(sCode); // 
			if (sCodeNameKr != null && !sCodeNameKr.equals("")) codeForm.setCodeName(sCodeNameKr); // 
			if (sCodeNameEn != null && !sCodeNameEn.equals("")) codeForm.setCodeNameEn(sCodeNameEn); //
			if (sCodeValueKr != null && !sCodeValueKr.equals("")) codeForm.setCodeValue(sCodeValueKr); // 
			if (sCodeValueEn != null && !sCodeValueEn.equals("")) codeForm.setCodeValueEn(sCodeValueEn); // 
			
			if (sCodeOne != null && !sCodeOne.equals("")) codeForm.setCodeOne(sCodeOne); // 
			if (sCodeTwo != null && !sCodeTwo.equals("")) codeForm.setCodeTwo(sCodeTwo); // 
			if (sCodeThree != null && !sCodeThree.equals("")) codeForm.setCodeThree(sCodeThree); // 
			if (sDescription != null && !sDescription.equals("")) codeForm.setDescription(sDescription); // 
			if (sIsDeleted != null && !sIsDeleted.equals("")) codeForm.setIsDelete(sIsDeleted); //
			
			if (sCodeType != null && !sCodeType.equals("")) codeForm.setCodeType(sCodeType); // 

			if( !existCode(sCodeType, sCode) ) {
				codeForm = (CommonCode) PersistenceHelper.manager.save(codeForm);
			} else { 
				throw new WTException("Code is duplicated!");
			}
			
			result += " : " + codeForm.getCodeType() + " : " + codeForm.getCode();
			//System.out.println("@ created CommonCode =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end createCode%4C7C9E26007D.body
   }

   //##begin deleteCode%4C7C9E3E036B.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteCode%4C7C9E3E036B.doc

   public String deleteCode( HashMap form )
            throws WTException {
      //##begin deleteCode%4C7C9E3E036B.body preserve=yes

	   /**
	    * 1. ??? ??? ???
	    * 2. ?????parent, Child????? Link????? 
	    */
	   
	   return null;
      //##end deleteCode%4C7C9E3E036B.body
   }

   //##begin updateCode%4C7C9E820280.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateCode%4C7C9E820280.doc

   public String updateCode( HashMap form )
            throws WTException {
      //##begin updateCode%4C7C9E820280.body preserve=yes
		ReferenceFactory rf = new ReferenceFactory();
		
		String sOid = (String) form.get("oid");
		CommonCode codeForm = (CommonCode) rf.getReference(sOid).getObject();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sCodeType = (String) form.get("codeType");
			String sCode = (String) form.get("code");
			
			String sCodeNameKr = (String) form.get("codeNamekr");
			String sCodeNameEn = (String) form.get("codeNameEn");
			String sCodeValueKr = (String) form.get("codeValueKr");
			String sCodeValueEn = (String) form.get("codeValueEn");
			
			String sIsDeleted = (String) form.get("isDeleted");
			String sDescription = (String) form.get("description");

			String sCodeOne = (String) form.get("codeOne");
			String sCodeTwo = (String) form.get("codeTwo");
			String sCodeThree = (String) form.get("codeThree");
			
			if (sCodeType != null) codeForm.setCodeType(sCodeType); //
			
			if (sCode != null) codeForm.setCode(sCode); // 
			if (sCodeNameKr != null) codeForm.setCodeName(sCodeNameKr); // 
			if (sCodeNameEn != null) codeForm.setCodeNameEn(sCodeNameEn); //
			if (sCodeValueKr != null) codeForm.setCodeValue(sCodeValueKr); // 
			if (sCodeValueEn != null) codeForm.setCodeValueEn(sCodeValueEn); //
			
			if (sIsDeleted != null) codeForm.setIsDelete(sIsDeleted); //
			if (sDescription != null) codeForm.setDescription(sDescription); //
			
			if (sCodeOne != null) codeForm.setCodeOne(sCodeOne); // 
			if (sCodeTwo != null) codeForm.setCodeTwo(sCodeTwo); // 
			if (sCodeThree != null) codeForm.setCodeThree(sCodeThree); //

			codeForm = (CommonCode) PersistenceHelper.manager.save(codeForm);
			
			result += " : " + codeForm.getCodeType() + " : " + codeForm.getCode();
			//System.out.println("@ updated CommonCode =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end updateCode%4C7C9E820280.body
   }

   //##begin searchCode%4C7C9E930290.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchCode%4C7C9E930290.doc

   public HashMap searchCode( HashMap form )
            throws WTException {
      //##begin searchCode%4C7C9E930290.body preserve=yes

		HashMap results = new HashMap();
	   	QueryResult queryResult = null; 
	   	
	   String sCmd = (String) form.get("cmd");
	   String sPage = (String) form.get("page");
	   String sTotalPage = (String) form.get("totalPage");
	   String sSessionID = (String) form.get("sessionID");
		   
		String sCodeType = (String) form.get("codeType");
		String sCode = (String) form.get("code");
		String sDel = (String) form.get("del");

		try {
			QuerySpec query = new QuerySpec();

			if (query.getConditionCount() > 0) query.appendAnd();

			Class classType = CommonCode.class;
			int pskIndex = query.appendClassList(classType, true);
			
			if (sCodeType != null && !sCodeType.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, CommonCode.CODE_TYPE, SearchCondition.EQUAL, sCodeType), new int[] { pskIndex });
			}
			
			if (sCode != null && !sCode.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, CommonCode.CODE, SearchCondition.EQUAL, sCode), new int[] { pskIndex });
			}
			
			if (sDel != null && !sDel.equals("")) {
				if (query.getConditionCount() > 0) query.appendAnd();
				query.appendWhere(new SearchCondition(classType, CommonCode.IS_DELETE, SearchCondition.EQUAL, sDel), new int[] { pskIndex });
			}

			ClassAttribute classattribute = new ClassAttribute();
			OrderBy orderby = null;
			classattribute = new ClassAttribute(classType, CommonCode.CODE);
			orderby = new OrderBy(classattribute, true);

			query.appendOrderBy(orderby, new int[] { 0 });

			//System.out.println("## REQUEST Query:" + query.toString());
			
			queryResult = PersistenceHelper.manager.find(query);
			
			results.put("results", queryResult);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return results;
      //##end searchCode%4C7C9E930290.body
   }

   //##begin createLinkCode%4C7C9EA60232.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createLinkCode%4C7C9EA60232.doc

   public String createLinkCode( HashMap form )
            throws WTException {
      //##begin createLinkCode%4C7C9EA60232.body preserve=yes

      return null;
      //##end createLinkCode%4C7C9EA60232.body
   }

   //##begin deleteLinkCode%4C7C9ED10128.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deleteLinkCode%4C7C9ED10128.doc

   public String deleteLinkCode( HashMap form )
            throws WTException {
      //##begin deleteLinkCode%4C7C9ED10128.body preserve=yes

      return null;
      //##end deleteLinkCode%4C7C9ED10128.body
   }

   //##begin searchChildCode%4C7C9EDE005D.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchChildCode%4C7C9EDE005D.doc

   public HashMap searchChildCode( HashMap form )
            throws WTException {
      //##begin searchChildCode%4C7C9EDE005D.body preserve=yes

	   OraclePds81 dds = new OraclePds81();
	   Connection con = null;
	   Statement stmt = null;
	   
	   HashMap result = new HashMap();
	   
	   String sCmd = (String) form.get("cmd");
	   String sSearchType = (String) form.get("searchType");
	   String sPage = (String) form.get("page");
	   String sPageRowCnt = (String) form.get("initPerPage");
	   
	   if( sPageRowCnt != null && sPageRowCnt.equals("") ) sPageRowCnt = "10";
	   
	   if( sPage != null && sPage.equals("") ) sPage = "1";

       String sNumber            = (String) form.get("shNumber");
       String sName              = (String) form.get("shName");
       
       String sState     = (String) form.get("shApprovalStatus");
       
       String sFromRegDate   = (String) form.get("shFromRegDate");
       String sToRegDate   = (String) form.get("shToRegDate");
       
       String sCreatorName = (String) form.get("shIssueUserNm");
       String sCreator = "";
       long lcreator = 0;
       if( sCreatorName != null && !sCreatorName.equals("") ) {
    	   LdapSearchUser searchUserId = new LdapSearchUser();
    	   sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName);
    	   
    	   if (sCreator != null && !sCreator.equals("")) {
    		   
    		   WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
    		   if( creator != null ) {
    			   lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
    			   if( !sCreator.equals( creator.getName() )) {
    				   sCreator = creator.getName();
    			   }
    		   }
    	   }
       }

       String query = "";
       String cntQuery = "";
       String pageQuery = "";
	   
	   try {
		   
		   //ECM --> ECR
		   if( sSearchType.equals("ECR") ) {
		    
		       query  = "   SELECT   ECR.*                                                                        \n";
		       query += "           ,EO.*                                                                         \n";
		       query += "           ,EVR.*                                                                        \n";
		       query += "           ,EVN.*                                                                        \n";
		       query += "     FROM  (                                                                             \n";
		       query += "               SELECT  A.BRANCHIDITERATIONINFO AS ECR_ADDR_LINK                          \n";
		       query += "                      ,A.IDA2A2 AS ECR_KEY                                               \n";
		       query += "                      ,A.CLASSNAMEA2A2 || ':' || A.IDA2A2 AS ECR_OID                     \n";
		       query += "                      ,TO_CHAR(A.RELEASEDATE,'yyyy-MM-dd') AS ECR_DATE                   \n";
		       query += "                      ,B.WTCHGREQUESTNUMBER AS ECR_NUMBER                                \n";
		       query += "                      ,B.NAME AS ECR_NAME                                                \n";
		       query += "                      ,A.STATESTATE AS ECR_STATE                                         \n";
		       query += "                      ,A.CREATESTAMPA2 AS ECR_CRE_DATE                                   \n";
		       query += "                 FROM  ECREQUEST A                                                       \n";
		       query += "                      ,WTCHANGEREQUEST2MASTER B                                          \n";
		       query += "                WHERE A.IDA3MASTERREFERENCE = B.IDA2A2                                   \n";
		       query += "                  AND A.LATESTITERATIONINFO = 1                                          \n";
		       
		       if (sNumber != null && !sNumber.equals("")) {
		    	   query += "                  AND B.WTCHGREQUESTNUMBER LIKE '%" + sNumber + "%'                  \n";
		       }
		       
		       if (sName != null && !sName.equals("")) {
		    	   query += "                  AND B.NAME LIKE '%" + sName + "%'                                  \n";
		       }
		       
		       if (sFromRegDate != null && !sFromRegDate.equals("")) {
		    	   query += "                  AND TO_CHAR(B.CREATESTAMPA2,'yyyy-MM-dd') >= '" + sFromRegDate + "'\n";
		       }
		       
		       if (sToRegDate != null && !sToRegDate.equals("")) {
		    	   query += "                  AND TO_CHAR(B.CREATESTAMPA2,'yyyy-MM-dd') <= '" + sToRegDate + "'  \n";
		       }
		       
		       if (sState != null && !sState.equals("")) {
		    	   query += "                  AND A.STATESTATE = '" + sState + "'                                \n";
		       }
		       
		       if ( lcreator != 0 ) {
		    	   query += "                  AND A.IDA3B7 = " + lcreator + "                                    \n";
		       }
		       
		       query += "           ) ECR                                                                         \n";
		       query += "          ,ADDRESSEDBY2    ADDR                                                          \n";
		       query += "          ,(                                                                             \n";
		       query += "               SELECT  A.BRANCHIDITERATIONINFO AS EO_ADDR_LINK                           \n";
		       query += "                      ,A.IDA2A2 AS EO_KEY                                                \n";
		       query += "                      ,A.CLASSNAMEA2A2 || ':' || A.IDA2A2 AS EO_OID                      \n";
		       query += "                      ,TO_CHAR(A.RELEASEDATE,'yyyy-MM-dd') AS EO_DATE                    \n";
		       query += "                      ,B.WTCHGORDERNUMBER AS EO_NUMBER                                   \n";
		       query += "                      ,B.NAME AS EO_NAME                                                 \n";
		       query += "                      ,A.STATESTATE AS EO_STATE                                          \n";
		       query += "                      ,C.*                                                               \n";
		       query += "                 FROM  EOALPHAFORM A                                                     \n";
		       query += "                      ,WTCHANGEORDER2MASTER B                                            \n";
		       query += "                      ,(                                                                 \n";
		       query += "                        SELECT  A.IDA3A5 AS EO_LINK                                      \n";
		       query += "                               ,A.IDA3B5 AS EO_EVR_LINK                                  \n";
		       query += "                          FROM  EOTOEVRLINK A                                            \n";
		       query += "                               ,EVREQUEST B                                              \n";
		       query += "                         WHERE B.LATESTITERATIONINFO = 1                                 \n";
		       query += "                           AND B.IDA2A2 = A.IDA3B5                                       \n";
		       query += "                       ) C                                                               \n";
		       query += "                WHERE A.IDA3MASTERREFERENCE = B.IDA2A2                                   \n";
		       query += "                  AND A.LATESTITERATIONINFO = 1                                          \n";
		       query += "                  AND A.IDA2A2 = C.EO_LINK(+)                                            \n";
		       query += "           ) EO                                                                          \n";
		       query += "          ,(                                                                             \n";
		       query += "               SELECT  A.IDA2A2 AS EVR_KEY                                               \n";
		       query += "                      ,A.CLASSNAMEA2A2 || ':' || A.IDA2A2 AS EVR_OID                     \n";
		       query += "                      ,TO_CHAR(A.RELEASEDATE,'yyyy-MM-dd') AS EVR_DATE                   \n";
		       query += "                      ,B.WTDOCUMENTNUMBER AS EVR_NUMBER                                  \n";
		       query += "                      ,B.NAME AS EVR_NAME                                                \n";
		       query += "                      ,A.STATESTATE AS EVR_STATE                                         \n";
		       query += "                 FROM  EVREQUEST A                                                       \n";
		       query += "                      ,WTDOCUMENTMASTER B                                                \n";
		       query += "                      ,WTDOCUMENTDEPENDENCYLINK C                                        \n";
		       query += "                      ,EVNOTICE D                                                        \n";
		       query += "                WHERE A.IDA3MASTERREFERENCE = B.IDA2A2                                   \n";
		       query += "                  AND A.IDA2A2 = C.IDA3B5                                                \n";
		       query += "                  AND D.IDA2A2 = C.IDA3A5                                                \n";
		       query += "                  AND A.LATESTITERATIONINFO = 1                                          \n";
		       query += "                  AND D.LATESTITERATIONINFO = 1                                          \n";
		       query += "           ) EVR                                                                         \n";
		       query += "          ,(                                                                             \n";
		       query += "               SELECT  A.IDA2A2 AS EVN_KEY                                               \n";
		       query += "                      ,A.CLASSNAMEA2A2 || ':' || A.IDA2A2 AS EVN_OID                     \n";
		       query += "                      ,TO_CHAR(A.RELEASEDATE,'yyyy-MM-dd') AS EVN_DATE                   \n";
		       query += "                      ,B.WTDOCUMENTNUMBER AS EVN_NUMBER                                  \n";
		       query += "                      ,B.NAME AS EVN_NAME                                                \n";
		       query += "                      ,A.STATESTATE AS EVN_STATE                                         \n";
		       query += "                      ,C.IDA3B5 AS EVR_LINK                                              \n";
		       query += "                 FROM  EVNOTICE A                                                        \n";
		       query += "                      ,WTDOCUMENTMASTER B                                                \n";
		       query += "                      ,WTDOCUMENTDEPENDENCYLINK C                                        \n";
		       query += "                      ,EVREQUEST D                                                       \n";
		       query += "                WHERE A.IDA3MASTERREFERENCE = B.IDA2A2                                   \n";
		       query += "                  AND A.IDA2A2 = C.IDA3A5                                                \n";
		       query += "                  AND D.IDA2A2 = C.IDA3B5                                                \n";
		       query += "                  AND A.LATESTITERATIONINFO = 1                                          \n";
		       query += "                  AND D.LATESTITERATIONINFO = 1                                          \n";
		       query += "           ) EVN                                                                         \n";
		       query += "    WHERE ECR.ECR_ADDR_LINK = ADDR.BRANCHIDA3A5(+)                                       \n";
		       query += "      AND ADDR.BRANCHIDA3B5 = EO.EO_ADDR_LINK(+)                                         \n";
		       query += "      AND EO.EO_EVR_LINK = EVR.EVR_KEY(+)                                                \n";
		       query += "      AND EVR.EVR_KEY = EVN.EVR_LINK(+)                                                  \n";
		       query += "    ORDER BY ECR.ECR_CRE_DATE DESC                                                       \n";

		       //Count Query Make
			   cntQuery  = "  SELECT *                                                               \n";
			   cntQuery += "    FROM (                                                               \n";
			   cntQuery += "          SELECT  COUNT(*) AS CNT                                        \n";
			   cntQuery += "            FROM (                                                       \n";
			   cntQuery += query;
			   cntQuery += "                 ) A                                                                        \n";
			   cntQuery += "         ) A                                                                                \n";

			   //Paging Query Make
			   pageQuery  = "  SELECT *                                                               \n";
			   pageQuery += "    FROM (                                                               \n";
			   pageQuery += "          SELECT  ROWNUM AS NUM                                          \n";
			   pageQuery += "                 ,A.*                                                    \n";
			   pageQuery += "            FROM (                                                       \n";
			   pageQuery += query;
			   pageQuery += "                 ) A                                                                        \n";
			   pageQuery += "         ) A                                                                                \n";
			   pageQuery += "   WHERE NUM BETWEEN ("+ sPage +"-1) * "+ sPageRowCnt +"+1 AND ("+ sPage +") * "+ sPageRowCnt +"   \n";
		       
		       con = dds.getDataSource().getConnection();
		       stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);

		   //ECM --> PSCR
		   } else {
			   
			   query  = "       SELECT  A.*                                                                                           \n";
			   query += "              ,CASE A.PSCR_STTS_CD                                                                           \n";
			   query += "               WHEN '0' THEN 'INWORK'                                                                        \n";
			   query += "               WHEN '1' THEN 'INAPPROVE'                                                                     \n";
			   query += "               WHEN '2' THEN 'RELEASED'                                                                      \n";
			   query += "               WHEN '4' THEN 'REJECTED'                                                                      \n";
			   query += "               END AS PR_STTS_CD                                                                             \n";
			   query += "              ,CASE A.PSCN_STTS_CD                                                                           \n";
			   query += "               WHEN '0' THEN 'INWORK'                                                                        \n";
			   query += "               WHEN '1' THEN 'INAPPROVE'                                                                     \n";
			   query += "               WHEN '2' THEN 'RELEASED'                                                                      \n";
			   query += "               WHEN '4' THEN 'REJECTED'                                                                      \n";
			   query += "               END AS PN_STTS_CD                                                                             \n";
			   query += "         FROM VIEW_PSCRN_STTS A                                                                              \n";
			   query += "        WHERE 1=1                                                                                            \n";
			   query += "          AND A.PSCR_STTS_CD = CASE '" + sState + "' WHEN 'INWORK'     THEN '0'                              \n";
			   query += "                                                   WHEN 'INAPPROVE'  THEN '1'                                \n";
			   query += "                                                   WHEN 'RELEASED'   THEN '2'                                \n";
			   query += "                                                   WHEN 'PRERELEASED' THEN '2'                               \n";
			   query += "                                                   WHEN 'REJECTED'   THEN '4'                                \n";
			   query += "                                                   ELSE A.PSCR_STTS_CD                                       \n";
			   query += "                             END                                                                             \n";			   
			   
		       if (sNumber != null && !sNumber.equals("")) {
		    	   query += "          AND A.PSCR_NO LIKE '%" + sNumber + "%'                                                           \n";
		       }
		       
		       if (sName != null && !sName.equals("")) {
		    	   query += "          AND A.PSCR_TITL LIKE '%" + sName + "%'                                                           \n";
		       }
		       
		       if (sFromRegDate != null && !sFromRegDate.equals("")) {
		    	   query += "          AND A.PR_CRTN_DT >= '" + sFromRegDate + "'                                                       \n";
		       }
		       
		       if (sToRegDate != null && !sToRegDate.equals("")) {
		    	   query += "          AND A.PR_CRTN_DT <= '" + sToRegDate + "'                                                         \n";
		       }
		       
		       if (sState != null && !sState.equals("")) {
		       }
		       
		       if (sCreator != null && !sCreator.equals("")) {
		    	   query += "          AND A.PR_CRTR_EMPNO = '" + sCreator + "'                                                           \n";
		       }
		       
		       query += "        ORDER BY A.PR_CRTN_DT DESC                                                                             \n";
		       
		       //Count Query Make
			   cntQuery  = "  SELECT *                                                               \n";
			   cntQuery += "    FROM (                                                               \n";
			   cntQuery += "          SELECT  COUNT(*) AS CNT                                        \n";
			   cntQuery += "            FROM (                                                       \n";
			   cntQuery += query;
			   cntQuery += "                 ) A                                                                        \n";
			   cntQuery += "         ) A                                                                                \n";
			   
			   //Paging Query Make
			   pageQuery  = "  SELECT *                                                               \n";
			   pageQuery += "    FROM (                                                               \n";
			   pageQuery += "          SELECT  ROWNUM AS NUM                                          \n";
			   pageQuery += "                 ,A.*                                                    \n";
			   pageQuery += "            FROM (                                                       \n";
			   pageQuery += query;
			   pageQuery += "                 ) A                                                                        \n";
			   pageQuery += "         ) A                                                                                \n";
			   pageQuery += "   WHERE NUM BETWEEN ("+ sPage +"-1) * "+ sPageRowCnt +"+1 AND ("+ sPage +") * "+ sPageRowCnt +"   \n";
		       
		       con = PSKDBConnect.connectNEXUS();
		       stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
		   }
		   
		   //totalCount Query Start
	       //System.out.println("sql:" + cntQuery);
	       ResultSet rs = stmt.executeQuery( cntQuery );
	       int totalCount = 0;

	       while ( rs != null && rs.next() ) {
	    	   OracleResultSetMetaData metaData = (OracleResultSetMetaData)rs.getMetaData();
	    	   HashMap row = new HashMap();
	    	   
	    	   for( int i = 1; i <= metaData.getColumnCount(); i++ ) {
			       String colName = metaData.getColumnName(i);
			       totalCount = rs.getInt(colName);
	    	   }
	       }
	       result.put("totalCount", totalCount + "" );
	       
	       try {
	    	   if( rs != null ) rs.close();
	       } catch(SQLException ee) {
	    	   ee.printStackTrace();
	       }
		   
		   //paging Query Start
	       Vector table = new Vector();
	       System.out.println("sql:" + pageQuery);
	       rs = stmt.executeQuery( pageQuery );
	       
	       while ( rs != null && rs.next() ) {
	    	   OracleResultSetMetaData metaData = (OracleResultSetMetaData)rs.getMetaData();
	    	   HashMap row = new HashMap();

	    	   //System.out.println(" getColumnCount " +  ttt.getColumnCount() );
	    	   
	    	   for( int i = 1; i <= metaData.getColumnCount(); i++ ) {
	    		   //System.out.println(" getColumnName " +  ttt.getColumnName(i) );
	    		   //System.out.println(" getColumnType " +  ttt.getColumnType(i) );
	    		   //System.out.println(" getColumnTypeName " +  ttt.getColumnTypeName(i) );
			       
			       String colName = metaData.getColumnName(i);
			       int colType = metaData.getColumnType(i);
			       
			       switch( colType ) {
				       case 12 :		//VARCHAR2
				    	   //System.out.println(colName + " : " + rs.getString(colName));
				    	   String colValue = rs.getString(colName) == null ? "" : rs.getString(colName);
				    	   row.put(colName, colValue );
				    	   break;
				    	   
				       case 91 :		//DATE
				    	   //System.out.println(colName + " : " + rs.getDate(colName));
				    	   row.put(colName, rs.getDate(colName) );
				    	   break;
				    	   
				       case 2 :			//NUMBER
				    	   //System.out.println(colName + " : " + rs.getDouble(colName));
				    	   row.put(colName, rs.getBigDecimal(colName) );
				    	   break;
				    	   
			    	   default:
			    		   System.out.println( colName + " : " + "Error");
			    		   break;
			       }
	    	   }
	    	   
	    	   table.add(row);
	       }
	
	       result.put("results", table);
	       result.put("page", sPage);
	       
	   } catch (SQLException e) {
	       e.printStackTrace();
	       
	   } finally {
	       try { if (stmt != null ) stmt.close(); } catch (SQLException e) { e.printStackTrace(); }
	       try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
	   }
	   
	   return result;
      //##end searchChildCode%4C7C9EDE005D.body
   }

   //##begin createPSKUserInfo%4C7E033802EE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createPSKUserInfo%4C7E033802EE.doc

   public String createPSKUserInfo( HashMap form )
            throws WTException {
      //##begin createPSKUserInfo%4C7E033802EE.body preserve=yes
		PSKUserInfo userForm = PSKUserInfo.newPSKUserInfo();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			String sWtUserOid = (String) form.get("wtUserOid");
			WTUser wtUser = (WTUser)rf.getReference(sWtUserOid).getObject();
			
			String sEnName = (String) form.get("enName");
			String sKRAddress = (String) form.get("krAddress");
			String sEnAddress = (String) form.get("enAddress");

			String sCellPhone = (String) form.get("cellPhone");
			String sInternalPhone = (String) form.get("internalPhone");
			String sTelePhone = (String) form.get("telePhone");
			String seMail = (String) form.get("eMail");
			String sPosition = (String) form.get("position");
			
			String sTitle = (String) form.get("title");
			String sTitleIndex = (String) form.get("titleIndex");
			String sSecureID = (String) form.get("secureID");
			String sJoiningDate = (String) form.get("joiningDate");
			String sRetirementDate = (String) form.get("retirementDate");
			
			String sIsRetirement = (String) form.get("isRetirement");
			
			if (wtUser != null ) userForm.setWtUser(wtUser);
			if (sEnName != null && !sEnName.equals("")) userForm.setEnName(sEnName); //
			if (sKRAddress != null && !sKRAddress.equals("")) userForm.setKrAddress(sKRAddress); // 
			if (sEnAddress != null && !sEnAddress.equals("")) userForm.setEnAddress(sEnAddress); // 
			
			if (sCellPhone != null && !sCellPhone.equals("")) userForm.setCellPhone(sCellPhone); // 
			if (sInternalPhone != null && !sInternalPhone.equals("")) userForm.setInternalPhone(sInternalPhone); // 
			if (sTelePhone != null && !sTelePhone.equals("")) userForm.setTelPhone(sTelePhone); //
			if (sPosition != null && !sPosition.equals("")) userForm.setPosition(sPosition); //

			if (sTitle != null && !sTitle.equals("")) userForm.setTitle(sTitle); // 
			if (sTitleIndex != null && !sTitleIndex.equals("")) userForm.setTitleIndex(sTitleIndex); // 
			if (sSecureID != null && !sSecureID.equals("")) userForm.setSecureID(sSecureID); // 
			if (sJoiningDate != null && !sJoiningDate.equals("")) userForm.setJoiningDate(sJoiningDate); // 
			if (sRetirementDate != null && !sRetirementDate.equals("")) userForm.setRetirementDate(sRetirementDate); //
			if (sIsRetirement != null && !sIsRetirement.equals("")) userForm.setIsRetirement(sIsRetirement); //
			
			userForm = (PSKUserInfo) PersistenceHelper.manager.save(userForm);
			
			result += " : " + wtUser.getName();
			//System.out.println("@ created PSKUserInfo =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end createPSKUserInfo%4C7E033802EE.body
   }

   //##begin updatePSKUserInfo%4C7E03630399.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updatePSKUserInfo%4C7E03630399.doc

   public String updatePSKUserInfo( HashMap form )
            throws WTException {
      //##begin updatePSKUserInfo%4C7E03630399.body preserve=yes
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sPskUserOid = (String) form.get("pskUserOid");
			PSKUserInfo userForm = (PSKUserInfo)rf.getReference(sPskUserOid).getObject();
			
			String sWtUserOid = (String) form.get("wtUserOid");
			WTUser wtUser = (WTUser)rf.getReference(sWtUserOid).getObject();
			
			String sEnName = (String) form.get("enName");
			String sKRAddress = (String) form.get("krAddress");
			String sEnAddress = (String) form.get("enAddress");

			String sCellPhone = (String) form.get("cellPhone");
			String sInternalPhone = (String) form.get("internalPhone");
			String sTelePhone = (String) form.get("telePhone");
			String seMail = (String) form.get("eMail");
			String sPosition = (String) form.get("position");
			
			String sTitle = (String) form.get("title");
			String sTitleIndex = (String) form.get("titleIndex");
			String sSecureID = (String) form.get("secureID");
			String sJoiningDate = (String) form.get("joiningDate");
			String sRetirementDate = (String) form.get("retirementDate");
			
			String sIsRetirement = (String) form.get("isRetirement");
			
			if (wtUser != null ) userForm.setWtUser(wtUser); 
			if (sEnName != null && !sEnName.equals("")) userForm.setEnName(sEnName); //
			if (sKRAddress != null && !sKRAddress.equals("")) userForm.setKrAddress(sKRAddress); // 
			if (sEnAddress != null && !sEnAddress.equals("")) userForm.setEnAddress(sEnAddress); // 
			
			if (sCellPhone != null && !sCellPhone.equals("")) userForm.setCellPhone(sCellPhone); // 
			if (sInternalPhone != null && !sInternalPhone.equals("")) userForm.setInternalPhone(sInternalPhone); // 
			if (sTelePhone != null && !sTelePhone.equals("")) userForm.setTelPhone(sTelePhone); // 
			if (sPosition != null && !sPosition.equals("")) userForm.setPosition(sPosition); //

			if (sTitle != null && !sTitle.equals("")) userForm.setTitle(sTitle); // 
			if (sTitleIndex != null && !sTitleIndex.equals("")) userForm.setTitleIndex(sTitleIndex); // 
			if (sSecureID != null && !sSecureID.equals("")) userForm.setSecureID(sSecureID); // 
			if (sJoiningDate != null && !sJoiningDate.equals("")) userForm.setJoiningDate(sJoiningDate); // 
			if (sRetirementDate != null && !sRetirementDate.equals("")) userForm.setRetirementDate(sRetirementDate); //
			if (sIsRetirement != null && !sIsRetirement.equals("")) userForm.setIsRetirement(sIsRetirement); //
			
			userForm = (PSKUserInfo) PersistenceHelper.manager.save(userForm);

			result += " : " + wtUser.getName();
			//System.out.println("@ updated PSKUserInfo =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end updatePSKUserInfo%4C7E03630399.body
   }

   //##begin deletePSKUserInfo%4C7E03740167.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deletePSKUserInfo%4C7E03740167.doc

   public String deletePSKUserInfo( HashMap form )
            throws WTException {
      //##begin deletePSKUserInfo%4C7E03740167.body preserve=yes

      return null;
      //##end deletePSKUserInfo%4C7E03740167.body
   }

   //##begin searchPSKUserInfo%4C7E0387004E.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchPSKUserInfo%4C7E0387004E.doc

   public HashMap searchPSKUserInfo( HashMap form )
            throws WTException {
      //##begin searchPSKUserInfo%4C7E0387004E.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
		HashMap results = new HashMap();
		String sCmd = (String) form.get("cmd");
		
		//Tree View
		if( sCmd.equals("orgTree")) {
			WTGroup pskGroup = (WTGroup)OrganizationServicesHelper.manager.getGroup("PSK-Root");	
			Vector teamInfo = new Vector();
			
			this.getTeamMember(teamInfo, 0, pskGroup);
			
			results.put("results", teamInfo);
			
		// search team member 
		} else if( sCmd.equals("teamUserSearch")) {
			String teamOid = (String) form.get("teamOid");
			
			WTUser subUser = null;
			Vector teamInfo = new Vector();
			
			if( teamOid.equals("") ) {
				results.put("results", teamInfo);
				return results;
			}
			
			WTGroup teamGroup = (WTGroup)rf.getReference(teamOid).getObject();
			WTGroup pskGroup = (WTGroup)OrganizationServicesHelper.manager.getGroup(teamGroup.getName());
			Enumeration childGroup = OrganizationServicesHelper.manager.members(pskGroup, false);
			WTPrincipal subs = null;

			/**
			 * 0	wtuser Oid(number)
			 * 1	wtuser Oid
			 * 2	name
			 * 3	Id
			 * 4	title
			 * 5    email
			 */
			if (childGroup != null) {
				int userIndex = 0;
				while (childGroup.hasMoreElements()) {
					subs = (WTPrincipal) childGroup.nextElement();

					if (subs instanceof WTUser) {
						String[] infos = new String[6];
						subUser = (WTUser)subs;
						
						infos[0] = String.valueOf( subUser.getPersistInfo().getObjectIdentifier().getId() );
						infos[1] = subUser.getPersistInfo().getObjectIdentifier().getClassname() + ":" + infos[0];
						infos[2] = subUser.getFullName();
						infos[3] = subUser.getName();
						infos[4] = "";
						infos[5] = subUser.getEMail();
						
						//System.out.println("@ getUserInfo=" + infos[0] + " , " + infos[1] + " , " + infos[2] + " , " + infos[3]);
						
						teamInfo.add(infos);
					}
				}
			}
			
			results.put("results", teamInfo);
			
		} else if( sCmd.equals("listUser")) {
		   	QueryResult queryResult = null; 
			String sId = (String) form.get("shId");
			String sName = (String) form.get("shKrName");

			try {
				QuerySpec query = new QuerySpec();

				if (query.getConditionCount() > 0) query.appendAnd();

				Class classType = PSKUserInfo.class;
				Class classType2 = WTUser.class;
				Class classType3 = WTUserPskUserInfoLink.class;
				int pskIndex = query.appendClassList(classType, true);
				int pskIndex2 = query.appendClassList(classType2, false);
				int pskIndex3 = query.appendClassList(classType3, false);

				query.appendJoin(pskIndex3, WTUserPskUserInfoLink.PSK_USER_ROLE, pskIndex);
				query.appendJoin(pskIndex3, WTUserPskUserInfoLink.WT_USER_ROLE, pskIndex2);

				if (sId != null && !sId.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType2, WTUser.NAME, SearchCondition.LIKE, "%" + sId + "%"), new int[] { pskIndex2 });
				}

				if (sName != null && !sName.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType2, WTUser.FULL_NAME, SearchCondition.LIKE, "%" + sName + "%"), new int[] { pskIndex2 });
				}
				
				ClassAttribute classattribute = new ClassAttribute();
				OrderBy orderby = null;
				classattribute = new ClassAttribute(classType, PSKUserInfo.TITLE_INDEX);
				orderby = new OrderBy(classattribute, true);

				query.appendOrderBy(orderby, new int[] { 0 });

				//System.out.println("## REQUEST Query:" + query.toString());

				queryResult = PersistenceHelper.manager.find(query);
				
				results.put("results", queryResult);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if( sCmd.equals("ccbReviewerList")) {
			try {
				Vector reviewerList = new Vector();
				WTGroup pskGroup = (WTGroup)OrganizationServicesHelper.manager.getPrincipal("CCB");
				
				if( pskGroup != null ) { 
					Enumeration childGroup = OrganizationServicesHelper.manager.members(pskGroup, false);
					
					WTPrincipal subs = null;
					if (childGroup != null) {
						while (childGroup.hasMoreElements()) {
							subs = (WTPrincipal) childGroup.nextElement();

							if (subs instanceof WTUser) {
								System.out.println("@ User : " + subs.getName());
								reviewerList.add( (WTUser)subs );
							} else if( subs instanceof WTGroup ) {
								//System.out.println("@ Group : " + subs.getName());
							}
						}
					}
				} else {
					System.out.println("@ pskGroup is null");
				}
				
				results.put("results", reviewerList);
				
			} catch( Exception e) {
				e.printStackTrace();
			}
			
		} else if( sCmd.equals("ccbTeamList")) {
			try {
				Vector teamList = new Vector();
				WTGroup pskGroup = (WTGroup)OrganizationServicesHelper.manager.getPrincipal("CCB");
				
				if( pskGroup != null ) { 
					Enumeration childGroup = OrganizationServicesHelper.manager.members(pskGroup, false);
					
					WTPrincipal subs = null;
					if (childGroup != null) {
						while (childGroup.hasMoreElements()) {
							subs = (WTPrincipal) childGroup.nextElement();

							if (subs instanceof WTUser) {
								//System.out.println("@ User : " + subs.getName());

							} else if( subs instanceof WTGroup ) {
								//System.out.println("@ Group : " + subs.getName());
								teamList.add( (WTGroup)subs );
							}
						}
					}
				} else {
					System.out.println("@ pskGroup is null");
				}
				
				results.put("results", teamList);
				
			} catch( Exception e) {
				e.printStackTrace();
			}
		}

		return results;
      //##end searchPSKUserInfo%4C7E0387004E.body
   }

   //##begin createInterface%4CBBA80F0112.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createInterface%4CBBA80F0112.doc

   public String createInterface( HashMap form )
            throws WTException {
      //##begin createInterface%4CBBA80F0112.body preserve=yes
		InterfaceState interForm = InterfaceState.newInterfaceState();
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			String sCategory = (String) form.get("category");
			String sResult = (String) form.get("result");
			String sTitle = (String) form.get("title");

			String sLog = (String) form.get("log");
			String sWtObject = (String) form.get("wtObject");

			if (sCategory != null && !sCategory.equals("")) interForm.setCategory(sCategory);
			if (sResult != null && !sResult.equals("")) interForm.setResult(sResult); //
			if (sTitle != null && !sTitle.equals("")) interForm.setTitle(sTitle); // 
			
			if (sLog != null && !sLog.equals("")) interForm.setLog(sLog); // 
			if (sWtObject != null && !sWtObject.equals("")) interForm.setWtObject(sWtObject); // 
			interForm.setRunDate(CommonUtil.getCurrentTimestamp());

			interForm = (InterfaceState) PersistenceHelper.manager.save(interForm);
			
			result = interForm.toString();
			//System.out.println("@ created PSKUserInfo =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end createInterface%4CBBA80F0112.body
   }

   //##begin updateInterface%4CBBA829017F.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updateInterface%4CBBA829017F.doc

   public String updateInterface( HashMap form )
            throws WTException {
      //##begin updateInterface%4CBBA829017F.body preserve=yes
		String sOid = (String) form.get("oid");
		
		InterfaceState interForm = null;
		ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			interForm = (InterfaceState)rf.getReference(sOid).getObject();

			String sCategory = (String) form.get("category");
			String sResult = (String) form.get("result");
			String sTitle = (String) form.get("title");

			String sLog = (String) form.get("log");
			String sWtObject = (String) form.get("wtObject");

			if (sCategory != null && !sCategory.equals("")) interForm.setCategory(sCategory);
			if (sResult != null && !sResult.equals("")) interForm.setResult(sResult); //
			if (sTitle != null && !sTitle.equals("")) interForm.setTitle(sTitle); // 
			
			if (sLog != null && !sLog.equals("")) interForm.setLog(sLog); // 
			if (sWtObject != null && !sWtObject.equals("")) interForm.setWtObject(sWtObject); // 
			interForm.setRunDate(CommonUtil.getCurrentTimestamp());

			interForm = (InterfaceState) PersistenceHelper.manager.save(interForm);
			
			result = interForm.toString();
			//System.out.println("@ created PSKUserInfo =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end updateInterface%4CBBA829017F.body
   }

   //##begin restartInterface%4CBBA8390076.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end restartInterface%4CBBA8390076.doc

   public String restartInterface( HashMap form )
            throws WTException {
      //##begin restartInterface%4CBBA8390076.body preserve=yes

      return null;
      //##end restartInterface%4CBBA8390076.body
   }

   //##begin searchInterface%4CBBA84903A2.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchInterface%4CBBA84903A2.doc

   public HashMap searchInterface( HashMap form )
            throws WTException {
      //##begin searchInterface%4CBBA84903A2.body preserve=yes

      return null;
      //##end searchInterface%4CBBA84903A2.body
   }

   //##begin user.operations preserve=yes
   public void getTeamMember(Vector teamInfo, int teamIndex, WTGroup parentGroup) throws WTException{
		Enumeration childGroup = OrganizationServicesHelper.manager.members(parentGroup, false);
		WTPrincipal subs = null;
		
		/**
		 * 0	parent Oid
		 * 1	child Oid
		 * 2	team Id
		 * 3	team Name
		 */
		String[] infos = new String[4];
		WTGroup subGroup = null;
		
		if (childGroup != null) {
			while (childGroup.hasMoreElements()) {
				subs = (WTPrincipal) childGroup.nextElement();

				// subs??????????  ????????
				if (subs instanceof WTGroup) {
					infos = new String[4];
					
					subGroup = (WTGroup)subs;
					if( subGroup.getDescription().equals("PSK")) { 
						infos[0] = "-1";
					} else { 
						infos[0] = String.valueOf( parentGroup.getPersistInfo().getObjectIdentifier().getId() );
					}
					
					infos[1] = String.valueOf( subGroup.getPersistInfo().getObjectIdentifier().getId() );
					infos[2] = subGroup.getName();
					infos[3] = subGroup.getDescription();

					teamInfo.add(teamIndex, infos);
					teamIndex += 1;
					
					this.getTeamMember(teamInfo, teamIndex, subGroup);
				}
			}
		}
   }

	public boolean existCode(String sCodeType, String sCode) throws WTException {
		boolean isExist = false;

		HashMap results = new HashMap();
		QueryResult queryResult = null;

		try {
			QuerySpec query = new QuerySpec();

			if (query.getConditionCount() > 0) query.appendAnd();

			Class classType = CommonCode.class;
			int pskIndex = query.appendClassList(classType, true);

			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE_TYPE, SearchCondition.EQUAL, sCodeType), new int[] { pskIndex });
			
			if (query.getConditionCount() > 0) query.appendAnd();
			query.appendWhere(new SearchCondition(classType, CommonCode.CODE, SearchCondition.EQUAL, sCode), new int[] { pskIndex });

			//System.out.println("## REQUEST Query existCode :" + query.toString());

			queryResult = PersistenceHelper.manager.find(query);

			Persistable[] objs = null;
			if (queryResult == null || (queryResult.size() < 0)) {
			} else if (queryResult.size() > 0) {
				objs = (Persistable[])queryResult.nextElement();
				CommonCode code = (CommonCode)objs[0];
				//System.out.println(" ,,,, " + code);
				isExist = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isExist;

	}
   //##end user.operations
}
