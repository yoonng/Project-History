// Generated CommonServiceFwd%4C7C9D8E001F: ? 10/18/10 11:01:36
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import ext.psk.common.CommonService;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class CommonServiceFwd implements RemoteAccess, CommonService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = CommonServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.psk.common.CommonService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.psk.common.CommonService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).createCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).deleteCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).updateCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).searchCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createLinkCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).createLinkCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createLinkCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createLinkCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createLinkCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deleteLinkCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).deleteLinkCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deleteLinkCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deleteLinkCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deleteLinkCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchChildCode( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).searchChildCode( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchChildCode", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchChildCode" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchChildCode" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createPSKUserInfo( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).createPSKUserInfo( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createPSKUserInfo", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createPSKUserInfo" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createPSKUserInfo" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updatePSKUserInfo( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).updatePSKUserInfo( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updatePSKUserInfo", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updatePSKUserInfo" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updatePSKUserInfo" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String deletePSKUserInfo( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).deletePSKUserInfo( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "deletePSKUserInfo", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "deletePSKUserInfo" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "deletePSKUserInfo" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchPSKUserInfo( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).searchPSKUserInfo( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchPSKUserInfo", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchPSKUserInfo" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchPSKUserInfo" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String createInterface( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).createInterface( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "createInterface", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createInterface" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createInterface" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String updateInterface( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).updateInterface( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "updateInterface", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "updateInterface" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "updateInterface" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   public String restartInterface( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).restartInterface( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (String)RemoteMethodServer.getDefault().invoke(
               "restartInterface", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "restartInterface" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "restartInterface" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap searchInterface( HashMap form )
            throws WTException {

      if (SERVER)
         return ((CommonService)getManager()).searchInterface( form );
      else {
         try {
            Class[]	argTypes	= { HashMap.class };
            Object[]	args		= { form };
            return (HashMap)RemoteMethodServer.getDefault().invoke(
               "searchInterface", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "searchInterface" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "searchInterface" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
