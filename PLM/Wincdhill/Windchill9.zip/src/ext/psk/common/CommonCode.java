// Generated CommonCode%4C7C9B48003E: ? 08/31/10 15:45:19
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.common;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import wt.fc.WTObject;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin CommonCode%4C7C9B48003E.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newCommonCode</code> static factory method(s), not the
 * <code>CommonCode</code> constructor, to construct instances of this class.
 *  Instances must be constructed using the static factory(s), in order
 * to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end CommonCode%4C7C9B48003E.doc

public class CommonCode extends WTObject implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.common.commonResource";
   private static final String CLASSNAME = CommonCode.class.getName();

   //##begin CODE%CODE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE%CODE.doc
   public static final String CODE = "code";

   private static int CODE_UPPER_LIMIT = -1;
   private String code;

   //##begin CODE_NAME%CODE_NAME.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_NAME%CODE_NAME.doc
   public static final String CODE_NAME = "codeName";

   private static int CODE_NAME_UPPER_LIMIT = -1;
   private String codeName;

   //##begin CODE_NAME_EN%CODE_NAME_EN.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_NAME_EN%CODE_NAME_EN.doc
   public static final String CODE_NAME_EN = "codeNameEn";

   private static int CODE_NAME_EN_UPPER_LIMIT = -1;
   private String codeNameEn;

   //##begin CODE_VALUE%CODE_VALUE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_VALUE%CODE_VALUE.doc
   public static final String CODE_VALUE = "codeValue";

   private static int CODE_VALUE_UPPER_LIMIT = -1;
   private String codeValue;

   //##begin CODE_VALUE_EN%CODE_VALUE_EN.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_VALUE_EN%CODE_VALUE_EN.doc
   public static final String CODE_VALUE_EN = "codeValueEn";

   private static int CODE_VALUE_EN_UPPER_LIMIT = -1;
   private String codeValueEn;

   //##begin DESCRIPTION%DESCRIPTION.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end DESCRIPTION%DESCRIPTION.doc
   public static final String DESCRIPTION = "description";

   private static int DESCRIPTION_UPPER_LIMIT = -1;
   private String description;

   //##begin CODE_ONE%CODE_ONE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_ONE%CODE_ONE.doc
   public static final String CODE_ONE = "codeOne";

   private static int CODE_ONE_UPPER_LIMIT = -1;
   private String codeOne;

   //##begin CODE_TWO%CODE_TWO.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_TWO%CODE_TWO.doc
   public static final String CODE_TWO = "codeTwo";

   private static int CODE_TWO_UPPER_LIMIT = -1;
   private String codeTwo;

   //##begin CODE_THREE%CODE_THREE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_THREE%CODE_THREE.doc
   public static final String CODE_THREE = "codeThree";

   private static int CODE_THREE_UPPER_LIMIT = -1;
   private String codeThree;

   //##begin CODE_TYPE%CODE_TYPE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end CODE_TYPE%CODE_TYPE.doc
   public static final String CODE_TYPE = "codeType";

   private static int CODE_TYPE_UPPER_LIMIT = -1;
   private String codeType;

   //##begin IS_DELETE%IS_DELETE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end IS_DELETE%IS_DELETE.doc
   public static final String IS_DELETE = "isDelete";

   private static int IS_DELETE_UPPER_LIMIT = -1;
   private String isDelete;
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 324611734417092901L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( code );
      output.writeObject( codeName );
      output.writeObject( codeNameEn );
      output.writeObject( codeOne );
      output.writeObject( codeThree );
      output.writeObject( codeTwo );
      output.writeObject( codeType );
      output.writeObject( codeValue );
      output.writeObject( codeValueEn );
      output.writeObject( description );
      output.writeObject( isDelete );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         code = (String)input.readObject();
         codeName = (String)input.readObject();
         codeNameEn = (String)input.readObject();
         codeOne = (String)input.readObject();
         codeThree = (String)input.readObject();
         codeTwo = (String)input.readObject();
         codeType = (String)input.readObject();
         codeValue = (String)input.readObject();
         codeValueEn = (String)input.readObject();
         description = (String)input.readObject();
         isDelete = (String)input.readObject();
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "code", code );
      output.setString( "codeName", codeName );
      output.setString( "codeNameEn", codeNameEn );
      output.setString( "codeValue", codeValue );
      output.setString( "codeValueEn", codeValueEn );
      output.setString( "description", description );
      output.setString( "codeOne", codeOne );
      output.setString( "codeTwo", codeTwo );
      output.setString( "codeThree", codeThree );
      output.setString( "codeType", codeType );
      output.setString( "isDelete", isDelete );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      code = input.getString( "code" );
      codeName = input.getString( "codeName" );
      codeNameEn = input.getString( "codeNameEn" );
      codeValue = input.getString( "codeValue" );
      codeValueEn = input.getString( "codeValueEn" );
      description = input.getString( "description" );
      codeOne = input.getString( "codeOne" );
      codeTwo = input.getString( "codeTwo" );
      codeThree = input.getString( "codeThree" );
      codeType = input.getString( "codeType" );
      isDelete = input.getString( "isDelete" );
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getCode%4C7C9B54038Ag.doc preserve=no
   /**
    * Gets the value of the attribute: CODE.
    *
    * @return    String
    **/
   //##end getCode%4C7C9B54038Ag.doc

   public String getCode() {
      //##begin getCode%4C7C9B54038Ag.body preserve=no

      return code;
      //##end getCode%4C7C9B54038Ag.body
   }

   //##begin setCode%4C7C9B54038As.doc preserve=no
   /**
    * Sets the value of the attribute: CODE.
    *
    * @param     a_Code
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCode%4C7C9B54038As.doc

   public void setCode( String a_Code )
            throws WTPropertyVetoException {
      //##begin setCode%4C7C9B54038As.body preserve=no

      codeValidate( a_Code );   // throws exception if not valid
      code = a_Code;
      //##end setCode%4C7C9B54038As.body
   }

   //##begin codeValidate%4C7C9B54038A.doc preserve=no
   /**
    * @param     a_Code
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeValidate%4C7C9B54038A.doc

   private void codeValidate( String a_Code )
            throws WTPropertyVetoException {
      if ( CODE_UPPER_LIMIT < 1 ) {
         try { CODE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "code" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Code != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Code, CODE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "code" ), String.valueOf( Math.min ( CODE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "code", code, a_Code ) );
      }
   }

   //##begin getCodeName%4C7C9B5B0000g.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_NAME.
    *
    * @return    String
    **/
   //##end getCodeName%4C7C9B5B0000g.doc

   public String getCodeName() {
      //##begin getCodeName%4C7C9B5B0000g.body preserve=no

      return codeName;
      //##end getCodeName%4C7C9B5B0000g.body
   }

   //##begin setCodeName%4C7C9B5B0000s.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_NAME.
    *
    * @param     a_CodeName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeName%4C7C9B5B0000s.doc

   public void setCodeName( String a_CodeName )
            throws WTPropertyVetoException {
      //##begin setCodeName%4C7C9B5B0000s.body preserve=no

      codeNameValidate( a_CodeName );   // throws exception if not valid
      codeName = a_CodeName;
      //##end setCodeName%4C7C9B5B0000s.body
   }

   //##begin codeNameValidate%4C7C9B5B0000.doc preserve=no
   /**
    * @param     a_CodeName
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeNameValidate%4C7C9B5B0000.doc

   private void codeNameValidate( String a_CodeName )
            throws WTPropertyVetoException {
      if ( CODE_NAME_UPPER_LIMIT < 1 ) {
         try { CODE_NAME_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeName" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_NAME_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeName != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeName, CODE_NAME_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeName" ), String.valueOf( Math.min ( CODE_NAME_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeName", codeName, a_CodeName ) );
      }
   }

   //##begin getCodeNameEn%4C7C9B60035Bg.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_NAME_EN.
    *
    * @return    String
    **/
   //##end getCodeNameEn%4C7C9B60035Bg.doc

   public String getCodeNameEn() {
      //##begin getCodeNameEn%4C7C9B60035Bg.body preserve=no

      return codeNameEn;
      //##end getCodeNameEn%4C7C9B60035Bg.body
   }

   //##begin setCodeNameEn%4C7C9B60035Bs.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_NAME_EN.
    *
    * @param     a_CodeNameEn
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeNameEn%4C7C9B60035Bs.doc

   public void setCodeNameEn( String a_CodeNameEn )
            throws WTPropertyVetoException {
      //##begin setCodeNameEn%4C7C9B60035Bs.body preserve=no

      codeNameEnValidate( a_CodeNameEn );   // throws exception if not valid
      codeNameEn = a_CodeNameEn;
      //##end setCodeNameEn%4C7C9B60035Bs.body
   }

   //##begin codeNameEnValidate%4C7C9B60035B.doc preserve=no
   /**
    * @param     a_CodeNameEn
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeNameEnValidate%4C7C9B60035B.doc

   private void codeNameEnValidate( String a_CodeNameEn )
            throws WTPropertyVetoException {
      if ( CODE_NAME_EN_UPPER_LIMIT < 1 ) {
         try { CODE_NAME_EN_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeNameEn" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_NAME_EN_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeNameEn != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeNameEn, CODE_NAME_EN_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeNameEn" ), String.valueOf( Math.min ( CODE_NAME_EN_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeNameEn", codeNameEn, a_CodeNameEn ) );
      }
   }

   //##begin getCodeValue%4C7C9B6B00EAg.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_VALUE.
    *
    * @return    String
    **/
   //##end getCodeValue%4C7C9B6B00EAg.doc

   public String getCodeValue() {
      //##begin getCodeValue%4C7C9B6B00EAg.body preserve=no

      return codeValue;
      //##end getCodeValue%4C7C9B6B00EAg.body
   }

   //##begin setCodeValue%4C7C9B6B00EAs.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_VALUE.
    *
    * @param     a_CodeValue
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeValue%4C7C9B6B00EAs.doc

   public void setCodeValue( String a_CodeValue )
            throws WTPropertyVetoException {
      //##begin setCodeValue%4C7C9B6B00EAs.body preserve=no

      codeValueValidate( a_CodeValue );   // throws exception if not valid
      codeValue = a_CodeValue;
      //##end setCodeValue%4C7C9B6B00EAs.body
   }

   //##begin codeValueValidate%4C7C9B6B00EA.doc preserve=no
   /**
    * @param     a_CodeValue
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeValueValidate%4C7C9B6B00EA.doc

   private void codeValueValidate( String a_CodeValue )
            throws WTPropertyVetoException {
      if ( CODE_VALUE_UPPER_LIMIT < 1 ) {
         try { CODE_VALUE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeValue" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_VALUE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeValue != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeValue, CODE_VALUE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeValue" ), String.valueOf( Math.min ( CODE_VALUE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeValue", codeValue, a_CodeValue ) );
      }
   }

   //##begin getCodeValueEn%4C7C9B7301E4g.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_VALUE_EN.
    *
    * @return    String
    **/
   //##end getCodeValueEn%4C7C9B7301E4g.doc

   public String getCodeValueEn() {
      //##begin getCodeValueEn%4C7C9B7301E4g.body preserve=no

      return codeValueEn;
      //##end getCodeValueEn%4C7C9B7301E4g.body
   }

   //##begin setCodeValueEn%4C7C9B7301E4s.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_VALUE_EN.
    *
    * @param     a_CodeValueEn
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeValueEn%4C7C9B7301E4s.doc

   public void setCodeValueEn( String a_CodeValueEn )
            throws WTPropertyVetoException {
      //##begin setCodeValueEn%4C7C9B7301E4s.body preserve=no

      codeValueEnValidate( a_CodeValueEn );   // throws exception if not valid
      codeValueEn = a_CodeValueEn;
      //##end setCodeValueEn%4C7C9B7301E4s.body
   }

   //##begin codeValueEnValidate%4C7C9B7301E4.doc preserve=no
   /**
    * @param     a_CodeValueEn
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeValueEnValidate%4C7C9B7301E4.doc

   private void codeValueEnValidate( String a_CodeValueEn )
            throws WTPropertyVetoException {
      if ( CODE_VALUE_EN_UPPER_LIMIT < 1 ) {
         try { CODE_VALUE_EN_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeValueEn" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_VALUE_EN_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeValueEn != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeValueEn, CODE_VALUE_EN_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeValueEn" ), String.valueOf( Math.min ( CODE_VALUE_EN_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeValueEn", codeValueEn, a_CodeValueEn ) );
      }
   }

   //##begin getDescription%4C7C9B7902CEg.doc preserve=no
   /**
    * Gets the value of the attribute: DESCRIPTION.
    *
    * @return    String
    **/
   //##end getDescription%4C7C9B7902CEg.doc

   public String getDescription() {
      //##begin getDescription%4C7C9B7902CEg.body preserve=no

      return description;
      //##end getDescription%4C7C9B7902CEg.body
   }

   //##begin setDescription%4C7C9B7902CEs.doc preserve=no
   /**
    * Sets the value of the attribute: DESCRIPTION.
    *
    * @param     a_Description
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setDescription%4C7C9B7902CEs.doc

   public void setDescription( String a_Description )
            throws WTPropertyVetoException {
      //##begin setDescription%4C7C9B7902CEs.body preserve=no

      descriptionValidate( a_Description );   // throws exception if not valid
      description = a_Description;
      //##end setDescription%4C7C9B7902CEs.body
   }

   //##begin descriptionValidate%4C7C9B7902CE.doc preserve=no
   /**
    * @param     a_Description
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end descriptionValidate%4C7C9B7902CE.doc

   private void descriptionValidate( String a_Description )
            throws WTPropertyVetoException {
      if ( DESCRIPTION_UPPER_LIMIT < 1 ) {
         try { DESCRIPTION_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "description" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { DESCRIPTION_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Description != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Description, DESCRIPTION_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "description" ), String.valueOf( Math.min ( DESCRIPTION_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "description", description, a_Description ) );
      }
   }

   //##begin getCodeOne%4C7C9B9F0000g.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_ONE.
    *
    * @return    String
    **/
   //##end getCodeOne%4C7C9B9F0000g.doc

   public String getCodeOne() {
      //##begin getCodeOne%4C7C9B9F0000g.body preserve=no

      return codeOne;
      //##end getCodeOne%4C7C9B9F0000g.body
   }

   //##begin setCodeOne%4C7C9B9F0000s.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_ONE.
    *
    * @param     a_CodeOne
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeOne%4C7C9B9F0000s.doc

   public void setCodeOne( String a_CodeOne )
            throws WTPropertyVetoException {
      //##begin setCodeOne%4C7C9B9F0000s.body preserve=no

      codeOneValidate( a_CodeOne );   // throws exception if not valid
      codeOne = a_CodeOne;
      //##end setCodeOne%4C7C9B9F0000s.body
   }

   //##begin codeOneValidate%4C7C9B9F0000.doc preserve=no
   /**
    * @param     a_CodeOne
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeOneValidate%4C7C9B9F0000.doc

   private void codeOneValidate( String a_CodeOne )
            throws WTPropertyVetoException {
      if ( CODE_ONE_UPPER_LIMIT < 1 ) {
         try { CODE_ONE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeOne" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_ONE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeOne != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeOne, CODE_ONE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeOne" ), String.valueOf( Math.min ( CODE_ONE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeOne", codeOne, a_CodeOne ) );
      }
   }

   //##begin getCodeTwo%4C7C9BAE0242g.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_TWO.
    *
    * @return    String
    **/
   //##end getCodeTwo%4C7C9BAE0242g.doc

   public String getCodeTwo() {
      //##begin getCodeTwo%4C7C9BAE0242g.body preserve=no

      return codeTwo;
      //##end getCodeTwo%4C7C9BAE0242g.body
   }

   //##begin setCodeTwo%4C7C9BAE0242s.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_TWO.
    *
    * @param     a_CodeTwo
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeTwo%4C7C9BAE0242s.doc

   public void setCodeTwo( String a_CodeTwo )
            throws WTPropertyVetoException {
      //##begin setCodeTwo%4C7C9BAE0242s.body preserve=no

      codeTwoValidate( a_CodeTwo );   // throws exception if not valid
      codeTwo = a_CodeTwo;
      //##end setCodeTwo%4C7C9BAE0242s.body
   }

   //##begin codeTwoValidate%4C7C9BAE0242.doc preserve=no
   /**
    * @param     a_CodeTwo
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeTwoValidate%4C7C9BAE0242.doc

   private void codeTwoValidate( String a_CodeTwo )
            throws WTPropertyVetoException {
      if ( CODE_TWO_UPPER_LIMIT < 1 ) {
         try { CODE_TWO_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeTwo" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_TWO_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeTwo != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeTwo, CODE_TWO_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeTwo" ), String.valueOf( Math.min ( CODE_TWO_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeTwo", codeTwo, a_CodeTwo ) );
      }
   }

   //##begin getCodeThree%4C7C9BB3005Dg.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_THREE.
    *
    * @return    String
    **/
   //##end getCodeThree%4C7C9BB3005Dg.doc

   public String getCodeThree() {
      //##begin getCodeThree%4C7C9BB3005Dg.body preserve=no

      return codeThree;
      //##end getCodeThree%4C7C9BB3005Dg.body
   }

   //##begin setCodeThree%4C7C9BB3005Ds.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_THREE.
    *
    * @param     a_CodeThree
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeThree%4C7C9BB3005Ds.doc

   public void setCodeThree( String a_CodeThree )
            throws WTPropertyVetoException {
      //##begin setCodeThree%4C7C9BB3005Ds.body preserve=no

      codeThreeValidate( a_CodeThree );   // throws exception if not valid
      codeThree = a_CodeThree;
      //##end setCodeThree%4C7C9BB3005Ds.body
   }

   //##begin codeThreeValidate%4C7C9BB3005D.doc preserve=no
   /**
    * @param     a_CodeThree
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeThreeValidate%4C7C9BB3005D.doc

   private void codeThreeValidate( String a_CodeThree )
            throws WTPropertyVetoException {
      if ( CODE_THREE_UPPER_LIMIT < 1 ) {
         try { CODE_THREE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeThree" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_THREE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeThree != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeThree, CODE_THREE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeThree" ), String.valueOf( Math.min ( CODE_THREE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeThree", codeThree, a_CodeThree ) );
      }
   }

   //##begin getCodeType%4C7C9BC3006Dg.doc preserve=no
   /**
    * Gets the value of the attribute: CODE_TYPE.
    *
    * @return    String
    **/
   //##end getCodeType%4C7C9BC3006Dg.doc

   public String getCodeType() {
      //##begin getCodeType%4C7C9BC3006Dg.body preserve=no

      return codeType;
      //##end getCodeType%4C7C9BC3006Dg.body
   }

   //##begin setCodeType%4C7C9BC3006Ds.doc preserve=no
   /**
    * Sets the value of the attribute: CODE_TYPE.
    *
    * @param     a_CodeType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setCodeType%4C7C9BC3006Ds.doc

   public void setCodeType( String a_CodeType )
            throws WTPropertyVetoException {
      //##begin setCodeType%4C7C9BC3006Ds.body preserve=no

      codeTypeValidate( a_CodeType );   // throws exception if not valid
      codeType = a_CodeType;
      //##end setCodeType%4C7C9BC3006Ds.body
   }

   //##begin codeTypeValidate%4C7C9BC3006D.doc preserve=no
   /**
    * @param     a_CodeType
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end codeTypeValidate%4C7C9BC3006D.doc

   private void codeTypeValidate( String a_CodeType )
            throws WTPropertyVetoException {
      if ( CODE_TYPE_UPPER_LIMIT < 1 ) {
         try { CODE_TYPE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "codeType" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { CODE_TYPE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_CodeType != null && !wt.fc.PersistenceHelper.checkStoredLength( a_CodeType, CODE_TYPE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "codeType" ), String.valueOf( Math.min ( CODE_TYPE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "codeType", codeType, a_CodeType ) );
      }
   }

   //##begin getIsDelete%4C7CA4DC03B9g.doc preserve=no
   /**
    * Gets the value of the attribute: IS_DELETE.
    *
    * @return    String
    **/
   //##end getIsDelete%4C7CA4DC03B9g.doc

   public String getIsDelete() {
      //##begin getIsDelete%4C7CA4DC03B9g.body preserve=no

      return isDelete;
      //##end getIsDelete%4C7CA4DC03B9g.body
   }

   //##begin setIsDelete%4C7CA4DC03B9s.doc preserve=no
   /**
    * Sets the value of the attribute: IS_DELETE.
    *
    * @param     a_IsDelete
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setIsDelete%4C7CA4DC03B9s.doc

   public void setIsDelete( String a_IsDelete )
            throws WTPropertyVetoException {
      //##begin setIsDelete%4C7CA4DC03B9s.body preserve=no

      isDeleteValidate( a_IsDelete );   // throws exception if not valid
      isDelete = a_IsDelete;
      //##end setIsDelete%4C7CA4DC03B9s.body
   }

   //##begin isDeleteValidate%4C7CA4DC03B9.doc preserve=no
   /**
    * @param     a_IsDelete
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end isDeleteValidate%4C7CA4DC03B9.doc

   private void isDeleteValidate( String a_IsDelete )
            throws WTPropertyVetoException {
      if ( IS_DELETE_UPPER_LIMIT < 1 ) {
         try { IS_DELETE_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "isDelete" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { IS_DELETE_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_IsDelete != null && !wt.fc.PersistenceHelper.checkStoredLength( a_IsDelete, IS_DELETE_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "isDelete" ), String.valueOf( Math.min ( IS_DELETE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "isDelete", isDelete, a_IsDelete ) );
      }
   }

   //##begin newCommonCode%newCommonCodef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    CommonCode
    * @exception wt.util.WTException
    **/
   //##end newCommonCode%newCommonCodef.doc

   public static CommonCode newCommonCode()
            throws WTException {
      //##begin newCommonCode%newCommonCodef.body preserve=no

      CommonCode instance = new CommonCode();
      instance.initialize();
      return instance;
      //##end newCommonCode%newCommonCodef.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
