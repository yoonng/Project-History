package ext.psk.part.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;
import ext.psk.util.upload.FileUploader;

import ext.psk.part.*;

public class PartRequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String contentType = req.getContentType();
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		FileUploader uploader = null;
		String cmd = "";
		String returnURI = "";
		String strReturn = "";
		boolean fileFlag = false;
		
		if ( contentType != null && contentType.indexOf("multipart/form-data") >= 0 ) {
			uploader = FileUploader.newFileUploader( null, req, res );
			//System.out.println("uploader = " + uploader);
			cmd = uploader.getFormParameter("cmd");
			form.put("addFiles", uploader.getFiles() == null ? new Vector() : uploader.getFiles() );
			
			fileFlag = true;
			
		} else {
			cmd = req.getParameter("cmd");
		}
		
		System.out.println("Request Start ===== " + cmd);

		Enumeration itor = null;
		if( fileFlag ) {
			itor = uploader.getFormParameter();
		} else {
			itor = req.getParameterNames();
		}
		
		while( itor.hasMoreElements() ) {
			String key = (String)itor.nextElement();
			String[] tempValues = null;
			if( fileFlag ) {
				tempValues = uploader.getFormValues(key);
			} else {
				tempValues = req.getParameterValues(key);
			}
			
			//when update, target put form
			if( key.equals("delFiles") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				
				Vector delFiles = new Vector();
				for(int i=0; i < values.length; i++ ) {
					HashMap hp = new HashMap();
					hp.put("fileId", values[i]);
					delFiles.addElement(hp);
				}
				form.put("fileId", delFiles);
				
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을 때 처리함 : 무조건 배열로 처리해야함
			} else if( key.equals("referenceDocument") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("only key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			
			//특정 항목에 대해 단건 또는 여러건으로 올 수 있을때 처리함 : 무조건 문자열로 처리해야함
			} else if( key.equals("maker") ) {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				String tempSite = "";
				
				for(int i = 0; i < values.length; i++) {
					tempSite += values[i] + "__/";
				}
				
				System.out.println("only key : " + key + " ____  value = " + tempSite );
				
				form.put(key, tempSite);
				
			} else if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}

		if( cmd.equals("registPart") || cmd.equals("deletePart") || cmd.equals("updatePart") ) {
			returnURI = "/Windchill/extcore/psk/jsp/part/part-list.jsp";
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";
			
			if( cmd.equals("listPart") || cmd.equals("listPartPopup") || cmd.equals("assyPartPopup") ) {
				if(cmd.equals("listPart") ) {
					returnURI = "/extcore/psk/jsp/part/part-list.jsp";
				} else {
					returnURI = "/extcore/psk/jsp/part/part-Popup.jsp";
				}

				HashMap resultMap = PartHelper.service.searchPart(form);
				PagingQueryResult pagingResult = (PagingQueryResult)resultMap.get("results");
				PageControl control = new PageControl( pagingResult , CommonUtil.parseInt( CommonUtil.checkNull(form.get("page").toString()), 1) );
				session.setAttribute("control", control);
				
				this.gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("registPart") ) {			//Part Regist ( new, revise, suffix )
				strReturn = PartHelper.service.createPart(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("revisePart") ) {			//Part Regist ( new, revise, suffix )
				strReturn = PartHelper.service.revisePart(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
			
			} else if( cmd.equals("changeSuffixPart") ) {			//Part Regist ( new, revise, suffix )
				strReturn = PartHelper.service.changeSuffixPart(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("registPartForm") ) {			//regist Form Call
				returnURI = "/extcore/psk/jsp/part/part-regist.jsp";
				
				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("changePartForm") || cmd.equals("updatePartForm") || cmd.equals("viewPart") ) {			
				if( cmd.equals("changePartForm") ) {							//revise form, suffix form call
					returnURI = "/extcore/psk/jsp/part/part-change.jsp";
				} else if( cmd.equals("updatePartForm") ) {						//update Form Data Call
					returnURI = "/extcore/psk/jsp/part/part-update.jsp";
				} else {														//view
					returnURI = "/extcore/psk/jsp/part/part-view.jsp";
				}

				HashMap resultMap = PartHelper.service.viewPart(form);
				WTPart part = (WTPart)resultMap.get("part");
				Vector docLinkList = (Vector)resultMap.get("docLinkList");
				Vector epmLink = (Vector)resultMap.get("epmLink");
				
				session.setAttribute("part", part);
				session.setAttribute("docLinkList", docLinkList);
				session.setAttribute("epmLink", epmLink);

				this.gotoResult( req, res, returnURI);

			} else if( cmd.equals("updatePart") ) {
				strReturn = PartHelper.service.updatePart(form);
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNCallFuncNclose(res, strReturn, callMathod);
				} else {
					this.alertNMsgNCallFunc2(res, strReturn, errCallMathod);
				}
				
			} else if( cmd.equals("deletePart") ) {
				strReturn = PartHelper.service.deletePart(form);
				
				callMathod = "parent.alterSearch()";
				
				if( strReturn.startsWith("SUCCESS")) {
					this.alertNMsgNCallFunc(res, strReturn, callMathod);
				} else {
					this.alert(res, strReturn);
				}
			}
			
			System.out.println("Request End ===== " + cmd);
			
		}catch( Exception ex ) {
			ex.printStackTrace();
		}
	}	
}