package ext.psk.part.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

import ext.psk.util.CommonServlet;
import ext.psk.util.CommonUtil;
//import ext.psk.util.upload.FileUploader;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.util.WTException;
import ext.psk.util.PageControl;
import ext.psk.util.upload.FileUploader;
import ext.psk.wf.WFHelper;

import ext.psk.part.*;

public class DMURequestServlet extends CommonServlet {

	protected void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String contentType = req.getContentType();
		HttpSession session = req.getSession(true);
		HashMap form = new HashMap();
		FileUploader uploader = null;
		String cmd = "";
		String returnURI = "";
		String strReturn = "";
		boolean fileFlag = false;
		
		System.out.println("contentType : " +  contentType );
		
		if ( contentType != null && contentType.indexOf("multipart/form-data") >= 0 ) {
			uploader = FileUploader.newFileUploader( null, req, res );
			//System.out.println("uploader = " + uploader);
			cmd = uploader.getFormParameter("cmd");
			System.out.println("addFiles : " +  uploader.getFiles() );
			form.put("addFiles", uploader.getFiles() == null ? new Vector() : uploader.getFiles() );
			
			fileFlag = true;
			
		} else {
			cmd = req.getParameter("cmd");
		}
		
		System.out.println("Request Start ===== " + cmd);

		Enumeration itor = null;
		if( fileFlag ) {
			itor = uploader.getFormParameter();
		} else {
			itor = req.getParameterNames();
		}
		
		while( itor.hasMoreElements() ) {
			String key = (String)itor.nextElement();
			String[] tempValues = null;
			if( fileFlag ) {
				tempValues = uploader.getFormValues(key);
			} else {
				tempValues = req.getParameterValues(key);
			}
			
			if( tempValues.length == 1 ) {
				String value = CommonUtil.checkNull( tempValues[0] );
				form.put(key, value);
				
				System.out.println("length 1 key : " + key + " ____  value = " + value );
			} else {
				String[] values = null;
				if( fileFlag ) {
					values = uploader.getFormValues(key);
				} else {
					values = req.getParameterValues(key);
				}
				form.put(key, values);
				
				for(int i = 0; i < values.length; i++) {
					System.out.println("array key : " + key + " ____  value = " + CommonUtil.checkNull( values[i] ) );
				}
			}
		}
		
		try{
			String callMathod = "parent.opener.alterSearch()";
			String errCallMathod = "history.back()";
			
			if( cmd.equals("searchFSC")) {
				returnURI = "/extcore/psk/jsp/part/viewDMUforFSC.jsp";
								
				HashMap resultMap = WFHelper.service.interfacePLM(form);
				QueryResult pagingResult = (QueryResult)resultMap.get("result");				
				session.setAttribute("return", pagingResult);
				
				gotoResult( req, res, returnURI);
				
			} else if( cmd.equals("GetGLforFSC") ) {
				returnURI = "/extcore/psk/jsp/part/viewDMUforFSC.jsp";
				
				HashMap resultMap = WFHelper.service.interfacePLM(form);
				Vector vcList = (Vector)resultMap.get("result");
				session.setAttribute("returnVC", vcList);
				
				gotoResult( req, res, returnURI);
				
			}else if( cmd.equals("GetGLforMODULE") ) {
				returnURI = "/extcore/psk/jsp/part/viewDMUforFSC.jsp";
				
				HashMap resultMap = WFHelper.service.interfacePLM(form);
				Vector vcList = (Vector)resultMap.get("result");
				session.setAttribute("returnVC", vcList);
				
				gotoResult( req, res, returnURI);
				
			}else if( cmd.equals("saveDMUPart") ) {
				returnURI = "/servlet/TypeBasedIncludeServlet";
				
				HashMap resultMap = WFHelper.service.interfacePLM(form);
				WTPart dmuPart = (WTPart)resultMap.get("result");
				session.setAttribute("returnDMUPart", dmuPart);
				
				returnURI = returnURI + "?oid=OR:" +  dmuPart.toString();
				
				this.alert(res, "Success: Part Number : " + dmuPart.getNumber());
				
				gotoResult( req, res, returnURI);
				
			}
			
			System.out.println("Request End ===== " + cmd);
			
		} catch( Exception e ) {
			e.printStackTrace();
			//throw new Exception(e);
		}
	}	
}