// Generated PSKCADServiceFwd%46A00A540167: �� 03/24/10 10:47:17
/* bcwti��?��?��?��?Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.��?��?��?��?This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.��?��?��?��?ecwti
 */

package ext.psk.part;

import ext.psk.part.PSKCADService;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.Object;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.epm.EPMDocument;
import wt.epm.structure.EPMMemberLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.templateutil.processor.HTTPState;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.Workable;

/**
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 * 
 * @version 1.0
 */

public class PSKCADServiceFwd implements RemoteAccess, PSKCADService,
		Serializable {

	// --- Attribute Section ---

	static final boolean SERVER = RemoteMethodServer.ServerFlag;

	private static final String FC_RESOURCE = "wt.fc.fcResource";

	private static final String CLASSNAME = PSKCADServiceFwd.class.getName();

	// --- Operation Section ---

	/**
	 * @return Manager
	 * @exception wt.util.WTException
	 */
	private static Manager getManager() throws WTException {

		Manager manager = ManagerServiceFactory.getDefault().getManager(
				ext.psk.part.PSKCADService.class);

		if (manager == null) {
			Object[] param = { "ext.psk.cad.PSKCADService" };
			throw new WTException(FC_RESOURCE,
					wt.fc.fcResource.UNREGISTERED_SERVICE, param);
		}
		return manager;
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param parent
	 * @param orgLink
	 * @param child
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	public void copyMemberLink(EPMDocument parent, EPMMemberLink orgLink,
			EPMDocument child) throws WTException, WTPropertyVetoException {

		if (SERVER)
			((PSKCADService) getManager()).copyMemberLink(parent, orgLink,
					child);
		else {
			try {
				Class[] argTypes = { EPMDocument.class, EPMMemberLink.class,
						EPMDocument.class };
				Object[] args = { parent, orgLink, child };
				RemoteMethodServer.getDefault().invoke("copyMemberLink", null,
						this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				Object[] param = { "copyMemberLink" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "copyMemberLink" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * basicAttr :?? [0] = number?? [1] = name?? [2] = lifecycle?? [3] = folder
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param basicAttr
	 * @param docType
	 *            true = part, false = assembly
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.io.IOException
	 * @exception java.beans.PropertyVetoException
	 */
	public EPMDocument createEPMdocument(String[] basicAttr, boolean docType,
			WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			IOException, PropertyVetoException {

		if (SERVER)
			return ((PSKCADService) getManager()).createEPMdocument(basicAttr,
					docType, wtcontext);
		else {
			try {
				Class[] argTypes = { String[].class, boolean.class,
						WTContainer.class };
				Object[] args = { basicAttr, new Boolean(docType), wtcontext };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"createEPMdocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof IOException)
					throw (IOException) targetE;
				if (targetE instanceof PropertyVetoException)
					throw (PropertyVetoException) targetE;
				Object[] param = { "createEPMdocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "createEPMdocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @param basicAttr
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	public EPMDocument changeEPMdocument(EPMDocument epm, String[] basicAttr,
			WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException {

		if (SERVER)
			return ((PSKCADService) getManager()).changeEPMdocument(epm,
					basicAttr, wtcontext);
		else {
			try {
				Class[] argTypes = { EPMDocument.class, String[].class,
						WTContainer.class };
				Object[] args = { epm, basicAttr, wtcontext };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"changeEPMdocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof PropertyVetoException)
					throw (PropertyVetoException) targetE;
				if (targetE instanceof RemoteException)
					throw (RemoteException) targetE;
				Object[] param = { "changeEPMdocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "changeEPMdocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param parent
	 * @param link
	 *            true = part, false = assembly
	 * @param doc
	 * @param location
	 * @param levelindex
	 *            true = upload, false = connect
	 * @param history
	 *            true = upload, false = connect
	 * @return Hashtable
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	public Hashtable copyCADBom(EPMDocument parent, EPMMemberLink link,
			EPMDocument doc, String location, int levelindex, Hashtable history)
			throws WTException, WTPropertyVetoException, PropertyVetoException,
			RemoteException {

		if (SERVER)
			return ((PSKCADService) getManager()).copyCADBom(parent, link, doc,
					location, levelindex, history);
		else {
			try {
				Class[] argTypes = { EPMDocument.class, EPMMemberLink.class,
						EPMDocument.class, String.class, int.class,
						Hashtable.class };
				Object[] args = { parent, link, doc, location,
						new Integer(levelindex), history };
				return (Hashtable) RemoteMethodServer.getDefault().invoke(
						"copyCADBom", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof PropertyVetoException)
					throw (PropertyVetoException) targetE;
				if (targetE instanceof RemoteException)
					throw (RemoteException) targetE;
				Object[] param = { "copyCADBom" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "copyCADBom" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param org
	 * @param location
	 * @param history
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	public EPMDocument copyEPMDocument(EPMDocument org, String location,
			Hashtable history) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException {

		if (SERVER)
			return ((PSKCADService) getManager()).copyEPMDocument(org,
					location, history);
		else {
			try {
				Class[] argTypes = { EPMDocument.class, String.class,
						Hashtable.class };
				Object[] args = { org, location, history };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"copyEPMDocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof PropertyVetoException)
					throw (PropertyVetoException) targetE;
				if (targetE instanceof RemoteException)
					throw (RemoteException) targetE;
				Object[] param = { "copyEPMDocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "copyEPMDocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param org
	 * @param location
	 * @param history
	 * @param ref
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	public EPMDocument copyEPMDocument(EPMDocument org, String location,
			Hashtable history, WTContainerRef ref) throws WTException,
			WTPropertyVetoException, PropertyVetoException, RemoteException {

		if (SERVER)
			return ((PSKCADService) getManager()).copyEPMDocument(org,
					location, history, ref);
		else {
			try {
				Class[] argTypes = { EPMDocument.class, String.class,
						Hashtable.class, WTContainerRef.class };
				Object[] args = { org, location, history, ref };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"copyEPMDocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof PropertyVetoException)
					throw (PropertyVetoException) targetE;
				if (targetE instanceof RemoteException)
					throw (RemoteException) targetE;
				Object[] param = { "copyEPMDocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "copyEPMDocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epmOid
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	public WTPart getRelationalPart(String epmOid) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelationalPart(epmOid);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { epmOid };
				return (WTPart) RemoteMethodServer.getDefault().invoke(
						"getRelationalPart", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelationalPart" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelationalPart" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	public WTPart getRelationalPart(EPMDocument epm) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelationalPart(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				return (WTPart) RemoteMethodServer.getDefault().invoke(
						"getRelationalPart", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelationalPart" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelationalPart" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param partOid
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	public EPMDocument getRelational3DCad(String partOid) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational3DCad(partOid);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { partOid };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"getRelational3DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational3DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational3DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	public EPMDocument getRelational3DCad(EPMDocument epm) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational3DCad(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"getRelational3DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational3DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational3DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param part
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	public EPMDocument getRelational3DCad(WTPart part) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational3DCad(part);
		else {
			try {
				Class[] argTypes = { WTPart.class };
				Object[] args = { part };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"getRelational3DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational3DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational3DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	public Vector getRelational2DCad(EPMDocument epm) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational2DCad(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				return (Vector) RemoteMethodServer.getDefault().invoke(
						"getRelational2DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational2DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational2DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param part
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	public Vector getRelational2DCad(WTPart part) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational2DCad(part);
		else {
			try {
				Class[] argTypes = { WTPart.class };
				Object[] args = { part };
				return (Vector) RemoteMethodServer.getDefault().invoke(
						"getRelational2DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational2DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational2DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param object
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	public Vector getRelational2DCad(String object) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational2DCad(object);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { object };
				return (Vector) RemoteMethodServer.getDefault().invoke(
						"getRelational2DCad", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational2DCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational2DCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean checkDrawing(EPMDocument epm) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).checkDrawing(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"checkDrawing", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "checkDrawing" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "checkDrawing" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epmOid
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean checkDrawing(String epmOid) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).checkDrawing(epmOid);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { epmOid };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"checkDrawing", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "checkDrawing" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "checkDrawing" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @exception wt.util.WTException
	 */
	public void syncDrawingState(String epm) throws WTException {

		if (SERVER)
			((PSKCADService) getManager()).syncDrawingState(epm);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { epm };
				RemoteMethodServer.getDefault().invoke("syncDrawingState",
						null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "syncDrawingState" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "syncDrawingState" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @exception wt.util.WTException
	 */
	public void syncDrawingState(EPMDocument epm) throws WTException {

		if (SERVER)
			((PSKCADService) getManager()).syncDrawingState(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				RemoteMethodServer.getDefault().invoke("syncDrawingState",
						null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "syncDrawingState" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "syncDrawingState" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param part
	 * @exception wt.util.WTException
	 */
	public void syncDrawingState(WTPart part) throws WTException {

		if (SERVER)
			((PSKCADService) getManager()).syncDrawingState(part);
		else {
			try {
				Class[] argTypes = { WTPart.class };
				Object[] args = { part };
				RemoteMethodServer.getDefault().invoke("syncDrawingState",
						null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "syncDrawingState" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "syncDrawingState" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param persist
	 * @return Persistable
	 * @exception wt.util.WTException
	 */
	public Persistable enforcedUpdate(Persistable persist) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).enforcedUpdate(persist);
		else {
			try {
				Class[] argTypes = { Persistable.class };
				Object[] args = { persist };
				return (Persistable) RemoteMethodServer.getDefault().invoke(
						"enforcedUpdate", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "enforcedUpdate" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "enforcedUpdate" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param org
	 * @param target
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	public boolean copyIBAValue(IBAHolder org, IBAHolder target)
			throws WTException, WTPropertyVetoException, RemoteException {

		if (SERVER)
			return ((PSKCADService) getManager()).copyIBAValue(org, target);
		else {
			try {
				Class[] argTypes = { IBAHolder.class, IBAHolder.class };
				Object[] args = { org, target };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"copyIBAValue", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				if (targetE instanceof RemoteException)
					throw (RemoteException) targetE;
				Object[] param = { "copyIBAValue" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "copyIBAValue" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean isExistCad(String part) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).isExistCad(part);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { part };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"isExistCad", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "isExistCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "isExistCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean isExistCad(WTPart part) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).isExistCad(part);
		else {
			try {
				Class[] argTypes = { WTPart.class };
				Object[] args = { part };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"isExistCad", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "isExistCad" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "isExistCad" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean canDeleteStructure(WTPart parent, WTPart child)
			throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).canDeleteStructure(parent,
					child);
		else {
			try {
				Class[] argTypes = { WTPart.class, WTPart.class };
				Object[] args = { parent, child };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"canDeleteStructure", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "canDeleteStructure" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "canDeleteStructure" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean canAddStructure(WTPart parent, WTPart child)
			throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager())
					.canAddStructure(parent, child);
		else {
			try {
				Class[] argTypes = { WTPart.class, WTPart.class };
				Object[] args = { parent, child };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"canAddStructure", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "canAddStructure" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "canAddStructure" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epmdoc
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	public boolean syncStructure(EPMDocument epmdoc) throws WTException,
			WTPropertyVetoException {

		if (SERVER)
			return ((PSKCADService) getManager()).syncStructure(epmdoc);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epmdoc };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"syncStructure", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				Object[] param = { "syncStructure" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "syncStructure" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param addPart
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	public boolean syncStructureByNewPart(WTPart addPart) throws WTException,
			WTPropertyVetoException {

		if (SERVER)
			return ((PSKCADService) getManager())
					.syncStructureByNewPart(addPart);
		else {
			try {
				Class[] argTypes = { WTPart.class };
				Object[] args = { addPart };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"syncStructureByNewPart", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				if (targetE instanceof WTPropertyVetoException)
					throw (WTPropertyVetoException) targetE;
				Object[] param = { "syncStructureByNewPart" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "syncStructureByNewPart" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param parent
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	public QueryResult getChildEPMDocument(EPMDocument parent)
			throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getChildEPMDocument(parent);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { parent };
				return (QueryResult) RemoteMethodServer.getDefault().invoke(
						"getChildEPMDocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getChildEPMDocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getChildEPMDocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param child
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	public QueryResult getParentEPMDocument(EPMDocument child)
			throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getParentEPMDocument(child);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { child };
				return (QueryResult) RemoteMethodServer.getDefault().invoke(
						"getParentEPMDocument", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getParentEPMDocument" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getParentEPMDocument" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param aObject
	 * @param bObject
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	public boolean enforcedSaveByCheckout(Workable aObject, Workable bObject)
			throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).enforcedSaveByCheckout(
					aObject, bObject);
		else {
			try {
				Class[] argTypes = { Workable.class, Workable.class };
				Object[] args = { aObject, bObject };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"enforcedSaveByCheckout", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "enforcedSaveByCheckout" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "enforcedSaveByCheckout" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param changeStr
	 * @param docType
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	public boolean fileDuplicate(String changeStr, boolean docType)
			throws IOException, WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).fileDuplicate(changeStr,
					docType);
		else {
			try {
				Class[] argTypes = { String.class, boolean.class };
				Object[] args = { changeStr, new Boolean(docType) };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"fileDuplicate", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof IOException)
					throw (IOException) targetE;
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "fileDuplicate" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "fileDuplicate" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param orgCompareStr
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	public boolean fileDuplicate(String orgCompareStr, String changeStr)
			throws IOException, WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).fileDuplicate(orgCompareStr,
					changeStr);
		else {
			try {
				Class[] argTypes = { String.class, String.class };
				Object[] args = { orgCompareStr, changeStr };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"fileDuplicate", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof IOException)
					throw (IOException) targetE;
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "fileDuplicate" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "fileDuplicate" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	public boolean fileDelete(String changeStr) throws IOException, WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).fileDelete(changeStr);
		else {
			try {
				Class[] argTypes = { String.class };
				Object[] args = { changeStr };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"fileDelete", null, this, argTypes, args))
						.booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof IOException)
					throw (IOException) targetE;
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "fileDelete" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "fileDelete" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param applicationData
	 * @param filename
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	public boolean fileSave(ApplicationData applicationData, String filename)
			throws IOException, WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).fileSave(applicationData,
					filename);
		else {
			try {
				Class[] argTypes = { ApplicationData.class, String.class };
				Object[] args = { applicationData, filename };
				return ((Boolean) RemoteMethodServer.getDefault().invoke(
						"fileSave", null, this, argTypes, args)).booleanValue();
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof IOException)
					throw (IOException) targetE;
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "fileSave" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "fileSave" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm3d
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	public EPMDocument getOwnDrawing(EPMDocument epm3d) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getOwnDrawing(epm3d);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm3d };
				return (EPMDocument) RemoteMethodServer.getDefault().invoke(
						"getOwnDrawing", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getOwnDrawing" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getOwnDrawing" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	public Vector getRelational2DCadLink(EPMDocument epm) throws WTException {

		if (SERVER)
			return ((PSKCADService) getManager()).getRelational2DCadLink(epm);
		else {
			try {
				Class[] argTypes = { EPMDocument.class };
				Object[] args = { epm };
				return (Vector) RemoteMethodServer.getDefault().invoke(
						"getRelational2DCadLink", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "getRelational2DCadLink" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "getRelational2DCadLink" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param obj
	 * @param state
	 * @param locale
	 * @param outputstream
	 * @exception wt.util.WTException
	 */
	public void makeThumbnailStream(Object obj, HTTPState state, Locale locale,
			OutputStream outputstream) throws WTException {

		if (SERVER)
			((PSKCADService) getManager()).makeThumbnailStream(obj, state,
					locale, outputstream);
		else {
			try {
				Class[] argTypes = { Object.class, HTTPState.class,
						Locale.class, OutputStream.class };
				Object[] args = { obj, state, locale, outputstream };
				RemoteMethodServer.getDefault().invoke("makeThumbnailStream",
						null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "makeThumbnailStream" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "makeThumbnailStream" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}
}
