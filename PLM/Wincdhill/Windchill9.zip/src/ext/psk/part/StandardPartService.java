// Generated StandardPartService%4C74DB2E037A: ? 11/01/10 16:09:12
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.part;

import ext.psk.part.PartService;
import java.io.Serializable;
import java.lang.String;
import java.util.HashMap;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import java.io.IOException;  // Preserved unmodeled dependency
import java.io.ObjectInput;  // Preserved unmodeled dependency
import java.io.ObjectOutput;  // Preserved unmodeled dependency
import java.lang.ClassNotFoundException;  // Preserved unmodeled dependency

import wt.change2.ChangeNoticeComplexity;
import wt.clients.folder.FolderTaskLogic;
import wt.content.ApplicationData;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentDependencyLink;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMApplicationType;
import wt.epm.EPMAuthoringAppType;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.epm.EPMDocumentType;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildLinksDelegate;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.EPMReferenceLink;
import wt.fc.IdentityHelper;
import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.service.StandardIBADefinitionService;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.BooleanValueDefaultView;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.iba.value.litevalue.IntegerValueDefaultView;
import wt.iba.value.litevalue.RatioValueDefaultView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.litevalue.URLValueDefaultView;
import wt.iba.value.litevalue.UnitValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.introspection.ClassInfo;  // Preserved unmodeled dependency
import wt.introspection.WTIntrospectionException;  // Preserved unmodeled dependency
import wt.introspection.WTIntrospector;  // Preserved unmodeled dependency
import ext.psk.part.PartHelper;  // Preserved unmodeled dependency
import ext.psk.util.CommonUtil;
import ext.psk.util.CreateNumberRuleUtil;
import ext.psk.util.LdapSearchUser;
import ext.psk.util.PSKCommonUtil;
import ext.psk.util.PageControl;
import ext.psk.util.upload.PLMContentHelper;
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
import ext.psk.ecm.eo.EOAlphaForm;  // Preserved unmodeled dependency
import ext.psk.ecm.eo.EOBetaAForm;  // Preserved unmodeled dependency
import ext.psk.ecm.ev.EVNotice;
import ext.psk.ecm.ev.EVRequest;
import wt.lifecycle.LifeCycleHelper;  // Preserved unmodeled dependency
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.LifeCycleTemplateReference;
import wt.org.OrganizationServicesHelper;  // Preserved unmodeled dependency
import wt.org.WTPrincipalReference;  // Preserved unmodeled dependency
import wt.org.WTUser;  // Preserved unmodeled dependency
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartMaster;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartUsageLink;
import wt.pdmlink.PDMLinkProduct;  // Preserved unmodeled dependency
import wt.pom.Transaction;  // Preserved unmodeled dependency
import wt.query.ClassAttribute;  // Preserved unmodeled dependency
import wt.query.OrderBy;  // Preserved unmodeled dependency
import wt.query.QuerySpec;  // Preserved unmodeled dependency
import wt.query.SearchCondition;  // Preserved unmodeled dependency
import wt.session.SessionHelper;  // Preserved unmodeled dependency
import java.beans.PropertyVetoException;  // Preserved unmodeled dependency
import java.io.FileInputStream;  // Preserved unmodeled dependency
import java.rmi.RemoteException;  // Preserved unmodeled dependency
import java.sql.Timestamp;  // Preserved unmodeled dependency
import java.text.SimpleDateFormat;  // Preserved unmodeled dependency
import java.util.Hashtable;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency
import wt.units.IncompatibleUnitsException;  // Preserved unmodeled dependency
import wt.units.UnitFormatException;  // Preserved unmodeled dependency
import wt.units.display.DefaultUnitRenderer;  // Preserved unmodeled dependency
import wt.units.service.QuantityOfMeasureDefaultView;  // Preserved unmodeled dependency
import wt.util.WTContext;  // Preserved unmodeled dependency
import wt.util.WTProperties;  // Preserved unmodeled dependency
import java.beans.PropertyVetoException;  // Preserved unmodeled dependency
import java.io.FileInputStream;  // Preserved unmodeled dependency
import java.rmi.RemoteException;  // Preserved unmodeled dependency
import java.sql.Timestamp;  // Preserved unmodeled dependency
import java.text.SimpleDateFormat;  // Preserved unmodeled dependency
import java.util.Hashtable;  // Preserved unmodeled dependency
import java.util.Iterator;  // Preserved unmodeled dependency
import java.util.Vector;  // Preserved unmodeled dependency
import wt.units.IncompatibleUnitsException;  // Preserved unmodeled dependency
import wt.units.UnitFormatException;  // Preserved unmodeled dependency
import wt.units.display.DefaultUnitRenderer;  // Preserved unmodeled dependency
import wt.units.service.QuantityOfMeasureDefaultView;  // Preserved unmodeled dependency
import wt.util.WTContext;  // Preserved unmodeled dependency
import wt.util.WTProperties;  // Preserved unmodeled dependency
//##end user.imports

//##begin StandardPartService%4C74DB2E037A.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardPartService</code> static factory method(s),
 * not the <code>StandardPartService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardPartService%4C74DB2E037A.doc

public class StandardPartService extends StandardManager implements PartService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.psk.part.partResource";
   private static final String CLASSNAME = StandardPartService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardPartService%newStandardPartServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardPartService
    * @exception wt.util.WTException
    **/
   //##end newStandardPartService%newStandardPartServicef.doc

   public static StandardPartService newStandardPartService()
            throws WTException {
      //##begin newStandardPartService%newStandardPartServicef.body preserve=no

      StandardPartService instance = new StandardPartService();
      instance.initialize();
      return instance;
      //##end newStandardPartService%newStandardPartServicef.body
   }

   //##begin createPart%4C74DBDF032C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createPart%4C74DBDF032C.doc

   public String createPart( HashMap form )
            throws WTException {
      //##begin createPart%4C74DBDF032C.body preserve=yes
	   WTPart part = WTPart.newWTPart();
	   ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();

			String sTempNumber    = (String) form.get("tempNumber");
			String sTempName      = (String) form.get("tempName");
			
			String sSuffix        = (String) form.get("suffix");
			String sSegment       = (String) form.get("segment");
			String sProcess       = (String) form.get("process");
			
			String sMaterial      = (String) form.get("material");
			String sModel         = (String) form.get("model");
			String sPartSpec      = (String) form.get("partSpec");
			String sUnit          = (String) form.get("unit");
			
			//Drawing Document nothing
			String sUPG           = (String) form.get("upgCode");
			String sTemporaryCad  = (String) form.get("temporaryCad");
			String sMaker  		  = (String) form.get("maker");
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();
			
			if (sTempName != null && !sTempName.equals("")) part.setName(sTempName); // sTempName
			
			// set Number
			String partNumber = ""; 
			String simpleUPG = "";
			//System.out.println("sUPG.length() " + sUPG + " , " + sUPG.length());
			if( sUPG != null && (sUPG.length() == 4) ) {
				simpleUPG = sUPG.substring(0, 1) + sUPG.substring(2,4);
				partNumber = simpleUPG;
			} else { 
				partNumber = "PLM";
			}
			
			partNumber = partNumber + CreateNumberRuleUtil.getPartNumber(partNumber);
	        
			if( sSuffix != null && sSuffix.equals("") ) partNumber += sSuffix;
	        
	        part.setNumber(partNumber);
	        if (sTempName == null || sTempName.equals("")) part.setName(partNumber);
	        
	        QuantityUnit defaultUnit = QuantityUnit.toQuantityUnit(sUnit);
	        part.setDefaultUnit(defaultUnit);
	        
			// save content
			String liftCycle = "LC_PSK_ECM";

			WTContainerRef wtContainerRef = null;
			Folder folder = null;
			if( sSegment != null && sSegment.equals("PSKLIB") ) {
				WTLibrary product = PSKCommonUtil.getWTLibrary("PSKLIB");
				wtContainerRef = WTContainerRef.newWTContainerRef(product);
				part.setContainer(product);

				String yy = CommonUtil.getCurrentTime("yyyy");
				String mm = CommonUtil.getCurrentTime("MM");
				String sFolderPath = "/Default/PART/" + simpleUPG + "/" + yy;
				folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
				
			} else {
				//PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct(sSegment);
				PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
				wtContainerRef = WTContainerRef.newWTContainerRef(product);
				part.setContainer(product);

				String yy = CommonUtil.getCurrentTime("yyyy");
				String mm = CommonUtil.getCurrentTime("MM");
				String sFolderPath = "/Default/PART/" + yy + "/" + mm;
				folder = CommonUtil.getPartFolder(sFolderPath, wtContainerRef);
			}

			// Folder assign
			FolderHelper.assignLocation((FolderEntry) part, folder);
			
			LifeCycleHelper.setLifeCycle(part, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

			// save SoftAttrubute
			Vector attName = new Vector();
			Vector attValue = new Vector();

			if (sProcess != null && !sProcess.equals("")) {
				attName.add("MAKER_PROCESS");
				attValue.add(sProcess);
			}

			if (sPartSpec != null && !sPartSpec.equals("")) {
				attName.add("PART_SPEC");
				attValue.add(sPartSpec);
			}

			if (sMaterial != null && !sMaterial.equals("")) {
				attName.add("MATERIAL");
				attValue.add(sMaterial);
			}

			if (sModel != null && !sModel.equals("")) {
				attName.add("MODEL");
				attValue.add(sModel);
			}

			if (sMaker != null && !sMaker.equals("")) {
				attName.add("MAKER");
				attValue.add(sMaker);
			}
			
			if (attName != null) {
				part = (WTPart)setIBADataNoCheckout((IBAHolder) part,attName, attValue);
			}
			
			//part Save Start
			part = (WTPart) PersistenceHelper.manager.save(part);
			//Part Save End
			
			// temp cad create and link start
			if( sTemporaryCad != null && !sTemporaryCad.equals("") ) {

				String CAD_LIFECYCLE = "Default";
				String attribute[] = new String[4];
				attribute[0] = part.getNumber();
				attribute[1] = part.getName();
				attribute[2] = CAD_LIFECYCLE;
				attribute[3] = "/Default";
				
				EPMDocument epmDoc = null;
				
				if( sTemporaryCad.equals("Create Part CAD")) {
					epmDoc = this.createEPMdocument(attribute, true, wtContainerRef.getContainer(), sSegment, simpleUPG);
					
				} else if( sTemporaryCad.equals("Create Assy CAD") ) {
					epmDoc = this.createEPMdocument(attribute, false, wtContainerRef.getContainer(), sSegment, simpleUPG);
					
				} else if( sTemporaryCad.equals("Use TempCAD") ) {
					String epmOid = (String)form.get("pskDrawingPickerId");
					if( epmOid != null && !epmOid.equals("")) {
						System.out.println("drawingDocument=" + epmOid);
						epmDoc = (EPMDocument)rf.getReference(epmOid).getObject();
					}
				}

				if( epmDoc != null ) {
	                EPMBuildRule sEPMBuildRule = EPMBuildRule.newEPMBuildRule(epmDoc, part);
	                sEPMBuildRule = (EPMBuildRule)PersistenceHelper.manager.save(sEPMBuildRule);

				}
			}
			// temp cad create and link end
			
			//part Reference Document Link Start
			String[] docOid = (String[]) form.get("referenceDocument");
			if( docOid != null )
			for(int i = 0; i < docOid.length; i++ ) {
				WTDocument refDoc = (WTDocument)rf.getReference(docOid[i]).getObject();
				WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(part, refDoc);
				link = (WTPartDescribeLink)PersistenceHelper.manager.save(link);
			}
			//part Reference Document Link End
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(part, addFiles, delFiles, fileDescVec, false);

			result += " : " + part.getNumber();
			System.out.println("@ created Part =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end createPart%4C74DBDF032C.body
   }

   //##begin updatePart%4C74DBF002EE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updatePart%4C74DBF002EE.doc

   public String updatePart( HashMap form )
            throws WTException {
      //##begin updatePart%4C74DBF002EE.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   
	   WTPart part = null;

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sOid = (String) form.get("oid");
			part = (WTPart) rf.getReference(sOid).getObject();
			
			//part = checkoutMandoDoc(part);
			//Start checkOut
			//System.out.println("WTPart Document Check-out Started...");
			
			wt.vc.wip.Workable workable =(wt.vc.wip.Workable)part;
			wt.vc.wip.CheckoutLink checkOutLink = null;
			wt.vc.wip.Workable workingCopy = null;
			wt.vc.wip.Workable orgCopy = null;
		      
			if(!wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
				if(!wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
			    	wt.folder.Folder folder = wt.vc.wip.WorkInProgressHelper.service.getCheckoutFolder();
			        //Folder folder = FolderHelper.service.getFolder("/Default");
			      
					//System.out.println("Folder is " + folder);
					//System.out.println("checkOutLink Is: " + workable +" and Folder is : " + folder);
			      
					try {
						checkOutLink = (wt.vc.wip.CheckoutLink)wt.vc.wip.WorkInProgressHelper.service.checkout(workable, folder, "");
					} catch(wt.util.WTPropertyVetoException wtpve) {
						throw new WTException(wtpve);
					}
			      
			        // get Original copy
			        orgCopy = checkOutLink.getOriginalCopy();
			        //System.out.println("orgCopy is " + orgCopy);
			        
			        // get working copy
			        workingCopy = checkOutLink.getWorkingCopy();
			        //System.out.println("workingCopy is " + workingCopy);
			        
			    } else if (wt.vc.wip.WorkInProgressHelper.isCheckedOut(workable)) {
			        // get Original copy
			        orgCopy = wt.vc.wip.WorkInProgressHelper.service.originalCopyOf(workable);
			        // get working copy
			        workingCopy = wt.vc.wip.WorkInProgressHelper.service.workingCopyOf(workable);
			        //System.out.println("workingCopy is " + workingCopy);
			    }

			} else if (wt.vc.wip.WorkInProgressHelper.isWorkingCopy(workable)) {
			    workingCopy = workable;
			}
			
			part = (WTPart)workingCopy;
			//System.out.println("WTPart Document Check-out Ended...");
			//End CheckOut
			
			String sTempNumber    = (String) form.get("tempNumber");
			String sTempName      = (String) form.get("tempName");

			String sUnit          = (String) form.get("unit");
			String sMaker  		  = (String) form.get("maker");

			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();	

			// save SoftAttrubute
			Vector attName = new Vector();
			Vector attValue = new Vector();

			//System.out.println( "sMaker ; " + sMaker);
			//if (sMaker == null || sMaker("")) sMaker = "N/A";
			if (sMaker != null && !sMaker.equals("")) {
				attName.add("MAKER");
				attValue.add(sMaker);
			}
			
			if (attName != null) {
				part = (WTPart)setIBADataNoCheckout((IBAHolder) part,attName, attValue);
			}
			
			//part Save Start
			part = (WTPart) PersistenceHelper.manager.save(part);
			//Part Save End
			
			// temp cad create and link --> no update

			//part Reference Document Link Start
			this.deletegetWTPartDescribeLink( part.getPersistInfo().getObjectIdentifier().getId() );

			String[] docOid = (String[]) form.get("referenceDocument");
			if( docOid != null )
			for(int i = 0; i < docOid.length; i++ ) {
				WTDocument refDoc = (WTDocument)rf.getReference(docOid[i]).getObject();
				WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(part, refDoc);
				link = (WTPartDescribeLink)PersistenceHelper.manager.save(link);
			}
			//part Reference Document Link End
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(part, addFiles, delFiles, fileDescVec, false);
			
			//Start checkin ...
			//System.out.println("DB checkin start...");
			part = (WTPart)wt.vc.wip.WorkInProgressHelper.service.checkin(part, "");
			//System.out.println("DB checkin end...");
			//System.out.println("DB refresh start...");
			part = (WTPart)PersistenceHelper.manager.refresh(part, true, true);
			//System.out.println("DB refresh end...");
			//End checkin ...

			result += " : " + part.getNumber();
			//System.out.println("@ updated Part =" + result);

			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			
			System.out.println("Start UndoCheckout WTPart Doc...");
			try {
				if (wt.vc.wip.WorkInProgressHelper.isCheckedOut((wt.vc.wip.Workable)part)) {
					wt.vc.wip.WorkInProgressHelper.service.undoCheckout(part);
				}
			} catch(Exception ee) {
				ee.printStackTrace();
			}
			System.out.println("End UndoCheckout WTPart Doc...");
	          
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		
		return result;
      //##end updatePart%4C74DBF002EE.body
   }

   //##begin deletePart%4C74DBFF0399.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deletePart%4C74DBFF0399.doc

   public String deletePart( HashMap form )
            throws WTException {
      //##begin deletePart%4C74DBFF0399.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String result = CommonUtil.SUCC;

	   try {
		   if( true ) throw new WTException("삭제할 수 없습니다");
	   } catch (Exception e) {
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
	   }
	   return result;
      //##end deletePart%4C74DBFF0399.body
   }

   //##begin searchPart%4C74DC0C01D4.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchPart%4C74DC0C01D4.doc

   public HashMap searchPart( HashMap form )
            throws WTException {
      //##begin searchPart%4C74DC0C01D4.body preserve=yes
		PagingQueryResult pagingResults = null;

		String sCmd = (String) form.get("cmd");
		String sPage = (String) form.get("page");
		String sTotalPage = (String) form.get("totalPage");
		String sSessionID = (String) form.get("sessionID");
		
		String sTempNumber    = (String) form.get("shTempNumber");  
		String sTempName      = (String) form.get("shTempName");
		
		String sState = (String) form.get("shApprovalStatus");		//state
		//String sSegment = (String) form.get("shSegment");		//state
		//String sRelatedProduct = (String) form.get("shRelatedProduct");		//state
		
		String sCreatorName = (String) form.get("shIssueUserNm");	
		String sCreator = "";
		if( sCreatorName != null && !sCreatorName.equals("") ) {
			LdapSearchUser searchUserId = new LdapSearchUser();

			sCreator = searchUserId.searchUserInfofromLDAP(sCreatorName); 
		}
		
		String sFromRegDate   = (String) form.get("shFromRegDate");
		String sToRegDate   = (String) form.get("shToRegDate");
		
		String sFromUpDate   = (String) form.get("shFromUpDate");
		String sToUpDate   = (String) form.get("shToUpDate");
		
		String sNewAssyOid  = (String) form.get("newAssyOid");

		try {
			
			if( sCmd.startsWith("listPart") ) {
				QuerySpec query = new QuerySpec();
				query.setAdvancedQueryEnabled(true);
	
				if (query.getConditionCount() > 0) query.appendAnd();
	
				Class classType = WTPart.class;
				int pskChangeIndex = query.appendClassList(classType, true);
	
				query.appendWhere(new SearchCondition(classType, "iterationInfo.latest", "TRUE"), new int[] { pskChangeIndex });

				if (sTempNumber != null && !sTempNumber.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, WTPart.NUMBER, SearchCondition.LIKE,  "%" + sTempNumber + "%"), new int[] { pskChangeIndex });
				}
	
				if (sTempName != null && !sTempName.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					
					query.appendWhere(new SearchCondition(classType, WTPart.NAME, SearchCondition.LIKE, "%" + sTempName + "%"), new int[] { pskChangeIndex });
				}

				if (sState != null && !sState.equals("")) {
					if (query.getConditionCount() > 0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "state.state", SearchCondition.EQUAL, sState), new int[] { pskChangeIndex });
				}
				
				if (sCreator != null && !sCreator.equals("")) {
					long lcreator = 0;
					WTUser creator = OrganizationServicesHelper.manager.getUser(sCreator);
					if( creator != null ) { 
						lcreator = creator.getPersistInfo().getObjectIdentifier().getId();
		
						if (query.getConditionCount() > 0) query.appendAnd();
						query.appendWhere(new SearchCondition(classType, "iterationInfo.creator.key.id", SearchCondition.EQUAL, lcreator), new int[] { pskChangeIndex });
					}
				}
				
				//RegistDate from to Start
				if ( sFromRegDate != null && !sFromRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromRegDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
				}
		          
				if ( sToRegDate != null && !sToRegDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.createStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToRegDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
				}
				//RegistDate from to End
				
				//UpdateDate from to Start
				if ( sFromUpDate != null && !sFromUpDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.GREATER_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sFromUpDate, "yyyy-MM-dd")), new int[]{pskChangeIndex});
				}
		          
				if ( sToUpDate != null && !sToUpDate.equals("") ) {
					if (query.getConditionCount()>0) query.appendAnd();
					query.appendWhere(new SearchCondition(classType, "thePersistInfo.modifyStamp", SearchCondition.LESS_THAN_OR_EQUAL, CommonUtil.formatString2Timestamp(sToUpDate+" 23:59", "yyyy-MM-dd HH:mm")), new int[]{pskChangeIndex});
				}
				//UpdateDate From To End
				
				ClassAttribute classattribute = new ClassAttribute();
				OrderBy orderby = null;
				classattribute = new ClassAttribute(classType, "thePersistInfo.createStamp");
				orderby = new OrderBy(classattribute, true);
	
				query.appendOrderBy(orderby, new int[] { 0 });
	
				//System.out.println("## REQUEST Query:" + query.toString());
	
				QueryResult queryResult = PersistenceHelper.manager.find(query);
				
				if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
					pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
					
				} else if (sCmd != null && sCmd.equals("EXPORT")) {
					pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
					
				} else {
					int PAGE = Integer.parseInt(sPage);
					long pagingSessionID = Long.parseLong(sSessionID);
					pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
					
				}
			} else if( sCmd.startsWith("assyPartPopup")) {

				QuerySpec query = new QuerySpec();
				query.setAdvancedQueryEnabled(true);
	
				if (query.getConditionCount() > 0) query.appendAnd();
				
				ReferenceFactory rf = new ReferenceFactory();
				WTPart part = (WTPart) rf.getReference(sNewAssyOid).getObject();
	
				Class classType = WTPart.class;
				Class linkType = WTPartUsageLink.class;
				Class masterType = WTPartMaster.class;
				int pskChangeIndex = query.appendClassList(classType, false);
				int PskChangeLinkIndex = query.appendClassList(linkType, true);
				int pskMasterIndex = query.appendClassList(masterType, true);

				query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_AOBJECT_ROLE, pskChangeIndex);
				query.appendJoin(PskChangeLinkIndex, WTPartUsageLink.ROLE_BOBJECT_ROLE, pskMasterIndex);
				
				if (query.getConditionCount() > 0) query.appendAnd();
					
				query.appendWhere(new SearchCondition(classType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, part.getPersistInfo().getObjectIdentifier().getId() ), new int[] { pskChangeIndex });
	
				ClassAttribute classattribute = new ClassAttribute(WTPartMaster.class, WTPartMaster.NUMBER);
				OrderBy orderby = new OrderBy(classattribute, true);	
				query.appendOrderBy(orderby, pskMasterIndex );
				
				//qs.appendOrderBy(new OrderBy(ca, true, null), fieldNoArr);
				//System.out.println("## REQUEST Query:" + query.toString());
	
				QueryResult queryResult = PersistenceHelper.manager.find(query);
				
				if ( sSessionID.equals("") && ( sCmd != null && !sCmd.equals("EXPORT")) ) {
					pagingResults = PagingSessionHelper.openPagingSession(0, PageControl.PERPAGE, query);
					
				} else if (sCmd != null && sCmd.equals("EXPORT")) {
					pagingResults = PagingSessionHelper.openPagingSession(0, Integer.parseInt(sTotalPage), query);
					
				} else {
					int PAGE = Integer.parseInt(sPage);
					long pagingSessionID = Long.parseLong(sSessionID);
					pagingResults = PagingSessionHelper.fetchPagingSession((PAGE - 1) * PageControl.PERPAGE, PageControl.PERPAGE, pagingSessionID);
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		HashMap results = new HashMap();
		results.put("results", pagingResults);

		return results;
      //##end searchPart%4C74DC0C01D4.body
   }

   //##begin viewPart%4C74DC2102DE.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewPart%4C74DC2102DE.doc

   public HashMap viewPart( HashMap form )
            throws WTException {
      //##begin viewPart%4C74DC2102DE.body preserve=yes
	   ReferenceFactory rf = new ReferenceFactory();
	   String sOid = (String) form.get("oid");
	   HashMap alphaMap = new HashMap();
	   
	   try {
		   WTPart part = (WTPart) rf.getReference(sOid).getObject();
		   Vector docLinkList = this.getWTPartDescribeLink( part.getPersistInfo().getObjectIdentifier().getId() );
		   Vector epmLink = this.getEPMBuildRuleLink( part.getPersistInfo().getObjectIdentifier().getId() );
	
		   alphaMap.put("part", part);
		   alphaMap.put("docLinkList", docLinkList);
		   alphaMap.put("epmLink", epmLink);
	   } catch (Exception e) {
			e.printStackTrace();
	   }
	   
       return alphaMap;
      //##end viewPart%4C74DC2102DE.body
   }

   //##begin revisePart%4C7CA3400242.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end revisePart%4C7CA3400242.doc

   public String revisePart( HashMap form )
            throws WTException {
      //##begin revisePart%4C7CA3400242.body preserve=yes
	   WTPart part = null;
	   ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sOid = (String) form.get("oid");
			part = (WTPart) rf.getReference(sOid).getObject();
			
			//System.out.println("Starting Revise WTPart Doc = " + part);
			try {
				part = (WTPart)wt.vc.VersionControlHelper.service.newVersion((wt.vc.Versioned)part);
			} catch(wt.util.WTPropertyVetoException wtpve) {
				wtpve.printStackTrace();
				throw new WTException(wtpve);
			}
			//System.out.println("Ending Revise WTPart Doc = " + part);
			
			String sTempNumber    = (String) form.get("tempNumber");
			String sTempName      = (String) form.get("tempName");

			String sUnit          = (String) form.get("unit");
			
			//Drawing Document nothing
			String sMaker  		  = (String) form.get("maker");
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

			// save SoftAttrubute
			Vector attName = new Vector();
			Vector attValue = new Vector();

			if (sMaker != null && !sMaker.equals("")) {
				attName.add("MAKER");
				attValue.add(sMaker);
			}
			
			if (attName != null) {
				part = (WTPart)setIBADataNoCheckout((IBAHolder) part,attName, attValue);
			}
			
			// save content
			String liftCycle = "LC_PSK_ECM";

			// Folder && LifeCycle Setting
			Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
			FolderHelper.assignLocation((FolderEntry) part, folder);
			PDMLinkProduct pskProduct = PSKCommonUtil.getPDMLinkProduct();
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(pskProduct);
			part.setContainer(pskProduct);
			LifeCycleHelper.setLifeCycle(part, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle
			
			part = (WTPart) PersistenceHelper.manager.save(part);
			part = (WTPart)PersistenceHelper.manager.refresh(part, true, true);
			
			//part Reference Document Link Start
			this.deletegetWTPartDescribeLink( part.getPersistInfo().getObjectIdentifier().getId() );
			
			//part Reference Document Link Start
			String[] docOid = (String[]) form.get("referenceDocument");
			if( docOid != null )
			for(int i = 0; i < docOid.length; i++ ) {
				WTDocument refDoc = (WTDocument)rf.getReference(docOid[i]).getObject();
				WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(part, refDoc);
				link = (WTPartDescribeLink)PersistenceHelper.manager.save(link);
			}
			//part Reference Document Link End
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(part, addFiles, delFiles, fileDescVec, false);

			result += " : " + part.getNumber();
			//System.out.println("@ created Part =" + result);
			
			trx.commit();

		} catch (Exception e) {
			trx.rollback();
			
			System.out.println("Start UndoCheckout WTPart Doc...");
			try {
				if (wt.vc.wip.WorkInProgressHelper.isCheckedOut((wt.vc.wip.Workable)part)) {
					wt.vc.wip.WorkInProgressHelper.service.undoCheckout(part);
				}
			} catch(Exception ee) {
				ee.printStackTrace();
			}
			System.out.println("End UndoCheckout WTPart Doc...");
			
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end revisePart%4C7CA3400242.body
   }

   //##begin changeSuffixPart%4C7CA35103D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end changeSuffixPart%4C7CA35103D8.doc

   public String changeSuffixPart( HashMap form )
            throws WTException {
      //##begin changeSuffixPart%4C7CA35103D8.body preserve=yes
	   WTPart part = WTPart.newWTPart();
	   ReferenceFactory rf = new ReferenceFactory();

		String result = CommonUtil.SUCC;

		Transaction trx = new Transaction();
		try {
			trx.start();
			
			String sTempNumber    = (String) form.get("tempNumber");  
			String sTempName      = (String) form.get("tempName");
			
			String sSuffix        = (String) form.get("suffix");
			String sProcess       = (String) form.get("process");
			
			String sMaterial      = (String) form.get("material");
			String sModel         = (String) form.get("model");
			String sPartSpec      = (String) form.get("partSpec");
			String sUnit          = (String) form.get("unit");
			
			String sMaker  		  = (String) form.get("maker");
			
			WTPrincipalReference creator = SessionHelper.manager.getPrincipalReference();

			// set Partnumber & suffix
			if( sSuffix != null && !sSuffix.equals("") ) {
				String partNumber = sTempNumber;
				if( sTempNumber != null && !sTempNumber.equals("") ) {
					if( sTempNumber.length() > 8 ) partNumber = sTempNumber.substring(0, 8);
				}
				partNumber += sSuffix;
				sTempNumber = partNumber;
			}
			
			part.setNumber(sTempNumber);

			if (sTempName != null && !sTempName.equals("")) part.setName(sTempName); // sTempName
			
			QuantityUnit defaultUnit = QuantityUnit.toQuantityUnit(sUnit);
	        part.setDefaultUnit(defaultUnit);

			Vector attName = new Vector();
			Vector attValue = new Vector();
			
			if (sProcess != null && !sProcess.equals("")) {
				attName.add("MAKER_PROCESS");
				attValue.add(sProcess);
			}
			
			if (sPartSpec != null && !sPartSpec.equals("")) {
				attName.add("PART_SPEC");
				attValue.add(sPartSpec);
			}
			
			if (sMaterial != null && !sMaterial.equals("")) {
				attName.add("MATERIAL");
				attValue.add(sMaterial);
			}
			
			if (sModel != null && !sModel.equals("")) {
				attName.add("MODEL");
				attValue.add(sModel);
			}
			
			if (sMaker != null && !sMaker.equals("")) {
				attName.add("MAKER");
				attValue.add(sMaker);
			}
			
			if (attName != null) {
				part = (WTPart)setIBADataNoCheckout((IBAHolder) part,attName, attValue);
			}
			
			// save content
			String liftCycle = "LC_PSK_ECM";

			// Folder && LifeCycle Setting
			Folder folder = FolderTaskLogic.getFolder("/Default/", PSKCommonUtil.getWTContainerRef());
			FolderHelper.assignLocation((FolderEntry) part, folder);
			PDMLinkProduct pskProduct = PSKCommonUtil.getPDMLinkProduct();
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(pskProduct);
			part.setContainer(pskProduct);
			LifeCycleHelper.setLifeCycle(part, LifeCycleHelper.service.getLifeCycleTemplate(liftCycle, wtContainerRef)); // Lifecycle

			part = (WTPart) PersistenceHelper.manager.save(part);

			//epm document Link Start
			//epm copy 필요함
			Vector epmLink = this.getEPMBuildRuleLink( part.getPersistInfo().getObjectIdentifier().getId() );
			for( int i=0; i < epmLink.size(); i++ ) {
				EPMBuildRule epmObj = (EPMBuildRule)epmLink.elementAt(i);
				
				if( epmObj != null ) {
					epmObj = (EPMBuildRule)PersistenceHelper.manager.save(epmObj);
				}
			}
			//epm document Link Stop
			
			//part Reference Document Link Start
			String[] docOid = (String[]) form.get("referenceDocument");
			if( docOid != null )
			for(int i = 0; i < docOid.length; i++ ) {
				WTDocument refDoc = (WTDocument)rf.getReference(docOid[i]).getObject();
				WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(part, refDoc);
				link = (WTPartDescribeLink)PersistenceHelper.manager.save(link);
			}
			//part Reference Document Link End
			
			Vector addFiles			 = (Vector) form.get("addFiles");
			Vector delFiles			 = (Vector) form.get("fileId");
			Vector fileDescVec 		 = new Vector();
			for(int i=0;i<addFiles.size();i++){
				fileDescVec.add("");
			}
			PLMContentHelper.service.updateContent(part, addFiles, delFiles, fileDescVec, false);

			result += " : " + part.getNumber();
			//System.out.println("@ created Part =" + result);
			
			trx.commit();
			
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			result = CommonUtil.FAIL + " : " + e.getMessage();
			//throw new WTException(e);

		} finally {
			trx = null;
		}
		return result;
      //##end changeSuffixPart%4C7CA35103D8.body
   }

	// ##begin user.operations preserve=yes
	public EPMDocument createEPMdocument(String[] basicAttr, boolean docType, WTContainer wtcontext, String sSegment, String simpleUPG)
			throws WTException, WTPropertyVetoException, IOException, PropertyVetoException, Exception {

		String DEFAULT_EPM_LIFECYCLE;
		String WT_HOME;
		String CAD_PART_TEMPLATE;
		String CAD_ASSY_TEMPLATE;
		String DRW_PART_TEMPLATE;
		String DRW_ASSY_TEMPLATE;
		String CAD_REFERENCE_LINK;
		boolean VERBOSE = true;
		boolean MIGRATION_STATE = false;
		EPMDocument doc = null;
		
		try {
	
			WTProperties wtproperties = WTProperties.getLocalProperties();
			DEFAULT_EPM_LIFECYCLE = wtproperties.getProperty("ext.psk.cad.default_lifecycle", "Default");
			WT_HOME = wtproperties.getProperty("wt.home", "D:/ptc");
			CAD_PART_TEMPLATE = "part_template.prt"; // wtproperties.getProperty("ext.psk.cad.part_template","part_template.prt");
			CAD_ASSY_TEMPLATE = "assy_template.asm"; // wtproperties.getProperty("ext.psk.cad.assy_template","assy_template.asm");
			DRW_PART_TEMPLATE = "part_template.drw"; // wtproperties.getProperty("ext.psk.cad.drw_part_template","part_template.drw");
			DRW_ASSY_TEMPLATE = "assy_template.drw"; // wtproperties.getProperty("ext.psk.cad.drw_assy_template","assy_template.drw");
			CAD_REFERENCE_LINK = wtproperties.getProperty("ext.psk.cad.epm_ref_link_type_def", "wt.epm.structure.EPMReferenceLink");
			String migState = wtproperties.getProperty("ext.psk.migration", "false");
	
			if (migState.equals("true")) {
				MIGRATION_STATE = true;
			} else {
				MIGRATION_STATE = false;
			}
	
			/***********************************************************************
			 * basicAttr [0] = number [1] = name [2] = lifecycle [3] = location
			 * docType true = part false = assembly
			 **********************************************************************/
			if (basicAttr == null) throw new WTException("Basic Attribute is NULL!");
			if (basicAttr.length != 4) throw new WTException("Basic Attribute can not match original size[4]!");
			if (wtcontext == null) throw new WTException("Container must be inputed!");
	
			// if uploadFalg == true, you must check between docType and the Type of
			// EPMDocument
	
			// WTContainerRef ref = WTContainerRef.newWTContainerRef(wtcontext);
			// PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct(sSegment);
			// PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
			// WTContainerRef ref = WTContainerRef.newWTContainerRef(product);
			WTContainerRef ref = null;
			Folder folder = null;
			if (sSegment != null && sSegment.equals("PSKLIB")) {
				WTLibrary product = PSKCommonUtil.getWTLibrary("PSKLIB");
				ref = WTContainerRef.newWTContainerRef(product);
				// part.setContainer(product);
	
				String yy = CommonUtil.getCurrentTime("yyyy");
				String mm = CommonUtil.getCurrentTime("MM");
				String sFolderPath = "/Default/PART/" + simpleUPG + "/" + yy;
				folder = CommonUtil.getPartFolder(sFolderPath, ref);
	
			} else {
				// PDMLinkProduct product =
				// PSKCommonUtil.getPDMLinkProduct(sSegment);
				PDMLinkProduct product = PSKCommonUtil.getPDMLinkProduct();
				ref = WTContainerRef.newWTContainerRef(product);
				// part.setContainer(product);
	
				String yy = CommonUtil.getCurrentTime("yyyy");
				String mm = CommonUtil.getCurrentTime("MM");
				String sFolderPath = "/Default/PART/" + yy + "/" + mm;
				folder = CommonUtil.getPartFolder(sFolderPath, ref);
			}
	
			LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(basicAttr[2], ref);
			// Folder checkOutFolder = (Folder)
			// FolderHelper.service.getFolder(basicAttr[3], ref);
	
			if (template == null) {
				template = LifeCycleHelper.service.getLifeCycleTemplate(DEFAULT_EPM_LIFECYCLE, ref);
			}
	
			// if (checkOutFolder == null)
			// throw new
			// WTException("Folder can not find on wtconainer!! [Folder]=basicAttr[3]="
			// + basicAttr[3]);
	
			// CREATE 3D
			EPMAuthoringAppType atype = EPMAuthoringAppType.toEPMAuthoringAppType("PROE");
			doc = EPMDocument.newEPMDocument();
			doc.setNumber(basicAttr[0]);
			doc.setName(basicAttr[1]);
			String filepath = null;
			String templateFileName = null;
			if (docType) {
				doc.setCADName(basicAttr[0] + ".prt");
				filepath = WT_HOME + "/codebase/" + CAD_PART_TEMPLATE;
				templateFileName = CAD_PART_TEMPLATE;
			} else {
				doc.setCADName(basicAttr[0] + ".asm");
				filepath = WT_HOME + "/codebase/" + CAD_ASSY_TEMPLATE;
				templateFileName = CAD_ASSY_TEMPLATE;
			}
	
			((EPMDocumentMaster) doc.getMaster()).setAuthoringApplication(EPMAuthoringAppType.toEPMAuthoringAppType("PROE"));
	
			if (docType) {
				((EPMDocumentMaster) doc.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType("CADCOMPONENT"));
			} else {
				((EPMDocumentMaster) doc.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType("CADASSEMBLY"));
			}
	
			((EPMDocumentMaster) doc.getMaster()).setOwnerApplication(EPMApplicationType.toEPMApplicationType("EPM"));
	
			doc = (EPMDocument) LifeCycleHelper.setLifeCycle(doc, template);
	
			/**
			 * Setting Folder
			 */
			// String yy = CommonUtil.getCurrentTime("yyyy");
			// String mm = CommonUtil.getCurrentTime("MM");
			// String sFolderPath = "/Default/CAD/" + yy + "/" + mm;
	
			// Folder assign
			// Folder folder = CommonUtil.getPartFolder(sFolderPath, ref);
			FolderHelper.assignLocation((FolderEntry) doc, folder);
	
			// FolderHelper.assignLocation(doc, checkOutFolder);
	
			doc = (EPMDocument) PersistenceHelper.manager.save(doc);
	
			FileInputStream fi = new FileInputStream(filepath);
			ApplicationData applicationData = ApplicationData.newApplicationData(doc);
			applicationData.setFileName("{$CAD_NAME}");
			applicationData.setCategory("PROE_UGC");
			applicationData.setRole(ContentRoleType.PRIMARY);
			ContentServerHelper.service.updateContent(doc, applicationData, fi);
		} catch( WTException e ) {
			e.printStackTrace();
			throw new WTException( e );
		}

		return doc;
	}

	public Hashtable getIBAList(IBAHolder part) throws WTException {
		Hashtable resultHash = new Hashtable();
		try {

			IBAHolder ibaholder = (IBAHolder) part;
			ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder, null, null, null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaholder.getAttributeContainer();

			if (defaultattributecontainer == null) {
				System.out.println("Attribute container is null.");
			}

			AbstractValueView[] result = defaultattributecontainer.getAttributeValues();

			//System.out.println("Service found " + result.length + " of values....");

			for (int i = 0; i < result.length; i++) {
				String s = new String();
				boolean okflag = true;

				if (result[i] instanceof StringValueDefaultView) {
					if (result[i].getDefinition().getName().equals("Legend_Primary_Files")) {
						s = "";
						okflag = false;
					} else {
						s = ((StringValueDefaultView) result[i]).getLocalizedDisplayString();
						System.out.println(s);
					}
				} else if (result[i] instanceof FloatValueDefaultView) {
					s = ((FloatValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof IntegerValueDefaultView) {
					s = ((IntegerValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof BooleanValueDefaultView) {
					s = ((BooleanValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof TimestampValueDefaultView) {
					s = timestampToString(((TimestampValueDefaultView) result[i]).getValue());
				} else if (result[i] instanceof UnitValueDefaultView) {
					
					String s1 = null;
					try {
						if (s1 == null) {
							((UnitValueDefaultView) result[i]).toUnit();
							// s =
							// ((UnitValueDefaultView)result[i]).toUnit().toString();

							QuantityOfMeasureDefaultView measure = ((UnitValueDefaultView) result[i]).getUnitDefinition().getQuantityOfMeasureDefaultView();

							if (measure.getDisplayUnitString("SI") != null && !(measure.getDisplayUnitString("SI").equals(""))) {
								s = ((UnitValueDefaultView) result[i]).getValue() + " " + measure.getDisplayUnitString("SI");
							} else {
								s = ((UnitValueDefaultView) result[i]).toUnit().toString();
							}

						} else {

							DefaultUnitRenderer defaultunitrenderer = new DefaultUnitRenderer();
							try {
								defaultunitrenderer.setDisplayDigits(((UnitValueDefaultView) result[i]).getPrecision());
							} catch (WTPropertyVetoException _ex) {
								throw new WTException( _ex );
							}
							s = defaultunitrenderer.renderValue(((UnitValueDefaultView) result[i]).toUnit(), ((UnitValueDefaultView) result[i]).getUnitDisplayInfo(s1));
						}
					} catch (UnitFormatException _ex) {
						throw new WTException( _ex );
					} catch (IncompatibleUnitsException _ex) {
						throw new WTException( _ex );
					}
				} else if (result[i] instanceof RatioValueDefaultView) {
					s = ((RatioValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof URLValueDefaultView) {
					s = "<A HREF=\""
							+ ((URLValueDefaultView) result[i]).getLocalizedDisplayString()
							+ "\">"
							+ (((URLValueDefaultView) result[i]).getDescription() == null ? ((URLValueDefaultView) result[i])
									.getLocalizedDisplayString() : ((URLValueDefaultView) result[i]).getDescription()) + "</A>";
				} else {
					s = "Attribute value type not implemented: " + result[i];
					okflag = false;
				}

				if (okflag) resultHash.put(result[i].getDefinition().getName(), s);
			}
		} catch (Exception e) {
			//e.printStackTrace();
			throw new WTException( e );
		}

		return resultHash;
	}

	public IBAHolder setIBADataNoCheckout(IBAHolder target, Vector attName, Vector attValue) throws WTException, PropertyVetoException,
			RemoteException {
		
		try {
			target = IBAValueHelper.service.refreshAttributeContainer(target, null, null, null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) target.getAttributeContainer();
	
			StandardIBADefinitionService standardibadefinitionservice = new StandardIBADefinitionService();
			for (int i = 0; i < attName.size(); i++) {
				String attributeName = (String) attName.elementAt(i);
				String attributeValue = (String) attValue.elementAt(i);
				AttributeDefDefaultView attributedefdefaultview = standardibadefinitionservice.getAttributeDefDefaultViewByPath(attributeName);
				AbstractValueView aabstractvalueview[] = defaultattributecontainer.getAttributeValues(attributedefdefaultview);
	
				if (aabstractvalueview.length < 1) {
					StringValueDefaultView obj2 = new StringValueDefaultView((StringDefView) attributedefdefaultview, attributeValue);
					defaultattributecontainer.addAttributeValue(((AbstractValueView) (obj2)));
	
				} else {
					((StringValueDefaultView) aabstractvalueview[0]).setValue(attributeValue);
					defaultattributecontainer.updateAttributeValue(aabstractvalueview[0]);
	
				}
			}
			defaultattributecontainer.setConstraintParameter(defaultattributecontainer);
			target.setAttributeContainer(defaultattributecontainer);
		} catch( WTException e ) {
			throw new WTException( e );
		}

		return target;

	}

	public Vector getWTPartDescribeLink(long Oid) throws WTException {
		Vector results = new Vector();
		WTPartDescribeLink form = null;

		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = WTPartDescribeLink.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class partType = WTPart.class;
			int partIndex = query.appendClassList(partType, false);

			query.appendJoin(linkIndex, WTPartDescribeLink.ROLE_AOBJECT_REF, partIndex);
			
			query.appendWhere(new SearchCondition(partType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid), new int[] { partIndex });

			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null;

			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[]) queryResult.nextElement();
					form = (WTPartDescribeLink) obj[0];
					results.add(form);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException( e );
		}

		return results;
	}

	public Vector getEPMBuildRuleLink(long Oid) throws WTException {
		Vector results = new Vector();
		EPMBuildRule form = null;

		try {
			QuerySpec query = new QuerySpec();
			query.setAdvancedQueryEnabled(true);

			if (query.getConditionCount() > 0) query.appendAnd();

			Class linkType = EPMBuildRule.class;
			int linkIndex = query.appendClassList(linkType, true);
			Class partType = WTPart.class;
			int partIndex = query.appendClassList(partType, false);

			query.appendJoin(linkIndex, EPMBuildRule.BUILD_TARGET_ROLE, partIndex);
			
			query.appendWhere(new SearchCondition(partType, "thePersistInfo.theObjectIdentifier.id", SearchCondition.EQUAL, Oid), new int[] { partIndex });

			QueryResult queryResult = PersistenceHelper.manager.find(query);
			Object[] obj = null;

			if (queryResult == null || (queryResult.size() < 0)) {
				System.out.println("result is null!!");
			} else if (queryResult.size() > 0) {
				for (int i = 0; i < queryResult.size(); i++) {
					obj = (Object[]) queryResult.nextElement();
					form = (EPMBuildRule) obj[0];
					results.add(form);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException( e );
		}

		return results;
	}

	public void deletegetWTPartDescribeLink(long Oid) throws WTException {
		try {
			Vector docList = this.getWTPartDescribeLink(Oid);
			WTPartDescribeLink docLink = null;

			for (int i = 0; i < docList.size(); i++) {
				docLink = (WTPartDescribeLink) docList.get(i);
				PersistenceHelper.manager.delete(docLink);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException( e );
		}
	}

	public String timestampToString(Timestamp timestamp) {
		WTContext wtcontext = WTContext.getContext();

		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", wtcontext.getLocale());
		simpledateformat.setTimeZone(wtcontext.getTimeZone());

		java.util.Date date = new java.util.Date(timestamp.getTime());
		String s = simpledateformat.format(date);

		return s;
	}   
   //##end user.operations
}
