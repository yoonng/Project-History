// Generated PSKCADHelper%46A00A3A0109: �� 03/24/10 10:47:17
/* bcwti��?��?��?��?Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.��?��?��?��?This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.��?��?��?��?ecwti
 */

package ext.psk.part;

import ext.psk.part.PSKCADService;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.String;

// ##begin user.imports preserve=yes
// ##end user.imports

// ##begin PSKCADHelper%46A00A3A0109.doc preserve=no
/**
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>true <BR>
 * <BR>
 * <B>Extendable: </B>false
 * 
 * @version 1.0
 */
// ##end PSKCADHelper%46A00A3A0109.doc
public class PSKCADHelper implements Externalizable {

	// --- Attribute Section ---

	private static final String RESOURCE = "ext.psk.cad.cadResource";

	private static final String CLASSNAME = PSKCADHelper.class.getName();

	// ##begin service%46A00C0600DA.doc preserve=no
	/**
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>true
	 */
	// ##end service%46A00C0600DA.doc
	public static final PSKCADService service = new PSKCADServiceFwd();

	static final long serialVersionUID = 1;

	public static final long EXTERNALIZATION_VERSION_UID = 957977401221134810L;

	protected static final long OLD_FORMAT_VERSION_UID = 3966536005790687571L;

	// WARNING: Fields placed in this section will not be generated into
	// externalization methods.
	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	public static final String CAD_LIFECYCLE = "LC_PSK_CAD";

	// ##end static.initialization

	// --- Operation Section ---

	// ##begin writeExternal%writeExternal.doc preserve=no
	/**
	 * �ܺ� �ҽ��� �� Ŭ������ ���ֹ߼� �ʵ带 ���ϴ�.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param output
	 * @exception java.io.IOException
	 */
	// ##end writeExternal%writeExternal.doc
	public void writeExternal(ObjectOutput output) throws IOException {
		// ##begin writeExternal%writeExternal.body preserve=no

		output.writeLong(EXTERNALIZATION_VERSION_UID);

		// ##end writeExternal%writeExternal.body
	}

	// ##begin readExternal%readExternal.doc preserve=no
	/**
	 * �ܺ� �ҽ����� �� Ŭ������ ���ֹ߼� �ʵ带 �н4ϴ�.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param input
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readExternal%readExternal.doc
	public void readExternal(ObjectInput input) throws IOException,
			ClassNotFoundException {
		// ##begin readExternal%readExternal.body preserve=no

		long readSerialVersionUID = input.readLong(); // consume UID
		readVersion(this, input, readSerialVersionUID, false, false); // read
																		// fields
		// ##end readExternal%readExternal.body
	}

	// ##begin readVersion%readVersion.doc preserve=no
	/**
	 * �ܺ� �ҽ����� �� Ŭ������ ���ֹ߼� �ʵ带 �н4ϴ�.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param thisObject
	 * @param input
	 * @param readSerialVersionUID
	 * @param passThrough
	 * @param superDone
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readVersion%readVersion.doc
	protected boolean readVersion(PSKCADHelper thisObject, ObjectInput input,
			long readSerialVersionUID, boolean passThrough, boolean superDone)
			throws IOException, ClassNotFoundException {
		// ##begin readVersion%readVersion.body preserve=no

		boolean success = true;

		if (readSerialVersionUID == EXTERNALIZATION_VERSION_UID) { // if
																	// current
																	// version
																	// UID
		} else {
			success = readOldVersion(input, readSerialVersionUID, passThrough,
					superDone);
			if (input instanceof wt.pds.PDSObjectInput)
				wt.fc.EvolvableHelper.requestRewriteOfEvolvedBlobbedObject();
		}

		return success;
		// ##end readVersion%readVersion.body
	}

	// ##begin readOldVersion%readOldVersion.doc preserve=no
	/**
	 * ���� ������ �ƴ� �ܺ� �ҽ����� �� Ŭ������ ���ֹ߼� �ʵ带 �н4ϴ�.
	 * 
	 * @param input
	 * @param readSerialVersionUID
	 * @param passThrough
	 * @param superDone
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readOldVersion%readOldVersion.doc
	private boolean readOldVersion(ObjectInput input,
			long readSerialVersionUID, boolean passThrough, boolean superDone)
			throws IOException, ClassNotFoundException {
		// ##begin readOldVersion%readOldVersion.body preserve=no

		boolean success = true;

		if (readSerialVersionUID == OLD_FORMAT_VERSION_UID) { // handle
																// previous
																// version
		} else
			throw new java.io.InvalidClassException(CLASSNAME,
					"Local class not compatible:"
							+ " stream classdesc externalizationVersionUID="
							+ readSerialVersionUID
							+ " local class externalizationVersionUID="
							+ EXTERNALIZATION_VERSION_UID);

		return success;
		// ##end readOldVersion%readOldVersion.body
	}

	// ##begin user.operations preserve=yes
	// ##end user.operations
}
