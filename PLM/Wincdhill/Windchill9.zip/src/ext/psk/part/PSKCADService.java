// Generated PSKCADService%46A00A540167: �� 03/24/10 10:47:17
/* bcwti��?��?��?��?Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.��?��?��?��?This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.��?��?��?��?ecwti
 */

package ext.psk.part;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.Object;
import java.lang.String;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.epm.EPMDocument;
import wt.epm.structure.EPMMemberLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.part.WTPart;
import wt.templateutil.processor.HTTPState;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.Workable;

// ##begin user.imports preserve=yes
// ##end user.imports

// ##begin PSKCADService%46A00A540167.doc preserve=no
/**
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>true <BR>
 * <BR>
 * <B>Extendable: </B>false
 * 
 * @version 1.0
 */
// ##end PSKCADService%46A00A540167.doc
public interface PSKCADService {

	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	// ##end static.initialization

	// --- Operation Section ---

	// ##begin copyMemberLink%46A00CCC0157.doc preserve=no
	/**
	 * @param parent
	 * @param orgLink
	 * @param child
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end copyMemberLink%46A00CCC0157.doc
	public void copyMemberLink(EPMDocument parent, EPMMemberLink orgLink,
			EPMDocument child) throws WTException, WTPropertyVetoException;

	// ##begin createEPMdocument%46A41B2B02DD.doc preserve=no
	/**
	 * basicAttr :?? [0] = number?? [1] = name?? [2] = lifecycle?? [3] = folder
	 * 
	 * @param basicAttr
	 * @param docType
	 *            true = part, false = assembly
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.io.IOException
	 * @exception java.beans.PropertyVetoException
	 */
	// ##end createEPMdocument%46A41B2B02DD.doc
	public EPMDocument createEPMdocument(String[] basicAttr, boolean docType,
			WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			IOException, PropertyVetoException;

	// ##begin changeEPMdocument%46A48F1B005D.doc preserve=no
	/**
	 * @param epm
	 * @param basicAttr
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end changeEPMdocument%46A48F1B005D.doc
	public EPMDocument changeEPMdocument(EPMDocument epm, String[] basicAttr,
			WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException;

	// ##begin copyCADBom%46A42C9E03CC.doc preserve=no
	/**
	 * @param parent
	 * @param link
	 *            true = part, false = assembly
	 * @param doc
	 * @param location
	 * @param levelindex
	 *            true = upload, false = connect
	 * @param history
	 *            true = upload, false = connect
	 * @return Hashtable
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyCADBom%46A42C9E03CC.doc
	public Hashtable copyCADBom(EPMDocument parent, EPMMemberLink link,
			EPMDocument doc, String location, int levelindex, Hashtable history)
			throws WTException, WTPropertyVetoException, PropertyVetoException,
			RemoteException;

	// ##begin copyEPMDocument%46A433E401B5.doc preserve=no
	/**
	 * @param org
	 * @param location
	 * @param history
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyEPMDocument%46A433E401B5.doc
	public EPMDocument copyEPMDocument(EPMDocument org, String location,
			Hashtable history) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException;

	// ##begin copyEPMDocument%4727D8D20138.doc preserve=no
	/**
	 * @param org
	 * @param location
	 * @param history
	 * @param ref
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyEPMDocument%4727D8D20138.doc
	public EPMDocument copyEPMDocument(EPMDocument org, String location,
			Hashtable history, WTContainerRef ref) throws WTException,
			WTPropertyVetoException, PropertyVetoException, RemoteException;

	// ##begin getRelationalPart%46A483A7002Eg.doc preserve=no
	/**
	 * @param epmOid
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	// ##end getRelationalPart%46A483A7002Eg.doc
	public WTPart getRelationalPart(String epmOid) throws WTException;

	// ##begin getRelationalPart%46A4835403D8g.doc preserve=no
	/**
	 * @param epm
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	// ##end getRelationalPart%46A4835403D8g.doc
	public WTPart getRelationalPart(EPMDocument epm) throws WTException;

	// ##begin getRelational3DCad%46A483D701B5g.doc preserve=no
	/**
	 * @param partOid
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46A483D701B5g.doc
	public EPMDocument getRelational3DCad(String partOid) throws WTException;

	// ##begin getRelational3DCad%46A483E6035Bg.doc preserve=no
	/**
	 * @param epm
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46A483E6035Bg.doc
	public EPMDocument getRelational3DCad(EPMDocument epm) throws WTException;

	// ##begin getRelational3DCad%46AEB18B0157g.doc preserve=no
	/**
	 * @param part
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46AEB18B0157g.doc
	public EPMDocument getRelational3DCad(WTPart part) throws WTException;

	// ##begin getRelational2DCad%46A57BEE0271g.doc preserve=no
	/**
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57BEE0271g.doc
	public Vector getRelational2DCad(EPMDocument epm) throws WTException;

	// ##begin getRelational2DCad%46A57BED00BBg.doc preserve=no
	/**
	 * @param part
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57BED00BBg.doc
	public Vector getRelational2DCad(WTPart part) throws WTException;

	// ##begin getRelational2DCad%46A57C230128g.doc preserve=no
	/**
	 * @param object
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57C230128g.doc
	public Vector getRelational2DCad(String object) throws WTException;

	// ##begin checkDrawing%46A57C6B02BF.doc preserve=no
	/**
	 * @param epm
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end checkDrawing%46A57C6B02BF.doc
	public boolean checkDrawing(EPMDocument epm) throws WTException;

	// ##begin checkDrawing%46A57C8B008C.doc preserve=no
	/**
	 * @param epmOid
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end checkDrawing%46A57C8B008C.doc
	public boolean checkDrawing(String epmOid) throws WTException;

	// ##begin syncDrawingState%46A57F870242.doc preserve=no
	/**
	 * @param epm
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46A57F870242.doc
	public void syncDrawingState(String epm) throws WTException;

	// ##begin syncDrawingState%46A57FAB009C.doc preserve=no
	/**
	 * @param epm
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46A57FAB009C.doc
	public void syncDrawingState(EPMDocument epm) throws WTException;

	// ##begin syncDrawingState%46AEB33A031C.doc preserve=no
	/**
	 * @param part
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46AEB33A031C.doc
	public void syncDrawingState(WTPart part) throws WTException;

	// ##begin enforcedUpdate%46AEB29301F4.doc preserve=no
	/**
	 * @param persist
	 * @return Persistable
	 * @exception wt.util.WTException
	 */
	// ##end enforcedUpdate%46AEB29301F4.doc
	public Persistable enforcedUpdate(Persistable persist) throws WTException;

	// ##begin copyIBAValue%46B035F300CB.doc preserve=no
	/**
	 * @param org
	 * @param target
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyIBAValue%46B035F300CB.doc
	public boolean copyIBAValue(IBAHolder org, IBAHolder target)
			throws WTException, WTPropertyVetoException, RemoteException;

	// ##begin isExistCad%46B042700196.doc preserve=no
	/**
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end isExistCad%46B042700196.doc
	public boolean isExistCad(String part) throws WTException;

	// ##begin isExistCad%46B042990203.doc preserve=no
	/**
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end isExistCad%46B042990203.doc
	public boolean isExistCad(WTPart part) throws WTException;

	// ##begin canDeleteStructure%46B042C1001F.doc preserve=no
	/**
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end canDeleteStructure%46B042C1001F.doc
	public boolean canDeleteStructure(WTPart parent, WTPart child)
			throws WTException;

	// ##begin canAddStructure%46B042E5035B.doc preserve=no
	/**
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end canAddStructure%46B042E5035B.doc
	public boolean canAddStructure(WTPart parent, WTPart child)
			throws WTException;

	// ##begin syncStructure%46BC1E420109.doc preserve=no
	/**
	 * @param epmdoc
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end syncStructure%46BC1E420109.doc
	public boolean syncStructure(EPMDocument epmdoc) throws WTException,
			WTPropertyVetoException;

	// ##begin syncStructureByNewPart%46C14F40035B.doc preserve=no
	/**
	 * @param addPart
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end syncStructureByNewPart%46C14F40035B.doc
	public boolean syncStructureByNewPart(WTPart addPart) throws WTException,
			WTPropertyVetoException;

	// ##begin getChildEPMDocument%46BC1F3000CBg.doc preserve=no
	/**
	 * @param parent
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	// ##end getChildEPMDocument%46BC1F3000CBg.doc
	public QueryResult getChildEPMDocument(EPMDocument parent)
			throws WTException;

	// ##begin getParentEPMDocument%46C181E8033Cg.doc preserve=no
	/**
	 * @param child
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	// ##end getParentEPMDocument%46C181E8033Cg.doc
	public QueryResult getParentEPMDocument(EPMDocument child)
			throws WTException;

	// ##begin enforcedSaveByCheckout%46C965BD005D.doc preserve=no
	/**
	 * @param aObject
	 * @param bObject
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end enforcedSaveByCheckout%46C965BD005D.doc
	public boolean enforcedSaveByCheckout(Workable aObject, Workable bObject)
			throws WTException;

	// ##begin fileDuplicate%46CAA72F0261.doc preserve=no
	/**
	 * @param changeStr
	 * @param docType
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDuplicate%46CAA72F0261.doc
	public boolean fileDuplicate(String changeStr, boolean docType)
			throws IOException, WTException;

	// ##begin fileDuplicate%46CD543B0128.doc preserve=no
	/**
	 * @param orgCompareStr
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDuplicate%46CD543B0128.doc
	public boolean fileDuplicate(String orgCompareStr, String changeStr)
			throws IOException, WTException;

	// ##begin fileDelete%46CAAA3E000F.doc preserve=no
	/**
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDelete%46CAAA3E000F.doc
	public boolean fileDelete(String changeStr) throws IOException, WTException;

	// ##begin fileSave%46CAB3E602AF.doc preserve=no
	/**
	 * @param applicationData
	 * @param filename
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileSave%46CAB3E602AF.doc
	public boolean fileSave(ApplicationData applicationData, String filename)
			throws IOException, WTException;

	// ##begin getOwnDrawing%46CCE84300ABg.doc preserve=no
	/**
	 * @param epm3d
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getOwnDrawing%46CCE84300ABg.doc
	public EPMDocument getOwnDrawing(EPMDocument epm3d) throws WTException;

	// ##begin getRelational2DCadLink%46DE697B0128g.doc preserve=no
	/**
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCadLink%46DE697B0128g.doc
	public Vector getRelational2DCadLink(EPMDocument epm) throws WTException;

	// ##begin makeThumbnailStream%47186922004E.doc preserve=no
	/**
	 * @param obj
	 * @param state
	 * @param locale
	 * @param outputstream
	 * @exception wt.util.WTException
	 */
	// ##end makeThumbnailStream%47186922004E.doc
	public void makeThumbnailStream(Object obj, HTTPState state, Locale locale,
			OutputStream outputstream) throws WTException;

	// ##begin user.operations preserve=yes
	// ##end user.operations
}
