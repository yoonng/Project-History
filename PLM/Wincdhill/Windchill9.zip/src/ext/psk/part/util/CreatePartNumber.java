package ext.psk.part.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import wt.pds.oracle81.OraclePds81;
import wt.util.WTException;

public class CreatePartNumber {

	public String getPartNumber(String preFixNumber) throws WTException{
		
		/**
		 *	SELECT MAX(SUBSTR(wtpartnumber, 4, 5)) FROM WTPARTMASTER
		 *	WHERE wtpartnumber LIKE 'MPG%'
		 *
		 * java.text.DecimalFormat df = new java.text.DecimalFormat("00000");
         * Long serialL = Long.valueOf(wt.fc.PersistenceHelper.manager.getNextSequence("DOC_SEQ"));
         * String serial = df.format(serialL.longValue());
		 */
		String result = "";
		int tempInt = 0;
		String nextNum = "";
		String maxcol = "";
		String buyPartQuery = "";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		
		try {
			String sql = 
					" SELECT MAX(substr(WTPARTNUMBER, 4, 5)) no "
					+ " FROM WTPARTMASTER "
					+ " WHERE WTPARTNUMBER LIKE '" + preFixNumber + "%' ";
			
			System.out.println("sql:"+sql);
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);

			if (rs != null && rs.next()) {
				if (rs.getString("no") == null)
					result = "00000";
				else {
					String no = rs.getString("no");
					
					int checkInt = -1;
					try {
						checkInt = Integer.parseInt(no);
					} catch (Exception ex){
						ex.printStackTrace();
					}
					
					if( checkInt == -1 ) {
						result = "10000";
					} else if (no.length() == 5) {
						result = no;
					} else if (no.length() == 4) {
						result = no + "0";
					} else if (no.length() == 3) {
						result = no + "00";
					} else if (no.length() == 2) {
						result = no + "000";
					} else if (no.length() == 1) {
						result = no + "0000";
					}

					//result = Integer.toString((Integer.parseInt(nextNum) + 1));
				}
			} else {
				result = "00000";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return Integer.toString((Integer.parseInt(nextNum) + 1));
	}
	
}
