// Generated StandardPSKCADService%46A00A700148: �� 03/24/10 10:47:17
/* bcwti��?��?��?��?Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.��?��?��?��?This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.��?��?��?��?ecwti
 */

package ext.psk.part;

import ext.psk.part.PSKCADService;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.Object;
import java.lang.String;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.epm.EPMDocument;
import wt.epm.structure.EPMMemberLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.templateutil.processor.HTTPState;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.Workable;

// ##begin user.imports preserve=yes

import java.beans.PropertyVetoException;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import wt.templateutil.processor.VisualizationRendererFactory;
import wt.templateutil.processor.VisualizationRendererIfc;
import wt.clients.util.http.HTTPUploadDownload;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.doc.DocumentMaster;
import wt.epm.EPMApplicationType;
import wt.epm.EPMAuthoringAppType;
import wt.epm.EPMDocSubType;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.epm.EPMDocumentType;
import wt.epm.structure.EPMMemberLink;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.structure.EPMStructureHelper;
import wt.epm.familytable.EPMParameterValue;
import wt.fc.IdentityHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.litedefinition.FloatDefView;
import wt.iba.definition.service.StandardIBADefinitionService;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.BooleanValueDefaultView;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.iba.value.litevalue.IntegerValueDefaultView;
import wt.iba.value.litevalue.RatioValueDefaultView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.litevalue.URLValueDefaultView;
import wt.iba.value.litevalue.UnitValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.LifeCycleTemplateReference;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.part.Quantity;
import wt.part.WTPart;
import wt.part.WTPartConfigSpec;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartStandardConfigSpec;
import wt.part.WTPartUsageLink;
import wt.pdmlink.PDMLinkProduct;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.units.IncompatibleUnitsException;
import wt.units.UnitFormatException;
import wt.units.display.DefaultUnitRenderer;
import wt.units.service.QuantityOfMeasureDefaultView;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;
import wt.vc.wip.Workable;
import wt.content.ContentServerHelper;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

// ##end user.imports

// ##begin StandardPSKCADService%46A00A700148.doc preserve=no
/**
 * 
 * <p>
 * <code>StandardPSKCADService</code> ���ڰ� �ƴ� d�� ���丮 �޼ҵ�
 * <code>newStandardPSKCADService</code>;(��) ����Ͽ� �� Ŭ������ �ν��Ͻ��� ���մϴ�.
 * �ν��Ͻ��� d����8�� �ʱ�ȭ�ǵ��� �Ϸx� d�� ���丮�� ����Ͽ� �ν��Ͻ��� ���ؾ� �մϴ�.
 * <p>
 * 
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>true <BR>
 * <BR>
 * <B>Extendable: </B>false
 * 
 * @version 1.0
 */
// ##end StandardPSKCADService%46A00A700148.doc
public class StandardPSKCADService extends StandardManager implements PSKCADService, Serializable {

	// --- Attribute Section ---

	private static final String RESOURCE = "ext.psk.cad.cadResource";

	private static final String CLASSNAME = StandardPSKCADService.class.getName();

	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	public static String DEFAULT_EPM_LIFECYCLE;

	public static String WT_HOME;

	public static String CAD_PART_TEMPLATE;

	public static String CAD_ASSY_TEMPLATE;

	public static String DRW_PART_TEMPLATE;

	public static String DRW_ASSY_TEMPLATE;

	public static String CAD_REFERENCE_LINK;

	public static boolean VERBOSE = true;

	public static boolean MIGRATION_STATE = false;

	// ##end static.initialization

	// --- Operation Section ---

	// ##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
	/**
	 * Ŭ������ ������(��) �̸�; ��ȯ�մϴ�.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @deprecated
	 * 
	 * @return String
	 */
	// ##end getConceptualClassname%getConceptualClassnameg.doc
	public String getConceptualClassname() {
		// ##begin getConceptualClassname%getConceptualClassnameg.body
		// preserve=no

		return CLASSNAME;
		// ##end getConceptualClassname%getConceptualClassnameg.body
	}

	// ##begin performStartupProcess%46BBCC930157.doc preserve=no
	/**
	 * Dummy method to be overridden by subclasses. Subclasses should override
	 * this method and provide startup processing.��?��?
	 * 
	 * @exception wt.services.ManagerException
	 */
	// ##end performStartupProcess%46BBCC930157.doc
	protected synchronized void performStartupProcess() throws ManagerException {
		// ##begin performStartupProcess%46BBCC930157.body preserve=yes

		super.performStartupProcess();

		getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
			public void notifyVetoableEvent(Object event) throws WTException {
				final Workable target = ((WorkInProgressServiceEvent) event).getWorkingCopy();
				if (VERBOSE)
					System.out.println("Listen hears PRE_CHECKIN: ");
				if (VERBOSE)
					System.out.print(" target:");
				if (VERBOSE)
					System.out.println(target.toString());
			}
		}, WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.PRE_CHECKIN));

		getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
			public void notifyVetoableEvent(Object event) throws WTException {
				// final Workable target =
				// ((WorkInProgressServiceEvent)event).getOriginalCopy();
				StandardPSKCADService operation = new StandardPSKCADService();
				final Workable target = ((WorkInProgressServiceEvent) event).getWorkingCopy();
				if (VERBOSE)
					System.out.println("Listen hears POST_CHECKIN: ");
				if (VERBOSE)
					System.out.print(" target:");
				if (VERBOSE)
					System.out.println(target.toString());

				if (target instanceof EPMDocument) {
					EPMDocument epmdoc = (EPMDocument) target;
					if (epmdoc.getDocType().getStringValue().equals(EPMDocumentType.toEPMDocumentType("CADCOMPONENT").getStringValue())
							|| epmdoc.getDocType().getStringValue().equals(EPMDocumentType.toEPMDocumentType("CADASSEMBLY").getStringValue())) {
						if (VERBOSE)
							System.out.println("[LISTENER POST CHECK_IN] WORKING:" + epmdoc.getIdentity() + "|"
									+ VersionControlHelper.getVersionIdentifier(epmdoc).getValue() + "."
									+ VersionControlHelper.getIterationIdentifier(epmdoc).getValue());

						WTPart part = (WTPart) PSKCADHelper.service.getRelationalPart(epmdoc);
						if (part != null) {
							if (VERBOSE)
								System.out.println("[LISTENER POST CHECK_IN]: PART IS NOT NULL.");

							try {
								// IBA copy
								PSKCADHelper.service.copyIBAValue(epmdoc, part);
								// SYNC STRUCTURE
								if (VERBOSE)
									System.out.println("[START syncStructure]");
								PSKCADHelper.service.syncStructure(epmdoc);
							} catch (WTPropertyVetoException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (RemoteException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					} else if (epmdoc.getDocType().getStringValue().equals(EPMDocumentType.toEPMDocumentType("CADDRAWING").getStringValue())) {

					}

				}

			}
		}, WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.POST_CHECKIN));

		// ##end performStartupProcess%46BBCC930157.body
	}

	// ##begin performShutdownProcess%46BBCC930167.doc preserve=no
	/**
	 * Dummy method to be overridden by subclasses. Subclasses should override
	 * this method and provide shutdown processing.
	 * 
	 * @exception wt.services.ManagerException
	 */
	// ##end performShutdownProcess%46BBCC930167.doc
	protected synchronized void performShutdownProcess() throws ManagerException {
		// ##begin performShutdownProcess%46BBCC930167.body preserve=yes

		super.performShutdownProcess();

		// ##end performShutdownProcess%46BBCC930167.body
	}

	// ##begin newStandardPSKCADService%newStandardPSKCADServicef.doc
	// preserve=no
	/**
	 * Ŭ������ ���� �⺻ ���丮�Դϴ�.
	 * 
	 * @return StandardPSKCADService
	 * @exception wt.util.WTException
	 */
	// ##end newStandardPSKCADService%newStandardPSKCADServicef.doc
	public static StandardPSKCADService newStandardPSKCADService() throws WTException {
		// ##begin newStandardPSKCADService%newStandardPSKCADServicef.body
		// preserve=no

		StandardPSKCADService instance = new StandardPSKCADService();
		instance.initialize();
		return instance;
		// ##end newStandardPSKCADService%newStandardPSKCADServicef.body
	}

	// ##begin copyMemberLink%46A00CCC0157.doc preserve=no
	/**
	 * @param parent
	 * @param orgLink
	 * @param child
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end copyMemberLink%46A00CCC0157.doc
	public void copyMemberLink(EPMDocument parent, EPMMemberLink orgLink, EPMDocument child) throws WTException, WTPropertyVetoException {
		// ##begin copyMemberLink%46A00CCC0157.body preserve=yes
		EPMMemberLink link = EPMMemberLink.newEPMMemberLink(parent, (EPMDocumentMaster) child.getMaster());

		link.setAsStoredChildName(orgLink.getAsStoredChildName());
		// link.setAttributeContainer(orgLink.getAttributeContainer());
		link.setCompLayerIdx(orgLink.getCompLayerIdx());
		link.setCompNumber(orgLink.getCompNumber());
		link.setCompRevNumber(orgLink.getCompRevNumber());
		link.setDepType(orgLink.getDepType());
		link.setIdentifier(orgLink.getIdentifier());
		link.setName(orgLink.getName());
		link.setPlaced(orgLink.isPlaced());
		link.setQuantity(orgLink.getQuantity());
		link.setReferenceControl(orgLink.getReferenceControl());
		link.setRequired(orgLink.isRequired());
		link.setSuppressed(orgLink.isSuppressed());
		link.setTransform(orgLink.getTransform());
		link.setTypeDefinitionReference(orgLink.getTypeDefinitionReference());
		link.setUniqueLinkID(orgLink.getUniqueLinkID());
		link.setUniqueNDId(orgLink.getUniqueNDId());

		PersistenceServerHelper.manager.insert(link);
		// ##end copyMemberLink%46A00CCC0157.body
	}

	// ##begin createEPMdocument%46A41B2B02DD.doc preserve=no
	/**
	 * basicAttr :?? [0] = number?? [1] = name?? [2] = lifecycle?? [3] = folder
	 * 
	 * @param basicAttr
	 * @param docType
	 *            true = part, false = assembly
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.io.IOException
	 * @exception java.beans.PropertyVetoException
	 */
	// ##end createEPMdocument%46A41B2B02DD.doc
	public EPMDocument createEPMdocument(String[] basicAttr, boolean docType, WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			IOException, PropertyVetoException {
		// ##begin createEPMdocument%46A41B2B02DD.body preserve=yes
		/***********************************************************************
		 * basicAttr [0] = number [1] = name [2] = lifecycle [3] = location
		 * docType true = part false = assembly
		 **********************************************************************/
		if (basicAttr == null)
			throw new WTException("Basic Attribute is NULL!");
		if (basicAttr.length != 4)
			throw new WTException("Basic Attribute can not match original size[4]!");
		if (wtcontext == null)
			throw new WTException("Container must be inputed!");

		// if uploadFalg == true, you must check between docType and the Type of
		// EPMDocument

		WTContainerRef ref = WTContainerRef.newWTContainerRef(wtcontext);
		LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(basicAttr[2], ref);
		Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(basicAttr[3], ref);

		if (template == null) {
			template = LifeCycleHelper.service.getLifeCycleTemplate(DEFAULT_EPM_LIFECYCLE, ref);
		}

		if (checkOutFolder == null)
			throw new WTException("Folder can not find on wtconainer!! [Folder]=basicAttr[3]=" + basicAttr[3]);

		// CREATE 3D
		EPMAuthoringAppType atype = EPMAuthoringAppType.toEPMAuthoringAppType("PROE");
		EPMDocument doc = EPMDocument.newEPMDocument();
		doc.setNumber(basicAttr[0]);
		doc.setName(basicAttr[1]);
		String filepath = null;
		String templateFileName = null;
		if (docType) {
			doc.setCADName(basicAttr[0] + ".prt");
			filepath = WT_HOME + "/codebase/" + CAD_PART_TEMPLATE;
			templateFileName = CAD_PART_TEMPLATE;
		} else {
			doc.setCADName(basicAttr[0] + ".asm");
			filepath = WT_HOME + "/codebase/" + CAD_ASSY_TEMPLATE;
			templateFileName = CAD_ASSY_TEMPLATE;
		}
		((EPMDocumentMaster) doc.getMaster()).setAuthoringApplication(EPMAuthoringAppType.toEPMAuthoringAppType("PROE"));
		if (docType)
			((EPMDocumentMaster) doc.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType("CADCOMPONENT"));
		else
			((EPMDocumentMaster) doc.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType("CADASSEMBLY"));
		((EPMDocumentMaster) doc.getMaster()).setOwnerApplication(EPMApplicationType.toEPMApplicationType("EPM"));

		doc = (EPMDocument) LifeCycleHelper.setLifeCycle(doc, template);
		FolderHelper.assignLocation(doc, checkOutFolder);

		doc = (EPMDocument) PersistenceHelper.manager.save(doc);

		FileInputStream fi = new FileInputStream(filepath);
		ApplicationData applicationData = ApplicationData.newApplicationData(doc);
		applicationData.setFileName("{$CAD_NAME}");
		applicationData.setCategory("PROE_UGC");
		applicationData.setRole(ContentRoleType.PRIMARY);
		ContentServerHelper.service.updateContent(doc, applicationData, fi);

		/*
		 * ��ǰ �� �� ���ø�; Ȱ���� 2D ��: ���� �ʱ�� ��(From ����ȣ)
		 * 2008-01-03(KYKIM)
		 */
		// CAD DUPLICATE
		// this.fileDuplicate(basicAttr[0], docType);
		// CREATE 2D
		/*
		 * EPMAuthoringAppType atype2D =
		 * EPMAuthoringAppType.toEPMAuthoringAppType("PROE"); EPMDocument doc2D
		 * = EPMDocument.newEPMDocument(); doc2D.setNumber(basicAttr[0]+"[2D]");
		 * doc2D.setName(basicAttr[1]); doc2D.setCADName(basicAttr[0]+".drw");
		 * ((EPMDocumentMaster)doc2D.getMaster()).setAuthoringApplication(
		 * EPMAuthoringAppType.toEPMAuthoringAppType("PROE"));
		 * ((EPMDocumentMaster
		 * )doc2D.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType
		 * ("CADDRAWING"));
		 * ((EPMDocumentMaster)doc2D.getMaster()).setOwnerApplication
		 * (EPMApplicationType.toEPMApplicationType("EPM"));
		 * ((EPMDocumentMaster)
		 * doc2D.getMaster()).setDocSubType(EPMDocSubType.toEPMDocSubType
		 * ("OTHER"));
		 * 
		 * doc2D = (EPMDocument)LifeCycleHelper.setLifeCycle(doc2D, template);
		 * FolderHelper.assignLocation(doc2D, checkOutFolder); doc2D =
		 * (EPMDocument)PersistenceHelper.manager.save(doc2D);
		 * 
		 * FileInputStream fi2D = new
		 * FileInputStream(WT_HOME+"/codebase/"+basicAttr[0]+".drw");
		 * ApplicationData applicationData2D =
		 * ApplicationData.newApplicationData(doc2D);
		 * applicationData2D.setUploadedFromPath
		 * (WT_HOME+"/codebase/"+basicAttr[0]+".drw");
		 * applicationData2D.setFileName("{$CAD_NAME}");
		 * applicationData2D.setCategory("PROE_UGC");
		 * applicationData2D.setRole(ContentRoleType.PRIMARY);
		 * ContentServerHelper.service.updateContent(doc2D, applicationData2D,
		 * fi2D);
		 * 
		 * EPMReferenceLink link =
		 * EPMReferenceLink.newEPMReferenceLink((EPMDocument)doc2D,
		 * (DocumentMaster)(((EPMDocument)doc).getMaster()));
		 * link.setAsStoredChildName(doc.getCADName()); link.setDepType(4);
		 * link.setRequired(true); link.setUniqueNDId("R/4/"+doc.getCADName());
		 * link.setTypeDefinitionReference(TypedUtilityServiceHelper.service.
		 * getTypeDefinitionReference(CAD_REFERENCE_LINK));
		 * PersistenceServerHelper.manager.insert(link);
		 * 
		 * this.fileDelete(basicAttr[0]+".drw");
		 */

		return doc;
		// ##end createEPMdocument%46A41B2B02DD.body
	}

	// ##begin changeEPMdocument%46A48F1B005D.doc preserve=no
	/**
	 * @param epm
	 * @param basicAttr
	 * @param wtcontext
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end changeEPMdocument%46A48F1B005D.doc
	public EPMDocument changeEPMdocument(EPMDocument epm, String[] basicAttr, WTContainer wtcontext) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException {
		// ##begin changeEPMdocument%46A48F1B005D.body preserve=yes
		/***********************************************************************
		 * basicAttr [0] = number [1] = name [2] = lifecycle [3] = location
		 **********************************************************************/
		if (basicAttr == null)
			throw new WTException("Basic Attribute is NULL!");
		if (basicAttr.length != 4)
			throw new WTException("Basic Attribute can not match original size[4]!");
		if (epm == null || basicAttr[0] == null || basicAttr[1] == null)
			throw new WTException("All of needed attributes must be inputed!!!");

		WTContainerRef ref = null;

		if (wtcontext == null)
			ref = epm.getContainerReference();
		else
			ref = WTContainerRef.newWTContainerRef(wtcontext);

		boolean changeLocationFlag = true;
		if (VERBOSE)
			System.out.println("[epm.getNumber()]=" + epm.getNumber());
		String originalEpmNumber = epm.getNumber();
		if (epm.getNumber().lastIndexOf(".") > 0)
			originalEpmNumber = epm.getNumber().substring(0, epm.getNumber().lastIndexOf("."));
		boolean originalDocType = true;

		if (basicAttr[2] == null || basicAttr[2].length() <= 0) {
			basicAttr[2] = this.DEFAULT_EPM_LIFECYCLE;
		}

		if (basicAttr[3] == null || basicAttr[3].length() <= 0) {
			basicAttr[3] = epm.getLocation();
			changeLocationFlag = false;
		}

		EPMDocumentMaster epmMaster = (EPMDocumentMaster) (epm.getMaster());

		EPMDocumentMasterIdentity identity = (EPMDocumentMasterIdentity) epmMaster.getIdentificationObject();
		identity.setNumber(basicAttr[0]);
		identity.setName(basicAttr[1]);
		epmMaster = (EPMDocumentMaster) IdentityHelper.service.changeIdentity(epmMaster, identity);

		String cangeCadNumber = null;
		if (this.checkDocType(epm)) {
			EPMDocumentHelper.service.changeCADName(epmMaster, (basicAttr[0] + ".prt").toLowerCase());
			cangeCadNumber = (basicAttr[0] + ".prt").toLowerCase();
			originalDocType = false;
		} else {
			EPMDocumentHelper.service.changeCADName(epmMaster, (basicAttr[0] + ".asm").toLowerCase());
			cangeCadNumber = (basicAttr[0] + ".asm").toLowerCase();
			originalDocType = true;
		}

		// CHANGE LC
		LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(basicAttr[2], ref);
		Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(basicAttr[3], ref);
		LifeCycleTemplateReference lref = LifeCycleTemplateReference.newLifeCycleTemplateReference(template);
		epm = (EPMDocument) LifeCycleHelper.service.reassign(epm, lref);
		// CHANGE LOCATION
		if (changeLocationFlag) {
			epm = (EPMDocument) PersistenceHelper.manager.refresh(epm);
			FolderHelper.service.changeFolder(epm, checkOutFolder);
		}

		/*
		 * Vector epm2dVector = this.getRelational2DCad(epm); EPMDocument epm2d
		 * = null; if( epm2dVector != null ) { for(int i=0; i <
		 * epm2dVector.size(); i++) { epm2d = (EPMDocument)epm2dVector.get(i);
		 * this.change2DEPMdocument(epm, epm2d, originalEpmNumber,
		 * originalDocType, basicAttr, wtcontext); } }
		 */

		if (VERBOSE)
			System.out.println("[START 2D DRAWING REFERENCE]");
		Vector epm2dVector = this.getRelational2DCadLink(epm);
		if (VERBOSE) {
			if (epm2dVector != null)
				System.out.println("[2D LINK SIZE]=" + epm2dVector.size());
			else
				System.out.println("[2D LINK SIZE]=null");
		}
		EPMDocument epm2d = null;
		EPMReferenceLink epm2dLink = null;
		if (epm2dVector != null) {
			for (int i = 0; i < epm2dVector.size(); i++) {
				epm2dLink = (EPMReferenceLink) epm2dVector.get(i);
				epm2d = (EPMDocument) epm2dLink.getReferencedBy();

				epm2dLink.setUniqueNDId("R/" + epm2dLink.getDepType() + "/" + cangeCadNumber);
				epm2dLink.setAsStoredChildName(cangeCadNumber);

				if (epm2dLink.getDepType() != -1) {
					if (VERBOSE)
						System.out.println("[CHECK OK] CHANGE 2D <-----------------------");
					this.change2DEPMdocument(epm, epm2d, originalEpmNumber, originalDocType, basicAttr, wtcontext);
				}

				PersistenceServerHelper.manager.update(epm2dLink);
				if (VERBOSE)
					System.out.println("EPM2DLink Update:" + i);
			}
		}

		return epm;
		// ##end changeEPMdocument%46A48F1B005D.body
	}

	// ##begin copyCADBom%46A42C9E03CC.doc preserve=no
	/**
	 * @param parent
	 * @param link
	 *            true = part, false = assembly
	 * @param doc
	 * @param location
	 * @param levelindex
	 *            true = upload, false = connect
	 * @param history
	 *            true = upload, false = connect
	 * @return Hashtable
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyCADBom%46A42C9E03CC.doc
	public Hashtable copyCADBom(EPMDocument parent, EPMMemberLink link, EPMDocument doc, String location, int levelindex, Hashtable history)
			throws WTException, WTPropertyVetoException, PropertyVetoException, RemoteException {
		// ##begin copyCADBom%46A42C9E03CC.body preserve=yes
		/***********************************************************************
		 * The variable of history is just used for 2D CAD Reference copy. The
		 * key of Hashtable is before number code, and Object is after number
		 * code.
		 **********************************************************************/

		/***********************************************************************
		 * history has two parameters: "3D", "2D"
		 **********************************************************************/

		EPMDocument childdoc = null;
		boolean recursive = false;

		if (history == null)
			history = new Hashtable();
		Hashtable epm3dHash = (Hashtable) history.get("3D");
		if (epm3dHash == null)
			epm3dHash = new Hashtable();

		if (doc.getNumber().substring(0, 1).equals("1") || doc.getNumber().substring(0, 1).equals("3")) {
			if (doc.getNumber().substring(4, 5).equals("-")) {
				if (epm3dHash.get(doc.getNumber()) == null)
					recursive = true;
				else
					recursive = false;

				childdoc = this.copyEPMDocument(doc, location, history);

			}
		}

		if (link != null && parent != null && childdoc != null)
			PSKCADHelper.service.copyMemberLink(parent, link, childdoc);
		else if (link != null && parent != null && childdoc == null)
			PSKCADHelper.service.copyMemberLink(parent, link, doc);

		if (recursive) {
			LatestConfigSpec spec = new LatestConfigSpec();
			QueryResult result = EPMStructureHelper.service.navigateUsesToIteration(doc, null, false, spec);
			if (result.size() > 0) {
				while (result.hasMoreElements()) {
					Persistable persist[] = (Persistable[]) result.nextElement();
					EPMMemberLink memberLink = (EPMMemberLink) persist[0];
					EPMDocument document = (EPMDocument) persist[1];

					if (document.isLatestIteration()) {
						this.copyCADBom(childdoc, memberLink, document, location, levelindex + 1, history);
					}
				}
			}
		}
		return history;
		// ##end copyCADBom%46A42C9E03CC.body
	}

	// ##begin copyEPMDocument%46A433E401B5.doc preserve=no
	/**
	 * @param org
	 * @param location
	 * @param history
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyEPMDocument%46A433E401B5.doc
	public EPMDocument copyEPMDocument(EPMDocument org, String location, Hashtable history) throws WTException, WTPropertyVetoException,
			PropertyVetoException, RemoteException {
		// ##begin copyEPMDocument%46A433E401B5.body preserve=yes
		return copyEPMDocument(org, location, history, null);
		// ##end copyEPMDocument%46A433E401B5.body
	}

	// ##begin copyEPMDocument%4727D8D20138.doc preserve=no
	/**
	 * @param org
	 * @param location
	 * @param history
	 * @param ref
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.beans.PropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyEPMDocument%4727D8D20138.doc
	public EPMDocument copyEPMDocument(EPMDocument org, String location, Hashtable history, WTContainerRef ref) throws WTException,
			WTPropertyVetoException, PropertyVetoException, RemoteException {
		// ##begin copyEPMDocument%4727D8D20138.body preserve=yes
		if (history == null)
			history = new Hashtable();
		if (org == null)
			throw new WTException("Orginal EPMDocument is NULL!");
		if (VERBOSE)
			System.out.println("[ORG CAD NUMNBER]=======>" + org.getNumber());
		if (location == null || location.length() <= 0) {
			location = org.getLocation();
		}

		// WTContainerRef ref = org.getContainerReference();
		if (ref == null) {
			ref = org.getContainerReference();
			if (VERBOSE)
				System.out.println("[NEW ref]=======>" + ref);
		} else {
			if (VERBOSE)
				System.out.println("[INPUT ref]=======>" + ref);
		}
		LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(DEFAULT_EPM_LIFECYCLE, ref);
		System.out.println("  LOCATION:" + location + "##");
		Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(location, ref);

		if (template == null)
			throw new WTException("Lifecycle Template can not find on wtconainer!! [DEFAULT_EPM_LIFECYCLE]=" + DEFAULT_EPM_LIFECYCLE);
		if (checkOutFolder == null)
			throw new WTException("Folder can not find on wtconainer!! [location]=" + location);

		Hashtable epm3dHash = (Hashtable) history.get("3D");
		Hashtable epm2dHash = (Hashtable) history.get("2D");

		if (epm3dHash == null)
			epm3dHash = new Hashtable();

		EPMDocument doc = null;

		doc = (EPMDocument) epm3dHash.get(org.getNumber());

		if (doc == null) {
			if (VERBOSE)
				System.out.println("[ORG NOT CREATED]");

			String changedNumber = "";

			String tmpNumber = (String) history.get("PartNumber");
			if (tmpNumber == null)
				tmpNumber = "";
			if (tmpNumber.length() != 12) {
				String futureVersion = getFutureVersion(org);
				changedNumber = org.getNumber().substring(0, 10) + futureVersion;
			} else
				changedNumber = tmpNumber;

			EPMAuthoringAppType atype = EPMAuthoringAppType.toEPMAuthoringAppType("PROE");
			doc = EPMDocument.newEPMDocument();

			doc.setNumber(changedNumber);
			doc.setName(org.getName());

			if (org.getDocType().getStringValue().substring(org.getDocType().getStringValue().lastIndexOf(".") + 1).equals("CADASSEMBLY"))
				doc.setCADName((changedNumber + ".asm").toLowerCase());
			else
				doc.setCADName((changedNumber + ".prt").toLowerCase());
			((EPMDocumentMaster) doc.getMaster()).setAuthoringApplication(EPMAuthoringAppType.toEPMAuthoringAppType("PROE"));
			((EPMDocumentMaster) doc.getMaster()).setDocType(org.getDocType());
			((EPMDocumentMaster) doc.getMaster()).setOwnerApplication(EPMApplicationType.toEPMApplicationType("EPM"));

			doc = (EPMDocument) LifeCycleHelper.setLifeCycle(doc, template);
			FolderHelper.assignLocation(doc, checkOutFolder);

			doc = (EPMDocument) PersistenceHelper.manager.save(doc);

			ContentHelper.service.copyContent(org, doc);

			// IBA COPY
			this.copyIBAValue(org, doc);

			epm3dHash.put(org.getNumber(), doc);
			history.put("3D", epm3dHash);
		}

		if (VERBOSE) {
			if (epm2dHash == null)
				System.out.println("[2D HASH IS NULL]********");
		}

		// 2D Copy
		if (epm2dHash != null) {
			Vector epm2dLinkVector = this.getRelational2DCadLink(org);
			EPMReferenceLink epm2dLink = null;
			EPMDocument epm2d = null;
			EPMDocument orgEpm2d = null;
			String checkCode = null;
			if (epm2dLinkVector != null) {
				for (int i = 0; i < epm2dLinkVector.size(); i++) {
					epm2dLink = (EPMReferenceLink) epm2dLinkVector.get(i);
					orgEpm2d = epm2dLink.getReferencedBy();

					if (VERBOSE)
						System.out.println("[GET<===]" + orgEpm2d.getNumber());
					checkCode = (String) epm2dHash.get(orgEpm2d.getNumber());
					if (VERBOSE)
						System.out.println("[FOUND<===]" + checkCode);
					if (checkCode == null) {
						epm2d = this.copy2DEPMDocument(epm2dLink, doc, location, ref);
						if (VERBOSE)
							System.out.println("[PUT===>]" + orgEpm2d.getNumber() + "|" + epm2d.getNumber());
						epm2dHash.put(orgEpm2d.getNumber(), epm2d.getNumber());
					} else {
						QuerySpec spec = new QuerySpec(EPMDocument.class);
						spec.appendWhere(new SearchCondition(EPMDocument.class, "master>number", SearchCondition.EQUAL, checkCode));
						LatestConfigSpec lSpec = new LatestConfigSpec();
						spec = lSpec.appendSearchCriteria(spec);

						QueryResult result = PersistenceHelper.manager.find(spec);
						epm2d = (EPMDocument) result.nextElement();
						epm2d = (EPMDocument) PersistenceHelper.manager.refresh(epm2d);
					}

					EPMReferenceLink copiedLink = EPMReferenceLink.newEPMReferenceLink(epm2d, (EPMDocumentMaster) doc.getMaster());
					copiedLink.setAsStoredChildName(epm2dLink.getAsStoredChildName());
					copiedLink.setDepType(epm2dLink.getDepType());
					copiedLink.setRequired(epm2dLink.isRequired());
					copiedLink.setUniqueLinkID(epm2dLink.getUniqueLinkID());
					copiedLink.setUniqueNDId(epm2dLink.getUniqueNDId());
					copiedLink.setTypeDefinitionReference(epm2dLink.getTypeDefinitionReference());

					PersistenceServerHelper.manager.insert(copiedLink);
					;
				}
			}
			history.put("2D", epm2dHash);
		} else {
			epm2dHash = new Hashtable();
			Vector epm2dLinkVector = this.getRelational2DCadLink(org);
			EPMReferenceLink epm2dLink = null;
			EPMDocument epm2d = null;
			EPMDocument orgEpm2d = null;
			String checkCode = null;
			if (epm2dLinkVector != null) {
				for (int i = 0; i < epm2dLinkVector.size(); i++) {
					epm2dLink = (EPMReferenceLink) epm2dLinkVector.get(i);
					orgEpm2d = epm2dLink.getReferencedBy();
					if (orgEpm2d.getNumber().equals(org.getNumber() + "[2D]")) {
						epm2d = this.copy2DEPMDocument(epm2dLink, doc, location, ref);

						if (VERBOSE)
							System.out.println("[PUT===>]" + orgEpm2d.getNumber() + "|" + epm2d.getNumber());
						epm2dHash.put(orgEpm2d.getNumber(), epm2d.getNumber());

						EPMReferenceLink copiedLink = EPMReferenceLink.newEPMReferenceLink(epm2d, (EPMDocumentMaster) doc.getMaster());
						copiedLink.setAsStoredChildName(epm2dLink.getAsStoredChildName());
						copiedLink.setDepType(epm2dLink.getDepType());
						copiedLink.setRequired(epm2dLink.isRequired());
						copiedLink.setUniqueLinkID(epm2dLink.getUniqueLinkID());
						copiedLink.setUniqueNDId(epm2dLink.getUniqueNDId());
						copiedLink.setTypeDefinitionReference(epm2dLink.getTypeDefinitionReference());

						PersistenceServerHelper.manager.insert(copiedLink);

						break;
					}
				}
			}
			history.put("2D", epm2dHash);
		}
		// }
		return doc;
		// ##end copyEPMDocument%4727D8D20138.body
	}

	// ##begin getRelationalPart%46A483A7002Eg.doc preserve=no
	/**
	 * @param epmOid
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	// ##end getRelationalPart%46A483A7002Eg.doc
	public WTPart getRelationalPart(String epmOid) throws WTException {
		// ##begin getRelationalPart%46A483A7002Eg.body preserve=yes

		return this.getRelationalPart((EPMDocument) this.getReferenceObject(epmOid));
		// ##end getRelationalPart%46A483A7002Eg.body
	}

	// ##begin getRelationalPart%46A4835403D8g.doc preserve=no
	/**
	 * @param epm
	 * @return WTPart
	 * @exception wt.util.WTException
	 */
	// ##end getRelationalPart%46A4835403D8g.doc
	public WTPart getRelationalPart(EPMDocument epm) throws WTException {
		// ##begin getRelationalPart%46A4835403D8g.body preserve=yes
		WTPart part = null;
		if (epm != null && epm instanceof EPMDocument) {
			String epmNumber = epm.getNumber();
			QuerySpec spec = new QuerySpec(WTPart.class);
			spec.appendWhere(new SearchCondition(WTPart.class, "master>number", SearchCondition.EQUAL, epmNumber));
			LatestConfigSpec latestCSpec = new LatestConfigSpec();
			spec = latestCSpec.appendSearchCriteria(spec);

			QueryResult result = PersistenceHelper.manager.find(spec);

			if (VERBOSE)
				System.out.println("[RELATIONAL PART SIZE]=" + result.size());
			if (result != null && result.size() > 0) {
				Hashtable resultHash = new Hashtable();
				WTPart one = null;
				while (result.hasMoreElements()) {
					one = (WTPart) result.nextElement();
					resultHash.put(VersionControlHelper.getVersionIdentifier(one).getValue(), one);
				}

				// Get Latest
				String hashKey = this.getLatestVersion(resultHash);
				part = (WTPart) resultHash.get(hashKey);
				if (VERBOSE)
					System.out.println("[RELATIONAL LATEST]=" + part.getNumber() + "|" + VersionControlHelper.getVersionIdentifier(part).getValue()
							+ "." + VersionControlHelper.getIterationIdentifier(part).getValue());
			}

		}
		return part;
		// ##end getRelationalPart%46A4835403D8g.body
	}

	// ##begin getRelational3DCad%46A483D701B5g.doc preserve=no
	/**
	 * @param partOid
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46A483D701B5g.doc
	public EPMDocument getRelational3DCad(String partOid) throws WTException {
		// ##begin getRelational3DCad%46A483D701B5g.body preserve=yes

		return this.getRelational3DCad((WTPart) this.getReferenceObject(partOid));
		// ##end getRelational3DCad%46A483D701B5g.body
	}

	// ##begin getRelational3DCad%46A483E6035Bg.doc preserve=no
	/**
	 * @param epm
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46A483E6035Bg.doc
	public EPMDocument getRelational3DCad(EPMDocument epm) throws WTException {
		// ##begin getRelational3DCad%46A483E6035Bg.body preserve=yes
		EPMDocument epm3d = null;
		if (epm != null && epm instanceof EPMDocument) {
			if (this.checkDrawing(epm)) {
				QueryResult result = EPMStructureHelper.service.navigateReferences(epm, null);
				if (result != null && result.size() > 0) {
					Hashtable resultHash = new Hashtable();
					EPMDocument one = null;
					while (result.hasMoreElements()) {
						one = (EPMDocument) result.nextElement();
						resultHash.put(VersionControlHelper.getVersionIdentifier(one).getValue(), one);
					}

					// Get Latest
					String hashKey = this.getLatestVersion(resultHash);
					epm3d = (EPMDocument) resultHash.get(hashKey);
				}
			} else
				epm3d = epm;
		}
		return epm3d;
		// ##end getRelational3DCad%46A483E6035Bg.body
	}

	// ##begin getRelational3DCad%46AEB18B0157g.doc preserve=no
	/**
	 * @param part
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getRelational3DCad%46AEB18B0157g.doc
	public EPMDocument getRelational3DCad(WTPart part) throws WTException {
		// ##begin getRelational3DCad%46AEB18B0157g.body preserve=yes
		EPMDocument epm = null;
		if (part != null && (part instanceof WTPart)) {
			String partNumber = part.getNumber();
			QuerySpec spec = new QuerySpec(EPMDocument.class);
			spec.appendWhere(new SearchCondition(EPMDocument.class, "master>number", SearchCondition.EQUAL, partNumber));
			LatestConfigSpec latestCSpec = new LatestConfigSpec();
			spec = latestCSpec.appendSearchCriteria(spec);
			QueryResult result = PersistenceHelper.manager.find(spec);
			if (result != null && result.size() > 0) {
				Hashtable resultHash = new Hashtable();
				EPMDocument one = null;
				while (result.hasMoreElements()) {
					one = (EPMDocument) result.nextElement();
					resultHash.put(VersionControlHelper.getVersionIdentifier(one).getValue(), one);

					String hashKey = this.getLatestVersion(resultHash);
					epm = (EPMDocument) resultHash.get(hashKey);
				}
			}
		}
		return epm;
		// ##end getRelational3DCad%46AEB18B0157g.body
	}

	// ##begin getRelational2DCad%46A57BEE0271g.doc preserve=no
	/**
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57BEE0271g.doc
	public Vector getRelational2DCad(EPMDocument epm) throws WTException {
		// ##begin getRelational2DCad%46A57BEE0271g.body preserve=yes
		Vector epm2dVector = null;
		EPMDocument epm2d = null;
		if (epm != null && epm instanceof EPMDocument) {
			if (!this.checkDrawing(epm)) {
				QueryResult result = EPMStructureHelper.service.navigateReferencedBy((DocumentMaster) epm.getMaster(), null);
				if (result != null && result.size() > 0) {
					Hashtable bodyHash = new Hashtable();
					Hashtable aHash = null;
					EPMDocument one = null;
					while (result.hasMoreElements()) {
						one = (EPMDocument) result.nextElement();
						aHash = (Hashtable) bodyHash.get(one.getNumber());

						if (aHash == null || aHash.size() == 0) {
							aHash = new Hashtable();
							aHash.put(
									VersionControlHelper.getVersionIdentifier(one).getValue() + "."
											+ VersionControlHelper.getIterationIdentifier(one).getValue(), one);
						} else
							aHash.put(
									VersionControlHelper.getVersionIdentifier(one).getValue() + "."
											+ VersionControlHelper.getIterationIdentifier(one).getValue(), one);

						bodyHash.put(one.getNumber(), aHash);
					}

					// Get Latest
					if (bodyHash != null && bodyHash.size() > 0) {
						epm2dVector = new Vector();
						Enumeration aEnum = bodyHash.elements();
						while (aEnum.hasMoreElements()) {
							aHash = (Hashtable) aEnum.nextElement();

							if (VERBOSE) {
								if (VERBOSE)
									System.out.println("*****************************8");
								Enumeration e = aHash.keys();
								while (e.hasMoreElements()) {
									String k = (String) e.nextElement();
									EPMDocument docu = (EPMDocument) aHash.get(k);
									if (VERBOSE)
										System.out.println("{VERBOSE}[KEY]=" + k);
									if (VERBOSE)
										System.out.println("[{VERBOSE}ALL byKey]=" + VersionControlHelper.getVersionIdentifier(docu).getValue() + "."
												+ VersionControlHelper.getIterationIdentifier(docu).getValue());
									if (docu.isLatestIteration())
										epm2d = docu;
								}
								if (VERBOSE)
									System.out.println("*****************************8");
							}
							epm2dVector.add(epm2d);
							// if (VERBOSE)
							// System.out.println("{VERBOSE}[2D VERSION]="
							// + VersionControlHelper
							// .getVersionIdentifier(epm2d)
							// .getValue()
							// + "."
							// + VersionControlHelper
							// .getIterationIdentifier(epm2d)
							// .getValue());
						}
					}
				}
			}
			/*
			 * else { epm2dVector.add(epm); }
			 */
		}
		return epm2dVector;
		// ##end getRelational2DCad%46A57BEE0271g.body
	}

	// ##begin getRelational2DCad%46A57BED00BBg.doc preserve=no
	/**
	 * @param part
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57BED00BBg.doc
	public Vector getRelational2DCad(WTPart part) throws WTException {
		// ##begin getRelational2DCad%46A57BED00BBg.body preserve=yes
		Vector epm2d = null;
		if (part != null) {
			epm2d = this.getRelational2DCad(this.getRelational3DCad(part));
		}
		return epm2d;
		// ##end getRelational2DCad%46A57BED00BBg.body
	}

	// ##begin getRelational2DCad%46A57C230128g.doc preserve=no
	/**
	 * @param object
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCad%46A57C230128g.doc
	public Vector getRelational2DCad(String object) throws WTException {
		// ##begin getRelational2DCad%46A57C230128g.body preserve=yes
		Vector epm2d = null;
		if (object != null && object.length() > 0) {
			WTObject refer = this.getReferenceObject(object);
			if (refer instanceof WTPart)
				epm2d = (Vector) this.getRelational2DCad((WTPart) refer);
			else
				epm2d = (Vector) this.getRelational2DCad((EPMDocument) refer);
		}
		return epm2d;
		// ##end getRelational2DCad%46A57C230128g.body
	}

	// ##begin checkDrawing%46A57C6B02BF.doc preserve=no
	/**
	 * @param epm
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end checkDrawing%46A57C6B02BF.doc
	public boolean checkDrawing(EPMDocument epm) throws WTException {
		// ##begin checkDrawing%46A57C6B02BF.body preserve=yes
		if (epm.getDocType().getStringValue().substring(epm.getDocType().getStringValue().lastIndexOf(".") + 1).equals("CADDRAWING"))
			return true;
		else
			return false;
		// ##end checkDrawing%46A57C6B02BF.body
	}

	// ##begin checkDrawing%46A57C8B008C.doc preserve=no
	/**
	 * @param epmOid
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end checkDrawing%46A57C8B008C.doc
	public boolean checkDrawing(String epmOid) throws WTException {
		// ##begin checkDrawing%46A57C8B008C.body preserve=yes

		return this.checkDrawing((EPMDocument) this.getReferenceObject(epmOid));
		// ##end checkDrawing%46A57C8B008C.body
	}

	// ##begin syncDrawingState%46A57F870242.doc preserve=no
	/**
	 * @param epm
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46A57F870242.doc
	public void syncDrawingState(String epm) throws WTException {
		// ##begin syncDrawingState%46A57F870242.body preserve=yes
		WTObject object = this.getReferenceObject(epm);
		if (object instanceof EPMDocument)
			syncDrawingState((EPMDocument) this.getReferenceObject(epm));
		else if (object instanceof WTPart)
			syncDrawingState((WTPart) this.getReferenceObject(epm));
		// ##end syncDrawingState%46A57F870242.body
	}

	// ##begin syncDrawingState%46A57FAB009C.doc preserve=no
	/**
	 * @param epm
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46A57FAB009C.doc
	public void syncDrawingState(EPMDocument epm) throws WTException {
		// ##begin syncDrawingState%46A57FAB009C.body preserve=yes
		// ******************************************************
		// Migration State
		// true - Migration
		// false - No Migration
		// ******************************************************

		if (!MIGRATION_STATE) {
			if (epm != null && !this.checkDrawing(epm)) {
				if (epm.getNumber().substring(0, 1).equals("5") && epm.getNumber().substring(4, 5).equals("-") && epm.getNumber().length() == 12) {
					this.subPartStateChange(epm, State.toState(epm.getState().toString()), null);
				}
			}
		}

		// EPMDocument sync3dEpm = null;
		// Vector sync2dVector = null;
		// EPMDocument sync2dEpm = null;
		//
		// if( !MIGRATION_STATE )
		// {
		// if( epm != null )
		// {
		// System.out.println("** syncDrawingState Start **");
		// if( !this.checkDrawing(epm) )
		// {
		// /* 3D�� ��õ� 2D�� �ְ� 3D�� ��õ� ��ǰ�� ��� ��� 2D�� State�� 3D��
		// State�� �����Ѵ�. */
		// sync3dEpm = epm;
		// sync2dVector = this.getRelational2DCad(epm);
		// if( sync3dEpm != null && sync2dVector != null )
		// {
		// for(int i=0; i < sync2dVector.size(); i++)
		// {
		// sync2dEpm = (EPMDocument)sync2dVector.get(i);
		//
		// if( sync2dEpm.getNumber().equals(sync3dEpm.getNumber()+"[2D]") )
		// {
		// String sync3dState = sync3dEpm.getState().toString();
		// String sync2dState = sync2dEpm.getState().toString();
		// WTPart part = this.getRelationalPart(sync3dEpm);
		//
		// if( part == null ) {
		// if( !sync3dState.equals(sync2dState) ) {
		// sync2dEpm = (EPMDocument)changeState(sync2dEpm,
		// State.toState(sync3dState));
		// }
		// }
		// break;
		// }
		// }
		// }
		//
		// }
		// else // 2D Drawing
		// {
		// String sync2dState = epm.getState().toString();
		// if( sync2dState.equals("PSK_DRAFT") )
		// {
		// if(VERBOSE) System.out.println("[INPUT 2D
		// DRAWING]:"+epm.getIdentity());
		//
		// QuerySpec spec = new QuerySpec(EPMDocument.class);
		// LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
		// spec = latestConfigSpec.appendSearchCriteria(spec);
		// QueryResult result1 =
		// EPMStructureHelper.service.navigateReferencesToIteration(epm, null,
		// false, latestConfigSpec);
		//
		// String oneReferNumber = null;
		// EPMDocument doc3d = null;
		// EPMReferenceLink referLink = null;
		// while( result1.hasMoreElements() ) {
		// Object[] object = (Object[])result1.nextElement();
		// referLink = (EPMReferenceLink)object[0];
		// if( referLink.getDepType() == 4 ) {
		// if (object[1] instanceof EPMDocument) {
		// doc3d = (EPMDocument)object[1];
		// oneReferNumber = doc3d.getNumber();
		// }
		// else if (object[1] instanceof EPMDocumentMaster) {
		// EPMDocumentMaster docmaster = (EPMDocumentMaster)object[1];
		// oneReferNumber = docmaster.getNumber();
		// spec = new QuerySpec(EPMDocument.class);
		// SearchCondition cond = new SearchCondition(EPMDocument.class,
		// "master>number", SearchCondition.EQUAL, oneReferNumber);
		// spec.appendWhere(cond);
		// latestConfigSpec = new LatestConfigSpec();
		// spec = latestConfigSpec.appendSearchCriteria(spec);
		// QueryResult result = PersistenceHelper.manager.find(spec);
		// if( result != null && result.size() > 0 ) {
		// doc3d = (EPMDocument)result.nextElement();
		// }
		// }
		// break;
		// }
		// }
		//
		//
		// if (doc3d != null) {
		//
		// if(VERBOSE) System.out.println("[RESULT 3D
		// DRAWING]:"+doc3d.getIdentity());
		//
		// String sync3dState = doc3d.getState().toString();
		// // Number Check
		// if( !sync3dState.equals("PSK_DRAFT"))
		// {
		// if( !epm.getNumber().equals(oneReferNumber+"[2D]") )
		// {
		// EPMDocumentHelper.service.changeCADName((EPMDocumentMaster)epm.getMaster(),
		// (oneReferNumber+".drw").toLowerCase());
		// epm = (EPMDocument)PersistenceHelper.manager.refresh(epm);
		//
		// EPMDocumentMaster epmMaster = (EPMDocumentMaster)(epm.getMaster());
		//
		// EPMDocumentMasterIdentity identity =
		// (EPMDocumentMasterIdentity)epmMaster.getIdentificationObject();
		// try
		// {
		// identity.setNumber(oneReferNumber + "[2D]");
		// identity.setName(doc3d.getName());
		// }
		// catch( WTPropertyVetoException wve)
		// {
		// throw new WTException(wve);
		// }
		// epmMaster =
		// (EPMDocumentMaster)IdentityHelper.service.changeIdentity(epmMaster,
		// identity);
		// }
		//
		// /* Waiting until checkout EPM has been checkin */
		// while( WorkInProgressHelper.isCheckedOut(epm) )
		// {
		// try {
		// Thread.sleep(10000);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		//
		// // Change State
		// if( !sync3dState.equals(sync2dState) )
		// {
		// epm = (EPMDocument)changeState(epm, State.toState(sync3dState));
		// }
		//
		// // Change Location
		// FolderHelper.service.changeFolder(epm,
		// FolderHelper.service.getFolder(doc3d));
		// }
		// }
		// }
		// }
		// System.out.println("** syncDrawingState End **");
		// }
		// }
		// ##end syncDrawingState%46A57FAB009C.body
	}

	// ##begin syncDrawingState%46AEB33A031C.doc preserve=no
	/**
	 * @param part
	 * @exception wt.util.WTException
	 */
	// ##end syncDrawingState%46AEB33A031C.doc
	public void syncDrawingState(WTPart part) throws WTException {
		// ##begin syncDrawingState%46AEB33A031C.body preserve=yes
		// ******************************************************
		// Migration State
		// true - Migration
		// false - No Migration
		// ******************************************************
		if (!MIGRATION_STATE) {
			if (part != null) {
				EPMDocument sync3dEpm = getRelational3DCad(part);
				Vector sync2dEpmVector = getRelational2DCad(part);
				;
				EPMDocument sync2dEpm = null;
				if (sync3dEpm != null) {
					System.out.println("## Sync State from Part to EPM Start (" + part.getIdentity() + ") ##");

					sync3dEpm = changeState(sync3dEpm, State.toState(part.getState().toString()));
					System.out.println(" - 3D Changed : " + sync3dEpm.getIdentity());
					// if( sync3dEpm.getNumber().substring(0,1).equals("5") &&
					// sync3dEpm.getNumber().substring(4,5).equals("-") &&
					// sync3dEpm.getNumber().length() == 12 ) {
					// this.subPartStateChange(sync3dEpm,
					// State.toState(part.getState().toString()), null);
					// }
					sync3dEpm = (EPMDocument) PersistenceHelper.manager.refresh(sync3dEpm);
					if (sync2dEpmVector != null) {
						for (int i = 0; i < sync2dEpmVector.size(); i++) {
							sync2dEpm = (EPMDocument) sync2dEpmVector.get(i);
							if (sync2dEpm.getNumber().equals(sync3dEpm.getNumber() + "[2D]")
									&& !sync3dEpm.getState().toString().equals(sync2dEpm.getState().toString())) {
								sync2dEpm = changeState(sync2dEpm, State.toState(part.getState().toString()));
								System.out.println(" - 2D Changed : " + sync3dEpm.getIdentity());
								sync2dEpm = (EPMDocument) PersistenceHelper.manager.refresh(sync2dEpm);
								break;
							}
						}
					}

					System.out.println("## Sync State from Part to EPM End ##");
				}
			}
		}
		// ##end syncDrawingState%46AEB33A031C.body
	}

	// ##begin enforcedUpdate%46AEB29301F4.doc preserve=no
	/**
	 * @param persist
	 * @return Persistable
	 * @exception wt.util.WTException
	 */
	// ##end enforcedUpdate%46AEB29301F4.doc
	public Persistable enforcedUpdate(Persistable persist) throws WTException {
		// ##begin enforcedUpdate%46AEB29301F4.body preserve=yes
		if (VERBOSE)
			System.out.println("ENFORECE UPDATE");
		PersistenceServerHelper.manager.insert(persist);
		return persist;
		// ##end enforcedUpdate%46AEB29301F4.body
	}

	// ##begin copyIBAValue%46B035F300CB.doc preserve=no
	/**
	 * @param org
	 * @param target
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 * @exception java.rmi.RemoteException
	 */
	// ##end copyIBAValue%46B035F300CB.doc
	public boolean copyIBAValue(IBAHolder org, IBAHolder target) throws WTException, WTPropertyVetoException, RemoteException {
		// ##begin copyIBAValue%46B035F300CB.body preserve=yes
		WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
		boolean returnBoolean = true;
		try {
			Hashtable orgHash = this.getIBAList(org);

			if (orgHash != null && orgHash.size() > 0) {
				// SessionHelper.manager.getAdministrator();
				/*
				 * if( !WorkInProgressHelper.isWorkingCopy((Workable)target) ) {
				 * Folder checkoutFolder =
				 * WorkInProgressHelper.service.getCheckoutFolder();
				 * CheckoutLink checklink =
				 * WorkInProgressHelper.service.checkout((Workable)target,
				 * checkoutFolder, null); target = (IBAHolder)
				 * checklink.getWorkingCopy(); }
				 */

				HashMap defMap = new HashMap();
				QuerySpec spec = new QuerySpec(StringDefinition.class);
				spec.appendWhere(new SearchCondition(StringDefinition.class, "name", SearchCondition.LIKE, "%"));
				QueryResult result = PersistenceHelper.manager.find(spec);
				while (result.hasMoreElements()) {
					StringDefinition def = (StringDefinition) result.nextElement();
					defMap.put(def.getName(), def);
				}

				Persistable persist = (Persistable) target;
				Hashtable defHb = new Hashtable();
				Hashtable valHb = new Hashtable();
				spec = new QuerySpec(StringValue.class);
				spec.appendWhere(new SearchCondition(StringValue.class, "theIBAHolderReference.key.id", SearchCondition.EQUAL, persist
						.getPersistInfo().getObjectIdentifier().getId()));
				result = PersistenceHelper.manager.find(spec);
				while (result.hasMoreElements()) {
					StringValue sval = (StringValue) result.nextElement();
					String keyid = sval.getDefinitionReference().toString();
					ReferenceFactory rf = new ReferenceFactory();
					StringDefinition def = (StringDefinition) rf.getReference(keyid).getObject();
					defHb.put(def.getName(), def);
					valHb.put(def.getName(), sval);
				}

				// target =
				// IBAValueHelper.service.refreshAttributeContainer(target,
				// null, null, null);
				// DefaultAttributeContainer defaultattributecontainer =
				// (DefaultAttributeContainer)target.getAttributeContainer();

				// StandardIBADefinitionService standardibadefinitionservice =
				// new StandardIBADefinitionService();

				Enumeration enumeration = orgHash.keys();
				while (enumeration.hasMoreElements()) {
					String attributeName = (String) enumeration.nextElement();
					String attributeValue = (String) orgHash.get(attributeName);
					if (!attributeName.equals("MASS")) {
						addIBAValue(defHb, defMap, valHb, target, attributeName, attributeValue);
					}
				}
				/*
				 * �Ʒ��� ��x ������ �����͸� ����Ʈ ���� ���� '�� ����
				 * ������(2007.11.29, KYKIM)
				 */
				/*
				 * if( VERBOSE ) System.out.println("AttributeName = " +
				 * attributeName); if( VERBOSE )
				 * System.out.println("attributeValue = " + attributeValue);
				 * AttributeDefDefaultView attributedefdefaultview =
				 * standardibadefinitionservice
				 * .getAttributeDefDefaultViewByPath(attributeName);
				 * AbstractValueView aabstractvalueview[] =
				 * defaultattributecontainer
				 * .getAttributeValues(attributedefdefaultview);
				 * if(aabstractvalueview.length < 1) {
				 * 
				 * if( VERBOSE ) System.out.println("Attribute didn't exist on
				 * part");
				 * 
				 * if( attributeName.equals("MASS") ) { FloatValueDefaultView
				 * obj2 = new
				 * FloatValueDefaultView((FloatDefView)attributedefdefaultview,
				 * new Double(attributeValue).doubleValue(), 0);
				 * defaultattributecontainer
				 * .addAttributeValue(((AbstractValueView) (obj2))); } else {
				 * StringValueDefaultView obj2 = new
				 * StringValueDefaultView((StringDefView
				 * )attributedefdefaultview, attributeValue);
				 * defaultattributecontainer
				 * .addAttributeValue(((AbstractValueView) (obj2))); } } else {
				 * if( VERBOSE ) System.out.println("Attribute already exist on
				 * part ... updating");
				 * ((StringValueDefaultView)aabstractvalueview
				 * [0]).setValue(attributeValue);
				 * defaultattributecontainer.updateAttributeValue
				 * (aabstractvalueview[0]); } }
				 * defaultattributecontainer.setConstraintParameter
				 * (defaultattributecontainer);
				 * target.setAttributeContainer(defaultattributecontainer);
				 * 
				 * PersistenceServerHelper.manager.update((Persistable)target);
				 */

				/* WorkInProgressHelper.service.checkin((Workable)target, ""); */
				// SessionHelper.manager.setPrincipal(orgPrincipal.getName());

				// if (tdata.szItemModel != null &&
				// !tdata.szItemModel.trim().equals("") &&
				// !tdata.szItemModel.trim().toUpperCase().equals("NULL")) {
				// addIBAValue(defHb, defMap, valHb, (IBAHolder)part, "MODEL",
				// tdata.szItemModel.trim());
				// }
				// if (tdata.szItemSpec != null &&
				// !tdata.szItemSpec.trim().equals("") &&
				// !tdata.szItemSpec.trim().toUpperCase().equals("NULL")) {
				// addIBAValue(defHb, defMap, valHb, (IBAHolder)part,
				// "PART_SPEC", tdata.szItemSpec.trim());
				// }
				// if (tdata.szItemUnit != null &&
				// !tdata.szItemUnit.trim().equals("") &&
				// !tdata.szItemUnit.trim().toUpperCase().equals("NULL")) {
				// addIBAValue(defHb, defMap, valHb, (IBAHolder)part,
				// "MATERIAL", tdata.szItemUnit.trim());
				// }
				// if (tdata.szMaker != null && !tdata.szMaker.trim().equals("")
				// && !tdata.szMaker.trim().toUpperCase().equals("NULL")) {
				// addIBAValue(defHb, defMap, valHb, (IBAHolder)part,
				// "MAKER_PROCESS", tdata.szMaker.trim());
				// }
			} else {
				if (org instanceof EPMDocument) {
					if (((EPMDocument) org).getFamilyTableStatus() == 1 || ((EPMDocument) org).getFamilyTableStatus() == 2) {
						Map map = ((EPMDocument) org).getParameterValues();
						if (map != null) {
							HashMap defMap = new HashMap();
							QuerySpec spec = new QuerySpec(StringDefinition.class);
							spec.appendWhere(new SearchCondition(StringDefinition.class, "name", SearchCondition.LIKE, "%"));
							QueryResult result = PersistenceHelper.manager.find(spec);
							while (result.hasMoreElements()) {
								StringDefinition def = (StringDefinition) result.nextElement();
								defMap.put(def.getName(), def);
							}

							Persistable persist = (Persistable) target;
							Hashtable defHb = new Hashtable();
							Hashtable valHb = new Hashtable();
							spec = new QuerySpec(StringValue.class);
							spec.appendWhere(new SearchCondition(StringValue.class, "theIBAHolderReference.key.id", SearchCondition.EQUAL, persist
									.getPersistInfo().getObjectIdentifier().getId()));
							result = PersistenceHelper.manager.find(spec);
							while (result.hasMoreElements()) {
								StringValue sval = (StringValue) result.nextElement();
								String keyid = sval.getDefinitionReference().toString();
								ReferenceFactory rf = new ReferenceFactory();
								StringDefinition def = (StringDefinition) rf.getReference(keyid).getObject();
								defHb.put(def.getName(), def);
								valHb.put(def.getName(), sval);
							}

							if (map.get("PART_SPEC") != null) {
								String strSpec = (String) ((EPMParameterValue) (map.get("PART_SPEC"))).getValue();
								addIBAValue(defHb, defMap, valHb, target, "PART_SPEC", strSpec);
							}
							if (map.get("MAKER_MATERIAL") != null) {
								String strProcess = (String) ((EPMParameterValue) (map.get("MAKER_MATERIAL"))).getValue();
								addIBAValue(defHb, defMap, valHb, target, "MAKER_MATERIAL", strProcess);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			e.printStackTrace();
			throw new WTException(e.getLocalizedMessage());
		} finally {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
		}
		return returnBoolean;
		// ##end copyIBAValue%46B035F300CB.body
	}

	// ##begin isExistCad%46B042700196.doc preserve=no
	/**
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end isExistCad%46B042700196.doc
	public boolean isExistCad(String part) throws WTException {
		// ##begin isExistCad%46B042700196.body preserve=yes

		return this.isExistCad((WTPart) this.getReferenceObject(part));
		// ##end isExistCad%46B042700196.body
	}

	// ##begin isExistCad%46B042990203.doc preserve=no
	/**
	 * @param part
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end isExistCad%46B042990203.doc
	public boolean isExistCad(WTPart part) throws WTException {
		// ##begin isExistCad%46B042990203.body preserve=yes
		boolean returnBoolean = false;
		EPMDocument doc = (EPMDocument) this.getRelational3DCad(part);
		if (doc != null)
			returnBoolean = true;
		return returnBoolean;
		// ##end isExistCad%46B042990203.body
	}

	// ##begin canDeleteStructure%46B042C1001F.doc preserve=no
	/**
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end canDeleteStructure%46B042C1001F.doc
	public boolean canDeleteStructure(WTPart parent, WTPart child) throws WTException {
		// ##begin canDeleteStructure%46B042C1001F.body preserve=yes
		boolean returnBoolean = true;

		boolean parentBoolean = this.isExistCad(parent);
		boolean childBoolean = this.isExistCad(child);
		if (parentBoolean && childBoolean)
			returnBoolean = false;

		return returnBoolean;
		// ##end canDeleteStructure%46B042C1001F.body
	}

	// ##begin canAddStructure%46B042E5035B.doc preserve=no
	/**
	 * @param parent
	 * @param child
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end canAddStructure%46B042E5035B.doc
	public boolean canAddStructure(WTPart parent, WTPart child) throws WTException {
		// ##begin canAddStructure%46B042E5035B.body preserve=yes
		boolean returnBoolean = true;

		boolean parentBoolean = this.isExistCad(parent);
		boolean childBoolean = this.isExistCad(child);
		if (parentBoolean && childBoolean)
			returnBoolean = false;

		return returnBoolean;
		// ##end canAddStructure%46B042E5035B.body
	}

	// ##begin syncStructure%46BC1E420109.doc preserve=no
	/**
	 * @param epmdoc
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end syncStructure%46BC1E420109.doc
	public boolean syncStructure(EPMDocument epmdoc) throws WTException, WTPropertyVetoException {
		// ##begin syncStructure%46BC1E420109.body preserve=yes
		boolean complete = false;
		Hashtable cadHash = null;
		Hashtable partHash = null;

		Hashtable addHash = null;
		Hashtable delHash = null;
		Hashtable quantityHash = null;
		try {

			if (epmdoc.getNumber().substring(0, 1).equals("3")
					&& epmdoc.getDocType().getStringValue().substring(epmdoc.getDocType().getStringValue().lastIndexOf(".") + 1)
							.equals("CADASSEMBLY") && epmdoc.getNumber().substring(4, 5).equals("-")) {
				System.out.println("** syncStructure Start **");

				cadHash = this.getCADStructure(epmdoc);
				partHash = this.getPartStructure(epmdoc);
				// if( cadHash != null && partHash != null )
				if (cadHash != null) {
					addHash = this.checkAddStructure(cadHash, partHash);
					delHash = this.checkDeleteStructure(cadHash, partHash);
					quantityHash = this.checkQuantityStructure(cadHash, partHash);

					if (VERBOSE) {
						if (addHash != null)
							System.out.println("[ADDED PART SIZE]=" + addHash.size());
						if (delHash != null)
							System.out.println("[DELETED PART SIZE]=" + delHash.size());
						if (quantityHash != null)
							System.out.println("[QUANTITY CHANGE]=" + quantityHash.size());
					}

					if (VERBOSE)
						System.out.println("[START EVENT ACTION]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
					if (addHash != null)
						this.addPartStructure(epmdoc, addHash);
					if (delHash != null)
						this.deletePartStructure(epmdoc, delHash);
					if (quantityHash != null)
						this.updatePartStructure(epmdoc, quantityHash);
					complete = true;
				}

				System.out.println("** syncStructure End **");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return complete;
		// ##end syncStructure%46BC1E420109.body
	}

	// ##begin syncStructureByNewPart%46C14F40035B.doc preserve=no
	/**
	 * @param addPart
	 * @return boolean
	 * @exception wt.util.WTException
	 * @exception wt.util.WTPropertyVetoException
	 */
	// ##end syncStructureByNewPart%46C14F40035B.doc
	public boolean syncStructureByNewPart(WTPart addPart) throws WTException, WTPropertyVetoException {
		// ##begin syncStructureByNewPart%46C14F40035B.body preserve=yes

		boolean complete = false;
		EPMDocument epmdoc = (EPMDocument) this.getRelational3DCad(addPart);

		// Child
		if (true)
		// if( addPart.getNumber().substring(0,1).equals("3") &&
		// addPart.getNumber().substring(4,5).equals("-") )
		{
			Hashtable aHash = this.getCADStructure(epmdoc);

			if (aHash != null && aHash.size() > 0) {
				Enumeration childNumberKey = aHash.keys();
				String childNumber = null;
				Vector aVector = null;
				EPMDocument aEpm = null;
				WTPart aRelationPart = null;
				boolean checkoutFlag = false;
				WTPartUsageLink aLink = null;
				Quantity aQuantity = null;

				while (childNumberKey.hasMoreElements()) {
					childNumber = (String) childNumberKey.nextElement();
					if (addPart.getNumber().substring(0, 1).equals("3") && addPart.getNumber().substring(4, 5).equals("-")
							&& addPart.getNumber().length() == 12) {
						if ((childNumber.substring(0, 1).equals("3") || childNumber.substring(0, 1).equals("5"))
								&& childNumber.substring(4, 5).equals("-") && childNumber.length() == 12) {
							aVector = (Vector) aHash.get(childNumber);
							aEpm = (EPMDocument) aVector.get(0);
							aRelationPart = (WTPart) this.getRelationalPart(aEpm);
							if (VERBOSE)
								System.out.println("[RELATIONAL PART]:" + aRelationPart);
							if (aRelationPart != null ) { //&& !(aRelationPart instanceof WTProduct)) {
								if (!checkoutFlag) {
									while (WorkInProgressHelper.isCheckedOut(addPart)) {
										try {
											Thread.sleep(10000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
									}

									if (!WorkInProgressHelper.isWorkingCopy(addPart)) {
										Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
										CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) addPart, checkoutFolder, null);
										addPart = (WTPart) checklink.getWorkingCopy();
									}

									checkoutFlag = true;
								}

								aQuantity = Quantity.newQuantity();
								if (VERBOSE)
									System.out.println(aRelationPart.getNumber() + "=" + (Integer) aVector.get(1));

								aQuantity.setAmount(((Integer) aVector.get(1)).doubleValue());
								aLink = WTPartUsageLink.newWTPartUsageLink(addPart, (WTPartMaster) aRelationPart.getMaster());
								aLink.setQuantity(aQuantity);
								aLink = (WTPartUsageLink) PersistenceHelper.manager.save(aLink);
								aLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(aLink);
							}
						}
					} else if (addPart.getNumber().substring(0, 1).equals("5") && addPart.getNumber().substring(4, 5).equals("-")
							&& addPart.getNumber().length() == 12) {
						if (childNumber.substring(0, 1).equals("5") && childNumber.substring(4, 5).equals("-") && childNumber.length() == 12) {
							aVector = (Vector) aHash.get(childNumber);
							aEpm = (EPMDocument) aVector.get(0);
							aRelationPart = (WTPart) this.getRelationalPart(aEpm);
							if (VERBOSE)
								System.out.println("[RELATIONAL PART]:" + aRelationPart);
							if (aRelationPart != null ) { //&& !(aRelationPart instanceof WTProduct)) {
								if (!checkoutFlag) {
									while (WorkInProgressHelper.isCheckedOut(addPart)) {
										try {
											Thread.sleep(10000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
									}

									if (!WorkInProgressHelper.isWorkingCopy(addPart)) {
										Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
										CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) addPart, checkoutFolder, null);
										addPart = (WTPart) checklink.getWorkingCopy();
									}

									checkoutFlag = true;
								}

								aQuantity = Quantity.newQuantity();
								if (VERBOSE)
									System.out.println(aRelationPart.getNumber() + "=" + (Integer) aVector.get(1));

								aQuantity.setAmount(((Integer) aVector.get(1)).doubleValue());
								aLink = WTPartUsageLink.newWTPartUsageLink(addPart, (WTPartMaster) aRelationPart.getMaster());
								aLink.setQuantity(aQuantity);
								aLink = (WTPartUsageLink) PersistenceHelper.manager.save(aLink);
								aLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(aLink);
							}
						}
					}

				}

				if (checkoutFlag) {
					// check in
					WorkInProgressHelper.service.checkin(addPart, "CHECKED IN");
				}
			}
		}

		// Parent
		QueryResult aResult = this.getParentEPMDocument(epmdoc);
		if (aResult != null && aResult.size() > 0) {
			Vector aVector = null;
			String aChildNumber = null;
			EPMDocument aEpm = null;
			EPMMemberLink aEpmLink = null;
			WTPart aRelationPart = null;
			WTPartUsageLink aLink = null;
			Quantity aQuantity = null;
			Hashtable aHash = null;
			Enumeration aEnum = null;
			String parentNumber = null;
			double amount = 0;
			String enumKey = null;

			while (aResult.hasMoreElements()) {
				aEpmLink = (EPMMemberLink) aResult.nextElement();
				aEpm = (EPMDocument) aEpmLink.getUsedBy();
				aRelationPart = (WTPart) this.getRelationalPart(aEpm);

				if (aRelationPart != null
						&& (aRelationPart.getNumber().substring(0, 1).equals("3") || aRelationPart.getNumber().substring(0, 1).equals("5"))
						&& aRelationPart.getNumber().substring(4, 5).equals("-") && aRelationPart.getNumber().length() == 12) {
					if (aHash == null)
						aHash = new Hashtable();

					aQuantity = null;
					aVector = null;
					aVector = (Vector) aHash.get(aEpm.getNumber());
					if (aVector != null) {
						aQuantity = (Quantity) aVector.get(1);

						if (aQuantity != null) {
							amount = aQuantity.getAmount() + 1;
							aQuantity.setAmount(amount);
						} else {
							aQuantity = Quantity.newQuantity();
							aQuantity.setAmount(1);
						}
						aVector.add(1, aQuantity);
					} else {
						aVector = new Vector();
						aQuantity = Quantity.newQuantity();
						aQuantity.setAmount(1);
						aVector.add(0, aRelationPart);
						aVector.add(1, aQuantity);
					}

					aHash.put(aEpm.getNumber(), aVector);
				}
			}

			if (aHash != null) {
				aVector = null;
				aEnum = aHash.keys();
				while (aEnum.hasMoreElements()) {
					enumKey = (String) aEnum.nextElement();
					aVector = (Vector) aHash.get(enumKey);
					aRelationPart = (WTPart) aVector.get(0);

					while (WorkInProgressHelper.isCheckedOut(aRelationPart)) {
						try {
							Thread.sleep(10000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}

					if (!WorkInProgressHelper.isWorkingCopy(aRelationPart)) {
						Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
						CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) aRelationPart, checkoutFolder, null);
						aRelationPart = (WTPart) checklink.getWorkingCopy();
					}

					aQuantity = (Quantity) aVector.get(1);
					aLink = WTPartUsageLink.newWTPartUsageLink(aRelationPart, (WTPartMaster) addPart.getMaster());
					aLink.setQuantity(aQuantity);
					aLink = (WTPartUsageLink) PersistenceHelper.manager.save(aLink);

					WorkInProgressHelper.service.checkin(aRelationPart, "CHECKED IN");
				}
			}
		}

		complete = true;
		return complete;
		// ##end syncStructureByNewPart%46C14F40035B.body
	}

	// ##begin getChildEPMDocument%46BC1F3000CBg.doc preserve=no
	/**
	 * @param parent
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	// ##end getChildEPMDocument%46BC1F3000CBg.doc
	public QueryResult getChildEPMDocument(EPMDocument parent) throws WTException {
		// ##begin getChildEPMDocument%46BC1F3000CBg.body preserve=yes
		LatestConfigSpec spec = new LatestConfigSpec();
		QueryResult result = EPMStructureHelper.service.navigateUsesToIteration(parent, null, false, spec);
		return result;
		// ##end getChildEPMDocument%46BC1F3000CBg.body
	}

	// ##begin getParentEPMDocument%46C181E8033Cg.doc preserve=no
	/**
	 * @param child
	 * @return QueryResult
	 * @exception wt.util.WTException
	 */
	// ##end getParentEPMDocument%46C181E8033Cg.doc
	public QueryResult getParentEPMDocument(EPMDocument child) throws WTException {
		// ##begin getParentEPMDocument%46C181E8033Cg.body preserve=yes
		QuerySpec spec = new QuerySpec(EPMDocument.class);
		LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
		spec = latestConfigSpec.appendSearchCriteria(spec);
		QueryResult result = EPMStructureHelper.service.navigateUsedBy((EPMDocumentMaster) child.getMaster(), spec, false);
		return result;
		// ##end getParentEPMDocument%46C181E8033Cg.body
	}

	// ##begin enforcedSaveByCheckout%46C965BD005D.doc preserve=no
	/**
	 * @param aObject
	 * @param bObject
	 * @return boolean
	 * @exception wt.util.WTException
	 */
	// ##end enforcedSaveByCheckout%46C965BD005D.doc
	public boolean enforcedSaveByCheckout(Workable aObject, Workable bObject) throws WTException {
		// ##begin enforcedSaveByCheckout%46C965BD005D.body preserve=yes
		boolean returnFlag = true;

		WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
		try {
			SessionHelper.manager.setAdministrator();

			Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
			CheckoutLink checklink = WorkInProgressHelper.service.checkout(aObject, checkoutFolder, null);
			aObject = (Workable) checklink.getWorkingCopy();

			EPMReferenceLink link = EPMReferenceLink.newEPMReferenceLink((EPMDocument) aObject,
					(DocumentMaster) (((EPMDocument) bObject).getMaster()));
			PersistenceHelper.manager.save(link);

			aObject = WorkInProgressHelper.service.checkin(aObject, "");
		} catch (Exception e) {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			e.printStackTrace();
		} finally {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
		}

		return returnFlag;
		// ##end enforcedSaveByCheckout%46C965BD005D.body
	}

	// ##begin fileDuplicate%46CAA72F0261.doc preserve=no
	/**
	 * @param changeStr
	 * @param docType
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDuplicate%46CAA72F0261.doc
	public boolean fileDuplicate(String changeStr, boolean docType) throws IOException, WTException {
		// ##begin fileDuplicate%46CAA72F0261.body preserve=yes
		// *************************************************
		// docType: true-part, false-assy
		// *************************************************
		String tempFileName = null;
		String orgCompareStr = null;
		if (docType) {
			tempFileName = this.DRW_PART_TEMPLATE;
			orgCompareStr = "PART_TEMPLATE";
		} else {
			tempFileName = this.DRW_ASSY_TEMPLATE;
			orgCompareStr = "ASSY_TEMPLATE";
		}

		if (VERBOSE)
			System.out.println("[orgCompareStr]=" + orgCompareStr);
		if (VERBOSE)
			System.out.println("[changeStr]=" + changeStr);

		if (changeStr == null || changeStr.length() <= 0)
			throw new WTException("The two attributes is null. [orgCompareStr or changeStr]");

		int buffSize = orgCompareStr.length();

		byte id[] = new byte[buffSize];
		RandomAccessFile fo = new RandomAccessFile(WT_HOME + "/codebase/" + changeStr + ".drw", "rw");
		RandomAccessFile fin = new RandomAccessFile(WT_HOME + "/codebase/" + tempFileName, "r");

		long filePosition = 0;
		while (fin.getFilePointer() < fin.length()) {
			fin.seek(filePosition);
			int i = fin.read(id);

			String idStr = new String(id);

			if (idStr.equals(orgCompareStr.toLowerCase())) {
				fo.write(changeStr.toLowerCase().getBytes());
				filePosition = filePosition + buffSize;

			} else if (idStr.equals(orgCompareStr.toUpperCase())) {
				fo.write(changeStr.toUpperCase().getBytes());
				filePosition = filePosition + buffSize;
			} else {
				fo.write(id[0]);
				filePosition++;
			}
			fin.seek(filePosition);

		}

		fo.close();
		fin.close();
		return true;
		// ##end fileDuplicate%46CAA72F0261.body
	}

	// ##begin fileDuplicate%46CD543B0128.doc preserve=no
	/**
	 * @param orgCompareStr
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDuplicate%46CD543B0128.doc
	public boolean fileDuplicate(String orgCompareStr, String changeStr) throws IOException, WTException {
		// ##begin fileDuplicate%46CD543B0128.body preserve=yes
		if (VERBOSE)
			System.out.println("[orgCompareStr]=" + orgCompareStr);
		if (VERBOSE)
			System.out.println("[changeStr]=" + changeStr);

		if ((orgCompareStr == null || orgCompareStr.length() <= 0) && (changeStr == null || changeStr.length() <= 0))
			throw new WTException("The two attributes is null. [orgCompareStr or changeStr]");

		int buffSize = orgCompareStr.length();

		byte id[] = new byte[buffSize];
		RandomAccessFile fo = new RandomAccessFile(WT_HOME + "/codebase/" + changeStr + ".drw", "rw");
		RandomAccessFile fin = new RandomAccessFile(WT_HOME + "/codebase/" + orgCompareStr, "r");

		long filePosition = 0;
		byte changeByte[] = changeStr.getBytes();
		while (fin.getFilePointer() < fin.length()) {
			fin.seek(filePosition);
			int i = fin.read(id);
			filePosition++;
			String idStr = new String(id);

			if (idStr.equals(orgCompareStr)) {
				filePosition = filePosition + buffSize - 1;
				fo.write(changeByte);
			} else {
				fo.write(id[0]);
			}
		}

		fo.close();
		fin.close();
		return true;
		// ##end fileDuplicate%46CD543B0128.body
	}

	// ##begin fileDelete%46CAAA3E000F.doc preserve=no
	/**
	 * @param changeStr
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileDelete%46CAAA3E000F.doc
	public boolean fileDelete(String changeStr) throws IOException, WTException {
		// ##begin fileDelete%46CAAA3E000F.body preserve=yes
		if (VERBOSE)
			System.out.println(WT_HOME + "/codebase/" + changeStr);
		File file = new File(WT_HOME + "/codebase/" + changeStr);
		boolean check = file.delete();
		return check;
		// ##end fileDelete%46CAAA3E000F.body
	}

	// ##begin fileSave%46CAB3E602AF.doc preserve=no
	/**
	 * @param applicationData
	 * @param filename
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception wt.util.WTException
	 */
	// ##end fileSave%46CAB3E602AF.doc
	public boolean fileSave(ApplicationData applicationData, String filename) throws IOException, WTException {
		// ##begin fileSave%46CAB3E602AF.body preserve=yes
		if (VERBOSE)
			System.out.println(WT_HOME + "/" + filename);
		ContentServerHelper.service.writeContentStream(applicationData, WT_HOME + "/codebase/" + filename);
		return true;
		// ##end fileSave%46CAB3E602AF.body
	}

	// ##begin getOwnDrawing%46CCE84300ABg.doc preserve=no
	/**
	 * @param epm3d
	 * @return EPMDocument
	 * @exception wt.util.WTException
	 */
	// ##end getOwnDrawing%46CCE84300ABg.doc
	public EPMDocument getOwnDrawing(EPMDocument epm3d) throws WTException {
		// ##begin getOwnDrawing%46CCE84300ABg.body preserve=yes
		EPMDocument epm2d = null;
		if (epm3d != null) {
			QuerySpec spec = new QuerySpec(EPMDocument.class);
			spec.appendWhere(new SearchCondition(EPMDocument.class, "master>number", SearchCondition.LIKE, epm3d.getNumber() + "[2D]"));
			LatestConfigSpec lSpec = new LatestConfigSpec();
			spec = lSpec.appendSearchCriteria(spec);

			QueryResult result = PersistenceHelper.manager.find(spec);

			if (result != null && result.size() > 0)
				epm2d = (EPMDocument) result.nextElement();

		}
		return epm2d;
		// ##end getOwnDrawing%46CCE84300ABg.body
	}

	// ##begin getRelational2DCadLink%46DE697B0128g.doc preserve=no
	/**
	 * @param epm
	 * @return Vector
	 * @exception wt.util.WTException
	 */
	// ##end getRelational2DCadLink%46DE697B0128g.doc
	public Vector getRelational2DCadLink(EPMDocument epm) throws WTException {
		// ##begin getRelational2DCadLink%46DE697B0128g.body preserve=yes
		Vector epm2dVector = null;
		EPMDocument epm2d = null;
		if (epm != null && epm instanceof EPMDocument) {
			if (!this.checkDrawing(epm)) {
				QuerySpec spec = new QuerySpec(EPMDocument.class);
				LatestConfigSpec lSpec = new LatestConfigSpec();
				spec = lSpec.appendSearchCriteria(spec);
				QueryResult result = EPMStructureHelper.service.navigateReferencedBy((EPMDocumentMaster) epm.getMaster(), spec, false);

				int count = 0;
				EPMReferenceLink link = null;
				if (result != null && result.size() > 0) {
					while (result.hasMoreElements()) {
						if (count == 0)
							epm2dVector = new Vector();
						count++;
						link = (EPMReferenceLink) result.nextElement();
						epm2dVector.add(link);
					}
				}
			}
		}
		return epm2dVector;
		// ##end getRelational2DCadLink%46DE697B0128g.body
	}

	// ##begin makeThumbnailStream%47186922004E.doc preserve=no
	/**
	 * @param obj
	 * @param state
	 * @param locale
	 * @param outputstream
	 * @exception wt.util.WTException
	 */
	// ##end makeThumbnailStream%47186922004E.doc
	public void makeThumbnailStream(Object obj, HTTPState state, Locale locale, OutputStream outputstream) throws WTException {
		// ##begin makeThumbnailStream%47186922004E.body preserve=yes
		WTPrincipal currentPrincipal = null;
		try {
			currentPrincipal = SessionHelper.manager.getPrincipal();

			SessionHelper.manager.setAdministrator();
			if (obj instanceof WTPart) {
				Object epmObj = null;
				epmObj = (Object) PSKCADHelper.service.getRelational3DCad((WTPart) obj);
				if (epmObj != null)
					obj = epmObj;
			}

			VisualizationRendererFactory visualizationrendererfactory = new VisualizationRendererFactory();
			VisualizationRendererIfc visualizationrendererifc = visualizationrendererfactory.getRenderer();
			visualizationrendererifc.displayCommonThumbnailButtonCmp(obj, state, locale, outputstream);
		} catch (Exception ioe) {
			ioe.printStackTrace();
		} finally {
			SessionHelper.manager.setPrincipal(currentPrincipal.getName());
		}
		// ##end makeThumbnailStream%47186922004E.body
	}

	// ##begin user.operations preserve=yes
	public EPMDocument changeState(EPMDocument holder, State state) throws WTException {
		EPMDocument returnObject = null;
		WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
		try {
			if (holder == null || state == null)
				returnObject = null;
			else {

				SessionHelper.manager.setAdministrator();
				returnObject = (EPMDocument) LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) holder, state);
				SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			}
		} catch (Exception e) {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
			throw new WTException(e.getLocalizedMessage());
		} finally {
			SessionHelper.manager.setPrincipal(orgPrincipal.getName());
		}

		return returnObject;
	}

	private String getLatestVersion(Hashtable versions) {
		Enumeration dKey = versions.keys();
		Vector v = new Vector();
		while (dKey.hasMoreElements()) {
			String dStr = (String) dKey.nextElement();
			v.add(dStr);
		}
		Collections.sort(v);

		return (String) v.get(v.size() - 1);
	}

	private WTObject getReferenceObject(String oid) throws WTException {
		ReferenceFactory referencefactory = new ReferenceFactory();
		WTReference wtreference = referencefactory.getReference(oid);
		return (WTObject) wtreference.getObject();
	}

	public String getFutureVersion(EPMDocument doc) throws WTException {
		String version1 = doc.getNumber().substring(11, 12);
		String version2 = doc.getNumber().substring(10, 11);
		QueryResult qResult = null;
		QuerySpec spec = null;
		boolean loopFlag = true;

		if (VERBOSE)
			System.out.println(doc.getIdentity());
		while (loopFlag) {

			if (version1.equals("-")) {
				version1 = "A";
			} else if (version1.equals("Z")) {
				version1 = "A";
				if (version2.equals("-"))
					version2 = "A";
				else {
					char c = version2.charAt(0);
					int result = (int) c + 1;
					char charStr = (char) result;
					version2 = String.valueOf(charStr);
				}
			} else {
				char c = version1.charAt(0);
				int result = (int) c + 1;
				char charStr = (char) result;
				version1 = String.valueOf(charStr);
			}

			String changedNumber = doc.getNumber().substring(0, 10) + version2 + version1;

			spec = new QuerySpec(EPMDocumentMaster.class);
			spec.appendWhere(new SearchCondition(EPMDocumentMaster.class, "number", SearchCondition.EQUAL, changedNumber));
			qResult = PersistenceHelper.manager.find(spec);

			if (VERBOSE)
				System.out.println(changedNumber);

			if (qResult == null || qResult.size() <= 0) {
				loopFlag = false;
				if (VERBOSE)
					System.out.println("[FOUND]" + changedNumber);
			}
		}

		return version2 + version1;
	}

	public boolean checkExistPart(String changeNumber) throws WTException {
		boolean returnFlag = false;
		QuerySpec spec = new QuerySpec(WTPartMaster.class);
		spec.appendWhere(new SearchCondition(WTPartMaster.class, "number", SearchCondition.EQUAL, changeNumber));
		QueryResult result = PersistenceHelper.manager.find(spec);

		if (result.size() > 0)
			returnFlag = true;

		return returnFlag;
	}

	public boolean checkDocType(EPMDocument doc) throws WTException {
		boolean returnFlag = false;
		if (doc.getDocType().getStringValue().substring(doc.getDocType().getStringValue().lastIndexOf(".") + 1).equals("CADASSEMBLY"))
			returnFlag = false;
		else
			returnFlag = true;

		return returnFlag;
	}

	private EPMDocument change2DEPMdocument(EPMDocument epm3D, EPMDocument epm2D, String orgEpmNumber, boolean orgDocType, String[] basicAttr,
			WTContainer wtcontext) throws WTException, WTPropertyVetoException, PropertyVetoException, RemoteException {
		/***********************************************************************
		 * basicAttr [0] = number [1] = name [2] = lifecycle [3] = location
		 **********************************************************************/
		if (basicAttr == null)
			throw new WTException("Basic Attribute is NULL!");
		if (basicAttr.length != 4)
			throw new WTException("Basic Attribute can not match original size[4]!");
		if (epm2D == null || basicAttr[0] == null || basicAttr[1] == null)
			throw new WTException("All of needed attributes must be inputed!!!");

		WTContainerRef ref = null;

		if (wtcontext == null)
			ref = epm2D.getContainerReference();
		else
			ref = WTContainerRef.newWTContainerRef(wtcontext);

		boolean changeLocationFlag = true;

		if (basicAttr[2] == null || basicAttr[2].length() <= 0) {
			basicAttr[2] = this.DEFAULT_EPM_LIFECYCLE;
		}

		if (basicAttr[3] == null || basicAttr[3].length() <= 0) {
			basicAttr[3] = epm2D.getLocation();
			changeLocationFlag = false;
		}

		String original2dNumber = null;
		// if( epm2D.getNumber().lastIndexOf(".") == -1 )
		original2dNumber = epm2D.getNumber();
		// else
		// original2dNumber =
		// epm2D.getNumber().substring(0,epm2D.getNumber().lastIndexOf("."));

		if (!original2dNumber.equals(orgEpmNumber + "[2D]")) {
			EPMDocumentHelper.service.changeCADName((EPMDocumentMaster) epm2D.getMaster(), (basicAttr[0] + ".drw").toLowerCase());
			epm2D = (EPMDocument) PersistenceHelper.manager.refresh(epm2D);

			EPMDocumentMaster epmMaster = (EPMDocumentMaster) (epm2D.getMaster());

			EPMDocumentMasterIdentity identity = (EPMDocumentMasterIdentity) epmMaster.getIdentificationObject();
			identity.setNumber(basicAttr[0] + "[2D]");
			identity.setName(basicAttr[1]);
			epmMaster = (EPMDocumentMaster) IdentityHelper.service.changeIdentity(epmMaster, identity);
		}

		// EPMDocumentHelper.service.changeCADName(epmMaster, basicAttr[0] +
		// ".drw");

		/***********************************************************************
		 * 20070906 try {
		 * ContentServerHelper.service.writeContentStream((ApplicationData
		 * )ContentHelper.service.getPrimary(epm2D),
		 * WT_HOME+"/codebase/"+orgEpmNumber); this.fileDuplicate(orgEpmNumber,
		 * basicAttr[0]); } catch (IOException e) { throw new WTException("Can
		 * not download for duplication by 2D CAD!!"); }
		 * 
		 * ContentServerHelper.service.deleteContent(epm2D,
		 * ContentHelper.service.getPrimary(epm2D)); epm2D =
		 * (EPMDocument)PersistenceHelper.manager.refresh(epm2D); 20070906
		 **********************************************************************/

		// NEW UPLOAD
		/***********************************************************************
		 * 20070906 try { FileInputStream fi2D = new
		 * FileInputStream(WT_HOME+"/codebase/"+basicAttr[0]+".drw");
		 * 
		 * BufferedInputStream bi2D = new BufferedInputStream(fi2D);
		 * DataInputStream di2D = new DataInputStream(bi2D); ApplicationData
		 * applicationData2D = ApplicationData.newApplicationData(epm2D);
		 * applicationData2D
		 * .setUploadedFromPath(WT_HOME+"/codebase/"+basicAttr[0]+".drw");
		 * applicationData2D.setFileName("{$CAD_NAME}");
		 * applicationData2D.setRole(ContentRoleType.PRIMARY);
		 * 
		 * HTTPUploadDownload uploader2D = new HTTPUploadDownload();
		 * 
		 * uploader2D.addPostParameter("contentRoleType", "PRIMARY", 0);
		 * uploader2D.setName("newFile", 0);
		 * uploader2D.setPath(applicationData2D.getUploadedFromPath(), 0);
		 * uploader2D.addPostParameter("UploadedFrom", uploader2D.getPath(0),
		 * 0);
		 * 
		 * uploader2D.setUploadURL(ContentHelper.getUploadURL(epm2D).toString())
		 * ; uploader2D.performUpload(false);
		 * 
		 * epm2D = (EPMDocument)PersistenceHelper.manager.refresh(epm2D);
		 * 
		 * ContentItem data2 = ContentHelper.service.getPrimary(epm2D);
		 * applicationData2D = (ApplicationData)data2;
		 * applicationData2D.setCategory("PROE_UGC");
		 * applicationData2D.setFileName("{$CAD_NAME}"); applicationData2D =
		 * (ApplicationData)PersistenceHelper.manager.save(applicationData2D);
		 * 
		 * if( original2dNumber.equals(orgEpmNumber) ) { EPMReferenceLink link =
		 * EPMReferenceLink.newEPMReferenceLink((EPMDocument)epm2D,
		 * (DocumentMaster)(((EPMDocument)epm3D).getMaster()));
		 * link.setAsStoredChildName(epm3D.getCADName()); link.setDepType(4);
		 * link.setRequired(true);
		 * link.setUniqueNDId("R/4/"+epm3D.getCADName());
		 * link.setTypeDefinitionReference
		 * (TypedUtilityServiceHelper.service.getTypeDefinitionReference
		 * (CAD_REFERENCE_LINK)); PersistenceServerHelper.manager.insert(link);
		 * } } catch(FileNotFoundException e) { throw new
		 * WTException(e.getLocalizedMessage()); } catch(MalformedURLException
		 * e) { throw new WTException(e.getLocalizedMessage()); }
		 * 
		 * try { this.fileDelete(WT_HOME+"/codebase/"+orgEpmNumber);
		 * this.fileDelete(WT_HOME+"/codebase/"+basicAttr[0]+".drw"); } catch
		 * (IOException e) { e.printStackTrace(); } 20070906
		 **********************************************************************/

		if (!original2dNumber.equals(orgEpmNumber + "[2D]")) {
			// CHANGE LC
			LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(basicAttr[2], ref);
			Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(basicAttr[3], ref);
			LifeCycleTemplateReference lref = LifeCycleTemplateReference.newLifeCycleTemplateReference(template);
			epm2D = (EPMDocument) LifeCycleHelper.service.reassign(epm2D, lref);
			// CHANGE LOCATION
			if (changeLocationFlag) {
				epm2D = (EPMDocument) PersistenceHelper.manager.refresh(epm2D);
				FolderHelper.service.changeFolder(epm2D, checkOutFolder);
			}
		}

		return epm2D;
	}

	public Vector enum2vector(Enumeration enumeration) {
		Vector vector = null;
		while (enumeration.hasMoreElements())
			vector.add(enumeration.nextElement());
		return vector;
	}

	public Hashtable getIBAList(IBAHolder part) throws WTException {
		Hashtable resultHash = new Hashtable();
		try {

			IBAHolder ibaholder = (IBAHolder) part;
			ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder, null, null, null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaholder.getAttributeContainer();

			if (defaultattributecontainer == null) {
				if (VERBOSE)
					System.out.println("Attribute container is null.");
			}

			AbstractValueView[] result = defaultattributecontainer.getAttributeValues();

			if (VERBOSE)
				System.out.println("Service found " + result.length + " of values....");

			for (int i = 0; i < result.length; i++) {

				String s = new String();
				boolean okflag = true;

				if (result[i] instanceof StringValueDefaultView) {
					if (result[i].getDefinition().getName().equals("Legend_Primary_Files")) {
						s = "";
						okflag = false;
					} else {
						s = ((StringValueDefaultView) result[i]).getLocalizedDisplayString();
						if (VERBOSE)
							System.out.println(s);
					}
				} else if (result[i] instanceof FloatValueDefaultView) {
					s = ((FloatValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof IntegerValueDefaultView) {
					s = ((IntegerValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof BooleanValueDefaultView) {
					s = ((BooleanValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof TimestampValueDefaultView) {
					s = timestampToString(((TimestampValueDefaultView) result[i]).getValue());
				} else if (result[i] instanceof UnitValueDefaultView) {
					String s1 = null;
					try {

						if (s1 == null) {
							((UnitValueDefaultView) result[i]).toUnit();
							// s =
							// ((UnitValueDefaultView)result[i]).toUnit().toString();

							QuantityOfMeasureDefaultView measure = ((UnitValueDefaultView) result[i]).getUnitDefinition()
									.getQuantityOfMeasureDefaultView();

							if (measure.getDisplayUnitString("SI") != null && !(measure.getDisplayUnitString("SI").equals(""))) {
								s = ((UnitValueDefaultView) result[i]).getValue() + " " + measure.getDisplayUnitString("SI");
							} else {
								s = ((UnitValueDefaultView) result[i]).toUnit().toString();
							}

							/*
							 * //System.out.println(measure.getQuantityOfMeasure(
							 * )); System.out.println(measure.getName());
							 * System.
							 * out.println(measure.getBaseUnit()+"+++++++++++++"
							 * ); System.out.println(measure.getDescription());
							 * System
							 * .out.println(measure.getDisplayUnitString("SI"));
							 * System
							 * .out.println(measure.getDefaultDisplayUnitString
							 * ("SI"));
							 * 
							 * Enumeration unitkeys =
							 * measure.defaultDisplayUnitsKeys();
							 * 
							 * while ( unitkeys.hasMoreElements() ) { String key
							 * = (String)unitkeys.nextElement();
							 * System.out.println(key);
							 * System.out.println(measure
							 * .getDefaultDisplayUnitString(key));
							 * System.out.println
							 * (measure.getDisplayUnitString(key)); }
							 */

						} else {

							DefaultUnitRenderer defaultunitrenderer = new DefaultUnitRenderer();
							try {
								defaultunitrenderer.setDisplayDigits(((UnitValueDefaultView) result[i]).getPrecision());
							} catch (WTPropertyVetoException _ex) {
							}
							s = defaultunitrenderer.renderValue(((UnitValueDefaultView) result[i]).toUnit(),
									((UnitValueDefaultView) result[i]).getUnitDisplayInfo(s1));
						}
					} catch (UnitFormatException _ex) {
					} catch (IncompatibleUnitsException _ex) {
					}
				} else if (result[i] instanceof RatioValueDefaultView) {
					s = ((RatioValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof URLValueDefaultView) {
					s = "<A HREF=\""
							+ ((URLValueDefaultView) result[i]).getLocalizedDisplayString()
							+ "\">"
							+ (((URLValueDefaultView) result[i]).getDescription() == null ? ((URLValueDefaultView) result[i])
									.getLocalizedDisplayString() : ((URLValueDefaultView) result[i]).getDescription()) + "</A>";
				} else {
					s = "Attribute value type not implemented: " + result[i];
					okflag = false;
				}

				if (okflag)
					resultHash.put(result[i].getDefinition().getName(), s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultHash;
	}

	static private String timestampToString(Timestamp timestamp) {
		WTContext wtcontext = WTContext.getContext();
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", wtcontext.getLocale());
		simpledateformat.setTimeZone(wtcontext.getTimeZone());
		java.util.Date date = new java.util.Date(timestamp.getTime());
		String s = simpledateformat.format(date);
		return s;
	}

	public Hashtable getCADStructure(EPMDocument epmdoc) throws WTException {
		Hashtable cadHash = null;
		LatestConfigSpec spec = new LatestConfigSpec();
		QueryResult result = EPMStructureHelper.service.navigateUsesToIteration(epmdoc, null, false, null);
		// QueryResult result = EPMStructureHelper.service.navigateUses(epmdoc,
		// null, false);
		if (result != null && result.size() > 0) {
			cadHash = new Hashtable();
			while (result.hasMoreElements()) {
				// HASHTABLE
				// KEY - NUMBER
				// Table - Vector( Object, Integer )
				Persistable[] persist = (Persistable[]) result.nextElement();
				// EPMMemberLink memberLink = (EPMMemberLink)persist[0];
				EPMDocument aDocument = (EPMDocument) persist[1];
				if (aDocument.getNumber().substring(0, 1).equals("3") || aDocument.getNumber().substring(0, 1).equals("5")
						&& aDocument.getNumber().length() == 12 && aDocument.getNumber().substring(4, 5).equals("-")) // CHECK
																														// PART
				{
					if (aDocument.isLatestIteration()) {
						Vector aObject = (Vector) cadHash.get(aDocument.getNumber());
						if (aObject != null) {
							Integer aCount = (Integer) aObject.get(1);
							int totalCount = aCount.intValue() + 1;
							aCount = new Integer(totalCount);
							aObject.remove(1);
							aObject.add(1, aCount);
						} else {
							aObject = new Vector();
							aObject.add(0, aDocument);
							aObject.add(1, new Integer(1));
						}
						cadHash.put(aDocument.getNumber(), aObject);
					}
				}
			}
		}
		return cadHash;
	}

	public Hashtable getPartStructure(EPMDocument epmdoc) throws WTException {
		WTPart part = this.getRelationalPart(epmdoc);
		Hashtable partHash = null;
		if (part != null) {
			WTPartConfigSpec configSpec = WTPartConfigSpec.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(null, null));
			QueryResult result = WTPartHelper.service.getUsesWTParts(part, configSpec);
			if (result.size() > 0) {
				partHash = new Hashtable();
				while (result.hasMoreElements()) {
					// HASHTABLE
					// KEY - NUMBER
					// Table - Vector( Object, Link, Quantity )
					Persistable persist[] = (Persistable[]) result.nextElement();
					WTPartUsageLink aLink = (WTPartUsageLink) persist[0];
					WTPart aPart = (WTPart) persist[1];
					if ((aPart.getNumber().substring(0, 1).equals("3") || aPart.getNumber().substring(0, 1).equals("5")) && this.isExistCad(aPart)) // CHECK
																																					// PART
					{
						Vector aObject = (Vector) partHash.get(aPart.getNumber());
						if (aObject == null) {
							aObject = new Vector();
							aObject.add(0, aPart);
							aObject.add(1, aLink);
							aObject.add(2, aLink.getQuantity());
							partHash.put(aPart.getNumber(), aObject);
						}

					}
				}
			}
		}
		return partHash;
	}

	public Hashtable checkAddStructure(Hashtable epmdoc, Hashtable part) throws WTException {
		Hashtable result = null;
		String epmNumber = null;
		Enumeration epmdocKeys = epmdoc.keys();
		while (epmdocKeys.hasMoreElements()) {
			epmNumber = (String) epmdocKeys.nextElement();
			if (part != null) {
				Vector aVector = (Vector) part.get(epmNumber);
				if (aVector == null) {
					if (result == null)
						result = new Hashtable();
					result.put(epmNumber, (Vector) epmdoc.get(epmNumber));
				}
			} else {
				if (result == null)
					result = new Hashtable();
				result.put(epmNumber, (Vector) epmdoc.get(epmNumber));
			}
		}
		return result;
	}

	public Hashtable checkDeleteStructure(Hashtable epmdoc, Hashtable part) throws WTException {
		Hashtable result = null;
		String partNumber = null;
		if (part != null) {
			Enumeration partKeys = part.keys();
			while (partKeys.hasMoreElements()) {
				partNumber = (String) partKeys.nextElement();
				Vector aVector = (Vector) epmdoc.get(partNumber);
				if (aVector == null) {
					if (result == null)
						result = new Hashtable();
					result.put(partNumber, (Vector) part.get(partNumber));
				}
			}
		}
		return result;
	}

	public Hashtable checkQuantityStructure(Hashtable epmdoc, Hashtable part) throws WTException {
		Hashtable result = null;
		String epmNumber = null;
		Vector partVector = null;
		Vector epmVector = null;
		Vector changeVector = null;
		Integer epmQuantity = null;
		Quantity partQuantity = null;
		int epmCount = 0;
		int partCount = 0;

		Enumeration epmdocKeys = epmdoc.keys();
		while (epmdocKeys.hasMoreElements()) {
			epmNumber = (String) epmdocKeys.nextElement();
			if (part != null) {
				partVector = (Vector) part.get(epmNumber);
				if (partVector != null) {
					epmVector = (Vector) epmdoc.get(epmNumber);
					// epm Quantity
					epmQuantity = (Integer) epmVector.get(1);
					epmCount = epmQuantity.intValue();
					// part Quantity
					partQuantity = (Quantity) partVector.get(2);
					// partCount =
					// Double.valueOf(partQuantity.getAmount()).intValue();
					partCount = Double.valueOf(Double.toString(partQuantity.getAmount())).intValue();

					if (epmCount != partCount) {
						if (result == null)
							result = new Hashtable();
						changeVector = new Vector();
						changeVector.add(0, epmQuantity);
						changeVector.add(1, (WTPartUsageLink) partVector.get(1));
						result.put(epmNumber, changeVector);
					}
				}
			}
		}
		return result;
	}

	public void addPartStructure(EPMDocument parent, Hashtable addHash) throws WTException, WTPropertyVetoException {
		WTPart parentPart = this.getRelationalPart(parent);
		// Part Checkout

		while (WorkInProgressHelper.isCheckedOut(parentPart)) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (!WorkInProgressHelper.isWorkingCopy(parentPart)) {
			Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
			CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) parentPart, checkoutFolder, null);
			parentPart = (WTPart) checklink.getWorkingCopy();
		}

		// epmNumber, Vector(object, integer)
		Enumeration keys = addHash.keys();
		String epmNumber = null;
		Vector aVector = null;
		EPMDocument aEpm = null;
		Integer aAmount = null;
		Quantity aQuantity = null;
		while (keys.hasMoreElements()) {
			epmNumber = (String) keys.nextElement();
			aVector = (Vector) addHash.get(epmNumber);
			aEpm = (EPMDocument) aVector.get(0);
			aAmount = (Integer) aVector.get(1);
			aQuantity = Quantity.newQuantity();

			aQuantity.setAmount(aAmount.doubleValue());
			WTPart aPart = this.getRelationalPart(aEpm);

			if (aPart != null) {
				WTPartUsageLink aLink = WTPartUsageLink.newWTPartUsageLink(parentPart, (WTPartMaster) aPart.getMaster());
				aLink.setQuantity(aQuantity);
				PersistenceHelper.manager.save(aLink);
			}
		}

		WorkInProgressHelper.service.checkin(parentPart, "CAD CHECKIN");
	}

	public void deletePartStructure(EPMDocument parent, Hashtable delHash) throws WTException, WTPropertyVetoException {
		WTPart parentPart = this.getRelationalPart(parent);
		// Part Checkout

		while (WorkInProgressHelper.isCheckedOut(parentPart)) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (!WorkInProgressHelper.isWorkingCopy(parentPart)) {
			Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
			CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) parentPart, checkoutFolder, null);
			parentPart = (WTPart) checklink.getWorkingCopy();
		}

		WTPartConfigSpec configSpec = WTPartConfigSpec.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(null, null));
		QueryResult result = WTPartHelper.service.getUsesWTParts(parentPart, configSpec);

		Hashtable realHash = new Hashtable();
		while (result.hasMoreElements()) {
			Persistable[] persist = (Persistable[]) result.nextElement();
			WTPartUsageLink realLink = (WTPartUsageLink) persist[0];
			WTPart part = (WTPart) persist[1];

			realHash.put(part.getNumber(), realLink);
		}

		// partNumber, Vector(object, Link, integer)
		Enumeration keys = delHash.keys();

		String partNumber = null;
		Vector aVector = null;
		WTPartUsageLink aLink = null;

		while (keys.hasMoreElements()) {
			partNumber = (String) keys.nextElement();
			aVector = (Vector) delHash.get(partNumber);
			// aLink = (WTPartUsageLink)aVector.get(1);
			aLink = (WTPartUsageLink) realHash.get(partNumber);

			if (aLink != null) {
				PersistenceHelper.manager.delete(aLink);
			}
		}
		WorkInProgressHelper.service.checkin(parentPart, "CAD CHECKIN");
	}

	public void updatePartStructure(EPMDocument parent, Hashtable updateHash) throws WTException, WTPropertyVetoException {
		WTPart parentPart = this.getRelationalPart(parent);
		// Part Checkout

		if (VERBOSE)
			System.out.println("[UPDATE HASH SIZE]=" + updateHash.size());
		if (VERBOSE)
			System.out.println("[updatePartStructure PARENT PART]=" + parentPart.getNumber() + "|"
					+ VersionControlHelper.getVersionIdentifier(parentPart).getValue() + "."
					+ VersionControlHelper.getIterationIdentifier(parentPart).getValue());
		if (VERBOSE)
			System.out.println("[BEFORE IS WORKING]=" + WorkInProgressHelper.isWorkingCopy(parentPart));
		while (WorkInProgressHelper.isCheckedOut(parentPart)) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (!WorkInProgressHelper.isWorkingCopy(parentPart)) {
			Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
			CheckoutLink checklink = WorkInProgressHelper.service.checkout((Workable) parentPart, checkoutFolder, null);
			parentPart = (WTPart) checklink.getWorkingCopy();
		}
		if (VERBOSE)
			System.out.println("[AFTER IS WORKING]=" + WorkInProgressHelper.isWorkingCopy(parentPart));

		WTPartConfigSpec configSpec = WTPartConfigSpec.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(null, null));
		QueryResult result = WTPartHelper.service.getUsesWTParts(parentPart, configSpec);

		Hashtable realHash = new Hashtable();
		while (result.hasMoreElements()) {
			Persistable[] persist = (Persistable[]) result.nextElement();
			WTPartUsageLink realLink = (WTPartUsageLink) persist[0];
			WTPart part = (WTPart) persist[1];

			realHash.put(part.getNumber(), realLink);
		}

		// partNumber, Vector(object, Link, integer)
		Enumeration keys = updateHash.keys();

		String partNumber = null;
		Vector aVector = null;
		WTPartUsageLink aLink = null;
		Integer aAmount = null;
		Quantity aQuantity = null;

		while (keys.hasMoreElements()) {
			partNumber = (String) keys.nextElement();
			aVector = (Vector) updateHash.get(partNumber);
			aAmount = (Integer) aVector.get(0);
			// aLink = (WTPartUsageLink)aVector.get(1);
			aLink = (WTPartUsageLink) realHash.get(partNumber);

			if (VERBOSE) {
				WTPart apart = (WTPart) aLink.getUsedBy();
				System.out.println("[PARENT PART]=" + apart.getNumber() + "|" + VersionControlHelper.getVersionIdentifier(apart).getValue() + "."
						+ VersionControlHelper.getIterationIdentifier(apart).getValue());
			}

			if (aLink != null) {
				aQuantity = Quantity.newQuantity();
				aQuantity.setAmount(aAmount.doubleValue());
				aLink.setQuantity(aQuantity);

				PersistenceHelper.manager.save(aLink);
			}
		}
		WorkInProgressHelper.service.checkin(parentPart, "CAD CHECKIN");
	}

	private EPMDocument copy2DEPMDocument(EPMReferenceLink referLink, EPMDocument copied3D, String location, WTContainerRef ref) throws WTException,
			WTPropertyVetoException, PropertyVetoException, RemoteException {
		if (referLink == null)
			throw new WTException("Orginal EPMReferenceLink is NULL!");
		if (copied3D == null)
			throw new WTException("copied 3D EPMDocument is NULL!");

		EPMDocument org2D = (EPMDocument) referLink.getReferencedBy();
		if (location == null || location.length() <= 0) {
			location = copied3D.getLocation();
		}

		// WTContainerRef ref = org2D.getContainerReference();
		LifeCycleTemplate template = LifeCycleHelper.service.getLifeCycleTemplate(DEFAULT_EPM_LIFECYCLE, ref);
		Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(location, ref);

		if (template == null)
			throw new WTException("Lifecycle Template can not find on wtconainer!! [DEFAULT_EPM_LIFECYCLE]=" + DEFAULT_EPM_LIFECYCLE);
		if (checkOutFolder == null)
			throw new WTException("Folder can not find on wtconainer!! [location]=" + location);

		String changedNumber = copied3D.getNumber();

		EPMDocument doc = null;

		// if( !checkExistPart(changedNumber) )
		// {
		EPMAuthoringAppType atype = EPMAuthoringAppType.toEPMAuthoringAppType("PROE");
		doc = EPMDocument.newEPMDocument();

		doc.setNumber(changedNumber + "[2D]");
		doc.setName(copied3D.getName());
		doc.setCADName((changedNumber + ".drw").toLowerCase());

		((EPMDocumentMaster) doc.getMaster()).setAuthoringApplication(EPMAuthoringAppType.toEPMAuthoringAppType("PROE"));
		((EPMDocumentMaster) doc.getMaster()).setDocType(EPMDocumentType.toEPMDocumentType("CADDRAWING"));
		((EPMDocumentMaster) doc.getMaster()).setOwnerApplication(EPMApplicationType.toEPMApplicationType("EPM"));
		((EPMDocumentMaster) doc.getMaster()).setDocSubType(EPMDocSubType.toEPMDocSubType("OTHER"));

		doc = (EPMDocument) LifeCycleHelper.setLifeCycle(doc, template);
		FolderHelper.assignLocation(doc, checkOutFolder);

		doc = (EPMDocument) PersistenceHelper.manager.save(doc);

		ContentHelper.service.copyContent(org2D, doc);
		// }
		return doc;
	}

	public void subPartStateChange(EPMDocument parent, State changingState, Hashtable cashed) throws WTException {
		if (cashed == null)
			cashed = new Hashtable();
		LatestConfigSpec spec = new LatestConfigSpec();
		QueryResult result = EPMStructureHelper.service.navigateUsesToIteration(parent, null, false, null);
		if (result != null && result.size() > 0) {
			System.out.println("## 3D sub prt change start (" + parent.getIdentity() + ") ##");
			EPMDocument aDocument = null;
			while (result.hasMoreElements()) {
				Persistable[] persist = (Persistable[]) result.nextElement();
				aDocument = (EPMDocument) persist[1];
				if (aDocument.isLatestIteration()) {
					if (cashed.get(aDocument.getNumber()) == null) {
						/*
						 * PSK���� ��ǰ��ȣ ��Ģ; ���� �ʴ� ��ǰ�� ���� State��
						 * �����Ѵ�.
						 */
						if (!(aDocument.getNumber().substring(0, 1).equals("5") && aDocument.getNumber().substring(4, 5).equals("-") && aDocument
								.getNumber().length() == 12)) {
							if (!aDocument.getLifeCycleState().equals(State.toState("PSK_D_COMPLETE"))) {
								aDocument = (EPMDocument) changeState(aDocument, State.toState(parent.getState().toString()));
								cashed.put(aDocument.getNumber(), aDocument);
								System.out.println(" - Sub 3D : " + aDocument.getIdentity());
							}
						} else {
							// aDocument = changeState(aDocument,
							// changingState);
						}
						// cashed.put(aDocument.getNumber(),
						// aDocument.getNumber());
						// this.subPartStateChange(aDocument, changingState,
						// cashed);
					}
				}
			}
			System.out.println("## 3D sub prt change end ##");
		}
	}

	public boolean isOwnDrawing(EPMDocument epm3D, EPMDocument epm2D) throws WTException {
		boolean returnFlag = true;

		String epm2DNumber = epm2D.getNumber();

		QuerySpec spec = new QuerySpec(EPMDocument.class);
		LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
		spec = latestConfigSpec.appendSearchCriteria(spec);
		QueryResult result = EPMStructureHelper.service.navigateUsedBy((EPMDocumentMaster) epm3D.getMaster(), spec, true);

		QueryResult result1 = EPMStructureHelper.service.navigateReferencesToIteration(epm2D, null, true, latestConfigSpec);

		Hashtable referCadName = new Hashtable();
		String oneReferNumber = null;
		if (VERBOSE)
			System.out.println("[2D DRAWING'S REFERNEC]VVVVVVVVVVVVVVVVVVVVVVV");
		while (result1.hasMoreElements()) {
			oneReferNumber = ((EPMDocument) result1.nextElement()).getNumber();
			if (VERBOSE)
				System.out.println("[REFER NUMBER]=" + oneReferNumber);
			referCadName.put(oneReferNumber, oneReferNumber);
		}
		if (VERBOSE)
			System.out.println("[2D DRAWING'S REFERNEC]^^^^^^^^^^^^^^^^^^^^^^^");

		if (VERBOSE)
			System.out.println("[3D DRAWING'S USED BY]VVVVVVVVVVVVVVVVVVVVVVV");
		while (result.hasMoreElements()) {
			oneReferNumber = ((EPMDocument) result.nextElement()).getNumber();
			if (VERBOSE)
				System.out.println("[USED BY NUMBER]=" + oneReferNumber);
			if (referCadName.get(oneReferNumber) != null)
				return false;
		}
		if (VERBOSE)
			System.out.println("[3D DRAWING'S USED BY]^^^^^^^^^^^^^^^^^^^^^^^");
		return returnFlag;
	}

	private void addIBAValue(Hashtable defHb, HashMap defMap, Hashtable valHb, IBAHolder part, String attName, String attValue) throws WTException {

		try {
			StringDefinition outdef = (StringDefinition) defHb.get(attName);
			if (outdef == null) {
				StringDefinition def = (StringDefinition) defMap.get(attName);
				StringValue sv = StringValue.newStringValue(def, part, attValue);
				PersistenceServerHelper.manager.insert(sv);
				System.out.println("     IBA CREATE:" + attName + "=>" + attValue);
			} else {
				StringValue sv = (StringValue) valHb.get(attName);
				sv.setValue(attValue);
				PersistenceServerHelper.manager.update(sv);
				System.out.println("     IBA UPDATE:" + attName + "=>" + attValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	static {
		try {
			WTProperties wtproperties = WTProperties.getLocalProperties();
			DEFAULT_EPM_LIFECYCLE = wtproperties.getProperty("ext.psk.cad.default_lifecycle", "LC_PSK_CAD");
			WT_HOME = wtproperties.getProperty("wt.home", "c:/ptc/Windchill");
			CAD_PART_TEMPLATE = wtproperties.getProperty("ext.psk.cad.part_template", "part_template.prt");
			CAD_ASSY_TEMPLATE = wtproperties.getProperty("ext.psk.cad.assy_template", "assy_template.asm");
			DRW_PART_TEMPLATE = wtproperties.getProperty("ext.psk.cad.drw_part_template", "part_template.drw");
			DRW_ASSY_TEMPLATE = wtproperties.getProperty("ext.psk.cad.drw_assy_template", "assy_template.drw");
			CAD_REFERENCE_LINK = wtproperties.getProperty("ext.psk.cad.epm_ref_link_type_def", "wt.epm.structure.EPMReferenceLink");
			String migState = wtproperties.getProperty("ext.psk.migration", "false");
			if (migState.equals("true"))
				MIGRATION_STATE = true;
			else
				MIGRATION_STATE = false;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// ##end user.operations
}
