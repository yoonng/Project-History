// Generated PartService%4C74DB490186: ? 08/31/10 15:39:22
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.psk.part;

import java.lang.String;
import java.util.HashMap;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
import java.io.Externalizable;  // Preserved unmodeled dependency
import java.io.IOException;  // Preserved unmodeled dependency
import java.io.ObjectInput;  // Preserved unmodeled dependency
import java.io.ObjectOutput;  // Preserved unmodeled dependency
import java.lang.ClassNotFoundException;  // Preserved unmodeled dependency
import ext.psk.part.PartHelper;  // Preserved unmodeled dependency
import wt.util.WTPropertyVetoException;  // Preserved unmodeled dependency
//##end user.imports

//##begin PartService%4C74DB490186.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end PartService%4C74DB490186.doc

@RemoteInterface
public interface PartService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createPart%4C74DBDF032C.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end createPart%4C74DBDF032C.doc

   public String createPart( HashMap form )
            throws WTException;

   //##begin updatePart%4C74DBF002EE.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end updatePart%4C74DBF002EE.doc

   public String updatePart( HashMap form )
            throws WTException;

   //##begin deletePart%4C74DBFF0399.doc preserve=no
   /**
    * @param     form
    * @return    String
    * @exception wt.util.WTException
    **/
   //##end deletePart%4C74DBFF0399.doc

   public String deletePart( HashMap form )
            throws WTException;

   //##begin searchPart%4C74DC0C01D4.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end searchPart%4C74DC0C01D4.doc

   public HashMap searchPart( HashMap form )
            throws WTException;

   //##begin viewPart%4C74DC2102DE.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end viewPart%4C74DC2102DE.doc

   public HashMap viewPart( HashMap form )
            throws WTException;

   //##begin revisePart%4C7CA3400242.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end revisePart%4C7CA3400242.doc

   public String revisePart( HashMap form )
            throws WTException;

   //##begin changeSuffixPart%4C7CA35103D8.doc preserve=no
   /**
    * @param     form
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   //##end changeSuffixPart%4C7CA35103D8.doc

   public String changeSuffixPart( HashMap form )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
