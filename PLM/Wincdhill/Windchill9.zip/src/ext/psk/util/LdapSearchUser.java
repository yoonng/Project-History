package ext.psk.util;

import java.io.*;
import java.util.*;
import com.infoengine.object.factory.Group;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Att;
import com.infoengine.SAK.IeService;
import com.infoengine.SAK.Task;
import com.infoengine.au.NamingService;
import com.infoengine.au.DirectoryService;
import wt.federation.PrincipalManager.DirContext;
import wt.util.*;
import wt.org.WTGroup;
import wt.org.WTUser;
import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPAttribute;
import netscape.ldap.LDAPAttributeSet;
import netscape.ldap.LDAPSearchResults;
import netscape.ldap.LDAPReferralException;
import netscape.ldap.LDAPv3;
import netscape.ldap.LDAPEntry;
import netscape.ldap.LDAPException;

//import netscape.ldap.controls.LDAPException;

public class LdapSearchUser {

	// 초기화된 여부
	public static boolean isInitialized = false;
	public static boolean isApplicationMode = false;

	private static IeService ie = new IeService();
	public static String defaultJndiAdapter = "";
	public static String defaultSearchBase = "";
	public static String taskRootDirectory = "";
	private static String delimiter = ";";
	public static boolean VERBOSE = false;
	static {
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 초기화 함수
	 */
	private static void initialize() throws java.io.IOException, com.infoengine.util.IEException {
		if (isInitialized == false) {
			try {
				// JNDI Adapter 관련 정보를 구한다.
				WTProperties wtproperties = WTProperties.getLocalProperties();

				NamingService ns = NamingService.getInstance();
				String name = wtproperties.getProperty("wt.federation.ie.namingService");
				String resource = wtproperties.getProperty("wt.federation.ie.propertyResource");

				if (ns == null) { // only do this once
					ns = NamingService.newInstance(name, resource);
				}

				defaultJndiAdapter = wtproperties.getProperty("wt.federation.org.defaultAdapter");

				defaultSearchBase = DirContext.getJNDIAdapterSearchBase(defaultJndiAdapter);
				if (isApplicationMode) {
					taskRootDirectory = wtproperties.getProperty("wt.federation.taskRootDirectory") + "/";
				} else {
					taskRootDirectory = "";
				}
				isInitialized = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Vector getGroupUserInfo(String groupName, String groupCode, String positionName, String userName, Vector userVec) throws WTException {
		try {
			initialize();
			System.out.println("groupName--" + groupName + "  groupCode--" + groupCode + "  userName--" + userName + "   positionName--"
					+ positionName);
			Task task = null;
			task = new Task("com/SearchUserService.xml");
			task.addParam("instance", defaultJndiAdapter);
			task.addParam("base", defaultSearchBase);
			task.addParam("scope", "SUBTREE");

			/*
			 * if(userName.equals("")){ if(groupName.equals("")){
			 * task.addParam("filter", "(plmPosition="+positionName+")"); }else
			 * if(positionName.equals("")){ task.addParam("filter",
			 * "(plmTeamName=*" + groupName + "*)"); }else{
			 * task.addParam("filter", "(&(plmTeamName=" + groupName +
			 * ")(plmPosition="+positionName+"))"); } }else{
			 * if(groupName.equals("")){ task.addParam("filter",
			 * "(|(plmKName=*"+userName+"*)(plmSabun="+userName+")*)"); }else{
			 * task.addParam("filter",
			 * "(|(|(plmKName=*"+userName+"*)(plmSabun="+
			 * userName+"*))(plmTeamName=*"+groupName+"*))"); } }
			 */

			task.addParam(
					"attribute",
					"plmSabun,plmKName,plmEName,plmCName,plmTelNumber,plmKAddr,plmEAddr,plmCAddr,plmEMail,plmTeamName,plmTeamCode,plmDivision,plmIsVendor,plmSecureID,plmPosition,plmRole,plmLocale,plmPassword,plmOrg,plmTeamCode,plmUpdateDate");
			task.addParam("group_out", "groupOut");
			task.invoke();

			Group group = task.getGroup("groupOut");

			// System.out.println("group.getElementCount()--->"+group.getElementCount());
			if (group.getElementCount() < 1)
				return userVec;

			if (VERBOSE)
				group.toXML(new java.io.PrintWriter(System.out), true);

			int size = group.getElementCount();
			for (int i = 0; i < size; i++) {
				Element element = group.getElementAt(i);
//				UserInfo info = new UserInfo();
//
//				String str = (String) element.getValueAt("plmSabun", 0);
//				if (str == null || str.equals(""))
//					str = " ";
//				info.setPlmSabun(str);
//
//				str = (String) element.getValueAt("plmUpdateDate", 0);
//				if (str == null || str.equals(""))
//					str = " ";
//				info.setPlmUpdateDate(str);
//
//				userVec.addElement(info);

			}

			return userVec;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new WTException(ex);
		}

	}

	public static String searchUserInfofromLDAP(String fullName) {
		String userId = "N/A";
		try {
			initialize();
			System.out.println("defaultJndiAdapter=" + defaultJndiAdapter);
			System.out.println("defaultSearchBase=" + defaultSearchBase);
			

			Task task = null;
			task = new Task("com/SearchUserService.xml");
			task.addParam("instance", defaultJndiAdapter);
			task.addParam("base", defaultSearchBase);
			task.addParam("scope", "SUBTREE");
			task.addParam("filter", "cn=" + fullName );
			//task.addParam("attribute", "plmSabun");
			task.addParam("group_out", "groupOut");
			task.invoke();

			Group group = task.getGroup("groupOut");
			String tmpStr = "";
			
			//if( group.getElementCount() != null ) 
//				System.out.println(" group.getElementCount() = " + group.getElementCount());

			if (group.getElementCount() > 0) {
				int size = group.getElementCount();
				for (int i = 0; i < size; i++) {
					Element element = group.getElementAt(i);
					
					//System.out.println("element=" + element.toString());
					
					String str = (String) element.getValueAt("uid", 0);
					if (str != null && !str.equals(""))
						userId = str;				
//
//					System.out.println("element uid=" + element.getValue("uid"));
//
//					System.out.println("element=" + element.toString());
//					
//					System.out.println("@@@ i=" + i + " ,,,,, " + userId);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return userId;
	}

}
