package ext.psk.util;

import java.rmi.RemoteException;
import java.security.AccessController;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.SimpleTimeZone;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.Vector;

import ext.psk.common.PSKUserInfo;

//import ext.psk.org.PSKGroup;
//import ext.psk.org.PSKOrgHelper;
//import ext.psk.workflow.PSKWorkStepApproval;
//import ext.psk.workflow.PSKWorkStepMultiApproval;

import sun.security.action.GetPropertyAction;
import wt.access.NotAuthorizedException;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.URLData;
import wt.doc.WTDocumentMasterIdentity;
import wt.fc.IconDelegate;
import wt.fc.IconDelegateFactory;
import wt.fc.IdentificationObject;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.folder.CabinetBased;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.FolderNotFoundException;
import wt.httpgw.URLFactory;
import wt.iba.definition.IBADefinitionException;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.PhaseLink;
import wt.lifecycle.PhaseTemplate;
import wt.lifecycle.State;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMasterIdentity;
import wt.pds.oracle81.OraclePds81;
import wt.query.ClassAttribute;
import wt.query.ColumnExpression;
import wt.query.ConstantExpression;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.team.TeamTemplate;
import wt.util.IconSelector;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.VersionForeignKey;
import wt.vc.VersionReference;
import wt.vc.config.LatestConfigSpec;

public class CommonUtil {
	private static ReferenceFactory rf = null;
	
	public static final String SUCC = "SUCCESS";
	public static final String FAIL = "Fail";

	/**
	 * 
	 */
	private CommonUtil() {
	}

	/**
	 * 
	 */
	public static String getOIDString(Persistable per) {
		if (per == null)
			return null;
		return PersistenceHelper.getObjectIdentifier(per).getStringValue();
	}

	public static String getFullOIDString(Persistable persistable) {
		try {
			if (rf == null)
				rf = new ReferenceFactory();
			return rf.getReferenceString(rf.getReference(persistable));
		} catch (Exception e) {
			return null;
		}
	}

	public static long getOIDLongValue(String oid) {
		String tempoid = oid;
		tempoid = tempoid.substring(tempoid.lastIndexOf(":") + 1);
		return Long.parseLong(tempoid);
	}

	public static long getOIDLongValue(Persistable per) {
		String tempoid = getOIDString(per);
		tempoid = tempoid.substring(tempoid.lastIndexOf(":") + 1);
		return Long.parseLong(tempoid);
	}

	/**
	 * VR oid
	 * 
	 * @param oid
	 * @return
	 */
	public static String getVROID(String oid) {
		Object obj = getObject(oid);
		if (obj == null)
			return null;
		return getVROID((Persistable) getObject(oid));
	}

	private static String getVRString(WTReference wtRef) throws WTException {
		VersionReference verRef = (VersionReference) wtRef;
		VersionForeignKey verForeignKey = (VersionForeignKey) verRef.getKey();
		return "VR:" + verRef.getKey().getClassname() + ":"
				+ verForeignKey.getBranchId();
	}

	/**
	 * VR oid
	 * 
	 * @param persistable
	 * @return
	 */
	public static String getVROID(Persistable persistable) {

		if (persistable == null)
			return null;
		try {
			if (rf == null)
				rf = new ReferenceFactory();
			return getVRString(rf.getReference(persistable));
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * OID
	 */
	public static Persistable getObject(String oid) {
		if (oid == null)
			return null;
		try {
			if (rf == null)
				rf = new ReferenceFactory();
			return rf.getReference(oid).getObject();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 *
	 */
	public static boolean isAdmin() throws Exception {
		return isMember("Administrators");
	}

	/**
	 *
	 */
	public static boolean isMember(String group) throws Exception {
		WTUser user = (wt.org.WTUser) SessionHelper.manager.getPrincipal();
		return isMember(group, user);
	}

	public static boolean isMember(String group, WTUser user) throws Exception {
		Enumeration en = user.parentGroupNames();
		while (en.hasMoreElements()) {
			String st = (String) en.nextElement();
			if (st.equals(group))
				return true;
		}
		return false;
	}

	/**
	 *
	 * 
	 * @return <code>java.lang.String</code>
	 */
	public static String getTempDir() {
		GetPropertyAction getpropertyaction = new GetPropertyAction(
				"java.io.tmpdir");
		String tmpdir = (String) AccessController
				.doPrivileged(getpropertyaction);
		return tmpdir;
	}

	/**
	 * @param :
	 *            String
	 * @return : String
	 * @author : PTC KOREA Yang Kyu
	 * @since : 2004.01
	 */
	public static WTUser findUserID(String userID) throws WTException {
		WTUser wtuser = (WTUser) OrganizationServicesHelper.manager
				.getAuthenticatedUser(userID);
		return wtuser;
	}

	public static String getUserIDFromSession() throws WTException {
		return ((WTUser) SessionHelper.manager.getPrincipal()).getName();
	}

	public static String getUsernameFromSession() throws WTException {
		return ((WTUser) SessionHelper.manager.getPrincipal()).getFullName();
	}

	public static String findUserName(String userID) throws WTException {
		String userName = "";
		WTUser wtuser = (WTUser) OrganizationServicesHelper.manager
				.getAuthenticatedUser(userID);
		userName = wtuser.getFullName();
		return userName;
	}

	public static TreeMap getUsers() throws WTException {
		QuerySpec query = new QuerySpec(WTUser.class);
		query
				.appendWhere(new SearchCondition(WTUser.class, "disabled",
						"FALSE"));

		QueryResult result = PersistenceHelper.manager.find(query);

		TreeMap userTree = new TreeMap();
		while (result.hasMoreElements()) {
			wt.org.WTUser wtuser = (wt.org.WTUser) result.nextElement();
			userTree.put(wtuser.getFullName(), wtuser.getName());
		}
		return userTree;
	}

	public static Vector removeDuplicate(Vector duplicateVector)
			throws Exception {
		HashSet hashset = new HashSet();
		Vector vec1 = new Vector();

		for (int i = 0; i < duplicateVector.size(); i++) {
			Persistable persistable = (Persistable) duplicateVector.get(i);
			ObjectIdentifier objectidentifier = PersistenceHelper
					.getObjectIdentifier(persistable);

			if (!hashset.contains(objectidentifier)) {
				hashset.add(objectidentifier);
				vec1.addElement(persistable);
			}
		}
		return vec1;
	}

	public static String getIconResource(WTObject wtobject) throws Exception {
		String s = null;
		IconDelegateFactory icondelegatefactory = new IconDelegateFactory();
		IconDelegate icondelegate = icondelegatefactory
				.getIconDelegate(wtobject);
		IconSelector iconselector;
		for (iconselector = icondelegate.getStandardIconSelector(); !iconselector
				.isResourceKey(); iconselector = icondelegate
				.getStandardIconSelector())
			icondelegate = icondelegate.resolveSelector(iconselector);

		s = "/" + iconselector.getIconKey();
		return s;
	}

	public static String getSeqNo(String seqName, String format,
			String tabName, String colName) {
		String result = "";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT MAX(" + colName + ") no FROM " + tabName
					+ " WHERE " + colName + " LIKE '" + seqName + "%'";
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				if (rs.getString("no") == null)
					result = "1";
				else {
					String no = rs.getString("no");
					System.out
							.println("ManageSequence::getSeqNo:no.substring() = "
									+ no.substring(seqName.length()));
					result = ""
							+ (Integer.parseInt(no.substring(seqName.length())) + 1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(Long.parseLong(result));
	}

	public static int getMaxNo(String tabName, String colName) {

		int result = 1;

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT MAX(" + colName + ") no FROM " + tabName;
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				result = rs.getInt("no") + 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public static String getDateCountNo(String tabName, String colName,
			String simpledateformat, String szdate, String format,
			String col2Name, String col2Val) {

		String result = "1";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT count(" + colName + ") no FROM " + tabName
					+ " WHERE to_char(" + colName + ",'" + simpledateformat
					+ "')='" + szdate + "'";
			if (!col2Name.equals(""))
				sql = sql + " AND " + col2Name + "='" + col2Val + "'";
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				result = Integer.toString(rs.getInt("no") + 1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(Long.parseLong(result));

	}

	public static String getDateCountNoForLike(String tabName, String colName,
			String simpledateformat, String szdate, String format,
			String col2Name, String col2Val, String maxCol) {

		String result = "1";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT max(" + maxCol + ") no FROM " + tabName
					+ " WHERE to_char(" + colName + ",'" + simpledateformat
					+ "')='" + szdate + "'";
			if (!col2Name.equals(""))
				sql = sql + " AND " + col2Name + " like '" + col2Val + "%'";
			System.out.println("SQL:" + sql);
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				String tmpstr = rs.getString("no");
				if (tmpstr != null) {
					if (tmpstr.length() > (format.length() - 1)) {
						tmpstr = tmpstr.substring(tmpstr.length()
								- format.length(), tmpstr.length());
					}
					int rInt = Integer.parseInt(tmpstr);
					result = Integer.toString(rInt + 1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(Long.parseLong(result));

	}

	public static String getDateCountNoForDept(String docno, String format) {

		String result = "1";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			// SELECT max(WTDOCUMENTNUMBER) no FROM WTDOCUMENTMASTER WHERE
			// WTDOCUMENTNUMBER like 'P-2000-070913-%'
			String sql = "SELECT max(WTDOCUMENTNUMBER) no FROM WTDOCUMENTMASTER WHERE WTDOCUMENTNUMBER like '"
					+ docno + "%'";
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				String tmpstr = rs.getString("no");
				if (tmpstr != null) {
					if (tmpstr.length() > (format.length() - 1)) {
						tmpstr = tmpstr.substring(tmpstr.length()
								- format.length(), tmpstr.length());
					}
					int rInt = Integer.parseInt(tmpstr);
					result = Integer.toString(rInt + 1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(Long.parseLong(result));

	}

	public static String getDateCountNo(String tabName, String colName,
			String simpledateformat, String szdate, String format) {
		return getDateCountNo(tabName, colName, simpledateformat, szdate,
				format, "", "");
	}

	/**
	 *
	 * 
	 * @param data
	 *            <code>java.lang.String</code> Target String
	 * @param defaultData
	 *            <code>int</code> default value
	 * @return <code>int</code>
	 */
	public static int parseInt(String data, int defaultData) {
		try {
			return Integer.parseInt(data);
		} catch (Exception e) {
			return defaultData;
		}
	}

	public static int getIntParameter(String str, int ifNulltoReplace) {
		try {
			if (str == null || str.equals(""))
				return ifNulltoReplace;
			else
				return Integer.parseInt(str.toString());
		} catch (NumberFormatException e) {
			return ifNulltoReplace;
		}
	}

	/**
	 *
	 * 
	 * @param sVal
	 */
	public static String checkNull(String sVal) {
		String sResult = "";

		if (sVal == null)
			return sResult;
		else
			sResult = sVal.trim();

		return sResult;
	}
	
	/**
	 * splitter
	 * 
	 * @param strValue
	 * @param splitter
	 * @return
	 */
	public static Vector getSplitStringVector(String strValue, String splitter) {
		if (strValue == null || strValue.length() == 0)
			return null;

		if (splitter == null)
			return null;

		StringTokenizer split = new StringTokenizer(strValue, splitter);
		Vector strList = new Vector();
		while (split.hasMoreTokens()) {
			strList.addElement(new String(split.nextToken().trim()));
		}
		return strList;
	}

	/**
	 * 
	 * @param strValue
	 * @param splitter
	 * @return
	 */
	public static Vector getSplitAllStringVector(String strValue,
			String splitter) {
		Vector strList = new Vector();

		if (strValue == null || strValue.length() == 0 || splitter == null
				|| splitter == null) {
			return strList;
		}

		int nOrd = strValue.indexOf(splitter);
		while (nOrd != -1) {
			String splitWord = strValue.substring(0, nOrd);
			splitWord = splitWord.trim();

			if (splitWord.startsWith("\"") && splitWord.endsWith("\"")) {
				splitWord = splitWord.substring(1, splitWord.length() - 1);
			}
			strList.addElement(new String(splitWord));
			int lastOrd = nOrd + splitter.length();
			strValue = strValue.substring(lastOrd);
			nOrd = strValue.indexOf(splitter);
		}
		strValue = strValue.trim();
		if (strValue.startsWith("\"") && strValue.endsWith("\"")) {
			strValue = strValue.substring(1, strValue.length() - 1);
		}
		strList.addElement(new String(strValue));

		return strList;
	}

	/**
	 * 
	 * @param _type
	 * @return
	 */
	public static String getTitle(String _type) {
		String title = null;
		if ("product".equals(_type))
			title = "get Title";
		else if ("part".equals(_type))
			title = "oart title";
		return title;
	}

	public static Timestamp formatString2Timestamp(String dateString,
			String format) throws java.text.ParseException {
		if (dateString == null || "".equals(dateString))
			return null;

		return formatString2Timestamp(dateString, format, null, false);
	}

	/*
	 */
	public static Timestamp formatString2Timestamp(String dateString,
			String format, TimeZone timeZone, boolean maxOfDay)
			throws java.text.ParseException {

		if (timeZone == null)
			timeZone = (TimeZone) wt.util.WTContext.getContext()
					.get("timezone");

		if (timeZone == null)
			if (timeZone == null)
				timeZone = wt.util.WTContext.getContext().getTimeZone();

		SimpleDateFormat sdf = new SimpleDateFormat(format);

		// Calendar cal = Calendar.getInstance();
		// cal.setTimeZone(timeZone);
		// sdf.setCalendar(cal);

		Date date = sdf.parse(dateString);

		long off = TimeZone.getDefault().getRawOffset();

		Timestamp t;
		if (maxOfDay)
			t = new Timestamp(date.getTime() + (24 * 3600 * 1000));// - off);
		else
			t = new Timestamp(date.getTime());// - off);

		return t;
	}

	/**
	 * 
	 * @param timeDate
	 * @param sFormat
	 * @return 
	 */
	public static String getTimeToString(java.util.Date timeDate, String sFormat) {
		TimeZone tz = TimeZone.getDefault();
		String defaultZone = tz.getID(); // "Asia/Seoul"
		return getTimeToString(timeDate, sFormat, defaultZone);
	}

	/**
	 * 
	 * @param timeDate
	 * @param sFormat
	 * @param tzString
	 * @return
	 */
	public static String getTimeToString(java.util.Date timeDate,
			String sFormat, String tzString) {
		if (timeDate == null) {
			return "";
		}

		if (sFormat == null || sFormat.length() == 0) {
			sFormat = "yyyy-MM-dd HH:mm:ss";
		}

		TimeZone tz = null;
		if (tzString == null || tzString.length() == 0) {
			tz = TimeZone.getDefault();
		} else {
			tz = TimeZone.getTimeZone(tzString);
		}

		String retString = "";

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(sFormat);
			SimpleTimeZone stz = new SimpleTimeZone(tz.getRawOffset(), tz
					.getID());
			sdf.setTimeZone(stz);
			retString = sdf.format(timeDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return retString;
	}

	/**
	 * 
	 * @param sDateStr
	 * @param sFormat
	 * @return Timestamp
	 * @exception Exception
	 * @author OH SE YOUNG 2006.02.16
	 */
	public static Timestamp str2Timestamp(String sDateStr, String sFormat)
			throws Exception {

		try {

			if (sDateStr == null || sDateStr.equals(""))
				return null;

			SimpleDateFormat oSimpleDateFormat = new SimpleDateFormat(sFormat);
			TimeZone oTimeZone = TimeZone.getTimeZone("GMT");
			GregorianCalendar oGregorianCalendar = new GregorianCalendar(
					oTimeZone);

			oSimpleDateFormat.setCalendar(oGregorianCalendar);
			Date dDate = oSimpleDateFormat.parse(sDateStr);

			return new Timestamp(dDate.getTime());

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * 
	 * @param format
	 * @return String
	 */
	public static String getCurrentTime(String format) {
		java.util.Date today = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(today);
	}

	/**
	 * @param oid
	 * @param name
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 */
	public static void changeName(String oid, String name) throws WTException,
			WTPropertyVetoException {
		name = name.trim();
		CabinetBased cabinetbased = (CabinetBased) CommonUtil.getObject(oid);
		changeName(cabinetbased, name);
	}

	/**
	 * @param cabintebased
	 * @param name
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 */
	public static void changeName(CabinetBased cabinetbased, String name)
			throws WTException, WTPropertyVetoException {
		name = name.trim();
		IdentificationObject obj = ((Identified) ((Iterated) cabinetbased)
				.getMaster()).getIdentificationObject();
		boolean flag = !name.equals(cabinetbased.getName())
				&& name.length() != 0;

		if (obj instanceof WTDocumentMasterIdentity) {
			String tempNumber = ((WTDocumentMasterIdentity) obj).getNumber();
			if (flag)
				((WTDocumentMasterIdentity) obj).setName(name);
		} else if (obj instanceof WTPartMasterIdentity) {
			String tempNumber = ((WTPartMasterIdentity) obj).getNumber();
			if (flag)
				((WTPartMasterIdentity) obj).setName(name);
		}
		if (flag) {
			IdentityHelper.service.changeIdentity(
					(Identified) ((Iterated) cabinetbased).getMaster(), obj);
		}
	}

	public static String changeFormatString(int indata, String format) {

		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(indata);

	}

//	public static String getGroupName(String userId) throws WTException {
//		String groupName = "";
//		ReferenceFactory rf = new ReferenceFactory();
//		WTUser user = (WTUser) rf.getReference(userId).getObject();
//		user.get
//		WTGroup group = (WTGroup) PSKOrgHelper.service.getLocalGroup(user);
//		if (group != null) {
//			groupName = group.getGroupName();
//		}
//		return groupName;
//	}
//
//	public static String getGroupCode(String userId) throws WTException {
//		String groupCode = "";
//		ReferenceFactory rf = new ReferenceFactory();
//		WTUser user = (WTUser) rf.getReference(userId).getObject();
//		PSKGroup group = (PSKGroup) PSKOrgHelper.service.getLocalGroup(user);
//		if (group != null) {
//			groupCode = group.getGroupCode();
//		}
//		return groupCode;
//	}

	/**
	 * 
	 * @param _query
	 * @param _target
	 * @param _idx
	 * @throws IBADefinitionException
	 * @throws NotAuthorizedException
	 * @throws RemoteException
	 * @throws WTException
	 * @throws QueryException
	 * @throws WTPropertyVetoException
	 */
	public static void addLastVersionCondition(QuerySpec _query, Class _target,
			int _idx) throws IBADefinitionException, NotAuthorizedException,
			RemoteException, WTException, QueryException,
			WTPropertyVetoException {
		AttributeDefDefaultView aview = IBADefinitionHelper.service
				.getAttributeDefDefaultViewByPath("LatestVersionFlag");
		if (aview != null) {
			if (_query.getConditionCount() > 0)
				_query.appendAnd();

			int idx = _query.appendClassList(StringValue.class, false);
			SearchCondition sc = new SearchCondition(new ClassAttribute(
					StringValue.class, "theIBAHolderReference.key.id"), "=",
					new ClassAttribute(_target,
							"thePersistInfo.theObjectIdentifier.id"));
			sc.setFromIndicies(new int[] { idx, _idx }, 0);
			sc.setOuterJoin(0);
			_query.appendWhere(sc, new int[] { idx, _idx });
			_query.appendAnd();
			sc = new SearchCondition(StringValue.class,
					"definitionReference.hierarchyID", "=", aview
							.getHierarchyID());
			_query.appendWhere(sc, new int[] { idx });
			_query.appendAnd();
			sc = new SearchCondition(StringValue.class, "value2", "=", "true");
			_query.appendWhere(sc, new int[] { idx });
		}
	}

	/**
	 * Get SecondaryContents from ContentHolder
	 * 
	 * @param :
	 *            FormatContentHolder
	 * @return : Vector(ContentInfo)
	 * @since : 2005.08
	 */
	public static Vector getSecondaryContents(ContentHolder holder) {
		Vector returnVec = new Vector();
		try {
			QueryResult result = ContentHelper.service.getContentsByRole(
					holder, ContentRoleType.SECONDARY);
			while (result.hasMoreElements()) {
				ContentItem item = (ContentItem) result.nextElement();
				returnVec.add(getContentInfo(holder, item));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnVec;
	}

	public static ContentInfo getContentInfo(ContentHolder holder,
			ContentItem item) throws WTException {
		ContentInfo info = null;
		if (item instanceof URLData) {
			URLData url = (URLData) item;
			info = new ContentInfo();
			info.setType("URL");
			info.setContentOid(url.toString());
			info.setName(url.getUrlLocation());
			info.setIconURLStr(getContentIconStr(url));
			info.setDescription(url.getDescription());
		} else if (item instanceof ApplicationData) {
			ApplicationData file = (ApplicationData) item;
			info = new ContentInfo();
			info.setType("FILE");
			info.setContentOid(file.toString());
			info.setName(file.getFileName());
			info.setDescription(file.getDescription());
			info.setDownURL(ContentHelper.getDownloadURL(holder, file));
			info.setIconURLStr(getContentIconStr(file));
			info.setFileSize(file.getFileSize());
			info.setBusinessType(file.getBusinessType());
		}
		return info;
	}

	public static String getContentIconStr(ContentItem item) throws WTException {
		URLFactory urlFac = new URLFactory();
		String iconStr = "";
		if (item instanceof URLData) {
			iconStr = urlFac.getBaseURL().getPath()
					+ "portal/icon/fileicon/link.gif";
		} else if (item instanceof ApplicationData) {
			ApplicationData data = (ApplicationData) item;

			String extStr = "";
			String tempFileName = data.getFileName();
			int dot = tempFileName.lastIndexOf(".");
			if (dot != -1)
				extStr = tempFileName.substring(dot + 1); // includes
			// "."

			if (extStr.equalsIgnoreCase("cc"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/ed.gif";
			else if (extStr.equalsIgnoreCase("exe"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/exe.gif";
			else if (extStr.equalsIgnoreCase("doc"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/doc.gif";
			else if (extStr.equalsIgnoreCase("ppt"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/ppt.gif";
			else if (extStr.equalsIgnoreCase("xls"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/xls.gif";
			else if (extStr.equalsIgnoreCase("csv"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/xls.gif";
			else if (extStr.equalsIgnoreCase("txt"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/notepad.gif";
			else if (extStr.equalsIgnoreCase("mpp"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/mpp.gif";
			else if (extStr.equalsIgnoreCase("pdf"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/pdf.gif";
			else if (extStr.equalsIgnoreCase("tif"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/tif.gif";
			else if (extStr.equalsIgnoreCase("gif"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/gif.gif";
			else if (extStr.equalsIgnoreCase("jpg"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/jpg.gif";
			else if (extStr.equalsIgnoreCase("ed"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/ed.gif";
			else if (extStr.equalsIgnoreCase("zip"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/zip.gif";
			else if (extStr.equalsIgnoreCase("tar"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/zip.gif";
			else if (extStr.equalsIgnoreCase("rar"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/zip.gif";
			else if (extStr.equalsIgnoreCase("jar"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/zip.gif";
			else if (extStr.equalsIgnoreCase("igs"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("pcb"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("asc"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("dwg"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("dxf"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("sch"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/epmall.gif";
			else if (extStr.equalsIgnoreCase("html"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/htm.gif";
			else if (extStr.equalsIgnoreCase("htm"))
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/htm.gif";
			else
				iconStr = urlFac.getBaseURL().getPath()
						+ "portal/icon/fileicon/generic.gif";
		} else {
			return null;
		}
		iconStr = "<img src='" + iconStr + "' border=0>";
		return iconStr;
	}

//	public static String getTimeStampString(PSKWorkStepApproval workapproval) {
//		Timestamp ts = workapproval.getCompleteDate();
//		SimpleDateFormat dformat = new SimpleDateFormat("yyyy/MM/dd");
//		String retstr = "";
//		if (workapproval.isVoteFlag())
//			retstr = "<font color='blue'>ACCEPT</font>";
//		else
//			retstr = "<font color='red'>REJECT</font>";
//		retstr = retstr + "<br>" + dformat.format(ts);
//		dformat = new SimpleDateFormat("HH:mm:ss");
//		retstr = retstr + "<br>" + dformat.format(ts);
//		return retstr;
//	}
//
//	public static String getTimeStampString(
//			PSKWorkStepMultiApproval workapproval) {
//		Timestamp ts = workapproval.getCompleteDate();
//		SimpleDateFormat dformat = new SimpleDateFormat("yyyy/MM/dd");
//		String retstr = "";
//		if (workapproval.isVoteFlag())
//			retstr = "<font color='blue'>OK</font>";
//		else
//			retstr = "<font color='red'>NG</font>";
//		retstr = retstr + "<br>" + dformat.format(ts);
//		dformat = new SimpleDateFormat("HH:mm:ss");
//		retstr = retstr + "<br>" + dformat.format(ts);
//		return retstr;
//	}
//
//	public static String getTimeStampStrings(
//			PSKWorkStepMultiApproval workapproval) {
//		Timestamp ts = workapproval.getCompleteDate();
//		SimpleDateFormat dformat = new SimpleDateFormat("yyyy/MM/dd");
//		String retstr = "";
//		if (workapproval.isVoteFlag())
//			retstr = "<font color='blue'>OK</font>";
//		else
//			retstr = "<font color='red'>N/A</font>";
//		retstr = retstr + "<br>" + dformat.format(ts);
//		dformat = new SimpleDateFormat("HH:mm:ss");
//		retstr = retstr + "<br>" + dformat.format(ts);
//		return retstr;
//	}

	/**
	 * 
	 * (targetClass, column 
	 * strCaseCondition(targetClass.class, columnKey,
	 * SearchCondition.LIKE)
	 * 
	 * @author : kiskim@e3ps.com
	 * @since : 2007.08.13
	 */
	public static SearchCondition getSCSQLFunction(Class targetClass,
			String key, String keyValue, String strCase, String condition) {
		SearchCondition sc = null;
		try {
			ClassAttribute attribute = new ClassAttribute(targetClass, key);
			SQLFunction function = SQLFunction.newSQLFunction(strCase);
			function.setArgumentAt((ColumnExpression) attribute, 0);
			ConstantExpression expression = new ConstantExpression((Object)keyValue);
			sc = new SearchCondition(function, condition, expression);
		} catch (QueryException e) {
			e.printStackTrace();
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sc;
	}

	/**
	 * 
	 * @param ibaHolder
	 * @return key:attr_name,value:attr_value
	 * @throws RemoteException
	 * @throws WTException
	 */
	public static HashMap getAttributes(IBAHolder ibaHolder)
			throws RemoteException, WTException {
		IBAHolder iba = IBAValueHelper.service.refreshAttributeContainer(
				ibaHolder, null, null, null);
		DefaultAttributeContainer container = (DefaultAttributeContainer) iba
				.getAttributeContainer();
		HashMap hash = new HashMap();
		if (container == null)
			return hash;

		AbstractValueView[] avv = container.getAttributeValues();
		for (int i = 0; i < avv.length; i++) {
			if (avv[i] instanceof StringValueDefaultView) {
				StringValueDefaultView sv = (StringValueDefaultView) avv[i];
				hash.put(sv.getDefinition().getName(), sv.getValueAsString());
			} else if (avv[i] instanceof FloatValueDefaultView) {
				FloatValueDefaultView fv = (FloatValueDefaultView) avv[i];
				hash.put(fv.getDefinition().getName(), fv.getValueAsString());
			} else if (avv[i] instanceof TimestampValueDefaultView) {
				TimestampValueDefaultView fv = (TimestampValueDefaultView) avv[i];
				hash.put(fv.getDefinition().getName(), fv.getValueAsString()
						.substring(0, 10));
			}
		}
		return hash;
	}

	public static Timestamp convertDate(String str) {
		if (str == null || str.length() == 0)
			return null;
		Timestamp convertDate = (new Timestamp(new SimpleDateFormat(
				"yyyy/MM/dd:HH-mm-ss").parse(str + ":12-59-59",
				new ParsePosition(0)).getTime()));
		return convertDate;
	}

	public static Timestamp convertStartDate(String str) {
		if (str == null || str.length() == 0)
			return null;
		Timestamp convertDate = (new Timestamp(new SimpleDateFormat(
				"yyyy/MM/dd").parse(str, new ParsePosition(0)).getTime()));
		return convertDate;
	}

	public static Timestamp convertEndDate(String str) {
		if (str == null || str.length() == 0)
			return null;
		Timestamp convertDate = (new Timestamp(new SimpleDateFormat(
				"yyyy/MM/dd:HH-mm-ss").parse(str + ":23-59-59",
				new ParsePosition(0)).getTime()));
		return convertDate;
	}

	/**
	 * Get State form Lifecycle Name
	 * 
	 * @param :
	 *            lcName
	 * @return : Vector
	 */
	public static Vector getLifecycleStates(String lcName) throws Exception {
		Vector vec = new Vector();
		QuerySpec query = new QuerySpec();

		int phaseIndex = query.appendClassList(PhaseTemplate.class, true);
		int lcIndex = query.appendClassList(LifeCycleTemplate.class, false);
		int linkIndex = query.appendClassList(PhaseLink.class, false);

		query.appendJoin(linkIndex, "template", lcIndex);
		query.appendJoin(linkIndex, "phase", phaseIndex);

		query.appendWhere(new SearchCondition(LifeCycleTemplate.class,
				"master>name", "=", lcName), new int[] { lcIndex });
		query.appendAnd();
		query.appendWhere(new SearchCondition(LifeCycleTemplate.class,
				"iterationInfo.latest", "TRUE"), new int[] { lcIndex });

		SearchUtil.setOrderBy(query, PhaseTemplate.class, phaseIndex, "name",
				"name", false);

		QueryResult result = PersistenceHelper.manager.find(query);
		while (result.hasMoreElements()) {
			Object[] object = (Object[]) result.nextElement();

			PhaseTemplate phase = (PhaseTemplate) object[0];
			State state = phase.getPhaseState();
			vec.add(state);
		}
		return vec;
	}

	public static TeamTemplate getTeamTemplate(String mTeamName) throws WTException {
		TeamTemplate teamTemplate = null;
		QuerySpec qt = new QuerySpec(TeamTemplate.class);
		SearchCondition sc = new SearchCondition(TeamTemplate.class, TeamTemplate.NAME, SearchCondition.EQUAL, mTeamName);
		qt.appendSearchCondition(sc);
		QueryResult qr = (QueryResult) PersistenceHelper.manager.find(qt);

		System.out.println("query:" + qt);
		while (qr.hasMoreElements()) {
			teamTemplate = (TeamTemplate) qr.nextElement();
		}
		return teamTemplate;
	}
	
	public static String getGroupNameFromSession() throws WTException {
		String groupName = "N/A";
		
		try {
			WTUser wtUser = CommonUtil.findUserID(getUserIDFromSession());
	
			Enumeration enumss = wtUser.parentGroupObjects();
			if( enumss != null )
			while( enumss.hasMoreElements()) {
				WTPrincipal wtp = (WTPrincipal)enumss.nextElement();
				if( wtp instanceof WTGroup ) {
					WTGroup subb = (WTGroup)wtp;
					if( subb.getName().startsWith("1") && !subb.getDescription().equals("PSK")) {
						groupName = subb.getDescription();
					}
				}
			}
		
		} catch(Exception err) {
			err.printStackTrace();
		}
		
		return groupName;
	}

	public static String getGroupName(String userID) throws WTException {
		String groupName = "N/A";
		
		try {
			WTUser wtUser = CommonUtil.findUserID(userID);
	
			Enumeration enumss = wtUser.parentGroupObjects();
			if( enumss != null )
			while( enumss.hasMoreElements()) {
				WTPrincipal wtp = (WTPrincipal)enumss.nextElement();
				if( wtp instanceof WTGroup ) {
					WTGroup subb = (WTGroup)wtp;
					if( subb.getName().startsWith("1") && !subb.getDescription().equals("PSK")) {
						groupName = subb.getDescription();
					}
				}
			}
		
		} catch(Exception err) {
			err.printStackTrace();
		}
		
		return groupName;
	}
	

	public static WTUser getSWCCB() throws Exception {
		WTGroup swccb = (WTGroup)OrganizationServicesHelper.manager.getPrincipal("SWCCB", 
				OrganizationServicesHelper.manager.getDefaultDirectoryService());
		
	    Enumeration memss = swccb.members();
	    WTUser mem = null;

		while(memss.hasMoreElements()) {
			mem = (WTUser)memss.nextElement();
		}
		
		return mem;
	}

	public static WTUser getMCCB() throws Exception {
		WTGroup mccb = (WTGroup)OrganizationServicesHelper.manager.getPrincipal("MCCB", 
				OrganizationServicesHelper.manager.getDefaultDirectoryService());
	
		Enumeration memss = mccb.members();
	    WTUser mem = null;
	
		while(memss.hasMoreElements()) {
			mem = (WTUser)memss.nextElement();
		}
		
		return mem;
	}
	
	public static String getSeq(String seqName) throws Exception {
		java.text.DecimalFormat df = new java.text.DecimalFormat("000");
        Long serialL = Long.valueOf(wt.fc.PersistenceHelper.manager.getNextSequence(seqName));
        
        return df.format(serialL.longValue());
	}

	public static String getSeqDMU(String seqName) throws Exception {
		java.text.DecimalFormat df = new java.text.DecimalFormat("00000");
        Long serialL = Long.valueOf(wt.fc.PersistenceHelper.manager.getNextSequence(seqName));
        
        return df.format(serialL.longValue());
	}
	
	public static Timestamp getCurrentTimestamp() throws Exception {
		Date today = new Date();
		return new Timestamp(today.getTime());
		
	}
	
	//Kim Tae Hyun Append Start
	public static String getContext(String con) {
		String strTemp1 = con;
		String strTemp2 = "";
		int i =0;	

		try {				
			if(strTemp1 != null && strTemp1.equals("")){				
			}else {
				java.util.StringTokenizer token = new java.util.StringTokenizer(strTemp1,"\n");
				while(token.hasMoreElements()) {
					strTemp2 = strTemp2 + token.nextToken()+"<br>";
					i++;
				}
			}
		}catch(Exception e) {
			strTemp2 = strTemp1;
		}
		return strTemp2;
	}
	
	public static String strLengthLimite(String str, int length){
		String retValue =null;
		try {
			if(str.indexOf("</") < 0 ) {
				if(str.length() >= length){
					retValue = str.substring(0,length) + "...";	
				}else {
					retValue = str;
				}
			} else {
				retValue = str;
			}
		}catch(Exception e){
			retValue = str;
		}
		return ViewString(retValue);
	}
	
	public static String ViewString(String str){
		String retValue = null;
		try {
			retValue = str.replaceAll("&", "&amp;");
			retValue = str.replaceAll(">", "&gt;");
			retValue = str.replaceAll("<", "&lt;");
			retValue = str.replaceAll("\n", "<br>");
			retValue = str.replaceAll("\"", "&quot;");
			retValue = str.replaceAll("\r\n", "<br>");
			retValue = str.replaceAll("\r", "<br>");
			retValue = str.replaceAll("\n", "<br>");
			//strTemp = str.replaceAll(chr(34), "&#34;")
			//strTemp = str.replaceAll(chr(9), "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
			//strTemp = str.replaceAll(chr(32) & chr(32), "&nbsp;&nbsp;")
		}catch (Exception e){
			System.out.println(e.toString());
		}
		
		return retValue;
	}
	//Kim Tae Hyun Append End

	/**
	 * String oid = "VR:ext.psk.part.PSKPart:50085";
	 * 
	 * ReferenceFactory rf = new ReferenceFactory(); PSKPart refPart =
	 * (PSKPart)rf.getReference(oid).getObject();
	 * 
	 * Hashtable ibas = CommonUtil.getIBAList((IBAHolder)refPart);
	 * 
	 * Enumeration keys = ibas.keys(); String key = ""; String value = "";
	 * while(keys.hasMoreElements()) { key = (String)keys.nextElement(); value =
	 * (String)ibas.get(key);
	 * 
	 * System.out.println("key=" + key + " , value=" + value); }
	 * 
	 * key=MATERIAL , value=2 
	 * key=MODEL , value=3 
	 * key=MAKER_PROCESS , value=4
	 * key=PART_SPEC , value=1
	 **/
	public static Hashtable getIBAList(IBAHolder holder) throws WTException {
		Hashtable resultHash = new Hashtable();
		try {

			IBAHolder ibaholder = (IBAHolder) holder;
			ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder, null, null, null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaholder.getAttributeContainer();

			if (defaultattributecontainer == null) {
				System.out.println("Attribute container is null.");
			}

			AbstractValueView[] result = defaultattributecontainer.getAttributeValues();

			for (int i = 0; i < result.length; i++) {

				String s = new String();
				boolean okflag = true;

				if (result[i] instanceof StringValueDefaultView) {
					s = ((StringValueDefaultView) result[i]).getLocalizedDisplayString();
				} else if (result[i] instanceof FloatValueDefaultView) {
					s = ((FloatValueDefaultView) result[i]).getLocalizedDisplayString();
				} else {
					s = "Attribute value type not implemented: " + result[i];
					okflag = false;
				}

				if (okflag)
					resultHash.put(result[i].getDefinition().getName(), s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultHash;
	}

    /**
     * 폴더를 검색하여 리턴한다. 단 없으면 신규생성
     * @param folderPath
     * @return
     * @throws Exception
     */
    public static Folder getPartFolder(String folderPath) throws Exception {
    	
        Folder tmpfolder = null;
        WTContainerRef wtContainerRef = null;
        String ROOT_PART_PATH = "/Default/Part";
        
        try {
            wtContainerRef = WTContainerRef.newWTContainerRef(PSKCommonUtil.getPDMLinkProduct());
            tmpfolder = FolderHelper.service.getFolder(ROOT_PART_PATH + folderPath, wtContainerRef);
        } catch ( FolderNotFoundException ex ) {
            tmpfolder = null;
        }

        if ( tmpfolder == null ) {
            String tmpfolderFullPath[] = folderPath.split("/");
            String tmpfolderPath = ROOT_PART_PATH;

            for ( int inxA = 0; inxA < tmpfolderFullPath.length; inxA++ ) {
                tmpfolder = null;
                tmpfolderPath = tmpfolderPath + "/" + tmpfolderFullPath[inxA];
                
                try {
                    tmpfolder = FolderHelper.service.getFolder(tmpfolderPath, wtContainerRef);
                } catch ( FolderNotFoundException ex ) {
                    tmpfolder = null;
                }

                if ( tmpfolder == null ) {
                    tmpfolder = FolderHelper.service.createSubFolder(tmpfolderPath, wtContainerRef);
                }
            }
        }

        return tmpfolder;
    }


    /**
     * 폴더를 검색하여 리턴한다. 단 없으면 신규생성
     * @param folderPath
     * @return
     * @throws Exception
     */
    public static Folder getPartFolder(String folderPath, WTContainerRef wtContainerRef) throws Exception {
    	
        Folder tmpfolder = null;
        String ROOT_PART_PATH = "";
        
        WTPrincipal orgPrincipal = SessionHelper.manager.getPrincipal();
        SessionHelper.manager.setAdministrator();
        
        try {
            tmpfolder = FolderHelper.service.getFolder(ROOT_PART_PATH + folderPath, wtContainerRef);
        } catch ( FolderNotFoundException ex ) {
            tmpfolder = null;
            ex.printStackTrace();
        }

        if ( tmpfolder == null ) {
            String tmpfolderFullPath[] = folderPath.split("/");
            String tmpfolderPath = tmpfolderFullPath[0];
            System.out.println("tmpfolderPath= " + tmpfolderPath);

            for ( int inxA = 1; inxA < tmpfolderFullPath.length; inxA++ ) {
                tmpfolder = null;
                tmpfolderPath = tmpfolderPath + "/" + tmpfolderFullPath[inxA];
                System.out.println("tmpfolderPath= " + tmpfolderPath);
                try {
                    tmpfolder = FolderHelper.service.getFolder(tmpfolderPath, wtContainerRef);
                } catch ( FolderNotFoundException ex ) {
                    tmpfolder = null;
                    ex.printStackTrace();
                }

                if ( tmpfolder == null ) {
                    tmpfolder = FolderHelper.service.createSubFolder(tmpfolderPath, wtContainerRef);
                }
            }
        }
        
        SessionHelper.manager.setPrincipal(orgPrincipal.getName());

        return tmpfolder;
    }


	public static WTPart findPart(String number) throws WTException {
		WTPart part = null;
		QuerySpec spec = new QuerySpec(WTPart.class);
		spec.appendWhere(new SearchCondition(WTPart.class, "master>number", SearchCondition.EQUAL, number));
		LatestConfigSpec latestCSpec = new LatestConfigSpec();
		spec = latestCSpec.appendSearchCriteria(spec);

		QueryResult result = PersistenceHelper.manager.find(spec);

		Hashtable hashtable = null;

		if (result != null && result.size() > 0) {
			hashtable = new Hashtable();
			while (result.hasMoreElements()) {
				WTPart one = (WTPart) result.nextElement();
				hashtable.put(VersionControlHelper.getVersionIdentifier(one).getValue(), one);
			}

			// Get Latest
			String hashKey = CommonUtil.getLatestVersion(hashtable);
			part = (WTPart) hashtable.get(hashKey);
		}
		return part;
	}

	public static String getLatestVersion(Hashtable versions) {
		Enumeration dKey = versions.keys();
		Vector v = new Vector();
		while (dKey.hasMoreElements()) {
			String dStr = (String) dKey.nextElement();
			v.add(dStr);
		}
		Collections.sort(v);

		return (String) v.get(v.size() - 1);
	}
}
