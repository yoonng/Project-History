/**
 * @file	NumberUtil.java Created on 2007. 06. 21
 * @Copyright (c) e3ps. All rights reserverd
 * @author Kim Kiseon, kiskim@e3ps.com
 * @version 1.00
 */

package ext.psk.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;

import wt.pds.oracle81.OraclePds81;

public class PSKNumberUtil {
	/**
	 * ���� sequence�� ���� ū sequence�� ��=��; ��ȯ�Ѵ�.
	 * 
	 * @param seqName
	 *            sequence name
	 * @param format
	 *            sequence format
	 * @param tabName
	 *            DB table name
	 * @param colName
	 *            DB column name
	 * @return
	 */
	public static String getSeqNo(String seqName, String format,
			String tabName, String colName) {
		String result = "";
		int tempInt = 0;
		String nextNum = "";
		String maxcol = "";
		String buyPartQuery = "";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		try {
			if (seqName.substring(0, 1).equals("9")) {
				maxcol = "substr(" + colName + ",8,length(" + colName + "))";
			} else
				maxcol = colName;

			if (format.equals("00000")) {
				buyPartQuery = " and substr(WTPartNumber,11,1) != '-'";
			}

			String sql = "SELECT MAX(" + maxcol + ") no FROM " + tabName
					+ " WHERE " + colName + " LIKE '" + seqName + "%'"
					+ buyPartQuery;
			System.out.println("sql:"+sql);
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY,
					ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				if (rs.getString("no") == null)
					result = "0";
				else {
					String no = rs.getString("no");
					// System.out.println("ManageSequence::getSeqNo:no.substring()
					// = "+no.substring(seqName.length()));
					// result = "" +
					// (Integer.parseInt(no.substring(seqName.length())) + 1);
					if (no.length() == 12) {
						for (int i = seqName.length(); i < no.length(); i++) {
							tempInt = (int) no.substring(i, i + 1).charAt(0);
							if (tempInt != 10) {
								if (tempInt > 47 && tempInt < 58)
									nextNum = nextNum + no.substring(i, i + 1);
							}
						}
					}

					if (nextNum.length() > format.length())
						nextNum = nextNum.substring(0, format.length());
					if (seqName.substring(0, 1).equals("9")) {
						nextNum = no;
					}
					if (nextNum.equals(""))
						nextNum = "0";

					result = Integer.toString((Integer.parseInt(nextNum) + 1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		DecimalFormat decimalformat = new DecimalFormat(format);
		return decimalformat.format(Long.parseLong(result));
	}
}
