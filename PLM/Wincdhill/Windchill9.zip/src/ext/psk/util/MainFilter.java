/*
 * Created on 2006-02-02
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package ext.psk.util;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * @author charismma
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MainFilter implements Filter {

	private FilterConfig config;

	private String encoding;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig config) throws ServletException {

		this.config = config;
		this.encoding = config.getInitParameter("encoding");

		// ServletContext context = config.getServletContext();
		// //GlobalConstants.REAL_SERVER_ROOT_PATH = context.getRealPath("");
		// String path = context.getRealPath("");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// web.xml�� �Էµ� �ʱ� ��8�� coding
		request.setCharacterEncoding(encoding);
		// this.setSiteSection( request );
		chain.doFilter(request, response);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		config = null;
		encoding = null;
	}

	public void setSiteSection(ServletRequest request) {

		HttpServletRequest sRequest = (HttpServletRequest) request;
		Pattern p = Pattern.compile("([a-zA-Z0-9]?)*R.do$");
		Matcher m = p.matcher(sRequest.getServletPath());

		if (m.find())
			sRequest.setAttribute("siteSection", "STD");
		else
			sRequest.setAttribute("siteSection", "SIS");

	}

}
