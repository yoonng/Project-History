package ext.psk.util;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import wt.fc.PagingQueryResult;
import wt.fc.PagingSessionHelper;
import wt.httpgw.WTContextBean;
import wt.query.QuerySpec;

public abstract class CommonServlet extends HttpServlet {

	/**
	 * 
	 * @param req
	 * @param res
	 * @throws ServletException
	 * @throws IOException
	 */
	protected abstract void doService(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;

	/**
	 * GET
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		WTContextBean wtcontextbean = new WTContextBean();
		wtcontextbean.setRequest(req);
		doService(req, res);
	}

	/**
	 * POST
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		doGet(req, res);
	}

	/**
	 * PageControl;
	 * 
	 * @param req
	 * @param res
	 * @return
	 */
	protected PageControl getPageControl(HttpServletRequest req, HttpServletResponse res) {
		String sessionid = req.getParameter("sessionid");

		if (sessionid != null && sessionid.length() > 0 && !sessionid.equals("0"))
			return find(req, sessionid);
		else {
			String page = req.getParameter("page");
			if (page != null && page.length() > 0) {
				return find(req, res, CommonUtil.parseInt(page, 1));
			} else {
				return find(req, res);
			}
		}
	}

	/**
	 * PageSessionId
	 * 
	 * @param req
	 * @param sessionid
	 * @return
	 */
	protected PageControl find(HttpServletRequest req, String sessionid) {
		int perPage = CommonUtil.getIntParameter(req.getParameter("perPage"), PageControl.PERPAGE);
		int formPage = CommonUtil.getIntParameter(req.getParameter("formPage"), PageControl.FORMPAGE);
		try {
			int page = CommonUtil.getIntParameter(req.getParameter("page"), 0);
			PagingQueryResult paging = PagingSessionHelper.fetchPagingSession( (page - 1) * perPage, perPage, Long.parseLong(sessionid));
			return new PageControl(paging, page, formPage, perPage);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * @param req
	 * @param res
	 * @return
	 */
	protected PageControl find(HttpServletRequest req, HttpServletResponse res) {
		int perPage = CommonUtil.getIntParameter(req.getParameter("perPage"), PageControl.PERPAGE);
		int formPage = CommonUtil.getIntParameter(req.getParameter("formPage"), PageControl.FORMPAGE);
		// System.out.println("perPage:"+perPage);
		try {
			PagingQueryResult paging = PagingSessionHelper.openPagingSession(0, perPage, getQuerySpec(req, res));
			return new PageControl(paging, 0, formPage, perPage);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * @param req
	 * @param res
	 * @return
	 */
	protected PageControl find(HttpServletRequest req, HttpServletResponse res, int page) {
		int perPage = CommonUtil.getIntParameter(req.getParameter("perPage"), PageControl.PERPAGE);
		int formPage = CommonUtil.getIntParameter(req.getParameter("formPage"), PageControl.FORMPAGE);
		
		try {
			PagingQueryResult paging = PagingSessionHelper.openPagingSession(page, perPage, getQuerySpec(req, res));
			return new PageControl(paging, page, formPage, perPage);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected QuerySpec getQuerySpec(HttpServletRequest req, HttpServletResponse res) {
		return null;
	}

	protected void gotoResult(HttpServletRequest req, HttpServletResponse res, String address) throws ServletException, IOException {
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(address);
		dispatcher.forward(req, res);
		return;
	}

	/**
	 * kth use
	 * 
	 * @param msg
	 * @param res
	 */
	protected void alert(HttpServletResponse res, String msg) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg  ="\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * kth use
	 * 
	 * @param msg
	 * @param res
	 */
	protected void alertNstop(HttpServletResponse res, String msg) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg  ="\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n   return;";
			rtn_msg +="\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * kth use
	 *
	 * @param msg
	 * @param url
	 * @param res
	 */
	protected void alertNgo(HttpServletResponse res, String msg, String url) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg = "\n <script language=\"javascript\">" + "\n   alert(\""
					+ replaceMsg(msg) + "\");" + "\n   location.href = '" + url
					+ "';" + "\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * kth use
	 * 
	 * @param res
	 * @param msg
	 * @param userUse
	 */
	protected void alertNMsgNCallFunc(HttpServletResponse res, String msg, String userUse) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg +="\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n   " + userUse + ";";
			//rtn_msg +="\n   " + userUse + ";";
			rtn_msg +="\n </script>";

			out.println(rtn_msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * kth use
	 * 
	 * @param res
	 * @param msg
	 * @param userUse
	 */
	protected void alertNMsgNCallFunc2(HttpServletResponse res, String msg, String userUse) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg +="\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n   " + userUse + ";";
			rtn_msg +="\n   " + userUse + ";";
			rtn_msg +="\n </script>";

			out.println(rtn_msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * kth use
	 * After Message
	 * parent of javaSCript Call
	 * self.close
	 * 
	 * @param res
	 * @param msg
	 * @param strFun
	 */
	protected void alertNCallFuncNclose(HttpServletResponse res,
			String msg, String strFun) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg = "\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n   " + strFun + ";";
			rtn_msg +="\n   window.close();";
			rtn_msg +="\n </script>";
			//+ "\n   parent.location.reload();" + "\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * kth use
	 * 
	 * After Message
	 * parent of javaSCript Call
	 * self.close
	 * 
	 * @param res
	 * @param msg
	 * @param strFun
	 */
	protected void alertNsetValueNclose(HttpServletResponse res, String msg) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			//rtn_msg += "<script language=\"javascript\" src=\"http://binnexus.psk-inc.com:8080/newNexus/common/js/pscrn.js\"></script>";
			rtn_msg += "\n <script language=\"javascript\">";
			//rtn_msg +="\n   document.domain = \"psk-inc.com\";";
			//rtn_msg +="\n   " + nexusFuncCall + ";";
			rtn_msg +="\n   alert(\"" + replaceMsg(msg) + "\");";
			rtn_msg +="\n   parent.cancel();";
			rtn_msg +="\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void myMsg(HttpServletResponse res) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg = "\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"Change Completed \");";
			rtn_msg +="\n 	history.back();";
			rtn_msg +="\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void myMsg1(HttpServletResponse res, String url) {
		try {
			res.setContentType("text/html;charset=UTF-8");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html;charset=UTF-8");
			
			String rtn_msg = "";
			rtn_msg +="\n <script language=\"javascript\">";
			rtn_msg +="\n   alert(\"Creation Completed \");";
			rtn_msg +="\n   location.href = '" + url + "';";
			rtn_msg +="\n </script>";
			out.println(rtn_msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected String checkNull(String _str) {
		if (_str != null)
			return _str;
		else
			return "";
	}

	protected boolean checkString(String _str) {
		return _str != null && _str.length() > 0 && !_str.equals("null");
	}

	private String replaceMsg(String msg) {
		msg = msg.replaceAll("\"", "&quot;");
		msg = msg.replaceAll("\r\n", " ");
		msg = msg.replaceAll("\r", " ");
		msg = msg.replaceAll("\n", " ");
		return msg;
	}

}
