/**
 * @file	SearchUtil.java Created on 2007. 05. 31
 * @Copyright (c) e3ps. All rights reserverd
 * @author Kim Kiseon, kiskim@e3ps.com
 * @version 1.00
 */

package ext.psk.util;

import wt.introspection.WTIntrospectionException;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.util.WTPropertyVetoException;

public class SearchUtil {

	/**
	 * appendLinkRoleJoin
	 * 
	 * @param spec
	 * @param sortingClass
	 * @param fieldNo
	 * @param field
	 * @param sortingFlag
	 *            Sorting ��� ( true : �������, false : �8���� )
	 * @throws Exception
	 */
	public static void setOrderBy(QuerySpec spec, Class sortingClass,
			int fieldNo, String field, boolean sortingFlag)
			throws WTPropertyVetoException, QueryException,
			WTIntrospectionException {
		ClassAttribute classattribute = new ClassAttribute(sortingClass, field);
		classattribute.setColumnAlias("wtsort" + String.valueOf(0));
		int[] fieldNoArr = { fieldNo };
		spec.appendSelect(classattribute, fieldNoArr, false);
		OrderBy orderby = new OrderBy(classattribute, sortingFlag, null);
		spec.appendOrderBy(orderby, fieldNoArr);
	}

	/**
	 * appendLinkRoleJoin
	 * 
	 * @param spec
	 * @param sortingClass
	 * @param sortField
	 * @param fieldNo
	 * @param sortingFlag
	 *            Sorting ��� ( true : �������, false : �8���� )
	 * @throws Exception
	 */
	public static void setOrderBy(QuerySpec spec, Class sortingClass,
			int fieldNo, String sortField, String aliasName, boolean sortingFlag)
			throws WTPropertyVetoException, QueryException,
			WTIntrospectionException {
		ClassAttribute classattribute = new ClassAttribute(sortingClass,
				sortField);
		classattribute.setColumnAlias(aliasName + String.valueOf(0));
		int[] fieldNoArr = { fieldNo };
		spec.appendSelect(classattribute, fieldNoArr, false);
		OrderBy orderby = new OrderBy(classattribute, sortingFlag, null);
		spec.appendOrderBy(orderby, fieldNo);

		// spec.appendOrderBy(new OrderBy(new ClassAttribute(sortingClass,
		// field), sortingFlag), new int[] { fieldNo });

	}

}
