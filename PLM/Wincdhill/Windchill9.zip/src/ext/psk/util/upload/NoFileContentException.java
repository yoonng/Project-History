/* $Header : $*/

/* bcwti
 *
 * Copyright (c) 2000 Webers. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Webers.
 * You shall not disclose such confidential information and
 * shall use it only in accordance with the terms of the license agreement
 *
 * ecwti
 */

package ext.psk.util.upload;

public class NoFileContentException extends Exception {

	/**
	 * @roseuid 39C1B1FD00AF
	 */
	public NoFileContentException() {
		super();
	}

	/**
	 * @roseuid 39C1B20B01BD
	 */
	public NoFileContentException(String message) {
		super(message);
	}
}
