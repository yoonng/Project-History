// Generated PLMContentHelper%41231F5D02A6: ? 06/12/07 17:17:12
/* bcwti????Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.????This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.????ecwti
 */

package ext.psk.util.upload;

import ext.psk.util.upload.PLMContentService;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.String;

// ##begin user.imports preserve=yes
// ##end user.imports

// ##begin PLMContentHelper%41231F5D02A6.doc preserve=no
/**
 * 
 * @version 1.0
 */
// ##end PLMContentHelper%41231F5D02A6.doc
public class PLMContentHelper implements Externalizable {

	// --- Attribute Section ---

	private static final String RESOURCE = "ext.psk.ec.content.contentResource";

	private static final String CLASSNAME = PLMContentHelper.class.getName();

	// ##begin service%41231FE60109.doc preserve=no
	/**
	 **/
	// ##end service%41231FE60109.doc
	public static final PLMContentService service = new PLMContentServiceFwd();

	static final long serialVersionUID = 1;

	public static final long EXTERNALIZATION_VERSION_UID = 957977401221134810L;

	protected static final long OLD_FORMAT_VERSION_UID = -8828551902318311242L;

	// WARNING: Fields placed in this section will not be generated into
	// externalization methods.
	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	// ##end static.initialization

	// --- Operation Section ---

	// ##begin writeExternal%writeExternal.doc preserve=no
	/**
	 * ?? ??? ? ???? ???? ??? ???.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param output
	 * @exception java.io.IOException
	 */
	// ##end writeExternal%writeExternal.doc
	public void writeExternal(ObjectOutput output) throws IOException {
		// ##begin writeExternal%writeExternal.body preserve=no

		output.writeLong(EXTERNALIZATION_VERSION_UID);

		// ##end writeExternal%writeExternal.body
	}

	// ##begin readExternal%readExternal.doc preserve=no
	/**
	 * ?? ???? ? ???? ???? ??? ????.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param input
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readExternal%readExternal.doc
	public void readExternal(ObjectInput input) throws IOException,
			ClassNotFoundException {
		// ##begin readExternal%readExternal.body preserve=no

		long readSerialVersionUID = input.readLong(); // consume UID
		readVersion(this, input, readSerialVersionUID, false, false); // read
																		// fields
		// ##end readExternal%readExternal.body
	}

	// ##begin readVersion%readVersion.doc preserve=no
	/**
	 * ?? ???? ? ???? ???? ??? ????.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param thisObject
	 * @param input
	 * @param readSerialVersionUID
	 * @param passThrough
	 * @param superDone
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readVersion%readVersion.doc
	protected boolean readVersion(PLMContentHelper thisObject,
			ObjectInput input, long readSerialVersionUID, boolean passThrough,
			boolean superDone) throws IOException, ClassNotFoundException {
		// ##begin readVersion%readVersion.body preserve=no

		boolean success = true;

		if (readSerialVersionUID == EXTERNALIZATION_VERSION_UID) { // if
																	// current
																	// version
																	// UID
		} else {
			success = readOldVersion(input, readSerialVersionUID, passThrough,
					superDone);
			if (input instanceof wt.pds.PDSObjectInput)
				wt.fc.EvolvableHelper.requestRewriteOfEvolvedBlobbedObject();
		}

		return success;
		// ##end readVersion%readVersion.body
	}

	// ##begin readOldVersion%readOldVersion.doc preserve=no
	/**
	 * ?? ??? ?? ?? ???? ? ???? ???? ??? ????.
	 * 
	 * @param input
	 * @param readSerialVersionUID
	 * @param passThrough
	 * @param superDone
	 * @return boolean
	 * @exception java.io.IOException
	 * @exception java.lang.ClassNotFoundException
	 */
	// ##end readOldVersion%readOldVersion.doc
	private boolean readOldVersion(ObjectInput input,
			long readSerialVersionUID, boolean passThrough, boolean superDone)
			throws IOException, ClassNotFoundException {
		// ##begin readOldVersion%readOldVersion.body preserve=no

		boolean success = true;

		if (readSerialVersionUID == OLD_FORMAT_VERSION_UID) { // handle
																// previous
																// version
		} else
			throw new java.io.InvalidClassException(CLASSNAME,
					"Local class not compatible:"
							+ " stream classdesc externalizationVersionUID="
							+ readSerialVersionUID
							+ " local class externalizationVersionUID="
							+ EXTERNALIZATION_VERSION_UID);

		return success;
		// ##end readOldVersion%readOldVersion.body
	}

	// ##begin user.operations preserve=yes
	// ##end user.operations
}
