// Decompiled by DJ v3.4.4.74 Copyright 2003 Atanas Neshkov  Date: 2003-09-24 ���� 2:44:39
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   UploadUtility.java

package ext.psk.util.upload;

import java.io.*;
import java.util.*;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import wt.util.WTProperties;

// Referenced classes of package ext.uploader:
//            DataHeader, WBFile, CannotReadFileException, NoFileContentException, 
//            FileUploader

public class UploadUtilityUTF8 {

	public UploadUtilityUTF8() {
		notFinished = true;
		tempdir = null;
		try {
			WTProperties wtproperties = WTProperties.getLocalProperties();
			tempdir = wtproperties.getProperty("wt.temp", "c:\\tmp");
		} catch (IOException ioexception) {
		}
	}

	public FileUploaderUTF8 fillContents(FileUploaderUTF8 uploader,
			HttpServletRequest request) throws IOException,
			CannotReadFileException, NoFileContentException {
		int contentLength = request.getContentLength();
		InputStream is = request.getInputStream();
		return fillContents(uploader, is, contentLength);
	}

	public FileUploaderUTF8 fillContents(FileUploaderUTF8 uploader,
			InputStream is, int contentLength) throws CannotReadFileException,
			NoFileContentException {
		Vector fileList = new Vector();
		notFinished = true;
		Hashtable fileTable = new Hashtable();
		is = new PushbackInputStream(is, 100);
		try {
			boolean passForBoundary = false;
			String boundary = null;
			while (notFinished) {
				boundary = getBoundary(is);
				if (boundary == null || boundary.length() == 0)
					return null;
				if (!notFinished
						|| boundary.charAt(boundary.length() - 1) == '-')
					break;
				String headerString = getHeaderData(is);
				DataHeader dataHeader = new DataHeader(headerString);
				if (dataHeader.isFile()) {
					String contStr = getHeaderData(is);
					headerString = headerString + "\n\r" + contStr;
					dataHeader = new DataHeader(headerString);
				}
				for (int i = 0; i < 2; i++)
					is.read();

				WBFile wFile = null;
				wFile = new WBFile(dataHeader);
				if (!dataHeader.isFile()) {
					String strData = getStrData(boundary, is);
					strData = strData.trim();
					uploader.putFormParameter(dataHeader.getFieldName(),
							strData);
					passForBoundary = false;
				} else {

					Vector formFileVec = null;
					String fileFormName = dataHeader.getFieldName();
					if (fileTable.containsKey(fileFormName)) {
						formFileVec = (Vector) (fileTable.get(fileFormName));
					} else {
						formFileVec = new Vector();
					}

					String filename = wFile.getName();
					if (filename.length() < 1) {
						passForBoundary = false;
						is.read();
					} else {
						filename = filename + "_" + (new Date()).getTime();
						File newFile = createFile(boundary, filename, is,
								contentLength);
						wFile.setFile(newFile);
						wFile.setSize((int) newFile.length());
						passForBoundary = true;
						fileList.addElement(wFile);
						formFileVec.addElement(wFile);
					}
					fileTable.put(fileFormName, formFileVec);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		uploader.setFiles(fileList);
		uploader.setFiles(fileTable);
		return uploader;
	}

	public String htmlEsc2String(String escString) {
		String convertString = new String();
		for (StringTokenizer st = new StringTokenizer(escString, "&;"); st
				.hasMoreTokens();) {
			String token = st.nextToken();
			if (token.startsWith("#"))
				convertString = convertString
						+ (char) Integer.parseInt(token.substring(2));
			else
				convertString = convertString + token;
		}

		return convertString;
	}

	private String getBoundary(InputStream is) throws IOException {
		ByteArrayOutputStream outStr = new ByteArrayOutputStream();
		do {
			int b = is.read();
			if (b == -1) {
				notFinished = false;
				break;
			}
			if (b == 13) {
				is.read();
				break;
			}
			outStr.write(b);
		} while (true);
		outStr.flush();
		byte retVal[] = outStr.toByteArray();
		return new String(retVal);
	}

	private String getHeaderData(InputStream is) throws IOException {
		ByteArrayOutputStream outStr = new ByteArrayOutputStream();
		do {
			int b = is.read();
			if (b == -1) {
				notFinished = false;
				return null;
			}
			if (b == 13) {
				is.read();
				break;
			}
			outStr.write(b);
		} while (true);
		outStr.flush();
		byte retVal[] = outStr.toByteArray();
		String dataHeaderStr = new String(retVal, "UTF-8");
		return dataHeaderStr;
	}

	private String getStrData(String boundary, InputStream is)
			throws IOException {
		int maxBufferSize = 0x19000;
		String returnString = "";
		ByteArrayOutputStream outStr = new ByteArrayOutputStream();
		boolean binaryEndFound = false;
		int boundaryKeyPosition = 0;
		byte bArr[] = new byte[boundary.length()];
		int totalLen = 0;
		byte block[] = new byte[maxBufferSize + boundary.length()];
		int curBlockSize = 0;
		while (!binaryEndFound) {
			int b = is.read();
			bArr[boundaryKeyPosition] = (byte) b;
			if ((byte) b == boundary.charAt(boundaryKeyPosition)) {
				if (boundaryKeyPosition == boundary.length() - 1) {
					binaryEndFound = true;
					returnString = returnString
							+ new String(block, 0, curBlockSize, "UTF-8");
					((PushbackInputStream) is).unread(bArr);
				} else {
					boundaryKeyPosition++;
				}
			} else {
				System.arraycopy(bArr, 0, block, curBlockSize,
						boundaryKeyPosition + 1);
				curBlockSize += boundaryKeyPosition + 1;
				if (curBlockSize > maxBufferSize) {
					returnString = returnString
							+ new String(block, 0, curBlockSize, "UTF-8");
					curBlockSize = 0;
				}
				totalLen += boundaryKeyPosition + 1;
				boundaryKeyPosition = 0;
			}
		}
		return returnString;
	}

	private File createFile(String boundary, String fileName, InputStream is,
			int cotentLength) throws IOException {
		String uploadPath = tempdir;
		int maxBufferSize = 0x19000;
		if (boundary.startsWith("\n"))
			boundary = boundary.substring(1);
		File outputFile = new File(uploadPath
				+ System.getProperty("file.separator") + fileName);
		FileOutputStream out = new FileOutputStream(outputFile);
		ByteArrayOutputStream outStr = new ByteArrayOutputStream();
		boolean binaryEndFound = false;
		int boundaryKeyPosition = 0;
		byte bArr[] = new byte[boundary.length()];
		int totalLen = 0;
		byte block[] = new byte[maxBufferSize + boundary.length()];
		int curBlockSize = 0;
		while (!binaryEndFound) {
			int b = is.read();
			bArr[boundaryKeyPosition] = (byte) b;
			if ((byte) b == boundary.charAt(boundaryKeyPosition)) {
				if (boundaryKeyPosition == boundary.length() - 1) {
					binaryEndFound = true;
					if (curBlockSize > 2) {
						curBlockSize -= 2;
						out.write(block, 0, curBlockSize);
					}
					((PushbackInputStream) is).unread(bArr);
				} else {
					boundaryKeyPosition++;
				}
			} else {
				System.arraycopy(bArr, 0, block, curBlockSize,
						boundaryKeyPosition + 1);
				curBlockSize += boundaryKeyPosition + 1;
				if (curBlockSize > maxBufferSize) {
					out.write(block, 0, curBlockSize);
					curBlockSize = 0;
					if (totalLen > cotentLength) {
						out.close();
						outputFile.delete();
						return null;
					}
				}
				totalLen += boundaryKeyPosition + 1;
				boundaryKeyPosition = 0;
			}
		}
		out.close();
		return outputFile;
	}

	public InputStream theInputStream;

	public static int fileSeq = 0;

	boolean notFinished;

	String tempdir;

}