/* $Header : $*/

/* bcwti
 *
 * Copyright (c) 2000 Webers. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Webers.
 * You shall not disclose such confidential information and
 * shall use it only in accordance with the terms of the license agreement
 *
 * ecwti
 */

package ext.psk.util.upload;

public class CannotReadFileException extends Exception {

	/**
	 * �̰� ������ �����Դϴ�.
	 * 
	 * @roseuid 39C1A2CA023A
	 */
	public CannotReadFileException() {
		super();
	}

	/**
	 * @roseuid 39C1A2D8024F
	 */
	public CannotReadFileException(String message) {
		super(message);
	}
}
