/* $Header : $*/

/* bcwti
 *
 * Copyright (c) 2000 Webers. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Webers.
 * You shall not disclose such confidential information and
 * shall use it only in accordance with the terms of the license agreement
 *
 * ecwti
 */

package ext.psk.util.upload;

import java.io.Serializable;
import java.io.ObjectInput;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.File;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class WBFile implements Serializable {
	private int size = 0;

	private byte[] contents;

	private DataHeader dataHeader;

	private File file = null;

	public WBFile() {
	}

	public WBFile(String name, int size, byte[] contents) {
		dataHeader = new DataHeader();
		setName(name);
		setSize(size);
		setContents(contents);
	}

	public WBFile(String name, int size, File file) {
		dataHeader = new DataHeader();
		setName(name);
		setSize(size);
		setFile(file);
	}

	/**
	 * @roseuid 39C6E8850262
	 */
	public WBFile(DataHeader dataHeader) {
		this.dataHeader = dataHeader;
	}

	/**
	 * @roseuid 39C6E85C0303
	 */
	public void setDataHeader(DataHeader dataHeader) {
		this.dataHeader = dataHeader;
	}

	/**
	 * @roseuid 39C1814400BE
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * @roseuid 39C1814400BF
	 */
	public void setSize(int size) {
		this.size = size;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public File getFile() {
		return this.file;
	}

	/**
	 * @roseuid 39C1814400CA
	 */
	public void setContents(byte[] contents) {
		this.contents = contents;
	}

	/**
	 * @roseuid 39C1814400CC
	 */
	public void setContentByte(int index, byte content) {
		this.contents[index] = content;
	}

	/**
	 * @roseuid 39C1814400B8
	 */
	public String getName() {
		return this.dataHeader.getFileName();
	}

	public void setName(String name) {
		this.dataHeader.setFileName(name);
	}

	public InputStream getInputStream() {
		if (this.contents != null) {
			return (new ByteArrayInputStream(this.contents));
		}
		if (this.file != null) {
			try {
				return (new FileInputStream(this.file));
			} catch (FileNotFoundException fnfe) {
				return null;
			}
		}
		return null;
	}

	/**
	 * @roseuid 39C1814400BB
	 */
	public String getFullPathName() {
		return this.dataHeader.getFullPathName();
	}

	/**
	 * @roseuid 39C1814400C1
	 */
	public String getContentType() {
		return this.dataHeader.getContentType();
	}

	/**
	 * @roseuid 39C6D7E402BC
	 */
	public String getContentDisposition() {
		return this.dataHeader.getContentDisposition();
	}

	/**
	 * @roseuid 39C1814400C4
	 */
	public String getMimeType() {
		return this.dataHeader.getMimeType();
	}

	/**
	 * @roseuid 39C6D789009F
	 */
	public String getMimeSubType() {
		return this.dataHeader.getMimeSubType();
	}

	/**
	 * @roseuid 39C957A80085
	 */
	public String getFieldName() {
		return this.dataHeader.getFieldName();
	}

	/**
	 * @roseuid 39FE854E0062
	 */
	public void readExternal(ObjectInput arg0) throws IOException,
			ClassNotFoundException {
	}

	/**
	 * @roseuid 39FE854E00E4
	 */
	public void writeExternal(ObjectOutput arg0) throws IOException {
	}

	protected void finalize() {
		this.file.delete();
	}

}
