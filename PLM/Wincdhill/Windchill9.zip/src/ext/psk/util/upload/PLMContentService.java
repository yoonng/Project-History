// Generated PLMContentService%41231F8603D2: ? 06/12/07 17:17:12
/* bcwti????Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.????This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.????ecwti
 */

package ext.psk.util.upload;

import ext.psk.util.upload.WBFile;
import java.lang.String;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.util.WTException;

// ##begin user.imports preserve=yes
// ##end user.imports

// ##begin PLMContentService%41231F8603D2.doc preserve=no
/**
 * 
 * @version 1.0
 */
// ##end PLMContentService%41231F8603D2.doc
public interface PLMContentService {

	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	// ##end static.initialization

	// --- Operation Section ---

	// ##begin uploadContent%412320970171.doc preserve=no
	/**
	 * @param target
	 * @param files
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%412320970171.doc
	public ContentHolder uploadContent(ContentHolder target, Vector files,
			Vector fileDescriptions, boolean isPrimary) throws WTException;

	// ##begin uploadContent%414505E20383.doc preserve=no
	/**
	 * @param target
	 * @param file
	 * @param fileDescription
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%414505E20383.doc
	public ContentHolder uploadContent(ContentHolder target, WBFile file,
			String fileDescription, boolean isPrimary) throws WTException;

	// ##begin uploadContent%418ECD7D00B2.doc preserve=no
	/**
	 * @param target
	 * @param app
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%418ECD7D00B2.doc
	public ContentHolder uploadContent(ContentHolder target,
			ApplicationData app, boolean isPrimary) throws WTException;

	// ##begin updateContent%412320E102D6.doc preserve=no
	/**
	 * @param target
	 * @param addFiles
	 * @param deleteFiles
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end updateContent%412320E102D6.doc
	public ContentHolder updateContent(ContentHolder target, Vector addFiles,
			Vector deleteFiles, Vector fileDescriptions, boolean isPrimary)
			throws WTException;

	// ##begin updateContent%414506A00015.doc preserve=no
	/**
	 * @param target
	 * @param file
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end updateContent%414506A00015.doc
	public ContentHolder updateContent(ContentHolder target, WBFile file,
			ContentItem item) throws WTException;

	// ##begin deleteContent%414507D10245.doc preserve=no
	/**
	 * @param target
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end deleteContent%414507D10245.doc
	public ContentHolder deleteContent(ContentHolder target, ContentItem item)
			throws WTException;

	// ##begin deleteContent%414507F900C6.doc preserve=no
	/**
	 * @param target
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end deleteContent%414507F900C6.doc
	public ContentHolder deleteContent(ContentHolder target) throws WTException;

	// ##begin user.operations preserve=yes
	// ##end user.operations
}
