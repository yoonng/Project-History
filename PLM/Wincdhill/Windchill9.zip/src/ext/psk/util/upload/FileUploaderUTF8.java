// Decompiled by DJ v3.4.4.74 Copyright 2003 Atanas Neshkov  Date: 2003-09-24 ���� 2:46:00
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   FileUploader.java

package ext.psk.util.upload;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Referenced classes of package ext.uploader:
//            UploadUtility, NoFileContentException, CannotReadFileException

public class FileUploaderUTF8 {

	protected FileUploaderUTF8(ServletContext context,
			HttpServletRequest request, HttpServletResponse response) {
		this();
		this.context = context;
		this.request = request;
		this.response = response;
	}

	protected FileUploaderUTF8() {
		request = null;
		response = null;
		context = null;
		request = null;
		response = null;
		context = null;
		files = null;
		fileTable = new Hashtable();
		formParameters = new Hashtable();
	}

	public static FileUploaderUTF8 newFileUploader(ServletContext context,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			FileUploaderUTF8 fileUploader = new FileUploaderUTF8(context,
					request, response);
			UploadUtilityUTF8 uploadUtil = new UploadUtilityUTF8();
			return uploadUtil.fillContents(fileUploader, request);
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return null;
		} catch (NoFileContentException nfcf) {
			nfcf.printStackTrace();
			return null;
		} catch (CannotReadFileException crfe) {
			crfe.printStackTrace();
		}
		return null;
	}

	public void putFormParameter(String name, String value) {
		Vector parameters = (Vector) formParameters.get(name);
		if (parameters == null) {
			parameters = new Vector();
			parameters.addElement(value);
			formParameters.put(name, parameters);
		} else {
			parameters.addElement(value);
		}
	}

	public String getFormParameter(String name) {
		Vector parameters = (Vector) formParameters.get(name);
		if (parameters == null)
			return null;
		else
			return (String) parameters.firstElement();
	}

	public String[] getFormParameters(String name) {
		Vector parameters = (Vector) formParameters.get(name);
		if (parameters == null)
			return null;
		String paramValues[] = new String[parameters.size()];
		for (int i = 0; i < parameters.size(); i++)
			paramValues[i] = (String) parameters.elementAt(i);

		return paramValues;
	}

	public Vector getFiles() {
		return files;
	}

	public Vector getFiles(String key) {
		return (Vector) this.fileTable.get(key);
	}

	public void setFiles(Vector aFiles) {
		files = aFiles;
	}

	public void setFiles(Hashtable _table) {
		this.fileTable = _table;
	}

	private HttpServletRequest request;

	private HttpServletResponse response;

	private ServletContext context;

	private Vector files;

	private Hashtable fileTable;

	private Hashtable formParameters;
}