// Generated StandardPLMContentService%41231FC40272: ? 06/12/07 17:17:12
/* bcwti????Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.????This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.????ecwti
 */

package ext.psk.util.upload;

import ext.psk.util.upload.PLMContentService;
import ext.psk.util.upload.WBFile;
import java.io.Serializable;
import java.lang.String;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.util.WTException;

// ##begin user.imports preserve=yes
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.HashMap;

import wt.content.StreamData;
import wt.content.Streamed;
import wt.util.WTPropertyVetoException;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.events.KeyedEventListener;
import wt.fc.LobLocator;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.org.WTPrincipalReference;
import wt.pom.Transaction;
import wt.session.SessionHelper;

// ##end user.imports

// ##begin StandardPLMContentService%41231FC40272.doc preserve=no
/**
 * 
 * <p>
 * <code>StandardPLMContentService</code> ???? ?? ?? ??? ???
 * <code>newStandardPLMContentService</code>?(?) ???? ? ???? ????? ?????.
 * ????? ????? ?????? ??? ?? ???? ???? ????? ???? ???.
 * <p>
 * 
 * 
 * @version 1.0
 */
// ##end StandardPLMContentService%41231FC40272.doc
public class StandardPLMContentService extends StandardManager implements
		PLMContentService, Serializable {

	// --- Attribute Section ---

	private static final String RESOURCE = "ext.psk.ec.content.contentResource";

	private static final String CLASSNAME = StandardPLMContentService.class
			.getName();

	// ##begin user.attributes preserve=yes
	private KeyedEventListener listener;

	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	private static boolean DEBUG = false;

	// ##end static.initialization

	// --- Operation Section ---

	// ##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
	/**
	 * ???? ???(??) ??? ?????.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @deprecated
	 * 
	 * @return String
	 */
	// ##end getConceptualClassname%getConceptualClassnameg.doc
	public String getConceptualClassname() {
		// ##begin getConceptualClassname%getConceptualClassnameg.body
		// preserve=no

		return CLASSNAME;
		// ##end getConceptualClassname%getConceptualClassnameg.body
	}

	// ##begin performStartupProcess%413D514B03E4.doc preserve=no
	/**
	 * @exception wt.services.ManagerException
	 */
	// ##end performStartupProcess%413D514B03E4.doc
	protected void performStartupProcess() throws ManagerException {
		// ##begin performStartupProcess%413D514B03E4.body preserve=yes
		super.performStartupProcess();

		// ##end performStartupProcess%413D514B03E4.body
	}

	// ##begin newStandardPLMContentService%newStandardPLMContentServicef.doc
	// preserve=no
	/**
	 * ???? ?? ?? ??????.
	 * 
	 * @return StandardPLMContentService
	 * @exception wt.util.WTException
	 */
	// ##end newStandardPLMContentService%newStandardPLMContentServicef.doc
	public static StandardPLMContentService newStandardPLMContentService()
			throws WTException {
		// ##begin
		// newStandardPLMContentService%newStandardPLMContentServicef.body
		// preserve=no

		StandardPLMContentService instance = new StandardPLMContentService();
		instance.initialize();
		return instance;
		// ##end newStandardPLMContentService%newStandardPLMContentServicef.body
	}

	// ##begin uploadContent%412320970171.doc preserve=no
	/**
	 * @param target
	 * @param files
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%412320970171.doc
	public ContentHolder uploadContent(ContentHolder target, Vector files, Vector fileDescriptions, boolean isPrimary) throws WTException {
		// ##begin uploadContent%412320970171.body preserve=yes
		WTPrincipalReference principalReference = SessionHelper.manager.getPrincipalReference();

		Transaction trx = new Transaction();
		try {
			trx.start();
			System.out.println("ContentHolder transaction started.");

			// Upload files.
			boolean isSecondary = false;

			if (isPrimary == false) isSecondary = true;

			if (files != null && files.size() > 0) {
				for (int i = 0; i < files.size(); i++) {
					WBFile uploadedFile = (WBFile) files.elementAt(i);

					System.out.println("!!!!!!!!!!!!!!!! ContentService Decrypt Start !!!!!!!!!!!!!!!!");

					String soruceFileStr = uploadedFile.getFile().getAbsolutePath();

					System.out.println("1 : source File path : "+ soruceFileStr);

					System.out.println("!!!!!!!!!!!!!!!! ContentService Decrypt End !!!!!!!!!!!!!!!!");
					
					System.out.println("");

					InputStream is = null;
					is = uploadedFile.getInputStream();

					ApplicationData applicationData = ApplicationData.newApplicationData(target);
					applicationData.setFileName(uploadedFile.getName());
					applicationData.setFileSize(uploadedFile.getSize());

					if (isPrimary) {
						applicationData.setRole(ContentRoleType.PRIMARY);
						applicationData.setDescription((String) fileDescriptions.elementAt(i) == null ? "": (String) fileDescriptions.elementAt(i));
						isPrimary = false;
						
					} else {
						applicationData.setRole(ContentRoleType.SECONDARY);
						applicationData.setDescription((String) fileDescriptions.elementAt(i) == null ? "": (String) fileDescriptions.elementAt(i));
					}
					
					applicationData.setCreatedBy(principalReference);
					ContentServerHelper.service.updateContent(target, applicationData, is);
				}
			}

			trx.commit();			
			System.out.println("ContentHolder transaction committed.");
			
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			throw new WTException(e.toString());
		} finally {
			trx = null;
		}

		return target;

		// ##end uploadContent%412320970171.body
	}

	// ##begin uploadContent%414505E20383.doc preserve=no
	/**
	 * @param target
	 * @param file
	 * @param fileDescription
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%414505E20383.doc
	public ContentHolder uploadContent(ContentHolder target, WBFile file, String fileDescription, boolean isPrimary) throws WTException {
		// ##begin uploadContent%414505E20383.body preserve=yes
		Transaction transaction = new Transaction();
		try {
			transaction.start();

			Vector attacheVec = new Vector();
			if (file != null) attacheVec.add(file);
			Vector descVec = null;
			if (fileDescription != null) {
				descVec = new Vector();
				descVec.add(fileDescription);
			}

			target = uploadContent(target, attacheVec, descVec, isPrimary);

			transaction.commit();
		} catch (WTException e) {
			transaction.rollback();
			throw new WTException(e);
		} finally {
			transaction = null;
		}
		return target;
		// ##end uploadContent%414505E20383.body
	}

	// ##begin uploadContent%418ECD7D00B2.doc preserve=no
	/**
	 * @param target
	 * @param app
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end uploadContent%418ECD7D00B2.doc
	public ContentHolder uploadContent(ContentHolder target, ApplicationData app, boolean isPrimary) throws WTException {
		// ##begin uploadContent%418ECD7D00B2.body preserve=yes
		Transaction transaction = new Transaction();
		try {
			transaction.start();

			LobLocator loblocator = null;
			app = (ApplicationData) PersistenceHelper.manager.refresh(app);
			Streamed streamed = (Streamed) PersistenceHelper.manager.refresh(app.getStreamData().getObjectId());
			try {
				loblocator.setObjectIdentifier(((ObjectReference) streamed).getObjectId());
				((StreamData) streamed).setLobLoc(loblocator);
			} catch (Exception exception) {
			}
			InputStream is = streamed.retrieveStream();

			ApplicationData saveData = ApplicationData.newApplicationData(target);
			saveData.setIntendedForHttpOp(true);
			saveData.setFileName(app.getFileName());

			saveData.setFileSize(app.getFileSize());
			saveData.setCreatedBy(app.getCreatedBy());
			saveData.setDescription(app.getDescription() == null ? "" : app.getDescription());

			if (isPrimary) {
				saveData.setRole(ContentRoleType.PRIMARY);
			} else {
				saveData.setRole(ContentRoleType.SECONDARY);
			}

			ContentServerHelper.service.updateContent(target, saveData, is);

			transaction.commit();
		} catch (WTPropertyVetoException wtpropertyvetoexception) {
			transaction.rollback();
			throw new WTException(wtpropertyvetoexception);
			
		} catch (PropertyVetoException propertyvetoexception) {
			transaction.rollback();
			throw new WTException(propertyvetoexception);
			
		} catch (IOException ioexception) {
			transaction.rollback();
			throw new WTException(ioexception);
			
		} finally {
			transaction = null;
		}
		
		return target;
		// ##end uploadContent%418ECD7D00B2.body
	}

	// ##begin updateContent%412320E102D6.doc preserve=no
	/**
	 * @param target
	 * @param addFiles
	 * @param deleteFiles
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end updateContent%412320E102D6.doc
	public ContentHolder updateContent(ContentHolder target, Vector addFiles, Vector deleteFiles, Vector fileDescriptions, boolean isPrimary)
			throws WTException {
		// ##begin updateContent%412320E102D6.body preserve=yes
		ReferenceFactory referencefactory = new ReferenceFactory();
		Transaction trx = new Transaction();
		try {
			trx.start();
			if (isPrimary) {
				for (QueryResult result = ContentHelper.service.getContentsByRole(target, ContentRoleType.PRIMARY); result.hasMoreElements();) {
					ContentItem contentItem = (ContentItem) result.nextElement();
					ContentServerHelper.service.deleteContent(target,contentItem);
				}
			}

			// Delete contents.
			if ((deleteFiles != null && deleteFiles.size() > 0)) {
				System.out.println("Delete contents.");
				
				target = ContentHelper.service.getContents(target);

				Vector contentList = null;
				contentList = ContentHelper.getContentList(target);
				String fileName = null;
				HashMap rsHash = new HashMap();
				if (deleteFiles != null && deleteFiles.size() > 0) {
					for (int i = 0; i < deleteFiles.size(); i++) {
						rsHash = (HashMap) deleteFiles.elementAt(i);
						
						System.out.println("delete file id:"+ (String) rsHash.get("fileId"));
						
						String deleteFileOid = (String) rsHash.get("fileId");
						WTReference wtreference = referencefactory.getReference(deleteFileOid);
						if (wtreference == null) continue;

						ApplicationData myFile = (ApplicationData) wtreference.getObject();
						String deleteFileName = myFile.getFileName();
						for (int j = 0; j < contentList.size(); j++) {
							ContentItem contentItem = (ContentItem) contentList.elementAt(j);
							if (contentItem instanceof ApplicationData) {
								fileName = ((ApplicationData) contentItem).getFileName();
								if (fileName.equals(deleteFileName)) {
									ContentServerHelper.service.deleteContent(target, contentItem);
								}
							}
						}
					}
				}
			}

			// Add contents.
			if (addFiles != null) {
				System.out.println("Add contents.");
				
				target = PLMContentHelper.service.uploadContent(target, addFiles, fileDescriptions, isPrimary);
			}

			trx.commit();
		
			System.out.println("UpdateContent transaction committed.");
			
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			throw new WTException(e.toString());
			
		} finally {
			trx = null;
		}

		return target;

		// ##end updateContent%412320E102D6.body
	}

	// ##begin updateContent%414506A00015.doc preserve=no
	/**
	 * @param target
	 * @param file
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end updateContent%414506A00015.doc
	public ContentHolder updateContent(ContentHolder target, WBFile file, ContentItem item) throws WTException {
		// ##begin updateContent%414506A00015.body preserve=yes
		Transaction transaction = new Transaction();
		try {
			transaction.start();
			ContentRoleType type = item.getRole();

			ContentServerHelper.service.deleteContent(target, item);

			boolean isPrimary = false;
			if (ContentRoleType.PRIMARY.equals(type.getDisplay())) isPrimary = true;
			target = uploadContent(target, file, null, isPrimary);

			transaction.commit();
		} catch (WTPropertyVetoException e) {
			transaction.rollback();
			throw new WTException(e);
			
		} catch (WTException e) {
			transaction.rollback();
			throw new WTException(e);
			
		} finally {
			transaction = null;
		}
		return target;
		// ##end updateContent%414506A00015.body
	}

	// ##begin deleteContent%414507D10245.doc preserve=no
	/**
	 * @param target
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end deleteContent%414507D10245.doc
	public ContentHolder deleteContent(ContentHolder target, ContentItem item)
			throws WTException {
		// ##begin deleteContent%414507D10245.body preserve=yes
		Transaction transaction = new Transaction();
		try {
			transaction.start();
			
			if (target == null || item == null) return target;
			target = ContentHelper.service.getContents(target);
			ContentServerHelper.service.deleteContent(target, item);
			
			transaction.commit();
			
		} catch (PropertyVetoException e) {
			transaction.rollback();
			throw new WTException(e);
			
		} finally {
			transaction = null;
		}
		return target;
		// ##end deleteContent%414507D10245.body
	}

	// ##begin deleteContent%414507F900C6.doc preserve=no
	/**
	 * @param target
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	// ##end deleteContent%414507F900C6.doc
	public ContentHolder deleteContent(ContentHolder target) throws WTException {
		// ##begin deleteContent%414507F900C6.body preserve=yes
		Transaction transaction = new Transaction();
		try {
			target = ContentHelper.service.getContents(target);
			Vector files = ContentHelper.getApplicationData(target);
			if (files != null) {
				for (int i = 0; i < files.size(); i++) {
					target = deleteContent(target, (ApplicationData) files.get(i));
				}
			}
			transaction.commit();
			
		} catch (WTException e) {
			transaction.rollback();
			e.printStackTrace();
			
		} catch (PropertyVetoException e) {
			transaction.rollback();
			e.printStackTrace();
			
		} finally {
			transaction = null;
		}
		return target;
		// ##end deleteContent%414507F900C6.body
	}

	// ##begin user.operations preserve=yes

	// ##end user.operations
}
