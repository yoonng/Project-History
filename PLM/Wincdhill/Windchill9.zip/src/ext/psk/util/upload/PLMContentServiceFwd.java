// Generated PLMContentServiceFwd%41231F8603D2: ? 06/12/07 17:17:12
/* bcwti????Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.????This software is the confidential and proprietary
 * information of PTC. You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license agreement.????ecwti
 */

package ext.psk.util.upload;

import ext.psk.util.upload.PLMContentService;
import ext.psk.util.upload.WBFile;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 * 
 * @version 1.0
 */

public class PLMContentServiceFwd implements RemoteAccess, PLMContentService,
		Serializable {

	// --- Attribute Section ---

	static final boolean SERVER = RemoteMethodServer.ServerFlag;

	private static final String FC_RESOURCE = "wt.fc.fcResource";

	private static final String CLASSNAME = PLMContentServiceFwd.class
			.getName();

	// --- Operation Section ---

	/**
	 * @return Manager
	 * @exception wt.util.WTException
	 */
	private static Manager getManager() throws WTException {

		Manager manager = ManagerServiceFactory.getDefault().getManager(
				ext.psk.util.upload.PLMContentService.class);

		if (manager == null) {
			Object[] param = { "ext.psk.ec.content.PLMContentService" };
			throw new WTException(FC_RESOURCE,
					wt.fc.fcResource.UNREGISTERED_SERVICE, param);
		}
		return manager;
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param files
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder uploadContent(ContentHolder target, Vector files,
			Vector fileDescriptions, boolean isPrimary) throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).uploadContent(target,
					files, fileDescriptions, isPrimary);
		else {
			try {
				Class[] argTypes = { ContentHolder.class, Vector.class,
						Vector.class, boolean.class };
				Object[] args = { target, files, fileDescriptions,
						new Boolean(isPrimary) };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"uploadContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "uploadContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "uploadContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param file
	 * @param fileDescription
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder uploadContent(ContentHolder target, WBFile file,
			String fileDescription, boolean isPrimary) throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).uploadContent(target,
					file, fileDescription, isPrimary);
		else {
			try {
				Class[] argTypes = { ContentHolder.class, WBFile.class,
						String.class, boolean.class };
				Object[] args = { target, file, fileDescription,
						new Boolean(isPrimary) };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"uploadContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "uploadContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "uploadContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param app
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder uploadContent(ContentHolder target,
			ApplicationData app, boolean isPrimary) throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).uploadContent(target,
					app, isPrimary);
		else {
			try {
				Class[] argTypes = { ContentHolder.class,
						ApplicationData.class, boolean.class };
				Object[] args = { target, app, new Boolean(isPrimary) };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"uploadContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "uploadContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "uploadContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param addFiles
	 * @param deleteFiles
	 * @param fileDescriptions
	 * @param isPrimary
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder updateContent(ContentHolder target, Vector addFiles,
			Vector deleteFiles, Vector fileDescriptions, boolean isPrimary)
			throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).updateContent(target,
					addFiles, deleteFiles, fileDescriptions, isPrimary);
		else {
			try {
				Class[] argTypes = { ContentHolder.class, Vector.class,
						Vector.class, Vector.class, boolean.class };
				Object[] args = { target, addFiles, deleteFiles,
						fileDescriptions, new Boolean(isPrimary) };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"updateContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "updateContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "updateContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param file
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder updateContent(ContentHolder target, WBFile file,
			ContentItem item) throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).updateContent(target,
					file, item);
		else {
			try {
				Class[] argTypes = { ContentHolder.class, WBFile.class,
						ContentItem.class };
				Object[] args = { target, file, item };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"updateContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "updateContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "updateContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @param item
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder deleteContent(ContentHolder target, ContentItem item)
			throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).deleteContent(target,
					item);
		else {
			try {
				Class[] argTypes = { ContentHolder.class, ContentItem.class };
				Object[] args = { target, item };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"deleteContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "deleteContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "deleteContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}

	/**
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param target
	 * @return ContentHolder
	 * @exception wt.util.WTException
	 */
	public ContentHolder deleteContent(ContentHolder target) throws WTException {

		if (SERVER)
			return ((PLMContentService) getManager()).deleteContent(target);
		else {
			try {
				Class[] argTypes = { ContentHolder.class };
				Object[] args = { target };
				return (ContentHolder) RemoteMethodServer.getDefault().invoke(
						"deleteContent", null, this, argTypes, args);
			} catch (InvocationTargetException e) {
				Throwable targetE = e.getTargetException();
				if (targetE instanceof WTException)
					throw (WTException) targetE;
				Object[] param = { "deleteContent" };
				throw new WTException(targetE, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			} catch (RemoteException rme) {
				Object[] param = { "deleteContent" };
				throw new WTException(rme, FC_RESOURCE,
						wt.fc.fcResource.OPERATION_FAILURE, param);
			}
		}
	}
}
