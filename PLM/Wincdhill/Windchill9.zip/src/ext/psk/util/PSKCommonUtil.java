package ext.psk.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.method.MethodContext;
//import wt.part.ProductMasterProduct;
import wt.part.WTPart;
//import wt.part.WTProduct;
//import wt.part.WTProductMaster;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.WTConnection;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
//import ext.psk.ec.ChangeMasterToDocumentLink;
//import ext.psk.ec.ChangeMasterToProductLink;
//import ext.psk.ec.EcReferenceDetailLink;
//import ext.psk.ec.NoticeToDocumentLink;
//import ext.psk.ec.NoticeToWTPartDetail;
//import ext.psk.ec.PSKActivity;
//import ext.psk.ec.PSKEffectivity;
//import ext.psk.ec.PSKNotice;
//import ext.psk.ec.PSKRequest;
//import ext.psk.ec.PSKChangeMaster;
//import ext.psk.ec.form.PSKBeansForm;
//import ext.psk.product.PSKProductAttribute;
//import ext.psk.product.PSKProductHelper;
//import ext.psk.product.beans.PSKProductUtil;

public class PSKCommonUtil {
	/**
	 * 첨부파일 정보 얻기
	 * 
	 * @param changeMaster
	 * @return
	 * @throws WTException
	 */
//	public static Vector getFilesInfo(PSKChangeMaster changeMaster)
//			throws WTException {
//		Vector resultVector = new Vector();
//
//		resultVector = getFilesInfo((ContentHolder) changeMaster);
//
//		return resultVector;
//	}

	public static Vector getFilesInfo(ContentHolder changeMaster)
			throws WTException {
		Vector resultVector = new Vector();

		try {
			ContentHolder master = (ContentHolder) ContentHelper.service.getContents(changeMaster);
			Vector contentList = ContentHelper.getContentListAll(master);

			for (int i = 0; i < contentList.size(); i++) {
				HashMap ht = new HashMap();

				ContentItem contentItem = (ContentItem) contentList.elementAt(i);

				if (contentItem instanceof ApplicationData) {
					String fileName = ((ApplicationData) contentItem).getFileName();

					ContentRoleType crt = contentItem.getRole();
					String temp = crt.getStringValue();

					// System.out.println("temp = " + temp);

					String fileType = (String) contentItem.getRole().toString();
					// System.out.println("Display = " + fileType);

					String fileId = PersistenceHelper.getObjectIdentifier(contentItem).toString();
					// System.out.println("File ID = " + fileId);

					String downURL = (ContentHelper.getDownloadURL((ContentHolder) master,(ApplicationData) contentItem)).toString();
					// System.out.println("Content URL = " + downURL);

					String fileSize = String.valueOf(((ApplicationData) contentItem).getFileSizeKB());
					// System.out.println("fileSize = " + fileSize);

					ht.put("fileName", fileName);
					ht.put("roleType", temp);
					ht.put("fileType", fileType);
					ht.put("fileId", fileId);
					ht.put("downURL", downURL);
					ht.put("fileSize", fileSize);

					resultVector.addElement(ht);
				}
			}
		} catch (java.beans.PropertyVetoException pve) {
			pve.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultVector;
	}

	public static Vector getFilesInfo(WTDocument doc) throws WTException {
		Vector resultVector = new Vector();

		try {
			WTDocument master = (WTDocument) ContentHelper.service.getContents(doc);
			Vector contentList = ContentHelper.getContentListAll(master);

			for (int i = 0; i < contentList.size(); i++) {
				HashMap ht = new HashMap();

				ContentItem contentItem = (ContentItem) contentList.elementAt(i);
				// System.out.println("contentItem:"+contentItem.toString());
				if (contentItem instanceof ApplicationData) {
					String fileName = ((ApplicationData) contentItem).getFileName();

					ContentRoleType crt = contentItem.getRole();
					String temp = crt.getStringValue();

					// System.out.println("temp = " + temp);

					String fileType = (String) contentItem.getRole().toString();
					// System.out.println("Display = " + fileType);

					String fileId = PersistenceHelper.getObjectIdentifier(contentItem).toString();
					// System.out.println("File ID = " + fileId);

					String downURL = (ContentHelper.getDownloadURL((ContentHolder) master,(ApplicationData) contentItem)).toString();
					// System.out.println("Content URL = " + downURL);

					String fileSize = String.valueOf(((ApplicationData) contentItem).getFileSizeKB());
					// System.out.println("fileSize = " + fileSize);

					ht.put("fileName", fileName);
					ht.put("roleType", temp);
					ht.put("fileType", fileType);
					ht.put("fileId", fileId);
					ht.put("downURL", downURL);
					ht.put("fileSize", fileSize);

					resultVector.addElement(ht);
				}
			}
		} catch (java.beans.PropertyVetoException pve) {
			pve.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultVector;
	}

	public static WTContainer getDefaultFolder() throws WTException {
		String DefaultFoldeName = "DOCUMENT";
		QuerySpec spec = new QuerySpec(WTLibrary.class);
		SearchCondition cond = new SearchCondition(WTLibrary.class,"containerInfo.name", SearchCondition.EQUAL, DefaultFoldeName);
		spec.appendWhere(cond, new int[] { 0 });
		// System.out.println(spec);
		QueryResult result = PersistenceHelper.manager.find(spec);
		WTLibrary link = null;
		while (result.hasMoreElements()) {
			link = (WTLibrary) result.nextElement();
		}
		return link;
	}
	

    /**
     * @since 2007/05/27
     * @author kang ho chul
     * @see
     * @return WTContainerRef - description: WTContainerRef 를 반환한다
     * 
     */
    public static WTContainerRef getWTContainerRef() throws Exception
    {

        PDMLinkProduct wtProduct = getPDMLinkProduct();
        WTContainerRef wtContainerRef = null;
        if (wtProduct != null)
        {
            wtContainerRef = WTContainerRef.newWTContainerRef(wtProduct);
        }

        return wtContainerRef;
    }

	
    /**
     * @since 2007/05/27
     * @author kang ho chul
     * @see
     * @return PDMLinkProduct - description: PDMLinkProduct 를 반환한다
     * 
     */
    
    public static PDMLinkProduct getPDMLinkProduct() throws Exception
    {
        QuerySpec qs = new QuerySpec(PDMLinkProduct.class);
        SearchCondition sc1 = new SearchCondition(PDMLinkProduct.class, PDMLinkProduct.NAME, SearchCondition.EQUAL, "PSK_Product");
        qs.appendSearchCondition(sc1);
        QueryResult results = (QueryResult) PersistenceHelper.manager.find(qs);
        PDMLinkProduct wtProduct = null;
        if (results.hasMoreElements())
        {
            wtProduct = (PDMLinkProduct) results.nextElement();
        }

        return wtProduct;
    }
    
    public static PDMLinkProduct getPDMLinkProduct(String product) throws Exception{
  	   //String contextName = WTProperties.getServerProperties().getProperty(product);
         QuerySpec qs = new QuerySpec(PDMLinkProduct.class);
         SearchCondition sc1 = new SearchCondition(PDMLinkProduct.class, PDMLinkProduct.NAME, SearchCondition.EQUAL, product);
         qs.appendSearchCondition(sc1);
         QueryResult results = (QueryResult)PersistenceHelper.manager.find(qs);
         PDMLinkProduct wtProduct = null;
         if (results.hasMoreElements()) {
             wtProduct = (PDMLinkProduct)results.nextElement();          
         }       
         return wtProduct;
     }
	
    public static WTLibrary getWTLibrary(String product) throws Exception{
  	   //String contextName = WTProperties.getServerProperties().getProperty(product);
         QuerySpec qs = new QuerySpec(WTLibrary.class);
         SearchCondition sc1 = new SearchCondition(WTLibrary.class, "containerInfo.name", SearchCondition.EQUAL, product);
         qs.appendSearchCondition(sc1);
         
         System.out.println("qs=" + qs);
         QueryResult results = (QueryResult)PersistenceHelper.manager.find(qs);
         WTLibrary wtProduct = null;
         System.out.println("results.hasMoreElements() " + results.hasMoreElements());
         
         if (results.hasMoreElements()) {
             wtProduct = (WTLibrary)results.nextElement();
             
             System.out.println("wtProduct=" + wtProduct);
         }       
         return wtProduct;
     }
    
//
//	public static void setRequestFolder(PSKChangeMaster obj, String location,
//			ArrayList serialId, String lifeCycle) throws WTException {
//		// Rule.여러호기중 첫번째 호기의 폴더에 문서를 생성한다.
//		WTProductMaster firstProduct = null;
//		ReferenceFactory rf = new ReferenceFactory();
//		// System.out.println("호기 개수:"+serialId.size());
//		if (serialId.size() != 0) {
//			// System.out.println("첫번째 호기:"+(String)serialId.get(0));
//			firstProduct = (WTProductMaster) rf.getReference(
//					(String) serialId.get(0)).getObject();
//		}
//		setRequestFolder(obj, location, firstProduct, lifeCycle);
//
//	}
//
//	public static void setRequestFolder(PSKChangeMaster obj, String location,
//			WTProductMaster master, String lifeCycle) throws WTException {
//		try {
//			WTContainer container = master.getContainer();
//			obj.setContainer(container);
//			WTContainerRef ref = WTContainerRef.newWTContainerRef(container);
//
//			LifeCycleTemplate template = LifeCycleHelper.service
//					.getLifeCycleTemplate(lifeCycle, ref);
//			obj = (PSKChangeMaster) LifeCycleHelper.setLifeCycle(obj, template);
//
//			Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(
//					location, ref);
//			FolderHelper.assignLocation(obj, checkOutFolder);
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	public static void setRequestFolder(PSKChangeMaster obj, String location,
//			WTContainer container, String lifeCycle) throws WTException {
//		try {
//			// System.out.println("container:"+container.getName());
//			// System.out.println("location : "+location);
//			obj.setContainer(container);
//			WTContainerRef ref = WTContainerRef.newWTContainerRef(container);
//
//			LifeCycleTemplate template = LifeCycleHelper.service
//					.getLifeCycleTemplate(lifeCycle, ref);
//			// System.out.println("template----->"+template.toString());
//			obj = (PSKChangeMaster) LifeCycleHelper.setLifeCycle(obj, template);
//
//			Folder checkOutFolder = (Folder) FolderHelper.service.getFolder(
//					location, ref);
//			FolderHelper.assignLocation(obj, checkOutFolder);
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTProductMasterLink 생성
//	 * 
//	 * @param serialId
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void createWTProductMasterLink(ArrayList serialId,
//			PSKChangeMaster linkObj) throws WTException {
//		// 각호기별로 WTproductMasterLink 연결
//		ReferenceFactory rf = new ReferenceFactory();
//		try {
//			if (serialId != null && serialId.size() != 0) {
//				for (int i = 0; i < serialId.size(); i++) {
//					WTProductMaster serialObj = (WTProductMaster) rf
//							.getReference((String) serialId.get(i)).getObject();
//					ChangeMasterToProductLink productLink = ChangeMasterToProductLink
//							.newChangeMasterToProductLink(linkObj, serialObj);
//					PersistenceHelper.manager.save(productLink);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTProductMasterLink 삭제
//	 * 
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void deleteWTProductMasterLink(PSKChangeMaster linkObj)
//			throws WTException {
//		// 각호기별로 WTproductMasterLink 삭제
//		/*
//		 * try{ if(linkObj != null){ QueryResult qr =
//		 * PersistenceHelper.manager.navigate(linkObj,
//		 * ChangeMasterToProductLink.WTPRODUCT_MASTER_ROLE,
//		 * ChangeMasterToProductLink.class); while(qr.hasMoreElements()){ //
//		 * System.out.println("document 삭제되는
//		 * oid:"+((ChangeMasterToProductLink)qr.nextElement()).toString());
//		 * PersistenceHelper.manager.delete((ChangeMasterToProductLink)qr.nextElement()); } }
//		 * }catch(Exception e){ e.printStackTrace(); throw new WTException(e); }
//		 */
//
//		// 각호기별로 WTproductMasterLink 삭제
//		try {
//			long docOid = linkObj.getPersistInfo().getObjectIdentifier()
//					.getId();
//			QuerySpec spec = new QuerySpec(ChangeMasterToProductLink.class);
//			SearchCondition cond = new SearchCondition(
//					ChangeMasterToProductLink.class, "roleAObjectRef.key.id",
//					SearchCondition.EQUAL, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			while (result.hasMoreElements()) {
//				PersistenceHelper.manager
//						.delete((ChangeMasterToProductLink) result
//								.nextElement());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("삭제 size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTProductMasterLink 수정 수정은 이전것을 삭제하고 새로운것을 생성
//	 * 
//	 * @param serialId
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void updateWTProductMasterLink(ArrayList serialId,
//			PSKChangeMaster linkObj) throws WTException {
//		// 각호기별로 WTproductMasterLink 수정
//		try {
//			if (serialId != null && linkObj != null) {
//				deleteWTProductMasterLink(linkObj);
//				createWTProductMasterLink(serialId, linkObj);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTProductMasterLink 정보얻기
//	 * 
//	 * @param linkObj
//	 * @return
//	 * @throws WTException
//	 */
//	public static ArrayList getWTProductMasterLink(PSKChangeMaster linkObj)
//			throws WTException {
//		// 각호기별로 WTproductMasterLink 얻기
//		ArrayList wtProductLink = new ArrayList();
//		try {
//			QueryResult qr = PersistenceHelper.manager.navigate(linkObj,
//					ChangeMasterToProductLink.WTPRODUCT_MASTER_ROLE,
//					ChangeMasterToProductLink.class);
//			// System.out.println("연결된 호기 개수:"+qr.size());
//			while (qr.hasMoreElements()) {
//				wtProductLink.add((WTProductMaster) qr.nextElement());
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//
//		return wtProductLink;
//	}
//
//	/**
//	 * WTDocumentLink 생성
//	 * 
//	 * @param docArr
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void createWTDocumentLink(ArrayList docArr,
//			PSKChangeMaster linkObj) throws WTException {
//		ReferenceFactory rf = new ReferenceFactory();
//		try {
//			if (docArr != null && docArr.size() != 0) {
//				for (int i = 0; i < docArr.size(); i++) {
//					String oid = (String) docArr.get(i);
//					WTDocument serialObj = (WTDocument) rf.getReference(oid)
//							.getObject();
//					// System.out.println("link doc name:"+serialObj.getName());
//					ChangeMasterToDocumentLink documentLink = ChangeMasterToDocumentLink
//							.newChangeMasterToDocumentLink(serialObj, linkObj);
//					PersistenceHelper.manager.save(documentLink);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTDocumentLink 삭제
//	 * 
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void deleteWTDocumentLink(PSKChangeMaster linkObj)
//			throws WTException {
//		/*
//		 * try{ if(linkObj != null){ QueryResult qr =
//		 * PersistenceHelper.manager.navigate(linkObj,
//		 * ChangeMasterToDocumentLink.PSKCHANGE_MASTER_ROLE,
//		 * ChangeMasterToDocumentLink.class); while(qr.hasMoreElements()){ //
//		 * System.out.println("document 삭제되는
//		 * oid:"+((ChangeMasterToDocumentLink)qr.nextElement()).toString());
//		 * PersistenceHelper.manager.delete((ChangeMasterToDocumentLink)qr.nextElement()); } }
//		 * }catch(Exception e){ e.printStackTrace(); throw new WTException(e); }
//		 */
//
//		try {
//			long docOid = linkObj.getPersistInfo().getObjectIdentifier()
//					.getId();
//			QuerySpec spec = new QuerySpec(ChangeMasterToDocumentLink.class);
//			SearchCondition cond = new SearchCondition(
//					ChangeMasterToDocumentLink.class, "roleBObjectRef.key.id",
//					SearchCondition.EQUAL, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			while (result.hasMoreElements()) {
//				PersistenceHelper.manager
//						.delete((ChangeMasterToDocumentLink) result
//								.nextElement());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("삭제 size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTDocumentLink 수정
//	 * 
//	 * @param docArr
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void updateWTDocumentLink(ArrayList docArr,
//			PSKChangeMaster linkObj) throws WTException {
//		try {
//			if (docArr != null && linkObj != null) {
//				deleteWTDocumentLink(linkObj);
//				createWTDocumentLink(docArr, linkObj);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * WTDocumentLink 정보얻기
//	 * 
//	 * @param linkObj
//	 * @return
//	 * @throws WTException
//	 */
//	public static ArrayList getWTDocumentLink(PSKChangeMaster linkObj)
//			throws WTException {
//		ArrayList wtDocumentLink = new ArrayList();
//		/*
//		 * try{ QueryResult qr = PersistenceHelper.manager.navigate(linkObj,
//		 * ChangeMasterToDocumentLink.PSKCHANGE_MASTER_ROLE,
//		 * ChangeMasterToDocumentLink.class); System.out.println(qr);
//		 * while(qr.hasMoreElements()){
//		 * wtDocumentLink.add((WTDocument)qr.nextElement()); } }catch(Exception
//		 * e){ e.printStackTrace(); throw new WTException(e); }
//		 */
//
//		try {
//			long docOid = linkObj.getPersistInfo().getObjectIdentifier()
//					.getId();
//			// System.out.println("docOid :"+docOid);
//			QuerySpec spec = new QuerySpec(ChangeMasterToDocumentLink.class);
//			SearchCondition cond = new SearchCondition(
//					ChangeMasterToDocumentLink.class, "roleBObjectRef.key.id",
//					SearchCondition.EQUAL, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			// System.out.println(spec);
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			ChangeMasterToDocumentLink link = null;
//			while (result.hasMoreElements()) {
//				link = (ChangeMasterToDocumentLink) result.nextElement();
//				wtDocumentLink.add(link.getRoleAObject());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//
//		return wtDocumentLink;
//	}
//
//	/**
//	 * reference 된 문서의 링크생성(여러개씩)
//	 * 
//	 * @param refDoc
//	 * @param srcObj
//	 * @throws WTException
//	 */
//	public static void createReferenceDocLink(ArrayList refDoc,
//			PSKChangeMaster srcObj) throws WTException {
//		if (refDoc == null || refDoc.size() == 0 || srcObj == null) {
//			return;
//		}
//		for (int i = 0; i < refDoc.size(); i++) {
//			createReferenceDocLink((String) refDoc.get(i), srcObj);
//		}
//	}
//
//	/**
//	 * reference 된 문서의 링크생성(한개씩)
//	 * 
//	 * @param refDoc
//	 * @param srcObj
//	 * @throws WTException
//	 */
//	public static void createReferenceDocLink(String refDoc,
//			PSKChangeMaster srcObj) throws WTException {
//		if (refDoc == null || refDoc.equals("") || srcObj == null) {
//			return;
//		}
//
//		ReferenceFactory rf = new ReferenceFactory();
//		PSKChangeMaster targetObj = (PSKChangeMaster) rf.getReference(refDoc)
//				.getObject();
//		try {
//			String docType = "";
//			if (targetObj instanceof PSKRequest) {
//				docType = "request";
//			} else if (targetObj instanceof PSKNotice) {
//				docType = "notice";
//			} else if (targetObj instanceof PSKActivity) {
//				docType = "activity";
//			} else if (targetObj instanceof PSKEffectivity) {
//				docType = "effectivity";
//			}
//
//			EcReferenceDetailLink refLink = EcReferenceDetailLink
//					.newEcReferenceDetailLink(srcObj, targetObj);
//			refLink.setRefType(docType);
//			PersistenceHelper.manager.save(refLink);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * reference 된 문서의 링크삭제(한개씩)
//	 * 
//	 * @param srcObj
//	 * @throws WTException
//	 */
//	public static void deleteReferenceDocLink(PSKChangeMaster srcObj)
//			throws WTException {
//		if (srcObj == null) {
//			return;
//		}
//
//		String docType = "";
//		if (srcObj instanceof PSKRequest) {
//			docType = "request";
//		} else if (srcObj instanceof PSKNotice) {
//			docType = "notice";
//		} else if (srcObj instanceof PSKActivity) {
//			docType = "activity";
//		} else if (srcObj instanceof PSKEffectivity) {
//			docType = "effectivity";
//		}
//
//		try {
//			long docOid = srcObj.getPersistInfo().getObjectIdentifier().getId();
//			QuerySpec spec = new QuerySpec(EcReferenceDetailLink.class);
//			SearchCondition cond = new SearchCondition(
//					EcReferenceDetailLink.class, "roleAObjectRef.key.id",
//					SearchCondition.LIKE, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			spec.appendAnd();
//			cond = new SearchCondition(EcReferenceDetailLink.class,
//					EcReferenceDetailLink.REF_TYPE, SearchCondition.LIKE,
//					docType);
//			spec.appendWhere(cond, new int[] { 0 });
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			while (result.hasMoreElements()) {
//				PersistenceHelper.manager.delete((EcReferenceDetailLink) result
//						.nextElement());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * reference 된 문서의 링크수정(여러개씩)
//	 * 
//	 * @param refDoc
//	 * @param srcObj
//	 * @throws WTException
//	 */
//	public static void updateReferenceDocLink(ArrayList refDoc,
//			PSKChangeMaster srcObj) throws WTException {
//		if (refDoc == null || refDoc.size() == 0 || srcObj == null) {
//			return;
//		}
//		// System.out.println("refDoc size:"+refDoc.size());
//		try {
//			deleteReferenceDocLink(srcObj);
//			createReferenceDocLink(refDoc, srcObj);
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	public static ArrayList getReferenceDocLink(PSKChangeMaster srcObj)
//			throws WTException {
//		return getReferenceDocLink(srcObj, null);
//	}
//
//	/**
//	 * reference 된 문서의 정보얻기
//	 * 
//	 * @param srcObj
//	 * @return
//	 * @throws WTException
//	 */
//	public static ArrayList getReferenceDocLink(PSKChangeMaster srcObj,
//			String docType) throws WTException {
//		if (srcObj == null) {
//			return null;
//		}
//
//		ArrayList docArr = new ArrayList();
//
//		try {
//			long docOid = srcObj.getPersistInfo().getObjectIdentifier().getId();
//			// System.out.println("docOid :"+docOid);
//			QuerySpec spec = new QuerySpec(EcReferenceDetailLink.class);
//			SearchCondition cond = new SearchCondition(
//					EcReferenceDetailLink.class, "roleAObjectRef.key.id",
//					SearchCondition.LIKE, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			if (docType != null) {
//				spec.appendAnd();
//				cond = new SearchCondition(EcReferenceDetailLink.class,
//						EcReferenceDetailLink.REF_TYPE, SearchCondition.LIKE,
//						docType);
//				spec.appendWhere(cond, new int[] { 0 });
//			}
//			// System.out.println(spec);
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			EcReferenceDetailLink link = null;
//			while (result.hasMoreElements()) {
//				link = (EcReferenceDetailLink) result.nextElement();
//				docArr.add(link.getRoleBObject());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//		return docArr;
//	}
//
//	/**
//	 * NoticeToDocumentLink 생성
//	 * 
//	 * @param docArr
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void createDocumentChangeLink(ArrayList docArr,
//			PSKNotice linkObj) throws WTException {
//		ReferenceFactory rf = new ReferenceFactory();
//		try {
//			if (docArr != null && docArr.size() != 0) {
//				for (int i = 0; i < docArr.size(); i++) {
//					String oid = (String) docArr.get(i);
//					WTDocument serialObj = (WTDocument) rf.getReference(oid)
//							.getObject();
//					// System.out.println("link doc name:"+serialObj.getName());
//					NoticeToDocumentLink documentLink = NoticeToDocumentLink
//							.newNoticeToDocumentLink(serialObj, linkObj);
//					PersistenceHelper.manager.save(documentLink);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * NoticeToDocumentLink 삭제
//	 * 
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void deleteDocumentChangeLink(PSKNotice linkObj)
//			throws WTException {
//		try {
//			long docOid = linkObj.getPersistInfo().getObjectIdentifier()
//					.getId();
//			QuerySpec spec = new QuerySpec(NoticeToDocumentLink.class);
//			SearchCondition cond = new SearchCondition(
//					NoticeToDocumentLink.class, "roleBObjectRef.key.id",
//					SearchCondition.EQUAL, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			while (result.hasMoreElements()) {
//				PersistenceHelper.manager.delete((NoticeToDocumentLink) result
//						.nextElement());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("삭제 size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * NoticeToDocumentLink 수정
//	 * 
//	 * @param docArr
//	 * @param linkObj
//	 * @throws WTException
//	 */
//	public static void updateDocumentChangeLink(ArrayList docArr,
//			PSKNotice linkObj) throws WTException {
//		try {
//			if (docArr != null && linkObj != null) {
//				deleteDocumentChangeLink(linkObj);
//				createDocumentChangeLink(docArr, linkObj);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * NoticeToDocumentLink 정보얻기
//	 * 
//	 * @param linkObj
//	 * @return
//	 * @throws WTException
//	 */
//	public static ArrayList getDocumentChangeLink(PSKNotice linkObj)
//			throws WTException {
//		ArrayList wtDocumentLink = new ArrayList();
//
//		try {
//			long docOid = linkObj.getPersistInfo().getObjectIdentifier()
//					.getId();
//			// System.out.println("docOid :"+docOid);
//			QuerySpec spec = new QuerySpec(NoticeToDocumentLink.class);
//			SearchCondition cond = new SearchCondition(
//					NoticeToDocumentLink.class, "roleBObjectRef.key.id",
//					SearchCondition.EQUAL, docOid);
//			spec.appendWhere(cond, new int[] { 0 });
//			// System.out.println(spec);
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			NoticeToDocumentLink link = null;
//			while (result.hasMoreElements()) {
//				link = (NoticeToDocumentLink) result.nextElement();
//				wtDocumentLink.add(link.getRoleAObject());
//				// System.out.println("===>"+((WTDocument)(link.getRoleAObject())).getName());
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//
//		return wtDocumentLink;
//	}
//
//	public static ArrayList getPartLink(PSKChangeMaster srcObj)
//			throws WTException {
//		ArrayList parts = new ArrayList();
//
//		QueryResult qr = PersistenceHelper.manager.navigate(srcObj,
//				NoticeToWTPartDetail.PART_ROLE, NoticeToWTPartDetail.class);
//		// System.out.println("getpartlink size:"+qr.size());
//		while (qr.hasMoreElements()) {
//			parts.add((WTPart) qr.nextElement());
//		}
//		return parts;
//	}

	public static ArrayList getFilterDocType(String flag) throws WTException {
		ArrayList rsArr = new ArrayList();
		if (flag == null || flag.equals("") || flag.equals("ALL")) {
			rsArr = getDocumentTypeAll();
		} else if (flag.equals("EC")) {
			rsArr = getDocumentTypeEc();
		} else if (flag.equals("GENERAL")) {
			rsArr = getDocumentTypeGeneral();
		} else if (flag.equals("REFERENCEDOC")) {
			rsArr = getDocumentTypeReferenceDoc();
		} else if (flag.equals("LIBRARY")) {
			rsArr = getDocumentTypeLibrary();
		} else if (flag.equals("PROJECT")) {
			rsArr = getDocumentTypeProject();
		}

		// debug
		/*
		 * for(int i=0; i<rsArr.size(); i++){ HashMap map =
		 * (HashMap)rsArr.get(i); System.out.println("name : "+map.get("name")); }
		 */
		return rsArr;
	}

	public static ArrayList getDocumentTypeAll() throws WTException {
		ArrayList rsArr = new ArrayList();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			value = new HashMap();
			value.put("name", docType[i].toString());
			value.put("value", docType[i].getDisplay());
			rsArr.add(value);
		}

		return rsArr;
	}

	public static ArrayList getDocumentTypeEc() throws WTException {
		ArrayList rsArr = new ArrayList();
		Vector filter = getFilterEcVaule();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			if (filter.contains(docType[i].toString())) {
				value = new HashMap();
				value.put("name", docType[i].getDisplay());
				value.put("value", docType[i].toString());
				rsArr.add(value);
			}
		}

		return rsArr;
	}

	public static ArrayList getDocumentTypeLibrary() throws WTException {
		ArrayList rsArr = new ArrayList();
		Vector filter = getFilterLibrary();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			if (!filter.contains(docType[i].toString())) {
				value = new HashMap();
				value.put("name", docType[i].getDisplay());
				value.put("value", docType[i].toString());
				rsArr.add(value);
			}
		}

		return rsArr;
	}

	public static ArrayList getDocumentTypeProject() throws WTException {
		ArrayList rsArr = new ArrayList();
		Vector filter = getFilterProject();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			if (!filter.contains(docType[i].toString())) {
				value = new HashMap();
				value.put("name", docType[i].getDisplay());
				value.put("value", docType[i].toString());
				rsArr.add(value);
			}
		}

		return rsArr;
	}

	public static ArrayList getDocumentTypeReferenceDoc() throws WTException {
		ArrayList rsArr = new ArrayList();
		Vector filter = getFilterVauleReferenceDoc();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			if (filter.contains(docType[i].toString())) {
				value = new HashMap();
				value.put("name", docType[i].getDisplay());
				value.put("value", docType[i].toString());
				rsArr.add(value);
			}
		}

		return rsArr;
	}

	public static ArrayList getDocumentTypeGeneral() throws WTException {
		ArrayList rsArr = new ArrayList();
		Vector filter = getFilterVaule();
		HashMap value = new HashMap();
		DocumentType[] docType = DocumentType.getDocumentTypeSet();
		for (int i = 0; i < docType.length; i++) {
			if (!filter.contains(docType[i].toString())) {
				value = new HashMap();
				value.put("name", docType[i].getDisplay());
				value.put("value", docType[i].toString());
				rsArr.add(value);
			}
		}

		return rsArr;
	}

	public static Vector getFilterEcVaule() throws WTException {
		Vector filterValue = new Vector();
		filterValue.add("request");
		filterValue.add("notice");
		filterValue.add("activity");
		filterValue.add("effectivity");

		return filterValue;
	}

	public static Vector getFilterLibrary() throws WTException {
		Vector filterValue = new Vector();
		filterValue.add("request");
		filterValue.add("notice");
		filterValue.add("activity");
		filterValue.add("effectivity");
		filterValue.add("DevFinish");
		filterValue.add("$$Document");
		filterValue.add("$$Requirements");
		filterValue.add("$$Specification");
		filterValue.add("$$TestPlan");
		filterValue.add("$$Template");

		return filterValue;
	}

	public static Vector getFilterProject() throws WTException {
		Vector filterValue = new Vector();
		filterValue.add("request");
		filterValue.add("notice");
		filterValue.add("activity");
		filterValue.add("effectivity");
		filterValue.add("DevFinish");
		filterValue.add("$$Document");
		filterValue.add("$$Requirements");
		filterValue.add("$$Specification");
		filterValue.add("$$TestPlan");
		filterValue.add("$$Template");

		return filterValue;
	}

	public static Vector getFilterVaule() throws WTException {
		Vector filterValue = new Vector();
		filterValue.add("request");
		filterValue.add("notice");
		filterValue.add("activity");
		filterValue.add("effectivity");
		filterValue.add("$$Document");
		filterValue.add("$$Requirements");
		filterValue.add("$$Specification");
		filterValue.add("$$TestPlan");
		filterValue.add("$$Template");

		return filterValue;
	}

	public static Vector getFilterVauleReferenceDoc() throws WTException {
		Vector filterValue = new Vector();
		filterValue.add("request");
		filterValue.add("effectivity");
		filterValue.add("notice");
		filterValue.add("pscr");

		return filterValue;
	}

	public static ArrayList getLastRevisionDocument(String classType) throws WTException {
		ArrayList res = new ArrayList();
		// System.out.println(classType);
		try {
			MethodContext methodcontext = MethodContext.getContext();
			WTConnection wtcon = (WTConnection) methodcontext.getConnection();
			Connection con = wtcon.getConnection();
			Statement stmt = con.createStatement();
			String fromName = "";
			if (classType.equals("request")) {
				fromName = "PSKRequest";
			} else if (classType.equals("notice")) {
				fromName = "PSKNotice";
			} else if (classType.equals("activity")) {
				fromName = "PSKActivity";
			} else if (classType.equals("effectivity")) {
				fromName = "PSKEffectivity";
			}

			// query
			StringBuffer sql = new StringBuffer();
			sql.append(" select max(tab.ida2a2) maxoid ");
			sql.append(" from ");
			sql.append(fromName);
			sql.append(" tab, wtdocumentmaster docmaster ");
			sql.append(" where tab.ida3masterreference = docmaster.ida2a2 ");
			sql.append(" group by tab.ida3masterreference ");
			// System.out.println("sql:"+sql.toString());
			ResultSet rs = stmt.executeQuery(sql.toString());
			ArrayList tmpArr = new ArrayList();
			while (rs.next()) {
				res.add(rs.getString("maxoid"));
			}

			rs.close();
			// con.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
		return res;
	}

	/**
	 * reference 된 문서의 정보얻기(PSKChangeMaster 으로 넘기기)
	 * 
	 * @param fromDoc
	 * @param toDoc
	 * @param docType
	 * @return
	 * @throws WTException
	 */
//	public static ArrayList getChangeMasterLink(PSKChangeMaster fromDoc,
//			PSKChangeMaster toDoc, String docType) throws WTException {
//		try {
//			String fromOid = null;
//			if (fromDoc != null) {
//				fromOid = String.valueOf(fromDoc.getPersistInfo()
//						.getObjectIdentifier().getId());
//			}
//			String toOid = null;
//			if (toDoc != null) {
//				toOid = String.valueOf(toDoc.getPersistInfo()
//						.getObjectIdentifier().getId());
//			}
//			// System.out.println("docOid :"+fromOid+" toOid : "+toOid);
//			return getChangeMasterLink(fromOid, toOid, docType);
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//	}
//
//	/**
//	 * reference 된 문서의 정보얻기(String 으로 넘기기)
//	 * 
//	 * @param fromDoc
//	 * @param toDoc
//	 * @param docType
//	 * @return
//	 * @throws WTException
//	 */
//	public static ArrayList getChangeMasterLink(String fromDoc, String toDoc,
//			String docType) throws WTException {
//		if (fromDoc == null && toDoc == null) {
//			return null;
//		}
//
//		ArrayList docArr = new ArrayList();
//		boolean isAnd = false;
//		try {
//			QuerySpec spec = new QuerySpec(EcReferenceDetailLink.class);
//			SearchCondition cond = null;
//			if (fromDoc != null && !fromDoc.equals("")) {
//				if (isAnd) {
//					spec.appendAnd();
//				}
//				cond = new SearchCondition(EcReferenceDetailLink.class,
//						"roleBObjectRef.key.id", SearchCondition.EQUAL, Long
//								.valueOf(fromDoc).longValue());
//				spec.appendWhere(cond, new int[] { 0 });
//				isAnd = true;
//			} else if (toDoc != null && !toDoc.equals("")) {
//				if (isAnd) {
//					spec.appendAnd();
//				}
//				cond = new SearchCondition(EcReferenceDetailLink.class,
//						"roleAObjectRef.key.id", SearchCondition.EQUAL, Long
//								.valueOf(toDoc).longValue());
//				spec.appendWhere(cond, new int[] { 0 });
//				isAnd = true;
//			}
//			if (docType != null) {
//				if (isAnd) {
//					spec.appendAnd();
//				}
//				cond = new SearchCondition(EcReferenceDetailLink.class,
//						EcReferenceDetailLink.REF_TYPE, SearchCondition.EQUAL,
//						docType);
//				spec.appendWhere(cond, new int[] { 0 });
//				isAnd = true;
//			}
//			QueryResult result = PersistenceHelper.manager.find(spec);
//			EcReferenceDetailLink link = null;
//			while (result.hasMoreElements()) {
//				HashMap hmap = new HashMap();
//				link = (EcReferenceDetailLink) result.nextElement();
//				hmap.put("fromDoc", link.getRoleAObject());
//				hmap.put("toDoc", link.getRoleBObject());
//				// System.out.println("ref
//				// A:"+link.getRoleAObject().toString());
//				// System.out.println("ref
//				// B:"+link.getRoleBObject().toString());
//				docArr.add(hmap);
//			}
//			// System.out.println("sql:"+spec);
//			// System.out.println("size:"+result.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new WTException(e);
//		}
//		return docArr;
//	}
//
//	public static String getFolderPath(String oid) throws Exception {
//		// System.out.println("oid:"+oid);
//		ReferenceFactory rf = new ReferenceFactory();
//		WTProductMaster product = (WTProductMaster) rf.getReference(oid)
//				.getObject();
//		return getFolderPath(product);
//	}
//
//	public static String getFolderPath(WTProductMaster product)
//			throws Exception {
//		/*
//		 * QueryResult qr = PersistenceHelper.manager.navigate(product,
//		 * "iteration", ProductMasterProduct.class, true); WTProduct prod = null
//		 * if (qr != null && qr.size() > 0 ){ prod =
//		 * (WTProduct)qr.nextElement(); System.out.println("number :
//		 * "+prod.getNumber()); System.out.println("name : "+prod.getName()); }
//		 */
//
//		WTProduct prod = PSKProductUtil.getLatestProduct(product);
//
//		wt.util.WTProperties props = wt.util.WTProperties.getLocalProperties();
//		String ecFolder = props.getProperty("psk.default.ec.DefaultFolder");
//		String folderPath = "/Default/";
//		String productSerial = "";
//		PSKProductAttribute proAtt = (PSKProductAttribute) PSKProductHelper.service
//				.getExpandAttribute(prod);
//		if (proAtt != null) {
//			productSerial = proAtt.getProductSerial();
//		}
//		if (productSerial != null && !productSerial.equals("")) {
//			folderPath = folderPath + productSerial + ecFolder;
//		}
//		return folderPath;
//	}

	public static String[] getPSCRTypes(String[] args, boolean trans) {
		String[] pscrTypes = null;
		if (trans) {
			for (int i = 0; i < args.length; i++) {
				if (args[i].equals("derivation"))
					args[i] = "Derivation FSC";
				else if (args[i].equals("new"))
					args[i] = "New FSC";
				else if (args[i].equals("update"))
					args[i] = "Update FSC";
				else if (args[i].equals("newU"))
					args[i] = "New UPG";
				else if (args[i].equals("newVC"))
					args[i] = "New UPG-VC";
				else if (args[i].equals("updateVC"))
					args[i] = "Update UPG-VC";
			}
			pscrTypes = args;
		} else {
			for (int i = 0; i < args.length; i++) {
				if (args[i].equals("Derivation FSC"))
					args[i] = "derivation";
				else if (args[i].equals("New FSC"))
					args[i] = "new";
				else if (args[i].equals("Update FSC"))
					args[i] = "update";
				else if (args[i].equals("New UPG"))
					args[i] = "newU";
				else if (args[i].equals("New UPG-VC"))
					args[i] = "newVC";
				else if (args[i].equals("Update UPG-VC"))
					args[i] = "updateVC";
			}
			pscrTypes = args;
		}

		return pscrTypes;
	}

	public static String[] getPSCRTypeSet(boolean trans) {
		if (trans) {
			String[] args = { "derivation", "new", "update", "newU", "newVC", "updateVC" };
			return args;
		} else {
			String[] args = { "Derivation FSC", "New FSC", "Update FSC", "New UPG", "New UPG-VC", "Update UPG-VC" };
			return args;
		}
	}

	public static void main(String args[]) {
		PSKCommonUtil op = new PSKCommonUtil();
		ReferenceFactory rf = new ReferenceFactory();
		try {
			// case 1
			// PSKChangeMaster cMaster =
			// (PSKChangeMaster)rf.getReference("ext.psk.ec.PSKActivity:28114").getObject();
			// request.setChangeMasterType("ALL");

			// case 2
			// op.getFilterDocType("GENERAL");

			// case 3
			String from = "";
			String to = "36132";
			String docType = "request";
//			getChangeMasterLink(from, to, docType);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
