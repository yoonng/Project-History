/**
 * @file	ContentInfo.java Created on 2007. 07. 23
 * @Copyright (c) e3ps. All rights reserverd
 * @author Kim Kiseon, kiskim@e3ps.com
 * @version 1.00
 */

package ext.psk.util;

import java.net.URL;

public class ContentInfo {
	private String type; // ���� Ÿ�� ( FILE or URL )

	private String contentOid; // ��ü OID

	private String name; // ���ϸ�

	private String description; // ���� ����

	private URL downURL; // �ٿ� URL ( ����Ÿ��:FILE �ϰ�� )

	private String fileSize; // ���� ������ ( ����Ÿ��:FILE �ϰ�� )

	private String businessType; // Business Ÿ�� ( ����Ÿ��:FILE �ϰ�� )

	private String iconURLStr; // icon �̹��� ( ����Ÿ��:FILE �ϰ�� )

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getType() {
		return type;
	}

	public URL getDownURL() {
		return downURL;
	}

	public String getContentOid() {
		return contentOid;
	}

	public String getFileSize() {
		return fileSize;
	}

	public String getBusinessType() {
		return businessType;
	}

	public String getDownURLStr() {
		StringBuffer sb = new StringBuffer();
		sb.append("<a target='blank' href='");
		sb.append(downURL.toString());
		sb.append("'>&nbsp;" + name);
		sb.append("</a>&nbsp;(&nbsp;" + fileSize + "&nbsp;)");
		return sb.toString();
	}

	public String getIconURLStr() {
		StringBuffer sb = new StringBuffer();
		sb.append("<a target='blank' href='");
		sb.append(downURL.toString());
		sb.append("'>" + iconURLStr);
		sb.append("</a>");
		return sb.toString();
	}

	public void setName(String aPath) {
		name = aPath;
	}

	public void setDescription(String aDescription) {
		description = aDescription;
	}

	public void setType(String aType) {
		type = aType;
	}

	public void setDownURL(URL aUrlPath) {
		downURL = aUrlPath;
	}

	public void setContentOid(String aContentOid) {
		contentOid = aContentOid;
	}

	public void setBusinessType(String a_businessType) {
		businessType = a_businessType;
	}

	public void setIconURLStr(String aIconURLStr) {
		iconURLStr = aIconURLStr;
	}

	public void setFileSize(long l_fileSize) {
		fileSize = FileUtil.getFileSizeStr(l_fileSize);
	}
}
