/**
 * @file	FileUtil.java Created on 2007. 07. 23
 * @Copyright (c) e3ps. All rights reserverd
 * @author Kim Kiseon, kiskim@e3ps.com
 * @version 1.00
 */

package ext.psk.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DecimalFormat;

public class FileUtil {
	public static void checkDir(String dir) {
		File createDir = new File(dir);
		if (!createDir.exists())
			createDir.mkdir();
		if (!createDir.exists())
			createDir.mkdirs();
	}

	public static void checkDir(File dir) {
		if (!dir.exists())
			dir.mkdir();
		if (!dir.exists())
			dir.mkdirs();
	}

	public static String getFileSizeStr(long filesize) {
		DecimalFormat df = new DecimalFormat(".#");
		String fSize = "";
		if ((filesize > 1024) && (filesize < 1024 * 1024)) {
			fSize = df.format((float) filesize / 1024).toString() + " KB";
		} else if (filesize >= 1024 * 1024) {
			fSize = df.format((float) filesize / (1024 * 1024)).toString()
					+ " MB";
		} else if (filesize < 1024 && filesize > 1) {
			fSize = "1 KB";
		} else {
			fSize = "0 Bytes";
		}
		return fSize;
	}

	// ���� : ���� �ִ� ����; �����Ѵ�.
	// �Ű����� : �� ���� Ǯ���, �纻 ������ ����� Ǯ���
	// ��ȯ�� : ���� : 0, ���� : -1
	public static int CopyServerToServer(String szOriginFileName,
			String szCopyFileName) {
		if (szOriginFileName == null || szCopyFileName == null
				|| szCopyFileName.length() < 1) {
			return -1;
		}
		char delim = '/';
		if (szCopyFileName.indexOf('\\') != -1) {
			delim = '\\';
		}
		int idx = szCopyFileName.lastIndexOf(delim);
		if (idx == -1 || idx == 0) {
			idx = szCopyFileName.length();
		}
		File CopyFullPath = new File(szCopyFileName.substring(0, idx));
		byte[] buf = new byte[1024];
		if (!CopyFullPath.exists()) {
			if (!CopyFullPath.mkdirs())
				return -1;
		}
		try {
			FileInputStream fin = new FileInputStream(szOriginFileName);
			FileOutputStream fout = new FileOutputStream(szCopyFileName);

			for (int iBytesThisTime = fin.read(buf); iBytesThisTime > 0; iBytesThisTime = fin
					.read(buf)) {
				fout.write(buf, 0, iBytesThisTime);
			}
			fin.close();
			fout.close();
		} catch (Exception e) {
			System.out.println(e);
			return -1;
		}

		return 0;
	}
}
