package ext.psk.util;

import java.io.FileOutputStream;
import java.util.Vector;

//import ext.psk.spec.PSKSOTreeData;

public class TreeTagUtil {

	private static final String piImagePath = "/Windchill/extcore/psk/images/tree/";

	public static String makeIndentImage(String indentStr) {

		String returnValue = "";

		for (int j = 1; j < indentStr.length(); j++) {
			if (indentStr.substring(j, j + 1).equals("Y")) {
				returnValue = returnValue + "<IMG src='" + piImagePath
						+ "TREE_vertline.gif' border=0>\n";
			} else {
				returnValue = returnValue + "<IMG src='" + piImagePath
						+ "TREE_S.gif' border=0>\n";
			}
		}

		return returnValue;

	}

	public static String makeStartDivtag(String nextFolderType, String divID,
			int inlineLevel, int currentLevel) {

		String returnValue = "";

		if ((nextFolderType.equals("TREE_AP") || nextFolderType
				.equals("TREE_AM"))) {
			if (currentLevel <= inlineLevel)
				returnValue = "<div id='Div" + divID
						+ "' style='display:inline;'>\n";
			else
				returnValue = "<div id='Div" + divID
						+ "' style='display:none;'>\n";
		}

		return returnValue;

	}

	public static String makeNodetag(String curFolderType, String nodeID,
			String nodeName, String aTagID, boolean assyFlag) {

		String returnValue = "";

		if (curFolderType.equals("TREE_AM") || curFolderType.equals("TREE_AP")) {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType
					+ ".gif' onclick=\"javascript:NodeClick(this,'" + nodeID
					+ "');\" style='cursor:hand;' border=0>\n";
		} else {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType + ".gif' border=0>\n";
		}

		if (assyFlag)
			returnValue = returnValue
					+ "<IMG src='"
					+ piImagePath
					+ "TREE_DN.gif' name='F"
					+ nodeID
					+ "' border=0><A id='"
					+ aTagID
					+ "' onclick=\"JAVASCRIPT:itemClick(this);\" style='cursor:hand;color:black;' border=0>"
					+ nodeName + "</A><BR>\n";
		else
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID + "' border=0>"
					+ nodeName + "<BR>\n";

		return returnValue;

	}

	public static String makeNodetag(String curFolderType, String nodeID,
			String nodeName, int clickLevel, int currentLevel) {

		String returnValue = "";

		if (curFolderType.equals("TREE_AM") || curFolderType.equals("TREE_AP")) {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType
					+ ".gif' onclick=\"javascript:NodeClick(this,'" + nodeID
					+ "');\" style='cursor:hand;' border=0>\n";
		} else {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType + ".gif' border=0>\n";
		}

		if (currentLevel >= clickLevel) {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID
					+ "' border=0><A onclick=\"JAVASCRIPT:itemClick('" + nodeID
					+ "', '" + nodeName
					+ "');\" style='cursor:hand;color:blue;' border=0 title='"
					+ nodeName + "'>" + nodeName + "</A><BR>\n";
		} else {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID + "' border=0>"
					+ nodeName + "<BR>\n";
		}

		return returnValue;

	}

	public static String makeNodetag(String curFolderType, String nodeID,
			String nodeName, int clickLevel, int currentLevel, String nodeType,
			String systemID) {

		String returnValue = "";

		if (curFolderType.equals("TREE_AM") || curFolderType.equals("TREE_AP")) {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType
					+ ".gif' onclick=\"javascript:NodeClick(this,'" + nodeID
					+ "', '" + nodeType + "', '" + currentLevel
					+ "');\" style='cursor:hand;' border=0>\n";
		} else {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType + ".gif' border=0>\n";
		}

		if (currentLevel >= clickLevel) {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID
					+ "' border=0><A onclick=\"JAVASCRIPT:itemClick('" + nodeID
					+ "', '" + nodeName + "', '" + nodeType + "', '" + systemID
					+ "', '" + currentLevel
					+ "');\" style='cursor:hand;color:blue;' border=0  title='"
					+ nodeName + "'>" + nodeName + "</A><BR>\n";
		} else {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID + "' border=0>"
					+ nodeName + "<BR>\n";
		}

		return returnValue;

	}

	public static String makeNodetagForPopup(String curFolderType,
			String nodeID, String nodeName, int clickLevel, int currentLevel) {

		String returnValue = "";

		if (curFolderType.equals("TREE_AM") || curFolderType.equals("TREE_AP")) {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType
					+ ".gif' onclick=\"javascript:NodeClick(this,'" + nodeID
					+ "');\" style='cursor:hand;' border=0>\n";
		} else {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType + ".gif' border=0>\n";
		}

		if (currentLevel >= clickLevel) {
			if (curFolderType.equals("TREE_AM")
					|| curFolderType.equals("TREE_AP")) {
				returnValue = returnValue
						+ "<IMG src='"
						+ piImagePath
						+ "TREE_DN.gif' name='F"
						+ nodeID
						+ "' border=0><A name='A"
						+ nodeID
						+ "' onclick=\"JAVASCRIPT:itemClick('"
						+ nodeID
						+ "', '"
						+ nodeName
						+ "');\" style='cursor:hand;color:blue;' border=0 onMouseOut=\"javascript:menuOut();' onMouseDown='javascript:rightControl(event.button, 'MIDDLE', '"
						+ nodeID + "');\" title='" + nodeName + "'>" + nodeName
						+ "</A><BR>\n";
			} else {
				returnValue = returnValue
						+ "<IMG src='"
						+ piImagePath
						+ "TREE_DN.gif' name='F"
						+ nodeID
						+ "' border=0><A name='A"
						+ nodeID
						+ "' onclick=\"JAVASCRIPT:itemClick('"
						+ nodeID
						+ "', '"
						+ nodeName
						+ "');\" style='cursor:hand;color:blue;' border=0 onMouseOut=\"javascript:menuOut();' onMouseDown='javascript:rightControl(event.button, 'END', '"
						+ nodeID + "');\" title='" + nodeName + "'>" + nodeName
						+ "</A><BR>\n";
			}
		} else {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID + "' border=0>"
					+ nodeName + "<BR>\n";
		}

		return returnValue;

	}

	public static String makeNodetagForPopup(String curFolderType,
			String nodeID, String nodeName, int clickLevel, int currentLevel,
			String nodeType, String systemID) {

		String returnValue = "";

		if (curFolderType.equals("TREE_AM") || curFolderType.equals("TREE_AP")) {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType
					+ ".gif' onclick=\"javascript:NodeClick(this,'" + nodeID
					+ "', '" + nodeType + "', '" + currentLevel
					+ "');\" style='cursor:hand;' border=0>\n";
		} else {
			returnValue = "<IMG name='P" + nodeID + "' src='" + piImagePath
					+ "" + curFolderType + ".gif' border=0>\n";
		}

		if (currentLevel >= clickLevel) {

			if (curFolderType.equals("TREE_AM")
					|| curFolderType.equals("TREE_AP")) {
				returnValue = returnValue
						+ "<IMG src='"
						+ piImagePath
						+ "TREE_DN.gif' name='F"
						+ nodeID
						+ "' border=0><A name='A"
						+ nodeID
						+ "' onclick=\"JAVASCRIPT:itemClick('"
						+ nodeID
						+ "', '"
						+ nodeName
						+ "', '"
						+ nodeType
						+ "', '"
						+ systemID
						+ "', '"
						+ currentLevel
						+ "');\" style='cursor:hand;color:blue;' border=0 onMouseOut='javascript:menuOut();' onMouseDown=\"javascript:rightControl(event.button, 'MIDDLE', '"
						+ nodeID + "');\" title='" + nodeName + "'>" + nodeName
						+ "</A><BR>\n";
			} else {
				returnValue = returnValue
						+ "<IMG src='"
						+ piImagePath
						+ "TREE_DN.gif' name='F"
						+ nodeID
						+ "' border=0><A name='A"
						+ nodeID
						+ "' onclick=\"JAVASCRIPT:itemClick('"
						+ nodeID
						+ "', '"
						+ nodeName
						+ "', '"
						+ nodeType
						+ "', '"
						+ systemID
						+ "', '"
						+ currentLevel
						+ "');\" style='cursor:hand;color:blue;' border=0 onMouseOut='javascript:menuOut();' onMouseDown=\"javascript:rightControl(event.button, 'END', '"
						+ nodeID + "');\" title='" + nodeName + "'>" + nodeName
						+ "</A><BR>\n";
			}

		} else {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_DN.gif' name='F" + nodeID + "' border=0>"
					+ nodeName + "<BR>\n";
		}

		return returnValue;

	}

	public static String makeEndDivtag(int currentLevel, int nextLevel) {

		String returnValue = "";

		for (int k = 0; k < currentLevel - nextLevel; k++) {
			returnValue = returnValue + "</div>\n";
		}

		return returnValue;

	}

	public static String makeIndentSpaceImage(String indentStr) {

		String returnValue = "";

		for (int j = 1; j < indentStr.length(); j++) {
			returnValue = returnValue + "<IMG src='" + piImagePath
					+ "TREE_S.gif' border=0>\n";
		}

		return returnValue;

	}
//
//	public static Vector modifyQueryData(Vector retVec) {
//		int i, j, k;
//		Vector returnData = new Vector();
//		String currentLevel = "";
//		String currentNodeID = "";
//		String prevImgFlag = "";
//		String prevNodeID = "";
//		String nextLevel = "";
//		String nodeFlag = "";
//		String imgFlag = "";
//		String temp = "";
//
//		for (i = 0; i < retVec.size(); i++) {
//			PSKSOTreeData pm = (PSKSOTreeData) retVec.elementAt(i);
//			currentLevel = pm.szIndexing;
//			currentNodeID = pm.szChildOid;
//			nodeFlag = "";
//
//			for (j = 1; j <= Integer.parseInt(currentLevel); j++) {
//				k = i;
//				if (i != retVec.size() - 1) {
//					while (k < retVec.size() - 1) {
//						PSKSOTreeData tmppm = (PSKSOTreeData) retVec
//								.elementAt(k + 1);
//						if (j - Integer.parseInt(tmppm.szIndexing) > 1) {
//							temp = "N";
//							break;
//						} else {
//							if (j - 1 == Integer.parseInt(tmppm.szIndexing)) {
//								temp = "Y";
//								break;
//							} else {
//								temp = "N";
//							}
//						}
//						k++;
//					}
//				} else {
//					temp = "N";
//				}
//				nodeFlag = nodeFlag + temp;
//			}
//
//			if (i != retVec.size() - 1) {
//				PSKSOTreeData pm2 = (PSKSOTreeData) retVec.elementAt(i + 1);
//				if (currentNodeID.equals(pm2.szParentOid)) {
//					if (currentLevel.equals("2"))
//						imgFlag = "TREE_AM";
//					else
//						imgFlag = "TREE_AP";
//				} else {
//					if (!currentLevel.equals(pm2.szIndexing))
//						imgFlag = "TREE_LastNode";
//					else
//						imgFlag = "TREE_Node";
//				}
//				nextLevel = pm2.szIndexing;
//			} else {
//				imgFlag = "TREE_LastNode";
//				nextLevel = "1";
//			}
//
//			TreeNodeData tn = new TreeNodeData(prevNodeID, currentNodeID,
//					pm.szChildName, pm.szObjectID, currentLevel, nextLevel,
//					nodeFlag, imgFlag, prevImgFlag, pm.szNumber);
//			returnData.add(tn);
//
//			prevImgFlag = imgFlag;
//			prevNodeID = currentNodeID;
//		}
//
//		return returnData;
//	}
//
//	public static Vector modifyQueryDataLeft(Vector retVec) {
//		int i, j, k;
//		Vector returnData = new Vector();
//		String currentLevel = "";
//		String currentNodeID = "";
//		String prevImgFlag = "";
//		String prevNodeID = "";
//		String nextLevel = "";
//		String nodeFlag = "";
//		String imgFlag = "";
//		String temp = "";
//
//		for (i = 0; i < retVec.size(); i++) {
//			PSKSOTreeData pm = (PSKSOTreeData) retVec.elementAt(i);
//			currentLevel = pm.szIndexing;
//			currentNodeID = pm.szChildOid;
//			nodeFlag = "";
//
//			for (j = 1; j <= Integer.parseInt(currentLevel); j++) {
//				k = i;
//				if (i != retVec.size() - 1) {
//					while (k < retVec.size() - 1) {
//						PSKSOTreeData tmppm = (PSKSOTreeData) retVec
//								.elementAt(k + 1);
//						if (j - Integer.parseInt(tmppm.szIndexing) > 1) {
//							temp = "N";
//							break;
//						} else {
//							if (j - 1 == Integer.parseInt(tmppm.szIndexing)) {
//								temp = "Y";
//								break;
//							} else {
//								temp = "N";
//							}
//						}
//						k++;
//					}
//				} else {
//					temp = "N";
//				}
//				nodeFlag = nodeFlag + temp;
//			}
//
//			if (i != retVec.size() - 1) {
//				PSKSOTreeData pm2 = (PSKSOTreeData) retVec.elementAt(i + 1);
//				if (currentNodeID.equals(pm2.szParentOid)) {
//					if (currentLevel.equals("2"))
//						imgFlag = "TREE_AM";
//					else
//						imgFlag = "TREE_AP";
//				} else {
//					if (!currentLevel.equals(pm2.szIndexing))
//						imgFlag = "TREE_LastNode";
//					else
//						imgFlag = "TREE_Node";
//				}
//				nextLevel = pm2.szIndexing;
//			} else {
//				imgFlag = "TREE_LastNode";
//				nextLevel = "1";
//			}
//
//			if (pm.szChildName.equals("")) {
//				if (imgFlag.equals("TREE_AM") || imgFlag.equals("TREE_AP"))
//					imgFlag = "TREE_Node";
//				pm.szChildName = "-";
//			}
//			TreeNodeData tn = new TreeNodeData(prevNodeID, currentNodeID,
//					pm.szChildName, pm.szObjectID, currentLevel, nextLevel,
//					nodeFlag, imgFlag, prevImgFlag, pm.szNumber);
//			returnData.add(tn);
//
//			prevImgFlag = imgFlag;
//			prevNodeID = currentNodeID;
//		}
//
//		return returnData;
//	}
//
//	public static Vector modifyQueryDataRight(Vector retVec) {
//		int i, j, k;
//		Vector returnData = new Vector();
//		String currentLevel = "";
//		String currentNodeID = "";
//		String prevImgFlag = "";
//		String prevNodeID = "";
//		String nextLevel = "";
//		String nodeFlag = "";
//		String imgFlag = "";
//		String temp = "";
//
//		for (i = 0; i < retVec.size(); i++) {
//			PSKSOTreeData pm = (PSKSOTreeData) retVec.elementAt(i);
//			currentLevel = pm.szIndexing;
//			currentNodeID = pm.szRChildOid;
//			nodeFlag = "";
//
//			for (j = 1; j <= Integer.parseInt(currentLevel); j++) {
//				k = i;
//				if (i != retVec.size() - 1) {
//					while (k < retVec.size() - 1) {
//						PSKSOTreeData tmppm = (PSKSOTreeData) retVec
//								.elementAt(k + 1);
//						if (j - Integer.parseInt(tmppm.szIndexing) > 1) {
//							temp = "N";
//							break;
//						} else {
//							if (j - 1 == Integer.parseInt(tmppm.szIndexing)) {
//								temp = "Y";
//								break;
//							} else {
//								temp = "N";
//							}
//						}
//						k++;
//					}
//				} else {
//					temp = "N";
//				}
//				nodeFlag = nodeFlag + temp;
//			}
//
//			if (i != retVec.size() - 1) {
//				PSKSOTreeData pm2 = (PSKSOTreeData) retVec.elementAt(i + 1);
//				if (currentNodeID.equals(pm2.szRParentOid)) {
//					if (currentLevel.equals("2"))
//						imgFlag = "TREE_AM";
//					else
//						imgFlag = "TREE_AP";
//				} else {
//					if (!currentLevel.equals(pm2.szIndexing))
//						imgFlag = "TREE_LastNode";
//					else
//						imgFlag = "TREE_Node";
//				}
//				nextLevel = pm2.szIndexing;
//			} else {
//				imgFlag = "TREE_LastNode";
//				nextLevel = "1";
//			}
//
//			if (pm.szRChildName.equals("")) {
//				if (imgFlag.equals("TREE_AM") || imgFlag.equals("TREE_AP"))
//					imgFlag = "TREE_Node";
//				pm.szRChildName = "-";
//			}
//
//			TreeNodeData tn = new TreeNodeData(prevNodeID, currentNodeID,
//					pm.szRChildName, pm.szRObjectID, currentLevel, nextLevel,
//					nodeFlag, imgFlag, prevImgFlag, pm.szRNumber);
//			returnData.add(tn);
//
//			prevImgFlag = imgFlag;
//			prevNodeID = currentNodeID;
//		}
//
//		return returnData;
//	}
//
//	public static void makeXmlData(Vector retVec, String xmlFilePath) {
//
//		try {
//			int curlevel = 0;
//			int nextlevel = 0;
//			StringBuffer szXmlWrite = new StringBuffer();
//			szXmlWrite.append("<?xml version='1.0' encoding='iso-8859-1'?>\n");
//			szXmlWrite.append("<tree id=\"0\">\n");
//			for (int i = 0; i < retVec.size(); i++) {
//				boolean lastflag = true;
//				boolean endtagflag = false;
//				if (i == 0) {
//					szXmlWrite
//							.append("<item text=\"Books\" id=\"books\" open=\"1\" im0=\"books_close.gif\" im1=\"tombs.gif\" im2=\"tombs.gif\"  call=\"1\" select=\"1\">\n");
//				} else {
//					PSKSOTreeData pm = (PSKSOTreeData) retVec.elementAt(i);
//					curlevel = Integer.parseInt(pm.szIndexing);
//					if (i < retVec.size() - 1) {
//						PSKSOTreeData pm2 = (PSKSOTreeData) retVec
//								.elementAt(i + 1);
//						nextlevel = Integer.parseInt(pm2.szIndexing);
//						if ((curlevel - nextlevel) < 0)
//							lastflag = false;
//						if ((curlevel - nextlevel) > 0)
//							endtagflag = true;
//					}
//					String indent = "";
//					for (int j = 0; j < curlevel; j++)
//						indent = indent + "   ";
//					if (lastflag) {
//						szXmlWrite
//								.append(indent
//										+ "<item text=\""
//										+ pm.szChildName.replaceAll("\"", "")
//										+ "\" id=\""
//										+ pm.szChildOid
//										+ "\" im0=\"book_titel.gif\" im1=\"book_titel.gif\" im2=\"book_titel.gif\"/>\n");
//					} else {
//						szXmlWrite
//								.append(indent
//										+ "<item text=\""
//										+ pm.szChildName.replaceAll("\"", "")
//										+ "\" id=\""
//										+ pm.szChildOid
//										+ "\" open=\"1\" im0=\"book.gif\" im1=\"books_open.gif\" im2=\"book.gif\">\n");
//					}
//
//					if (endtagflag) {
//						int depth = curlevel - nextlevel;
//						for (int k = 0; k < depth; k++) {
//							indent = "";
//							for (int j = 0; j < depth - k + 1; j++)
//								indent = indent + "   ";
//							szXmlWrite.append(indent + "</item>\n");
//						}
//					}
//				}
//			}
//			for (int i = 0; i < curlevel; i++) {
//				String indent = "";
//				for (int j = 0; j < curlevel - i; j++)
//					indent = indent + "   ";
//				szXmlWrite.append(indent + "</item>\n");
//			}
//			szXmlWrite.append("</tree>");
//
//			FileOutputStream XmlWrite = new FileOutputStream(xmlFilePath);
//			XmlWrite.write(szXmlWrite.toString().getBytes());
//			XmlWrite.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

}
