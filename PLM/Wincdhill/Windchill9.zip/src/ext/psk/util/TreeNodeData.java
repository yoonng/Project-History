package ext.psk.util;

public class TreeNodeData {

	public String szPrevNodeID;

	public String szCurNodeID;

	public String szNodeName;

	public String szNodeObjectID;

	public String szCurLevel;

	public String szNextLevel;

	public String szNodeFlag;

	public String szCurImgFlag;

	public String szPrevImgFlag;

	public String szCurNumber;

	public TreeNodeData(String prevNodeID, String curNodeID, String nodeName,
			String nodeObjectID, String curLevel, String nextLevel,
			String nodeFlag, String curImgFlag, String prevImgFlag,
			String curNumber) {
		this.szPrevNodeID = prevNodeID;
		this.szCurNodeID = curNodeID;
		this.szNodeName = nodeName;
		this.szNodeObjectID = nodeObjectID;
		this.szCurLevel = curLevel;
		this.szNextLevel = nextLevel;
		this.szNodeFlag = nodeFlag;
		this.szCurImgFlag = curImgFlag;
		this.szPrevImgFlag = prevImgFlag;
		this.szCurNumber = curNumber;
	}

}
