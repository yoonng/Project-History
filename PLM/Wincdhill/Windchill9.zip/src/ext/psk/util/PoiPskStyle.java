package ext.psk.util;

import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class PoiPskStyle {

	private OutputStream xOutputStream = null;

	private HSSFWorkbook xwbook = null; // workbook

	private HSSFSheet xsheet = null; // sheet

	private HSSFRow xrow = null; // row

	private HSSFCell xcell = null; // cell

	private HSSFCellStyle label = null; // f�� ��Ÿ��

	private HSSFCellStyle header = null; // ��� ��Ÿ��

	private HSSFCellStyle dataCenter = null; // �߾�d��

	private HSSFCellStyle dataLeft = null; // ����d��

	private HSSFCellStyle dataRight = null; // ����d��

	private HSSFFont tileFont = null;

	private HSSFFont headerFont = null;

	private HSSFFont dataFont = null;

	private short rownum;

	public PoiPskStyle(OutputStream output) {

		xOutputStream = output;
		xwbook = new HSSFWorkbook();
		xsheet = xwbook.createSheet();

		label = xwbook.createCellStyle();
		header = xwbook.createCellStyle();
		dataCenter = xwbook.createCellStyle();
		dataLeft = xwbook.createCellStyle();
		dataRight = xwbook.createCellStyle();

		tileFont = xwbook.createFont();
		tileFont.setFontHeightInPoints((short) 14);
		tileFont.setColor(tileFont.COLOR_NORMAL);
		tileFont.setBoldweight(tileFont.BOLDWEIGHT_BOLD);
		tileFont.setFontName("����ü");

		headerFont = xwbook.createFont();
		headerFont.setFontHeightInPoints((short) 10);
		headerFont.setFontName("����ü");

		dataFont = xwbook.createFont();
		dataFont.setFontHeightInPoints((short) 9);
		dataFont.setFontName("����ü");

		label = xwbook.createCellStyle();
		label.setBorderTop(label.BORDER_NONE);
		label.setBorderBottom(label.BORDER_NONE);
		label.setBorderLeft(label.BORDER_NONE);
		label.setBorderRight(label.BORDER_NONE);
		label.setFont(tileFont);
		label.setAlignment(label.ALIGN_CENTER);
		label.setVerticalAlignment(label.VERTICAL_CENTER);

		header = xwbook.createCellStyle();
		header.setBorderTop(header.BORDER_THIN);
		header.setBorderBottom(header.BORDER_THIN);
		header.setBorderLeft(header.BORDER_THIN);
		header.setBorderRight(header.BORDER_THIN);
		header.setFillPattern((short) 1);
		header.setFillForegroundColor(HSSFColor.AQUA.index);
		header.setAlignment(header.ALIGN_CENTER);
		header.setVerticalAlignment(header.VERTICAL_CENTER);
		header.setFont(headerFont);

		dataCenter = xwbook.createCellStyle();
		dataCenter.setBorderTop(dataCenter.BORDER_THIN);
		dataCenter.setBorderBottom(dataCenter.BORDER_THIN);
		dataCenter.setBorderLeft(dataCenter.BORDER_THIN);
		dataCenter.setBorderRight(dataCenter.BORDER_THIN);
		dataCenter.setAlignment(dataCenter.ALIGN_CENTER);
		dataCenter.setVerticalAlignment(dataCenter.VERTICAL_CENTER);
		dataCenter.setFont(dataFont);

		dataLeft = xwbook.createCellStyle();
		dataLeft.setBorderTop(dataLeft.BORDER_THIN);
		dataLeft.setBorderBottom(dataLeft.BORDER_THIN);
		dataLeft.setBorderLeft(dataLeft.BORDER_THIN);
		dataLeft.setBorderRight(dataLeft.BORDER_THIN);
		dataLeft.setAlignment(dataLeft.ALIGN_LEFT);
		dataLeft.setVerticalAlignment(dataLeft.VERTICAL_CENTER);
		dataLeft.setFont(dataFont);

		dataRight = xwbook.createCellStyle();
		dataRight.setBorderTop(dataRight.BORDER_THIN);
		dataRight.setBorderBottom(dataRight.BORDER_THIN);
		dataRight.setBorderLeft(dataRight.BORDER_THIN);
		dataRight.setBorderRight(dataRight.BORDER_THIN);
		dataRight.setAlignment(dataRight.ALIGN_RIGHT);
		dataRight.setVerticalAlignment(dataRight.VERTICAL_CENTER);
		dataRight.setFont(dataFont);

		xwbook.setSheetName(0, "REPORT");

		rownum = 3;

	}

	public void setSheetName(String sName) {
		xwbook.setSheetName(0, sName);
	}

	public void setTile(String sTitle, short headerLength, short tHeight,
			short eHeight) {
		// Title
		org.apache.poi.hssf.util.Region reg = new org.apache.poi.hssf.util.Region(
				0, (short) 0, 0, headerLength);
		xsheet.addMergedRegion(reg);
		xrow = xsheet.createRow((short) 0);
		xrow.setHeight(tHeight);
		xcell = xrow.createCell((short) 0);
		xcell.setCellStyle(label);
		//xcell.setCellValue(new HSSFRichTextString(sTitle));
		
		// empty row
		xrow = xsheet.createRow((short) 1);
		xrow.setHeight(eHeight);
		xcell = xrow.createCell((short) 0);
		reg = new org.apache.poi.hssf.util.Region(1, (short) 0, 1, headerLength);
		xsheet.addMergedRegion(reg);
	}

	public void setHeaderData(String[] sHeader, short[] sWidth, short sHeight) {
		xrow = xsheet.createRow((short) 2);
		xrow.setHeight(sHeight); // row ���� ��d

		for (int i = 0; i < sHeader.length; i++) {
			xcell = xrow.createCell((short) i);
			xcell.setCellStyle(header);
			//xcell.setCellValue(new HSSFRichTextString(sHeader[i]));
			xsheet.setColumnWidth((short) i, sWidth[i]);
		}
	}

	public void setListData(String[] sDate, short[] sWidth, short sHeight,
			HSSFCellStyle[] cStyle) {
		xrow = xsheet.createRow(rownum);
		xrow.setHeight(sHeight); // row ���� ��d

		for (int i = 0; i < sDate.length; i++) {
			xcell = xrow.createCell((short) i);
			xcell.setCellStyle(cStyle[i]);
			//xcell.setCellValue(new HSSFRichTextString(sDate[i]));
			xsheet.setColumnWidth((short) i, sWidth[i]);
		}
		rownum++;
	}

	public void generateXls() {
		try {
			xwbook.write(xOutputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public HSSFCellStyle getDataCenter() {
		return dataCenter;
	}

	public void setDataCenter(HSSFCellStyle dataCenter) {
		this.dataCenter = dataCenter;
	}

	public HSSFFont getDataFont() {
		return dataFont;
	}

	public void setDataFont(HSSFFont dataFont) {
		this.dataFont = dataFont;
	}

	public HSSFCellStyle getDataLeft() {
		return dataLeft;
	}

	public void setDataLeft(HSSFCellStyle dataLeft) {
		this.dataLeft = dataLeft;
	}

	public HSSFCellStyle getDataRight() {
		return dataRight;
	}

	public void setDataRight(HSSFCellStyle dataRight) {
		this.dataRight = dataRight;
	}

	public HSSFCellStyle getHeader() {
		return header;
	}

	public void setHeader(HSSFCellStyle header) {
		this.header = header;
	}

	public HSSFFont getHeaderFont() {
		return headerFont;
	}

	public void setHeaderFont(HSSFFont headerFont) {
		this.headerFont = headerFont;
	}

	public HSSFCellStyle getLabel() {
		return label;
	}

	public void setLabel(HSSFCellStyle label) {
		this.label = label;
	}

	public HSSFFont getTileFont() {
		return tileFont;
	}

	public void setTileFont(HSSFFont tileFont) {
		this.tileFont = tileFont;
	}

}
