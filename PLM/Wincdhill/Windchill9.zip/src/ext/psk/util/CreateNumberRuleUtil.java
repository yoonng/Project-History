package ext.psk.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ext.psk.ecm.eo.EOAlphaForm;
import ext.psk.ecm.eo.EOBetaBForm;

import wt.change2.AffectedActivityData;
import wt.change2.IncludedIn2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.pds.oracle81.OraclePds81;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

public class CreateNumberRuleUtil {

	public static String getPartNumber(String preFixNumber) throws WTException{
		
		/**
		 *	SELECT MAX(SUBSTR(wtpartnumber, 4, 5)) FROM WTPARTMASTER
		 *	WHERE wtpartnumber LIKE 'MPG%'
		 *
		 * java.text.DecimalFormat df = new java.text.DecimalFormat("00000");
         * Long serialL = Long.valueOf(wt.fc.PersistenceHelper.manager.getNextSequence("DOC_SEQ"));
         * String serial = df.format(serialL.longValue());
		 */
		String result = "";
		int tempInt = 0;
		String nextNum = "";
		String maxcol = "";
		String buyPartQuery = "";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		
		try {
			String sql = 
					" SELECT MAX(substr(WTPARTNUMBER, 4, 5)) no "
					+ " FROM WTPARTMASTER "
					+ " WHERE WTPARTNUMBER LIKE '" + preFixNumber + "%' ";
			
			System.out.println("sql:"+sql);
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);

			if (rs != null && rs.next()) {
				if (rs.getString("no") == null)
					result = "00001";
				else {
					String no = rs.getString("no");
					
					int checkInt = -1;
					try {
						checkInt = Integer.parseInt(no);
					} catch (Exception ex){
						ex.printStackTrace();
					}
					
					if( checkInt == -1 ) {
						result = "10000";
					} else if (no.length() == 5) {
						result = Integer.toString((Integer.parseInt(no) + 1));
						
						if( result.length() == 4 ) {
							result = "0" + result;
						} else if( result.length() == 3 ) {
							result = "00" + result;
						} else if( result.length() == 2 ) {
							result = "000" + result;
						} else if( result.length() == 1 ) {
							result = "0000" + result;
						}
						
					} else if (no.length() == 4) {
						result = no + "0";
					} else if (no.length() == 3) {
						result = no + "00";
					} else if (no.length() == 2) {
						result = no + "000";
					} else if (no.length() == 1) {
						result = no + "0000";
					}

					//result = Integer.toString((Integer.parseInt(nextNum) + 1));
				}
			} else {
				result = "00001";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return result;
	}
	

	public static String getEOEulFormNo(String preFixNumber) throws WTException{
		
		/**
		 *	SELECT MAX(SUBSTR(wtpartnumber, 4, 5)) FROM WTPARTMASTER
		 *	WHERE wtpartnumber LIKE 'MPG%'
		 *
		 * java.text.DecimalFormat df = new java.text.DecimalFormat("00000");
         * Long serialL = Long.valueOf(wt.fc.PersistenceHelper.manager.getNextSequence("DOC_SEQ"));
         * String serial = df.format(serialL.longValue());
		 */
		String result = "";
		int tempInt = 0;
		String nextNum = "";
		String maxcol = "";
		String buyPartQuery = "";

		OraclePds81 dds = new OraclePds81();
		Connection con = null;
		ResultSet rs = null;
		
		try {
			String sql = 
					" SELECT MAX(SUBSTR(WTCHGACTIVITYNUMBER, 11, 4)) no "
					+ " FROM WTCHANGEACTIVITY2MASTER "
					+ " WHERE WTCHGACTIVITYNUMBER LIKE '" + preFixNumber + "%' ";
			
			
			
			
			System.out.println("sql:"+sql);
			con = dds.getDataSource().getConnection();
			Statement stmt = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			rs = stmt.executeQuery(sql);

			if (rs != null && rs.next()) {
				if (rs.getString("no") == null)
					result = "0001";
				else {
					String no = rs.getString("no");
					System.out.println("@@@1 no =" + no);
					int checkInt = -1;
					try {
						checkInt = Integer.parseInt(no);
					} catch (Exception ex){
						ex.printStackTrace();
					}
					
					if( checkInt == -1 ) {
						result = "1000";
					} else if (no.length() == 4) {
						result = Integer.toString((Integer.parseInt(no) + 1));
						if( result.length() == 3 ) {
							result = "0" + result;
						} else if( result.length() == 2 ) {
							result = "00" + result;
						} else if( result.length() == 1 ) {
							result = "000" + result;
						}
						
					} else if (no.length() == 3) {
						result = no + "0";
					} else if (no.length() == 2) {
						result = no + "00";
					} else if (no.length() == 1) {
						result = no + "000";
					}
					System.out.println("@@@2 no =" + result);
					//result = Integer.toString((Integer.parseInt(nextNum) + 1));
				}
			} else {
				result = "0001";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("@@@3 result =" + result);
		return result;
	}

	public static String getEOEulFormNo(EOAlphaForm alphaForm, String preFixNumber) throws WTException {
		QuerySpec query = new QuerySpec();
		query.setAdvancedQueryEnabled(true);

		if (query.getConditionCount() > 0)
			query.appendAnd();

		Class betaType = EOBetaBForm.class;
		int betaIndex = query.appendClassList(betaType, true);

		if (query.getConditionCount() > 0)
			query.appendAnd();
		query.appendWhere(new SearchCondition(betaType, EOBetaBForm.NUMBER, SearchCondition.LIKE, preFixNumber + "%"), new int[] { betaIndex });

		ClassAttribute classattribute = new ClassAttribute();
		OrderBy orderby = null;
		classattribute = new ClassAttribute(betaType, EOBetaBForm.NUMBER);
		orderby = new OrderBy(classattribute, true);

		query.appendOrderBy(orderby, new int[] { betaIndex });

		System.out.println("## REQUEST Query:" + query.toString());

		QueryResult queryResult = PersistenceHelper.manager.find(query);

		EOBetaBForm bForm = null;
		Persistable[] objs = null;
		String result = "";

		if (queryResult == null || (queryResult.size() < 1)) {
			System.out.println("result is null!!");
			result = "0001";

		} else if (queryResult.size() > 0) {
			if ( queryResult.hasMoreElements() ){
				objs = (Persistable[]) queryResult.nextElement();
				bForm = (EOBetaBForm) objs[0];
				System.out.println(" ,,,, " + bForm + " = No = " + bForm.getNumber());

				result = bForm.getNumber();

				String no = result.substring(10, 14);

				int checkInt = -1;
				try {
					checkInt = Integer.parseInt(no);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				if (checkInt == -1) {
					result = "1000";
				} else if (no.length() == 4) {
					result = Integer.toString((Integer.parseInt(no) + 1));
					if (result.length() == 3) {
						result = "0" + result;
					} else if (result.length() == 2) {
						result = "00" + result;
					} else if (result.length() == 1) {
						result = "000" + result;
					}

				} else if (no.length() == 3) {
					result = no + "0";
				} else if (no.length() == 2) {
					result = no + "00";
				} else if (no.length() == 1) {
					result = no + "000";
				}
			}
		}

		return result;
	}
}
