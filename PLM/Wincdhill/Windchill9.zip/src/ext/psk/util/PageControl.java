package ext.psk.util;

import java.util.HashMap;
import java.util.Vector;

import wt.fc.PagingQueryResult;

public class PageControl {
	public static final int PERPAGE = 20; //10
	public static final int FORMPAGE = 10;
	private int initPerPage = 20;	//10
	private int initFormPage = 10;

	private PagingQueryResult result;
	private Vector resultMap;

	private int topListCount;
	private int pageScope;

	private long sessionid; // Paging Session ID

	private String sessionidStr;

	private int totalCount;
	private int currentPage;
	private int startPage;
	private int endPage;
	private int totalPage;
	private String href;
	private String param = "";
	private boolean isPostMethod = false;
	
	public PageControl() {
	}

	public PageControl(PagingQueryResult _result, int _pageNo, int _initFormPage, int _initPerPage) {
		this.initFormPage = _initFormPage;
		this.initPerPage = _initPerPage;
		this.result = _result;
		sessionid = _result.getSessionId();

		if (_pageNo <= 0)
			this.currentPage = 1;
		else
			this.currentPage = _pageNo;

		this.pageScope = 0;
		
		if (currentPage == 1)
			pageScope = 0;
		else
			pageScope = (currentPage - 1) / this.initFormPage;
		
		this.startPage = pageScope * this.initFormPage + 1;
		this.totalPage = 0;
		
		if (_result.getTotalSize() % this.initPerPage == 0)
			this.totalPage = _result.getTotalSize() / this.initPerPage;
		else
			this.totalPage = _result.getTotalSize() / this.initPerPage + 1;
		
		this.endPage = this.startPage + this.initFormPage - 1;
		
		if (this.totalPage < this.endPage)
			this.endPage = this.totalPage;

		this.totalCount = _result.getTotalSize();
		this.topListCount = this.totalCount - ((this.currentPage - 1) * this.initPerPage);
	}

	public PageControl(PagingQueryResult _result, int _pageNo, int _initFormPage) {
		this(_result, _pageNo, _initFormPage, PageControl.PERPAGE);
	}

	public PageControl(PagingQueryResult _result, int _pageNo) {
		this(_result, _pageNo, PageControl.FORMPAGE);
	}
	
	/**
	 * thkim append start
	 * PagingQueryResult --> HashMap change
	 * @param _result
	 * @param _pageNo
	 * @param _initFormPage
	 * @param _initPerPage
	 * @param totalCount
	 */
	public PageControl(Vector _result, int _pageNo, int _initFormPage, int _initPerPage, int totalCount) {
		this.initFormPage = _initFormPage;
		this.initPerPage = _initPerPage;
		this.resultMap = _result;

		if (_pageNo <= 0)
			this.currentPage = 1;
		else
			this.currentPage = _pageNo;

		this.pageScope = 0;
		
		if (currentPage == 1)
			pageScope = 0;
		else
			pageScope = (currentPage - 1) / this.initFormPage;
		
		this.startPage = pageScope * this.initFormPage + 1;
		this.totalPage = 0;
		
		if (totalCount % this.initPerPage == 0)
			this.totalPage = totalCount / this.initPerPage;
		else
			this.totalPage = totalCount / this.initPerPage + 1;
		
		this.endPage = this.startPage + this.initFormPage - 1;
		
		if (this.totalPage < this.endPage)
			this.endPage = this.totalPage;

		this.totalCount = totalCount;
		this.topListCount = this.totalCount - ((this.currentPage - 1) * this.initPerPage);
	}
	
	public PageControl(Vector _result, int _pageNo, int _initFormPage, int _totalCount) {
		this(_result, _pageNo, _initFormPage, PageControl.PERPAGE, _totalCount);
	}

	public PageControl(Vector _result, int _pageNo, int _totalCount) {
		this(_result, _pageNo, PageControl.FORMPAGE, _totalCount);
	}
	
	public Vector getResultMap() {
		return this.resultMap;
	}
	//thkim append end

	public void setHref(String _href) {
		this.href = _href;
	}

	public void setParam(String _param) {
		this.param = _param;
	}

	public void setGetMethod() {
		this.isPostMethod = false;
	}

	public void setPostMethod() {
		this.isPostMethod = true;
	}

	public void setSessionidStr(String sessionidstr) {
		this.sessionidStr = sessionidstr;
	}

	/**
	 * @return Returns the isPostMethod.
	 */

	public PagingQueryResult getResult() {
		return result;
	}

	public int getTopListCount() {
		return this.topListCount;
	}

	public int getTotalPage() {
		return this.totalPage;
	}

	public int getTotalCount() {
		return this.totalCount;
	}

	public int getCurrentPage() {
		return this.currentPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public String getHref() {
		return href;
	}

	public long getSessionId() {
		return this.sessionid;
	}

	public String getSessionIdStr() {
		return this.sessionidStr;
	}

	public String getParam() {
		return param;
	}

	public boolean isPostMethod() {
		return isPostMethod;
	}

	public int getInitFormPage() {
		return initFormPage;
	}

	public int getInitPerPage() {
		return initPerPage;
	}
}
